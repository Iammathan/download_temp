package com.adventnet.charm;

/** <p> Description of the table <code>AutomatedMeasureReport2015</code>.
 *  Column Name and Table Name of  database table  <code>AutomatedMeasureReport2015</code> is mapped
 * as constants in this util.</p> 
  Automated Measures calculations stored. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AUTOMATED_MEASURE_REPORT_2015_ID}
  * </ul>
 */
 
public final class AUTOMATEDMEASUREREPORT2015
{
    private AUTOMATEDMEASUREREPORT2015()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AutomatedMeasureReport2015" ;
    /**
              * <p> Unique id for AutomatedMeasureReport2015 table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AUTOMATED_MEASURE_REPORT_2015_ID= "AUTOMATED_MEASURE_REPORT_2015_ID" ;

    /*
    * The index position of the column AUTOMATED_MEASURE_REPORT_2015_ID in the table.
    */
    public static final int AUTOMATED_MEASURE_REPORT_2015_ID_IDX = 1 ;

    /**
              * <p> Request Id from AutomatedMeasureRequest2015.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AUTOMATED_MEASURE_REQUEST_2015_ID= "AUTOMATED_MEASURE_REQUEST_2015_ID" ;

    /*
    * The index position of the column AUTOMATED_MEASURE_REQUEST_2015_ID in the table.
    */
    public static final int AUTOMATED_MEASURE_REQUEST_2015_ID_IDX = 2 ;

    /**
              * <p> Name of the automated measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEASURE_NAME= "MEASURE_NAME" ;

    /*
    * The index position of the column MEASURE_NAME in the table.
    */
    public static final int MEASURE_NAME_IDX = 3 ;

    /**
              * <p> Numerator calculations of automated measure.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                     * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NUMERATOR= "NUMERATOR" ;

    /*
    * The index position of the column NUMERATOR in the table.
    */
    public static final int NUMERATOR_IDX = 4 ;

    /**
              * <p> Demoninator calculations of automated measure.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                     * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DENOMINATOR= "DENOMINATOR" ;

    /*
    * The index position of the column DENOMINATOR in the table.
    */
    public static final int DENOMINATOR_IDX = 5 ;

    /**
              * <p> Percentage calculated for satisfied measured.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PERCENTAGE= "PERCENTAGE" ;

    /*
    * The index position of the column PERCENTAGE in the table.
    */
    public static final int PERCENTAGE_IDX = 6 ;

    /**
              * <p> Status when meaningful use measure is a check.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SATISFIED= "IS_SATISFIED" ;

    /*
    * The index position of the column IS_SATISFIED in the table.
    */
    public static final int IS_SATISFIED_IDX = 7 ;

    /**
              * <p> Status when a measure is excluded for Meaningful Use.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_EXCLUDED= "IS_EXCLUDED" ;

    /*
    * The index position of the column IS_EXCLUDED in the table.
    */
    public static final int IS_EXCLUDED_IDX = 8 ;

    /**
              * <p> Patient list stored in JSON format..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_LIST_NUMERATOR= "PATIENT_LIST_NUMERATOR" ;

    /*
    * The index position of the column PATIENT_LIST_NUMERATOR in the table.
    */
    public static final int PATIENT_LIST_NUMERATOR_IDX = 9 ;

    /**
              * <p> Patient list stored in JSON format..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_LIST_DENOMINATOR= "PATIENT_LIST_DENOMINATOR" ;

    /*
    * The index position of the column PATIENT_LIST_DENOMINATOR in the table.
    */
    public static final int PATIENT_LIST_DENOMINATOR_IDX = 10 ;

}
