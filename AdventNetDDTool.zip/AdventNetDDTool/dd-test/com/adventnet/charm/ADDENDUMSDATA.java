package com.adventnet.charm;

/** <p> Description of the table <code>AddendumsData</code>.
 *  Column Name and Table Name of  database table  <code>AddendumsData</code> is mapped
 * as constants in this util.</p> 
  Addendums data of Consultation. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ADDENDUM_ID}
  * </ul>
 */
 
public final class ADDENDUMSDATA
{
    private ADDENDUMSDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AddendumsData" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDENDUM_ID= "ADDENDUM_ID" ;

    /*
    * The index position of the column ADDENDUM_ID in the table.
    */
    public static final int ADDENDUM_ID_IDX = 1 ;

    /**
              * <p> Identifier of AppointmentHistory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Time of Creation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 3 ;

    /**
              * <p> Member Identification number.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 4 ;

    /**
              * <p> Addendums data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDENDUMS= "ADDENDUMS" ;

    /*
    * The index position of the column ADDENDUMS in the table.
    */
    public static final int ADDENDUMS_IDX = 5 ;

}
