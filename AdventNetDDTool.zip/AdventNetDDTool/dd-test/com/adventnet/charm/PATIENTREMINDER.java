package com.adventnet.charm;

/** <p> Description of the table <code>PatientReminder</code>.
 *  Column Name and Table Name of  database table  <code>PatientReminder</code> is mapped
 * as constants in this util.</p> 
  Entry when a patients list is generated with a specific condition.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_REMINDER_MAP_ID}
  * </ul>
 */
 
public final class PATIENTREMINDER
{
    private PATIENTREMINDER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientReminder" ;
    /**
              * <p> Unique id for PatientReminder table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_REMINDER_MAP_ID= "PATIENT_REMINDER_MAP_ID" ;

    /*
    * The index position of the column PATIENT_REMINDER_MAP_ID in the table.
    */
    public static final int PATIENT_REMINDER_MAP_ID_IDX = 1 ;

    /**
              * <p> Physicisn id on behalf of whom reminder is sent.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Patient id for whom reminder has been sent.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Date on which the remiders were sent.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 4 ;

    /**
              * <p> Status to check whether patient reminder is sent through preferred communication..</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PREFERRED_COMMUNICATION= "IS_PREFERRED_COMMUNICATION" ;

    /*
    * The index position of the column IS_PREFERRED_COMMUNICATION in the table.
    */
    public static final int IS_PREFERRED_COMMUNICATION_IDX = 5 ;

    /**
              * <p> Mode by which reminder was sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMUNICATION_MODE= "COMMUNICATION_MODE" ;

    /*
    * The index position of the column COMMUNICATION_MODE in the table.
    */
    public static final int COMMUNICATION_MODE_IDX = 6 ;

}
