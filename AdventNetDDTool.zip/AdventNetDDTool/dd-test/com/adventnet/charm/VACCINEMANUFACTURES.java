package com.adventnet.charm;

/** <p> Description of the table <code>VaccineManufactures</code>.
 *  Column Name and Table Name of  database table  <code>VaccineManufactures</code> is mapped
 * as constants in this util.</p> 
  Vaccine(Immunization) Manufacturer List. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VACCINE_MANUFACTURER_ID}
  * </ul>
 */
 
public final class VACCINEMANUFACTURES
{
    private VACCINEMANUFACTURES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VaccineManufactures" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VACCINE_MANUFACTURER_ID= "VACCINE_MANUFACTURER_ID" ;

    /*
    * The index position of the column VACCINE_MANUFACTURER_ID in the table.
    */
    public static final int VACCINE_MANUFACTURER_ID_IDX = 1 ;

    /**
              * <p> Name of the manufacturer.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MANUFACTURER_NAME= "MANUFACTURER_NAME" ;

    /*
    * The index position of the column MANUFACTURER_NAME in the table.
    */
    public static final int MANUFACTURER_NAME_IDX = 2 ;

    /**
              * <p> Vaccine manufacturer code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MANUFACTURER_CODE= "MANUFACTURER_CODE" ;

    /*
    * The index position of the column MANUFACTURER_CODE in the table.
    */
    public static final int MANUFACTURER_CODE_IDX = 3 ;

}
