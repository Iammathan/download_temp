package com.adventnet.charm;

/** <p> Description of the table <code>EncounterDxVsImagicDx</code>.
 *  Column Name and Table Name of  database table  <code>EncounterDxVsImagicDx</code> is mapped
 * as constants in this util.</p> 
  This table will maintain account details of Patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENCOUNTER_DX_IMAGICDX_ID}
  * </ul>
 */
 
public final class ENCOUNTERDXVSIMAGICDX
{
    private ENCOUNTERDXVSIMAGICDX()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EncounterDxVsImagicDx" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENCOUNTER_DX_IMAGICDX_ID= "ENCOUNTER_DX_IMAGICDX_ID" ;

    /*
    * The index position of the column ENCOUNTER_DX_IMAGICDX_ID in the table.
    */
    public static final int ENCOUNTER_DX_IMAGICDX_ID_IDX = 1 ;

    /**
              * <p> encounter ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENCOUNTER_ID= "ENCOUNTER_ID" ;

    /*
    * The index position of the column ENCOUNTER_ID in the table.
    */
    public static final int ENCOUNTER_ID_IDX = 2 ;

    /**
              * <p> comma separated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DX= "DX" ;

    /*
    * The index position of the column DX in the table.
    */
    public static final int DX_IDX = 3 ;

    /**
              * <p> comma separated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IMAGIC_DX= "IMAGIC_DX" ;

    /*
    * The index position of the column IMAGIC_DX in the table.
    */
    public static final int IMAGIC_DX_IDX = 4 ;

}
