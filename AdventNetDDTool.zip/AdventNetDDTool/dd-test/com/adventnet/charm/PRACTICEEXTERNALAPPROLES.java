package com.adventnet.charm;

/** <p> Description of the table <code>PracticeExternalAppRoles</code>.
 *  Column Name and Table Name of  database table  <code>PracticeExternalAppRoles</code> is mapped
 * as constants in this util.</p> 
  Information about practice's external apps role mapping. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXTERNAL_APP_ROLE_ID}
  * </ul>
 */
 
public final class PRACTICEEXTERNALAPPROLES
{
    private PRACTICEEXTERNALAPPROLES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeExternalAppRoles" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXTERNAL_APP_ROLE_ID= "EXTERNAL_APP_ROLE_ID" ;

    /*
    * The index position of the column EXTERNAL_APP_ROLE_ID in the table.
    */
    public static final int EXTERNAL_APP_ROLE_ID_IDX = 1 ;

    /**
              * <p> App ID from table PracticeExternalApps.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXTERNAL_APP_ID= "EXTERNAL_APP_ID" ;

    /*
    * The index position of the column EXTERNAL_APP_ID in the table.
    */
    public static final int EXTERNAL_APP_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ROLE_ID= "ROLE_ID" ;

    /*
    * The index position of the column ROLE_ID in the table.
    */
    public static final int ROLE_ID_IDX = 3 ;

}
