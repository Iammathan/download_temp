package com.adventnet.charm;

/** <p> Description of the table <code>RCMMonthlyScheduler</code>.
 *  Column Name and Table Name of  database table  <code>RCMMonthlyScheduler</code> is mapped
 * as constants in this util.</p> 
  Monthly summary is calculated based on the configurations through a daily scheduler. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_MS_ID}
  * </ul>
 */
 
public final class RCMMONTHLYSCHEDULER
{
    private RCMMONTHLYSCHEDULER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMMonthlyScheduler" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_MS_ID= "RCM_MS_ID" ;

    /*
    * The index position of the column RCM_MS_ID in the table.
    */
    public static final int RCM_MS_ID_IDX = 1 ;

    /**
              * <p> start date of the month.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MONTH_START_DATE= "MONTH_START_DATE" ;

    /*
    * The index position of the column MONTH_START_DATE in the table.
    */
    public static final int MONTH_START_DATE_IDX = 2 ;

    /**
              * <p> Calculate summary or not for the associated month .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CALCULATE_SUMMARY= "CALCULATE_SUMMARY" ;

    /*
    * The index position of the column CALCULATE_SUMMARY in the table.
    */
    public static final int CALCULATE_SUMMARY_IDX = 3 ;

    /**
              * <p> Decides Receivables need to be calculated for the associated month .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String UPDATE_RECEIVABLES= "UPDATE_RECEIVABLES" ;

    /*
    * The index position of the column UPDATE_RECEIVABLES in the table.
    */
    public static final int UPDATE_RECEIVABLES_IDX = 4 ;

    /**
              * <p> PracticeId of MBP for the Monthly scheduler.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 5 ;

}
