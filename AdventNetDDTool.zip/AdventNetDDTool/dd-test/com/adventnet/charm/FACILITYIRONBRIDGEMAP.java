package com.adventnet.charm;

/** <p> Description of the table <code>FacilityIronBridgeMap</code>.
 *  Column Name and Table Name of  database table  <code>FacilityIronBridgeMap</code> is mapped
 * as constants in this util.</p> 
  Facility Id mapped to location and registry. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FACILITY_IRON_BRIDGE_MAP_ID}
  * </ul>
 */
 
public final class FACILITYIRONBRIDGEMAP
{
    private FACILITYIRONBRIDGEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FacilityIronBridgeMap" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_IRON_BRIDGE_MAP_ID= "FACILITY_IRON_BRIDGE_MAP_ID" ;

    /*
    * The index position of the column FACILITY_IRON_BRIDGE_MAP_ID in the table.
    */
    public static final int FACILITY_IRON_BRIDGE_MAP_ID_IDX = 1 ;

    /**
              * <p> FACILITY ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 2 ;

    /**
              * <p> id of location.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LOCATION_ID= "LOCATION_ID" ;

    /*
    * The index position of the column LOCATION_ID in the table.
    */
    public static final int LOCATION_ID_IDX = 3 ;

    /**
              * <p> id of the registry.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REGISTRY_ID= "REGISTRY_ID" ;

    /*
    * The index position of the column REGISTRY_ID in the table.
    */
    public static final int REGISTRY_ID_IDX = 4 ;

    /**
              * <p> name of registry.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REGISTRY_NAME= "REGISTRY_NAME" ;

    /*
    * The index position of the column REGISTRY_NAME in the table.
    */
    public static final int REGISTRY_NAME_IDX = 5 ;

    /**
              * <p> id of location linked to registry.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BRIDGEWAY_ID= "BRIDGEWAY_ID" ;

    /*
    * The index position of the column BRIDGEWAY_ID in the table.
    */
    public static final int BRIDGEWAY_ID_IDX = 6 ;

    /**
              * <p> id of environment. 1 = production 2 = testing.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENVIRONMENT_ID= "ENVIRONMENT_ID" ;

    /*
    * The index position of the column ENVIRONMENT_ID in the table.
    */
    public static final int ENVIRONMENT_ID_IDX = 7 ;

    /**
              * <p> Time of at which the facility was moved to production.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRODUCTION_MOVE_TIME= "PRODUCTION_MOVE_TIME" ;

    /*
    * The index position of the column PRODUCTION_MOVE_TIME in the table.
    */
    public static final int PRODUCTION_MOVE_TIME_IDX = 8 ;

    /**
              * <p> State to which submission is to be done.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_STATE= "PATIENT_STATE" ;

    /*
    * The index position of the column PATIENT_STATE in the table.
    */
    public static final int PATIENT_STATE_IDX = 9 ;

}
