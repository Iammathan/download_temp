package com.adventnet.charm;

/** <p> Description of the table <code>ChARMConnectInfo</code>.
 *  Column Name and Table Name of  database table  <code>ChARMConnectInfo</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CONNECT_INFO_ID}
  * </ul>
 */
 
public final class CHARMCONNECTINFO
{
    private CHARMCONNECTINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ChARMConnectInfo" ;
    /**
              * <p> Unique Id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONNECT_INFO_ID= "CONNECT_INFO_ID" ;

    /*
    * The index position of the column CONNECT_INFO_ID in the table.
    */
    public static final int CONNECT_INFO_ID_IDX = 1 ;

    /**
              * <p> Practice's connect portal ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NETWORK_ID= "NETWORK_ID" ;

    /*
    * The index position of the column NETWORK_ID in the table.
    */
    public static final int NETWORK_ID_IDX = 2 ;

    /**
              * <p> Trial period start date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRIAL_STARTS= "TRIAL_STARTS" ;

    /*
    * The index position of the column TRIAL_STARTS in the table.
    */
    public static final int TRIAL_STARTS_IDX = 3 ;

    /**
              * <p> Trial period end date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRIAL_ENDS= "TRIAL_ENDS" ;

    /*
    * The index position of the column TRIAL_ENDS in the table.
    */
    public static final int TRIAL_ENDS_IDX = 4 ;

    /**
              * <p> status about last trasaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ACCOUNT_TYPE= "ACCOUNT_TYPE" ;

    /*
    * The index position of the column ACCOUNT_TYPE in the table.
    */
    public static final int ACCOUNT_TYPE_IDX = 5 ;

    /**
              * <p> status about last trasaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ACCOUNT_STATUS= "ACCOUNT_STATUS" ;

    /*
    * The index position of the column ACCOUNT_STATUS in the table.
    */
    public static final int ACCOUNT_STATUS_IDX = 6 ;

}
