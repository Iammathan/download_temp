package com.adventnet.charm;

/** <p> Description of the table <code>BillingReportPDF</code>.
 *  Column Name and Table Name of  database table  <code>BillingReportPDF</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REPORT_ID}
  * </ul>
 */
 
public final class BILLINGREPORTPDF
{
    private BILLINGREPORTPDF()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillingReportPDF" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_ID= "REPORT_ID" ;

    /*
    * The index position of the column REPORT_ID in the table.
    */
    public static final int REPORT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REPORT_NAME= "REPORT_NAME" ;

    /*
    * The index position of the column REPORT_NAME in the table.
    */
    public static final int REPORT_NAME_IDX = 2 ;

    /**
              * <p> Value is true if the PDF should be in portrait.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_PORTRAIT= "IS_PORTRAIT" ;

    /*
    * The index position of the column IS_PORTRAIT in the table.
    */
    public static final int IS_PORTRAIT_IDX = 3 ;

    /**
              * <p> This value will be true if subtotals for the grouped reports should be shown.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String SHOW_SUB_TOTALS= "SHOW_SUB_TOTALS" ;

    /*
    * The index position of the column SHOW_SUB_TOTALS in the table.
    */
    public static final int SHOW_SUB_TOTALS_IDX = 4 ;

}
