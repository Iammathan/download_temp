package com.adventnet.charm;

/** <p> Description of the table <code>RoutingMsgSupervisorMap</code>.
 *  Column Name and Table Name of  database table  <code>RoutingMsgSupervisorMap</code> is mapped
 * as constants in this util.</p> 
  Mapping beween Prescriber and Supervisor. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ROUTINGMSG_SUPERVISOR_ID}
  * </ul>
 */
 
public final class ROUTINGMSGSUPERVISORMAP
{
    private ROUTINGMSGSUPERVISORMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RoutingMsgSupervisorMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ROUTINGMSG_SUPERVISOR_ID= "ROUTINGMSG_SUPERVISOR_ID" ;

    /*
    * The index position of the column ROUTINGMSG_SUPERVISOR_ID in the table.
    */
    public static final int ROUTINGMSG_SUPERVISOR_ID_IDX = 1 ;

    /**
              * <p> Id of the Routing Message.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 2 ;

    /**
              * <p> First Name of the Supervisor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUPERVISOR_FIRST_NAME= "SUPERVISOR_FIRST_NAME" ;

    /*
    * The index position of the column SUPERVISOR_FIRST_NAME in the table.
    */
    public static final int SUPERVISOR_FIRST_NAME_IDX = 3 ;

    /**
              * <p> Last name of the Supervisor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUPERVISOR_LAST_NAME= "SUPERVISOR_LAST_NAME" ;

    /*
    * The index position of the column SUPERVISOR_LAST_NAME in the table.
    */
    public static final int SUPERVISOR_LAST_NAME_IDX = 4 ;

    /**
              * <p> NPI of the Supervisor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUPERVISOR_NPI= "SUPERVISOR_NPI" ;

    /*
    * The index position of the column SUPERVISOR_NPI in the table.
    */
    public static final int SUPERVISOR_NPI_IDX = 5 ;

}
