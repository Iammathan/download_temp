package com.adventnet.charm;

/** <p> Description of the table <code>CommandLangModules</code>.
 *  Column Name and Table Name of  database table  <code>CommandLangModules</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CMMND_LANG_MODULE_ID}
  * </ul>
 */
 
public final class COMMANDLANGMODULES
{
    private COMMANDLANGMODULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CommandLangModules" ;
    /**
              * <p> Pk of CommandLangModules.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CMMND_LANG_MODULE_ID= "CMMND_LANG_MODULE_ID" ;

    /*
    * The index position of the column CMMND_LANG_MODULE_ID in the table.
    */
    public static final int CMMND_LANG_MODULE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODULE_NAME= "MODULE_NAME" ;

    /*
    * The index position of the column MODULE_NAME in the table.
    */
    public static final int MODULE_NAME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PARENT_URL_TYPE= "PARENT_URL_TYPE" ;

    /*
    * The index position of the column PARENT_URL_TYPE in the table.
    */
    public static final int PARENT_URL_TYPE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String JS_METHOD_NAME= "JS_METHOD_NAME" ;

    /*
    * The index position of the column JS_METHOD_NAME in the table.
    */
    public static final int JS_METHOD_NAME_IDX = 4 ;

}
