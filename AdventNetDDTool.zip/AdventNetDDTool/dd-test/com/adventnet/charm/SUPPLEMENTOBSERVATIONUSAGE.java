package com.adventnet.charm;

/** <p> Description of the table <code>SupplementObservationUsage</code>.
 *  Column Name and Table Name of  database table  <code>SupplementObservationUsage</code> is mapped
 * as constants in this util.</p> 
  Table capturing usage of Supplement and Observation together. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #SUPPLEMENT_ID}
  * <li> {@link #OBSERVATION_ID}
  * <li> {@link #REPORT_DATE}
  * </ul>
 */
 
public final class SUPPLEMENTOBSERVATIONUSAGE
{
    private SUPPLEMENTOBSERVATIONUSAGE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SupplementObservationUsage" ;
    /**
              * <p> Identifier of Supplement.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SUPPLEMENT_ID= "SUPPLEMENT_ID" ;

    /*
    * The index position of the column SUPPLEMENT_ID in the table.
    */
    public static final int SUPPLEMENT_ID_IDX = 1 ;

    /**
              * <p> Identifier of Observation.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OBSERVATION_ID= "OBSERVATION_ID" ;

    /*
    * The index position of the column OBSERVATION_ID in the table.
    */
    public static final int OBSERVATION_ID_IDX = 2 ;

    /**
              * <p> Date on which the aggregate report was genrated.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_DATE= "REPORT_DATE" ;

    /*
    * The index position of the column REPORT_DATE in the table.
    */
    public static final int REPORT_DATE_IDX = 3 ;

    /**
              * <p> Number of patients using this Supplement and observation.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PATIENT_COUNT= "PATIENT_COUNT" ;

    /*
    * The index position of the column PATIENT_COUNT in the table.
    */
    public static final int PATIENT_COUNT_IDX = 4 ;

    /**
              * <p> Number of patients seen improvement in this observation after using this supplement.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PROGRESS_COUNT= "PROGRESS_COUNT" ;

    /*
    * The index position of the column PROGRESS_COUNT in the table.
    */
    public static final int PROGRESS_COUNT_IDX = 5 ;

    /**
              * <p> Number of patients seen regression in this observation after using this supplement.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String REGRESSION_COUNT= "REGRESSION_COUNT" ;

    /*
    * The index position of the column REGRESSION_COUNT in the table.
    */
    public static final int REGRESSION_COUNT_IDX = 6 ;

}
