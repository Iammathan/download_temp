package com.adventnet.charm;

/** <p> Description of the table <code>VaccineReminderSMSSchedule</code>.
 *  Column Name and Table Name of  database table  <code>VaccineReminderSMSSchedule</code> is mapped
 * as constants in this util.</p> 
  Vaccine Remainder Days Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SETTINGS_ID}
  * </ul>
 */
 
public final class VACCINEREMINDERSMSSCHEDULE
{
    private VACCINEREMINDERSMSSCHEDULE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VaccineReminderSMSSchedule" ;
    /**
              * <p> Settings ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SETTINGS_ID= "SETTINGS_ID" ;

    /*
    * The index position of the column SETTINGS_ID in the table.
    */
    public static final int SETTINGS_ID_IDX = 1 ;

    /**
              * <p> Vaccine remainder notification day before.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DAYS_BEFORE= "DAYS_BEFORE" ;

    /*
    * The index position of the column DAYS_BEFORE in the table.
    */
    public static final int DAYS_BEFORE_IDX = 2 ;

}
