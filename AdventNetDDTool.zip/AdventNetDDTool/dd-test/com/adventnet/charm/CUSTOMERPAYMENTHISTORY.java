package com.adventnet.charm;

/** <p> Description of the table <code>CustomerPaymentHistory</code>.
 *  Column Name and Table Name of  database table  <code>CustomerPaymentHistory</code> is mapped
 * as constants in this util.</p> 
   Customer Payment History . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CPH_ID}
  * </ul>
 */
 
public final class CUSTOMERPAYMENTHISTORY
{
    private CUSTOMERPAYMENTHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CustomerPaymentHistory" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CPH_ID= "CPH_ID" ;

    /*
    * The index position of the column CPH_ID in the table.
    */
    public static final int CPH_ID_IDX = 1 ;

    /**
              * <p>  PLAN_CUSTOMER_ID available in the ServiceCustomerPlan .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PLAN_CUSTOMER_ID= "PLAN_CUSTOMER_ID" ;

    /*
    * The index position of the column PLAN_CUSTOMER_ID in the table.
    */
    public static final int PLAN_CUSTOMER_ID_IDX = 2 ;

    /**
              * <p> Payment Type : Recurring / One-Time / etc.. .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYMENT_TYPE= "PAYMENT_TYPE" ;

    /*
    * The index position of the column PAYMENT_TYPE in the table.
    */
    public static final int PAYMENT_TYPE_IDX = 3 ;

    /**
              * <p> Payment Mode : Cheque / Card / etc.. .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYMENT_MODE= "PAYMENT_MODE" ;

    /*
    * The index position of the column PAYMENT_MODE in the table.
    */
    public static final int PAYMENT_MODE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_PAID_DATE= "LAST_PAID_DATE" ;

    /*
    * The index position of the column LAST_PAID_DATE in the table.
    */
    public static final int LAST_PAID_DATE_IDX = 5 ;

    /**
              * <p> Comment section : Ex: Cheque Number : xyz ; Bank Name : Acme .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 6 ;

    /**
              * <p>  LAST PAID AMOUNT .</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String LAST_PAID_AMOUNT= "LAST_PAID_AMOUNT" ;

    /*
    * The index position of the column LAST_PAID_AMOUNT in the table.
    */
    public static final int LAST_PAID_AMOUNT_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STRIPE_INVOICE_ID= "STRIPE_INVOICE_ID" ;

    /*
    * The index position of the column STRIPE_INVOICE_ID in the table.
    */
    public static final int STRIPE_INVOICE_ID_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STRIPE_INVOICE_ITEM_ID= "STRIPE_INVOICE_ITEM_ID" ;

    /*
    * The index position of the column STRIPE_INVOICE_ITEM_ID in the table.
    */
    public static final int STRIPE_INVOICE_ITEM_ID_IDX = 9 ;

}
