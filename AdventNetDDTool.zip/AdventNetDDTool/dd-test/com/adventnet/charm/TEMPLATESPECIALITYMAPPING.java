package com.adventnet.charm;

/** <p> Description of the table <code>TemplateSpecialityMapping</code>.
 *  Column Name and Table Name of  database table  <code>TemplateSpecialityMapping</code> is mapped
 * as constants in this util.</p> 
  Contain the  Mapping of Templates and Speciality . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAPPING_ID}
  * </ul>
 */
 
public final class TEMPLATESPECIALITYMAPPING
{
    private TEMPLATESPECIALITYMAPPING()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TemplateSpecialityMapping" ;
    /**
              * <p> Unique identifier of Mapping ENTRY.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAPPING_ID= "MAPPING_ID" ;

    /*
    * The index position of the column MAPPING_ID in the table.
    */
    public static final int MAPPING_ID_IDX = 1 ;

    /**
              * <p> Unique identifier for templates.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Unique identifier for Speciality.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SPECIALITY_ID= "SPECIALITY_ID" ;

    /*
    * The index position of the column SPECIALITY_ID in the table.
    */
    public static final int SPECIALITY_ID_IDX = 3 ;

}
