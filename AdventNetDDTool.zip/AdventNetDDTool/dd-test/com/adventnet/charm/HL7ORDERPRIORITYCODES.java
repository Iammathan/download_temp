package com.adventnet.charm;

/** <p> Description of the table <code>HL7OrderPriorityCodes</code>.
 *  Column Name and Table Name of  database table  <code>HL7OrderPriorityCodes</code> is mapped
 * as constants in this util.</p> 
  List of priority codes with description. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HL7_ORDER_PRIORITY_ID}
  * </ul>
 */
 
public final class HL7ORDERPRIORITYCODES
{
    private HL7ORDERPRIORITYCODES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HL7OrderPriorityCodes" ;
    /**
              * <p> Unique identifier in this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HL7_ORDER_PRIORITY_ID= "HL7_ORDER_PRIORITY_ID" ;

    /*
    * The index position of the column HL7_ORDER_PRIORITY_ID in the table.
    */
    public static final int HL7_ORDER_PRIORITY_ID_IDX = 1 ;

    /**
              * <p> code priority to be sent to lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRIORITY_CODE= "PRIORITY_CODE" ;

    /*
    * The index position of the column PRIORITY_CODE in the table.
    */
    public static final int PRIORITY_CODE_IDX = 2 ;

    /**
              * <p> description of priority code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRIORITY_DESCRIPTION= "PRIORITY_DESCRIPTION" ;

    /*
    * The index position of the column PRIORITY_DESCRIPTION in the table.
    */
    public static final int PRIORITY_DESCRIPTION_IDX = 3 ;

    /**
              * <p> boolean to indicate whether to display to the users.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DISPLAY_TO_USER= "DISPLAY_TO_USER" ;

    /*
    * The index position of the column DISPLAY_TO_USER in the table.
    */
    public static final int DISPLAY_TO_USER_IDX = 4 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 5 ;

}
