package com.adventnet.charm;

/** <p> Description of the table <code>ExternalMemberMap</code>.
 *  Column Name and Table Name of  database table  <code>ExternalMemberMap</code> is mapped
 * as constants in this util.</p> 
  Member Id map of the external services across modules(practiceSpace). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXTERNAL_MEMBER_MAP_ID}
  * </ul>
 */
 
public final class EXTERNALMEMBERMAP
{
    private EXTERNALMEMBERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ExternalMemberMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXTERNAL_MEMBER_MAP_ID= "EXTERNAL_MEMBER_MAP_ID" ;

    /*
    * The index position of the column EXTERNAL_MEMBER_MAP_ID in the table.
    */
    public static final int EXTERNAL_MEMBER_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 2 ;

    /**
              * <p> Type of module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>DISPENSE</code></li>
              * </ul>
                         */
    public static final String MODULE= "MODULE" ;

    /*
    * The index position of the column MODULE in the table.
    */
    public static final int MODULE_IDX = 3 ;

    /**
              * <p> External partner id (profileSpace) - PK.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PARTNER_ID= "PARTNER_ID" ;

    /*
    * The index position of the column PARTNER_ID in the table.
    */
    public static final int PARTNER_ID_IDX = 4 ;

    /**
              * <p> PracticeMembersList.MEMBER_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 5 ;

    /**
              * <p> Faciliy id (practiceSpace).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXTERNAL_REFERENCE_ID= "EXTERNAL_REFERENCE_ID" ;

    /*
    * The index position of the column EXTERNAL_REFERENCE_ID in the table.
    */
    public static final int EXTERNAL_REFERENCE_ID_IDX = 7 ;

    /**
              * <p> Email Id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMAILID= "EMAILID" ;

    /*
    * The index position of the column EMAILID in the table.
    */
    public static final int EMAILID_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 9 ;

}
