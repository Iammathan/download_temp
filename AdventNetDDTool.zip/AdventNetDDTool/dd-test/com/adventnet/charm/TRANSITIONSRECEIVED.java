package com.adventnet.charm;

/** <p> Description of the table <code>TransitionsReceived</code>.
 *  Column Name and Table Name of  database table  <code>TransitionsReceived</code> is mapped
 * as constants in this util.</p> 
  Transitions or referrals received and reconciliation performed for encounter.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TRANSITIONS_RECEIVED_ID}
  * </ul>
 */
 
public final class TRANSITIONSRECEIVED
{
    private TRANSITIONSRECEIVED()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TransitionsReceived" ;
    /**
              * <p> Unique id for TransitionsReceived table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSITIONS_RECEIVED_ID= "TRANSITIONS_RECEIVED_ID" ;

    /*
    * The index position of the column TRANSITIONS_RECEIVED_ID in the table.
    */
    public static final int TRANSITIONS_RECEIVED_ID_IDX = 1 ;

    /**
              * <p> Mapping id used from ConsultationHistory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Whether encounter is based on a Referral or Transition of Care incoming request.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String REFERRAL_IN= "REFERRAL_IN" ;

    /*
    * The index position of the column REFERRAL_IN in the table.
    */
    public static final int REFERRAL_IN_IDX = 3 ;

    /**
              * <p> Whether this is the first encounter with this patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FIRST_TIME_ENCOUNTER= "FIRST_TIME_ENCOUNTER" ;

    /*
    * The index position of the column FIRST_TIME_ENCOUNTER in the table.
    */
    public static final int FIRST_TIME_ENCOUNTER_IDX = 4 ;

    /**
              * <p> File link of CCDA file from UploadedFiles.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CCDA_FILE= "CCDA_FILE" ;

    /*
    * The index position of the column CCDA_FILE in the table.
    */
    public static final int CCDA_FILE_IDX = 5 ;

    /**
              * <p> Exclusion for the physician.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String EXCLUDED= "EXCLUDED" ;

    /*
    * The index position of the column EXCLUDED in the table.
    */
    public static final int EXCLUDED_IDX = 6 ;

    /**
              * <p> Check for medication reconciliation performed.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String MEDICATION_RECONCILED= "MEDICATION_RECONCILED" ;

    /*
    * The index position of the column MEDICATION_RECONCILED in the table.
    */
    public static final int MEDICATION_RECONCILED_IDX = 7 ;

    /**
              * <p> Check for allergy reconciliation performed.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String ALLERGY_RECONCILED= "ALLERGY_RECONCILED" ;

    /*
    * The index position of the column ALLERGY_RECONCILED in the table.
    */
    public static final int ALLERGY_RECONCILED_IDX = 8 ;

    /**
              * <p> Check for problems/diagnosis reconciliation performed.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PROBLEMS_RECONCILED= "PROBLEMS_RECONCILED" ;

    /*
    * The index position of the column PROBLEMS_RECONCILED in the table.
    */
    public static final int PROBLEMS_RECONCILED_IDX = 9 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 10 ;

    /**
              * <p> Comma seperated vales of CCDA file ids associated to the encounter from UploadedFiles table.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CCDA_FILE_IDS= "CCDA_FILE_IDS" ;

    /*
    * The index position of the column CCDA_FILE_IDS in the table.
    */
    public static final int CCDA_FILE_IDS_IDX = 11 ;

}
