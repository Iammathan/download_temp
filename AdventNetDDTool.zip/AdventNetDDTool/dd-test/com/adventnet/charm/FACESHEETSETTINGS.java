package com.adventnet.charm;

/** <p> Description of the table <code>FaceSheetSettings</code>.
 *  Column Name and Table Name of  database table  <code>FaceSheetSettings</code> is mapped
 * as constants in this util.</p> 
  To store face sheet settings Sections . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SECTION_ID}
  * </ul>
 */
 
public final class FACESHEETSETTINGS
{
    private FACESHEETSETTINGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FaceSheetSettings" ;
    /**
              * <p> Unique identifier for face sheet settings.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SECTION_ID= "SECTION_ID" ;

    /*
    * The index position of the column SECTION_ID in the table.
    */
    public static final int SECTION_ID_IDX = 1 ;

    /**
              * <p> Practice member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Name of the section of facesheet.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SECTION= "SECTION" ;

    /*
    * The index position of the column SECTION in the table.
    */
    public static final int SECTION_IDX = 3 ;

    /**
              * <p> Practice member set the position of section name.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 4 ;

}
