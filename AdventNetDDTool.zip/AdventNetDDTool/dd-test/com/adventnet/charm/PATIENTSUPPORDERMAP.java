package com.adventnet.charm;

/** <p> Description of the table <code>PatientSuppOrderMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientSuppOrderMap</code> is mapped
 * as constants in this util.</p> 
  Patient Supplement vs External dispensing services Orders (practiceSpace). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAT_SUPP_ORDER_MAP_ID}
  * </ul>
 */
 
public final class PATIENTSUPPORDERMAP
{
    private PATIENTSUPPORDERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientSuppOrderMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAT_SUPP_ORDER_MAP_ID= "PAT_SUPP_ORDER_MAP_ID" ;

    /*
    * The index position of the column PAT_SUPP_ORDER_MAP_ID in the table.
    */
    public static final int PAT_SUPP_ORDER_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_SUPPLEMENT_ID= "PATIENT_SUPPLEMENT_ID" ;

    /*
    * The index position of the column PATIENT_SUPPLEMENT_ID in the table.
    */
    public static final int PATIENT_SUPPLEMENT_ID_IDX = 2 ;

    /**
              * <p> Txn Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DISPENSING_ORDER_ID= "DISPENSING_ORDER_ID" ;

    /*
    * The index position of the column DISPENSING_ORDER_ID in the table.
    */
    public static final int DISPENSING_ORDER_ID_IDX = 3 ;

}
