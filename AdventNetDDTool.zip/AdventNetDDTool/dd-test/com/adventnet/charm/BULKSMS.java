package com.adventnet.charm;

/** <p> Description of the table <code>BulkSMS</code>.
 *  Column Name and Table Name of  database table  <code>BulkSMS</code> is mapped
 * as constants in this util.</p> 
  Bulk SMS Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BULK_SMS_ID}
  * </ul>
 */
 
public final class BULKSMS
{
    private BULKSMS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BulkSMS" ;
    /**
              * <p> Bulk SMS ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BULK_SMS_ID= "BULK_SMS_ID" ;

    /*
    * The index position of the column BULK_SMS_ID in the table.
    */
    public static final int BULK_SMS_ID_IDX = 1 ;

    /**
              * <p> Title of Bulk SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TITLE= "TITLE" ;

    /*
    * The index position of the column TITLE in the table.
    */
    public static final int TITLE_IDX = 2 ;

    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 4 ;

    /**
              * <p> Identifier of the patient category.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_CATEGORY_ID= "PATIENT_CATEGORY_ID" ;

    /*
    * The index position of the column PATIENT_CATEGORY_ID in the table.
    */
    public static final int PATIENT_CATEGORY_ID_IDX = 5 ;

    /**
              * <p> Identifier of the file(patient record id and mobile number as a CSV).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_PATH= "FILE_PATH" ;

    /*
    * The index position of the column FILE_PATH in the table.
    */
    public static final int FILE_PATH_IDX = 6 ;

    /**
              * <p> Bulk SMS configured time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INITIATED_ON= "INITIATED_ON" ;

    /*
    * The index position of the column INITIATED_ON in the table.
    */
    public static final int INITIATED_ON_IDX = 7 ;

    /**
              * <p> Bulk SMS scheduled time.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SCHEDULED_ON= "SCHEDULED_ON" ;

    /*
    * The index position of the column SCHEDULED_ON in the table.
    */
    public static final int SCHEDULED_ON_IDX = 8 ;

    /**
              * <p> Bulk SMS sent time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SENT_TIME= "SENT_TIME" ;

    /*
    * The index position of the column SENT_TIME in the table.
    */
    public static final int SENT_TIME_IDX = 9 ;

    /**
              * <p> sending preference of bulk sms (Send Now / Send Later) .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SEND_PREFERENCE= "SEND_PREFERENCE" ;

    /*
    * The index position of the column SEND_PREFERENCE in the table.
    */
    public static final int SEND_PREFERENCE_IDX = 10 ;

    /**
              * <p> Bulk SMS message Ccontent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1600</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MESSAGE= "MESSAGE" ;

    /*
    * The index position of the column MESSAGE in the table.
    */
    public static final int MESSAGE_IDX = 11 ;

    /**
              * <p> patients criteria as a json string.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_CRITERIA= "PATIENT_CRITERIA" ;

    /*
    * The index position of the column PATIENT_CRITERIA in the table.
    */
    public static final int PATIENT_CRITERIA_IDX = 12 ;

    /**
              * <p> number of patients this message content is sent.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_COUNT= "PATIENT_COUNT" ;

    /*
    * The index position of the column PATIENT_COUNT in the table.
    */
    public static final int PATIENT_COUNT_IDX = 13 ;

    /**
              * <p> number of total messages sent for this bulk sms.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOTAL_SMS_COUNT= "TOTAL_SMS_COUNT" ;

    /*
    * The index position of the column TOTAL_SMS_COUNT in the table.
    */
    public static final int TOTAL_SMS_COUNT_IDX = 14 ;

    /**
              * <p> current status of Bulk SMS (0 - Scheduled, 1 - In-progress, 2 - Completed, 3 - Deleted).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 15 ;

    /**
              * <p> Description of SMS (response from sms provider) .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 16 ;

}
