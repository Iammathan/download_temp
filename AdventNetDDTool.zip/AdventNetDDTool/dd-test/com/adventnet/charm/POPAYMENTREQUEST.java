package com.adventnet.charm;

/** <p> Description of the table <code>POPaymentRequest</code>.
 *  Column Name and Table Name of  database table  <code>POPaymentRequest</code> is mapped
 * as constants in this util.</p> 
   Invoice Payment  . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PO_PAYMENT_REQUEST_ID}
  * </ul>
 */
 
public final class POPAYMENTREQUEST
{
    private POPAYMENTREQUEST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "POPaymentRequest" ;
    /**
              * <p> Payment identity.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PO_PAYMENT_REQUEST_ID= "PO_PAYMENT_REQUEST_ID" ;

    /*
    * The index position of the column PO_PAYMENT_REQUEST_ID in the table.
    */
    public static final int PO_PAYMENT_REQUEST_ID_IDX = 1 ;

    /**
              * <p> Digest to identify old links.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>BLUEFIN</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DIGEST= "DIGEST" ;

    /*
    * The index position of the column DIGEST in the table.
    */
    public static final int DIGEST_IDX = 2 ;

    /**
              * <p> BLUEFIN/RAZORPAY.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GATEWAY= "GATEWAY" ;

    /*
    * The index position of the column GATEWAY in the table.
    */
    public static final int GATEWAY_IDX = 3 ;

    /**
              * <p>  Practice identification .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 4 ;

    /**
              * <p> Identifier of Invoice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVOICE_ID= "INVOICE_ID" ;

    /*
    * The index position of the column INVOICE_ID in the table.
    */
    public static final int INVOICE_ID_IDX = 5 ;

    /**
              * <p> Identifier of AppointmentHistory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 6 ;

    /**
              * <p> Identifier of Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 7 ;

    /**
              * <p> Identifier of member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 8 ;

    /**
              * <p> Merchant Account Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MERCHANT_ACCOUNT_ID= "MERCHANT_ACCOUNT_ID" ;

    /*
    * The index position of the column MERCHANT_ACCOUNT_ID in the table.
    */
    public static final int MERCHANT_ACCOUNT_ID_IDX = 9 ;

    /**
              * <p>  Amount to Pay .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String AMOUNT= "AMOUNT" ;

    /*
    * The index position of the column AMOUNT in the table.
    */
    public static final int AMOUNT_IDX = 10 ;

    /**
              * <p>  To maintain amount paid in case of partial payment .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String AMOUNT_PAID= "AMOUNT_PAID" ;

    /*
    * The index position of the column AMOUNT_PAID in the table.
    */
    public static final int AMOUNT_PAID_IDX = 11 ;

    /**
              * <p>  Paid status .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 12 ;

    /**
              * <p> Email Id of patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 13 ;

    /**
              * <p> Email Id of sender.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FROM_EMAIL_ID= "FROM_EMAIL_ID" ;

    /*
    * The index position of the column FROM_EMAIL_ID in the table.
    */
    public static final int FROM_EMAIL_ID_IDX = 14 ;

    /**
              * <p> Identifier of Statement.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STATEMENT_ID= "STATEMENT_ID" ;

    /*
    * The index position of the column STATEMENT_ID in the table.
    */
    public static final int STATEMENT_ID_IDX = 15 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 16 ;

    /**
              * <p> Type of Statement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATEMENT_TYPE= "STATEMENT_TYPE" ;

    /*
    * The index position of the column STATEMENT_TYPE in the table.
    */
    public static final int STATEMENT_TYPE_IDX = 17 ;

    /**
              * <p> PDF File Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 18 ;

    /**
              * <p> PDF file path stored in a dfs.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_PATH= "FILE_PATH" ;

    /*
    * The index position of the column FILE_PATH in the table.
    */
    public static final int FILE_PATH_IDX = 19 ;

    /**
              * <p> Patient's and Guarantor's Mobile Number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MOBILE_NO= "MOBILE_NO" ;

    /*
    * The index position of the column MOBILE_NO in the table.
    */
    public static final int MOBILE_NO_IDX = 20 ;

    /**
              * <p> Is Payment Requested or only Invoice PDF is sent.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PAYMENT_REQUESTED= "IS_PAYMENT_REQUESTED" ;

    /*
    * The index position of the column IS_PAYMENT_REQUESTED in the table.
    */
    public static final int IS_PAYMENT_REQUESTED_IDX = 21 ;

    /**
              * <p> Description to be shown at the time of payment request.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 22 ;

    /**
              * <p> Is added as part of Payment Link.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PAYMENT_LINK_REQUEST= "IS_PAYMENT_LINK_REQUEST" ;

    /*
    * The index position of the column IS_PAYMENT_LINK_REQUEST in the table.
    */
    public static final int IS_PAYMENT_LINK_REQUEST_IDX = 23 ;

}
