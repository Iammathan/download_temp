package com.adventnet.charm;

/** <p> Description of the table <code>PHRBillStatements</code>.
 *  Column Name and Table Name of  database table  <code>PHRBillStatements</code> is mapped
 * as constants in this util.</p> 
  This table will hold details of Statement that are shared to PHR from EHR. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #STATEMENT_ID}
  * </ul>
 */
 
public final class PHRBILLSTATEMENTS
{
    private PHRBILLSTATEMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRBillStatements" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATEMENT_ID= "STATEMENT_ID" ;

    /*
    * The index position of the column STATEMENT_ID in the table.
    */
    public static final int STATEMENT_ID_IDX = 1 ;

    /**
              * <p> Refers sum of 'Bill Amount' of all Invoices in the Statement.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATEMENT_AMOUNT= "STATEMENT_AMOUNT" ;

    /*
    * The index position of the column STATEMENT_AMOUNT in the table.
    */
    public static final int STATEMENT_AMOUNT_IDX = 2 ;

    /**
              * <p> Refers sum of 'Bill Due' of all Invoices in the Statement.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATEMENT_DUE= "STATEMENT_DUE" ;

    /*
    * The index position of the column STATEMENT_DUE in the table.
    */
    public static final int STATEMENT_DUE_IDX = 3 ;

    /**
              * <p> Refers sum of 'Payment Request' of all Invoices in the Statement.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_REQUEST= "PAYMENT_REQUEST" ;

    /*
    * The index position of the column PAYMENT_REQUEST in the table.
    */
    public static final int PAYMENT_REQUEST_IDX = 4 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_PRACTICE_MAP_ID= "PATIENT_PRACTICE_MAP_ID" ;

    /*
    * The index position of the column PATIENT_PRACTICE_MAP_ID in the table.
    */
    public static final int PATIENT_PRACTICE_MAP_ID_IDX = 5 ;

    /**
              * <p> Refers whether Statement is specific to a particular Facility or not.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 6 ;

    /**
              * <p> Identifier of Member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SHARED_BY= "SHARED_BY" ;

    /*
    * The index position of the column SHARED_BY in the table.
    */
    public static final int SHARED_BY_IDX = 7 ;

    /**
              * <p> Time of Satement shared.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SHARED_TIME= "SHARED_TIME" ;

    /*
    * The index position of the column SHARED_TIME in the table.
    */
    public static final int SHARED_TIME_IDX = 8 ;

    /**
              * <p> Refers whether Statement is paid or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PAID= "IS_PAID" ;

    /*
    * The index position of the column IS_PAID in the table.
    */
    public static final int IS_PAID_IDX = 9 ;

    /**
              * <p> Refers whether Statement is read or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_READ= "IS_READ" ;

    /*
    * The index position of the column IS_READ in the table.
    */
    public static final int IS_READ_IDX = 10 ;

    /**
              * <p> Refers DFS file path of the Statement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATEMENT_FILE_PATH= "STATEMENT_FILE_PATH" ;

    /*
    * The index position of the column STATEMENT_FILE_PATH in the table.
    */
    public static final int STATEMENT_FILE_PATH_IDX = 11 ;

    /**
              * <p> Identifier of Merchant Account.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MERCHANT_ACCOUNT_ID= "MERCHANT_ACCOUNT_ID" ;

    /*
    * The index position of the column MERCHANT_ACCOUNT_ID in the table.
    */
    public static final int MERCHANT_ACCOUNT_ID_IDX = 12 ;

}
