package com.adventnet.charm;

/** <p> Description of the table <code>LabFacilityDetails</code>.
 *  Column Name and Table Name of  database table  <code>LabFacilityDetails</code> is mapped
 * as constants in this util.</p> 
  Lab facilities associated in conducting tests.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FACILITY_ID}
  * </ul>
 */
 
public final class LABFACILITYDETAILS
{
    private LABFACILITYDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabFacilityDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 1 ;

    /**
              * <p> Name of the lab facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FACILITY_NAME= "FACILITY_NAME" ;

    /*
    * The index position of the column FACILITY_NAME in the table.
    */
    public static final int FACILITY_NAME_IDX = 2 ;

    /**
              * <p> Line Address 1.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_LINE_1= "FACILITY_LINE_1" ;

    /*
    * The index position of the column FACILITY_LINE_1 in the table.
    */
    public static final int FACILITY_LINE_1_IDX = 3 ;

    /**
              * <p> Line Address 2.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_LINE_2= "FACILITY_LINE_2" ;

    /*
    * The index position of the column FACILITY_LINE_2 in the table.
    */
    public static final int FACILITY_LINE_2_IDX = 4 ;

    /**
              * <p> City.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_CITY= "FACILITY_CITY" ;

    /*
    * The index position of the column FACILITY_CITY in the table.
    */
    public static final int FACILITY_CITY_IDX = 5 ;

    /**
              * <p> State.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_STATE= "FACILITY_STATE" ;

    /*
    * The index position of the column FACILITY_STATE in the table.
    */
    public static final int FACILITY_STATE_IDX = 6 ;

    /**
              * <p> Country.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_COUNTRY= "FACILITY_COUNTRY" ;

    /*
    * The index position of the column FACILITY_COUNTRY in the table.
    */
    public static final int FACILITY_COUNTRY_IDX = 7 ;

    /**
              * <p> Zip code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_POSTALCODE= "FACILITY_POSTALCODE" ;

    /*
    * The index position of the column FACILITY_POSTALCODE in the table.
    */
    public static final int FACILITY_POSTALCODE_IDX = 8 ;

    /**
              * <p> Phone number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_PHONE_NUMBER= "FACILITY_PHONE_NUMBER" ;

    /*
    * The index position of the column FACILITY_PHONE_NUMBER in the table.
    */
    public static final int FACILITY_PHONE_NUMBER_IDX = 9 ;

    /**
              * <p> Director's title.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_DIRECTOR_TITLE= "FACILITY_DIRECTOR_TITLE" ;

    /*
    * The index position of the column FACILITY_DIRECTOR_TITLE in the table.
    */
    public static final int FACILITY_DIRECTOR_TITLE_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_DIRECTOR_FIRST_NAME= "FACILITY_DIRECTOR_FIRST_NAME" ;

    /*
    * The index position of the column FACILITY_DIRECTOR_FIRST_NAME in the table.
    */
    public static final int FACILITY_DIRECTOR_FIRST_NAME_IDX = 11 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_DIRECTOR_LAST_NAME= "FACILITY_DIRECTOR_LAST_NAME" ;

    /*
    * The index position of the column FACILITY_DIRECTOR_LAST_NAME in the table.
    */
    public static final int FACILITY_DIRECTOR_LAST_NAME_IDX = 12 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_DIRECTOR_MIDDLE_NAME= "FACILITY_DIRECTOR_MIDDLE_NAME" ;

    /*
    * The index position of the column FACILITY_DIRECTOR_MIDDLE_NAME in the table.
    */
    public static final int FACILITY_DIRECTOR_MIDDLE_NAME_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_DIRECTOR_DEGREE= "FACILITY_DIRECTOR_DEGREE" ;

    /*
    * The index position of the column FACILITY_DIRECTOR_DEGREE in the table.
    */
    public static final int FACILITY_DIRECTOR_DEGREE_IDX = 14 ;

    /**
              * <p> Lab code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_MNEMONIC= "FACILITY_MNEMONIC" ;

    /*
    * The index position of the column FACILITY_MNEMONIC in the table.
    */
    public static final int FACILITY_MNEMONIC_IDX = 15 ;

    /**
              * <p> CLIA number of the lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_CLIA_NUMBER= "FACILITY_CLIA_NUMBER" ;

    /*
    * The index position of the column FACILITY_CLIA_NUMBER in the table.
    */
    public static final int FACILITY_CLIA_NUMBER_IDX = 16 ;

    /**
              * <p> Name of the lab which adds this Facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 17 ;

    /**
              * <p> Additional Details are stored in JSON string format.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 18 ;

}
