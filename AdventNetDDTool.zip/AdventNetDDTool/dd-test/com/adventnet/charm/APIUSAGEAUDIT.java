package com.adventnet.charm;

/** <p> Description of the table <code>APIUsageAudit</code>.
 *  Column Name and Table Name of  database table  <code>APIUsageAudit</code> is mapped
 * as constants in this util.</p> 
  API Audits will be saved here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AUDIT_ID}
  * </ul>
 */
 
public final class APIUSAGEAUDIT
{
    private APIUSAGEAUDIT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "APIUsageAudit" ;
    /**
              * <p> Unique identifier of AUDIT message.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AUDIT_ID= "AUDIT_ID" ;

    /*
    * The index position of the column AUDIT_ID in the table.
    */
    public static final int AUDIT_ID_IDX = 1 ;

    /**
              * <p> LoginName of the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LOGIN_ID= "LOGIN_ID" ;

    /*
    * The index position of the column LOGIN_ID in the table.
    */
    public static final int LOGIN_ID_IDX = 2 ;

    /**
              * <p> Id of the Practice used as Practice Space.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

    /**
              * <p> the api called time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CALL= "TIME_OF_CALL" ;

    /*
    * The index position of the column TIME_OF_CALL in the table.
    */
    public static final int TIME_OF_CALL_IDX = 4 ;

    /**
              * <p> API Method; Whether the method is GET, POST, PUT, DELETE..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String API_METHOD= "API_METHOD" ;

    /*
    * The index position of the column API_METHOD in the table.
    */
    public static final int API_METHOD_IDX = 5 ;

    /**
              * <p> URL called from API call.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String API_URL= "API_URL" ;

    /*
    * The index position of the column API_URL in the table.
    */
    public static final int API_URL_IDX = 6 ;

}
