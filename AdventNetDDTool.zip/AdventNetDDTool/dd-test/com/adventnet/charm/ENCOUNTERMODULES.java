package com.adventnet.charm;

/** <p> Description of the table <code>EncounterModules</code>.
 *  Column Name and Table Name of  database table  <code>EncounterModules</code> is mapped
 * as constants in this util.</p> 
  List of the encounter modules. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENCOUNTER_MODULE_ID}
  * </ul>
 */
 
public final class ENCOUNTERMODULES
{
    private ENCOUNTERMODULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EncounterModules" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENCOUNTER_MODULE_ID= "ENCOUNTER_MODULE_ID" ;

    /*
    * The index position of the column ENCOUNTER_MODULE_ID in the table.
    */
    public static final int ENCOUNTER_MODULE_ID_IDX = 1 ;

    /**
              * <p> Name of the module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENCOUNTER_MODULE_NAME= "ENCOUNTER_MODULE_NAME" ;

    /*
    * The index position of the column ENCOUNTER_MODULE_NAME in the table.
    */
    public static final int ENCOUNTER_MODULE_NAME_IDX = 2 ;

}
