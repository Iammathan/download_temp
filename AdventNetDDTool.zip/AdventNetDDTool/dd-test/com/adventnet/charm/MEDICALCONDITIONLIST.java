package com.adventnet.charm;

/** <p> Description of the table <code>MedicalConditionList</code>.
 *  Column Name and Table Name of  database table  <code>MedicalConditionList</code> is mapped
 * as constants in this util.</p> 
  Medical Condition list. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEDICAL_CONDITION_ID}
  * </ul>
 */
 
public final class MEDICALCONDITIONLIST
{
    private MEDICALCONDITIONLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MedicalConditionList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEDICAL_CONDITION_ID= "MEDICAL_CONDITION_ID" ;

    /*
    * The index position of the column MEDICAL_CONDITION_ID in the table.
    */
    public static final int MEDICAL_CONDITION_ID_IDX = 1 ;

    /**
              * <p> Medical Condition Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MEDICAL_CONDITION_NAME= "MEDICAL_CONDITION_NAME" ;

    /*
    * The index position of the column MEDICAL_CONDITION_NAME in the table.
    */
    public static final int MEDICAL_CONDITION_NAME_IDX = 2 ;

    /**
              * <p> Medical Condition Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEDICAL_CONDITION_TYPE= "MEDICAL_CONDITION_TYPE" ;

    /*
    * The index position of the column MEDICAL_CONDITION_TYPE in the table.
    */
    public static final int MEDICAL_CONDITION_TYPE_IDX = 3 ;

    /**
              * <p> To chek whether the medical condition is approved or not.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APPROVAL_STATUS= "APPROVAL_STATUS" ;

    /*
    * The index position of the column APPROVAL_STATUS in the table.
    */
    public static final int APPROVAL_STATUS_IDX = 4 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 5 ;

}
