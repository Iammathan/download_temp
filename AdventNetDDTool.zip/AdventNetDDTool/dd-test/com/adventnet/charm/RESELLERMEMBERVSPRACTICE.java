package com.adventnet.charm;

/** <p> Description of the table <code>ResellerMemberVsPractice</code>.
 *  Column Name and Table Name of  database table  <code>ResellerMemberVsPractice</code> is mapped
 * as constants in this util.</p> 
  Information about Reseller org Members. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEMBER_VS_PRACTICE_ID}
  * </ul>
 */
 
public final class RESELLERMEMBERVSPRACTICE
{
    private RESELLERMEMBERVSPRACTICE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ResellerMemberVsPractice" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_VS_PRACTICE_ID= "MEMBER_VS_PRACTICE_ID" ;

    /*
    * The index position of the column MEMBER_VS_PRACTICE_ID in the table.
    */
    public static final int MEMBER_VS_PRACTICE_ID_IDX = 1 ;

    /**
              * <p> Reseller member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESELLER_MEMBER_ID= "RESELLER_MEMBER_ID" ;

    /*
    * The index position of the column RESELLER_MEMBER_ID in the table.
    */
    public static final int RESELLER_MEMBER_ID_IDX = 2 ;

    /**
              * <p> FK from Managed Practices.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MANAGED_PRACTICE_ID= "MANAGED_PRACTICE_ID" ;

    /*
    * The index position of the column MANAGED_PRACTICE_ID in the table.
    */
    public static final int MANAGED_PRACTICE_ID_IDX = 3 ;

}
