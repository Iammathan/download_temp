package com.adventnet.charm;

/** <p> Description of the table <code>PracticeTemplates</code>.
 *  Column Name and Table Name of  database table  <code>PracticeTemplates</code> is mapped
 * as constants in this util.</p> 
  Template status in Practice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TEMPLATE_ID}
  * </ul>
 */
 
public final class PRACTICETEMPLATES
{
    private PRACTICETEMPLATES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeTemplates" ;
    /**
              * <p> Mapping from Template table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 1 ;

    /**
              * <p> Approved/Waiting for Approval.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 2 ;

}
