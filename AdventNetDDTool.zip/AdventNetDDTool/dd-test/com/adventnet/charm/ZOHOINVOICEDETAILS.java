package com.adventnet.charm;

/** <p> Description of the table <code>ZohoInvoiceDetails</code>.
 *  Column Name and Table Name of  database table  <code>ZohoInvoiceDetails</code> is mapped
 * as constants in this util.</p> 
  Maitains the details about the ZOHO_INVOICE_CONTACT_ID. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ZOHO_INVOICE_DETAILS_ID}
  * </ul>
 */
 
public final class ZOHOINVOICEDETAILS
{
    private ZOHOINVOICEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ZohoInvoiceDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZOHO_INVOICE_DETAILS_ID= "ZOHO_INVOICE_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_INVOICE_DETAILS_ID in the table.
    */
    public static final int ZOHO_INVOICE_DETAILS_ID_IDX = 1 ;

    /**
              * <p> Practice Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Zoho Invoice Contact ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_INVOICE_CONTACT_ID= "ZOHO_INVOICE_CONTACT_ID" ;

    /*
    * The index position of the column ZOHO_INVOICE_CONTACT_ID in the table.
    */
    public static final int ZOHO_INVOICE_CONTACT_ID_IDX = 3 ;

}
