package com.adventnet.charm;

/** <p> Description of the table <code>CQMMedicalRecordData</code>.
 *  Column Name and Table Name of  database table  <code>CQMMedicalRecordData</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEDICAL_DATA_ID}
  * </ul>
 */
 
public final class CQMMEDICALRECORDDATA
{
    private CQMMEDICALRECORDDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMMedicalRecordData" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEDICAL_DATA_ID= "MEDICAL_DATA_ID" ;

    /*
    * The index position of the column MEDICAL_DATA_ID in the table.
    */
    public static final int MEDICAL_DATA_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NUMERATOR_MEDICTION= "NUMERATOR_MEDICTION" ;

    /*
    * The index position of the column NUMERATOR_MEDICTION in the table.
    */
    public static final int NUMERATOR_MEDICTION_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String EXCEPTION_PROCEDURE= "EXCEPTION_PROCEDURE" ;

    /*
    * The index position of the column EXCEPTION_PROCEDURE in the table.
    */
    public static final int EXCEPTION_PROCEDURE_IDX = 4 ;

}
