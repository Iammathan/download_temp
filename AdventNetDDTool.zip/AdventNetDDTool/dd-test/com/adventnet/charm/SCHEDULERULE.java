package com.adventnet.charm;

/** <p> Description of the table <code>ScheduleRule</code>.
 *  Column Name and Table Name of  database table  <code>ScheduleRule</code> is mapped
 * as constants in this util.</p> 
  Facility specific member and visit type schedule rule configuration. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SCHEDULE_RULE_ID}
  * </ul>
 */
 
public final class SCHEDULERULE
{
    private SCHEDULERULE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ScheduleRule" ;
    /**
              * <p> Unique value generator.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SCHEDULE_RULE_ID= "SCHEDULE_RULE_ID" ;

    /*
    * The index position of the column SCHEDULE_RULE_ID in the table.
    */
    public static final int SCHEDULE_RULE_ID_IDX = 1 ;

    /**
              * <p> Identifier of practice facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 2 ;

    /**
              * <p> Identifier of practice member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Identifier of visit type.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 4 ;

    /**
              * <p> Day of the week i.e, Sunday as 0 and Monday as 1 to Saturday as 6.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * <li><code>6</code></li>
              * </ul>
                         */
    public static final String DAY_OF_WEEK= "DAY_OF_WEEK" ;

    /*
    * The index position of the column DAY_OF_WEEK in the table.
    */
    public static final int DAY_OF_WEEK_IDX = 5 ;

    /**
              * <p> Maximum Appointment Count allowed for the day.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAX_APP_COUNT= "MAX_APP_COUNT" ;

    /*
    * The index position of the column MAX_APP_COUNT in the table.
    */
    public static final int MAX_APP_COUNT_IDX = 6 ;

}
