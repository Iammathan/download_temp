package com.adventnet.charm;

/** <p> Description of the table <code>Manufacturer</code>.
 *  Column Name and Table Name of  database table  <code>Manufacturer</code> is mapped
 * as constants in this util.</p> 
  Manufacturer List. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MANUFACTURER_ID}
  * </ul>
 */
 
public final class MANUFACTURER
{
    private MANUFACTURER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Manufacturer" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MANUFACTURER_ID= "MANUFACTURER_ID" ;

    /*
    * The index position of the column MANUFACTURER_ID in the table.
    */
    public static final int MANUFACTURER_ID_IDX = 1 ;

    /**
              * <p> Name of Supplement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MANUFACTURER_NAME= "MANUFACTURER_NAME" ;

    /*
    * The index position of the column MANUFACTURER_NAME in the table.
    */
    public static final int MANUFACTURER_NAME_IDX = 2 ;

    /**
              * <p> Product Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRODUCT_TYPE= "PRODUCT_TYPE" ;

    /*
    * The index position of the column PRODUCT_TYPE in the table.
    */
    public static final int PRODUCT_TYPE_IDX = 3 ;

    /**
              * <p> to identify default Manufaturer.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_APPROVED= "IS_APPROVED" ;

    /*
    * The index position of the column IS_APPROVED in the table.
    */
    public static final int IS_APPROVED_IDX = 4 ;

}
