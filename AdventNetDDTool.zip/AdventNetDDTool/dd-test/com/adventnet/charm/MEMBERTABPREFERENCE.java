package com.adventnet.charm;

/** <p> Description of the table <code>MemberTabPreference</code>.
 *  Column Name and Table Name of  database table  <code>MemberTabPreference</code> is mapped
 * as constants in this util.</p> 
  Physician dashboard main tabs . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ID}
  * </ul>
 */
 
public final class MEMBERTABPREFERENCE
{
    private MEMBERTABPREFERENCE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MemberTabPreference" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 1 ;

    /**
              * <p> Identifier of physician.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Member or patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>MEMBER</code></li>
              * <li><code>PATIENT</code></li>
              * <li><code>ENC_LEFT</code></li>
              * </ul>
                         */
    public static final String DASHBOARD_TYPE= "DASHBOARD_TYPE" ;

    /*
    * The index position of the column DASHBOARD_TYPE in the table.
    */
    public static final int DASHBOARD_TYPE_IDX = 3 ;

    /**
              * <p> Tab Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PREFERED_TABS= "PREFERED_TABS" ;

    /*
    * The index position of the column PREFERED_TABS in the table.
    */
    public static final int PREFERED_TABS_IDX = 4 ;

}
