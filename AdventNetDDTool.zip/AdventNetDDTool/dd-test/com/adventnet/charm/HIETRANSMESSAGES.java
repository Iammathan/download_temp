package com.adventnet.charm;

/** <p> Description of the table <code>HIETransMessages</code>.
 *  Column Name and Table Name of  database table  <code>HIETransMessages</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HIE_HL7_MESSAGE_ID}
  * </ul>
 */
 
public final class HIETRANSMESSAGES
{
    private HIETRANSMESSAGES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HIETransMessages" ;
    /**
              * <p> Unique value for the HIETransMessages Table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HIE_HL7_MESSAGE_ID= "HIE_HL7_MESSAGE_ID" ;

    /*
    * The index position of the column HIE_HL7_MESSAGE_ID in the table.
    */
    public static final int HIE_HL7_MESSAGE_ID_IDX = 1 ;

    /**
              * <p> The type of the message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MESSAGE_TYPE= "MESSAGE_TYPE" ;

    /*
    * The index position of the column MESSAGE_TYPE in the table.
    */
    public static final int MESSAGE_TYPE_IDX = 2 ;

    /**
              * <p> The HL7 Message sent to the Endpoint.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String HL7_MESSAGE= "HL7_MESSAGE" ;

    /*
    * The index position of the column HL7_MESSAGE in the table.
    */
    public static final int HL7_MESSAGE_IDX = 3 ;

    /**
              * <p> Additional comments while sending the message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 4 ;

}
