package com.adventnet.charm;

/** <p> Description of the table <code>MemberSecurityQuestionMap</code>.
 *  Column Name and Table Name of  database table  <code>MemberSecurityQuestionMap</code> is mapped
 * as constants in this util.</p> 
  Contains selected Security Questions . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEMBER_SECURITY_QUESTION_ID}
  * </ul>
 */
 
public final class MEMBERSECURITYQUESTIONMAP
{
    private MEMBERSECURITYQUESTIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MemberSecurityQuestionMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_SECURITY_QUESTION_ID= "MEMBER_SECURITY_QUESTION_ID" ;

    /*
    * The index position of the column MEMBER_SECURITY_QUESTION_ID in the table.
    */
    public static final int MEMBER_SECURITY_QUESTION_ID_IDX = 1 ;

    /**
              * <p> store MemberId based on PracticeMembersList.MEMBER_ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Contain security question.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SECURITY_QUESTION= "SECURITY_QUESTION" ;

    /*
    * The index position of the column SECURITY_QUESTION in the table.
    */
    public static final int SECURITY_QUESTION_IDX = 3 ;

    /**
              * <p> Type of security question .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUESTION_TYPE= "QUESTION_TYPE" ;

    /*
    * The index position of the column QUESTION_TYPE in the table.
    */
    public static final int QUESTION_TYPE_IDX = 4 ;

    /**
              * <p> security question answer enc.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ANSWER= "ANSWER" ;

    /*
    * The index position of the column ANSWER in the table.
    */
    public static final int ANSWER_IDX = 5 ;

    /**
              * <p> Security Question is Updated date.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_CHANGED_DATE= "LAST_CHANGED_DATE" ;

    /*
    * The index position of the column LAST_CHANGED_DATE in the table.
    */
    public static final int LAST_CHANGED_DATE_IDX = 6 ;

}
