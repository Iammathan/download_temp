package com.adventnet.charm;

/** <p> Description of the table <code>ControlHighBPData</code>.
 *  Column Name and Table Name of  database table  <code>ControlHighBPData</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HIGH_BP_DATA_ID}
  * </ul>
 */
 
public final class CONTROLHIGHBPDATA
{
    private CONTROLHIGHBPDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ControlHighBPData" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HIGH_BP_DATA_ID= "HIGH_BP_DATA_ID" ;

    /*
    * The index position of the column HIGH_BP_DATA_ID in the table.
    */
    public static final int HIGH_BP_DATA_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Procedure Performed: procedures indicative of ESRD.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ESRD_PROCEDURE_PERFORMED= "IS_ESRD_PROCEDURE_PERFORMED" ;

    /*
    * The index position of the column IS_ESRD_PROCEDURE_PERFORMED in the table.
    */
    public static final int IS_ESRD_PROCEDURE_PERFORMED_IDX = 3 ;

    /**
              * <p> Diagnosis Active: Pregnancy.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PREGNANCY_DIAGNOISED= "IS_PREGNANCY_DIAGNOISED" ;

    /*
    * The index position of the column IS_PREGNANCY_DIAGNOISED in the table.
    */
    public static final int IS_PREGNANCY_DIAGNOISED_IDX = 4 ;

    /**
              * <p> Diagnosis active: ESRD.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ESRD_DIAGNOISED= "IS_ESRD_DIAGNOISED" ;

    /*
    * The index position of the column IS_ESRD_DIAGNOISED in the table.
    */
    public static final int IS_ESRD_DIAGNOISED_IDX = 5 ;

}
