package com.adventnet.charm;

/** <p> Description of the table <code>PresTemplateEntries</code>.
 *  Column Name and Table Name of  database table  <code>PresTemplateEntries</code> is mapped
 * as constants in this util.</p> 
  Mapping Prescriptions to the Template. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class PRESTEMPLATEENTRIES
{
    private PRESTEMPLATEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PresTemplateEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from Template table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Drug Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DRUGDETAILS_ID= "DRUGDETAILS_ID" ;

    /*
    * The index position of the column DRUGDETAILS_ID in the table.
    */
    public static final int DRUGDETAILS_ID_IDX = 3 ;

    /**
              * <p> Changed to String from float.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DOSAGE= "DOSAGE" ;

    /*
    * The index position of the column DOSAGE in the table.
    */
    public static final int DOSAGE_IDX = 4 ;

    /**
              * <p> Dosage Unit.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DOSAGE_UNIT_ID= "DOSAGE_UNIT_ID" ;

    /*
    * The index position of the column DOSAGE_UNIT_ID in the table.
    */
    public static final int DOSAGE_UNIT_ID_IDX = 5 ;

    /**
              * <p> Prescription Intake duration.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DURATION_IN_DAYS= "DURATION_IN_DAYS" ;

    /*
    * The index position of the column DURATION_IN_DAYS in the table.
    */
    public static final int DURATION_IN_DAYS_IDX = 6 ;

    /**
              * <p> Prescription Dispense(Number of units to be dispensed).</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DISPENSE= "DISPENSE" ;

    /*
    * The index position of the column DISPENSE in the table.
    */
    public static final int DISPENSE_IDX = 7 ;

    /**
              * <p> How many times to be refilled.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFILL= "REFILL" ;

    /*
    * The index position of the column REFILL in the table.
    */
    public static final int REFILL_IDX = 8 ;

    /**
              * <p> To check if the prescription can be substituted with generic.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SUBSTITUTE_GENERIC= "SUBSTITUTE_GENERIC" ;

    /*
    * The index position of the column SUBSTITUTE_GENERIC in the table.
    */
    public static final int SUBSTITUTE_GENERIC_IDX = 9 ;

    /**
              * <p> Manufacturer type(Compounded/Manufactured).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MANUFACTURING_TYPE= "MANUFACTURING_TYPE" ;

    /*
    * The index position of the column MANUFACTURING_TYPE in the table.
    */
    public static final int MANUFACTURING_TYPE_IDX = 10 ;

    /**
              * <p> Intake Route.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTAKE_ROUTE= "INTAKE_ROUTE" ;

    /*
    * The index position of the column INTAKE_ROUTE in the table.
    */
    public static final int INTAKE_ROUTE_IDX = 11 ;

    /**
              * <p> Entry order of Notes for a template.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 12 ;

    /**
              * <p> SIG for this medication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SIG= "SIG" ;

    /*
    * The index position of the column SIG in the table.
    */
    public static final int SIG_IDX = 13 ;

    /**
              * <p> Directions.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DIRECTIONS= "DIRECTIONS" ;

    /*
    * The index position of the column DIRECTIONS in the table.
    */
    public static final int DIRECTIONS_IDX = 14 ;

    /**
              * <p> Dispense unit(Units of measure given by surescripts).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISPENSE_UNIT= "DISPENSE_UNIT" ;

    /*
    * The index position of the column DISPENSE_UNIT in the table.
    */
    public static final int DISPENSE_UNIT_IDX = 15 ;

    /**
              * <p> Boolean for checking if the directions is entered manually.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String DIRECTION_EDITED= "DIRECTION_EDITED" ;

    /*
    * The index position of the column DIRECTION_EDITED in the table.
    */
    public static final int DIRECTION_EDITED_IDX = 16 ;

    /**
              * <p> Medication Comment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 17 ;

    /**
              * <p> For storing the duration unit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DURATION_UNIT= "DURATION_UNIT" ;

    /*
    * The index position of the column DURATION_UNIT in the table.
    */
    public static final int DURATION_UNIT_IDX = 18 ;

    /**
              * <p> Specifies the days of supply.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DAYS_OF_SUPPLY= "DAYS_OF_SUPPLY" ;

    /*
    * The index position of the column DAYS_OF_SUPPLY in the table.
    */
    public static final int DAYS_OF_SUPPLY_IDX = 19 ;

}
