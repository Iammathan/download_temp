package com.adventnet.charm;

/** <p> Description of the table <code>DietEntries</code>.
 *  Column Name and Table Name of  database table  <code>DietEntries</code> is mapped
 * as constants in this util.</p> 
  Daily Diets given for patients. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DIET_ENTRY_ID}
  * </ul>
 */
 
public final class DIETENTRIES
{
    private DIETENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DietEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DIET_ENTRY_ID= "DIET_ENTRY_ID" ;

    /*
    * The index position of the column DIET_ENTRY_ID in the table.
    */
    public static final int DIET_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DIET_ID= "DIET_ID" ;

    /*
    * The index position of the column DIET_ID in the table.
    */
    public static final int DIET_ID_IDX = 3 ;

    /**
              * <p> Date from which the data is collected.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 4 ;

    /**
              * <p> Date till which the data is collected.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 5 ;

    /**
              * <p> Daily Intake.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INTAKE= "INTAKE" ;

    /*
    * The index position of the column INTAKE in the table.
    */
    public static final int INTAKE_IDX = 6 ;

    /**
              * <p> Diet taken frequency.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FREQUENCY= "FREQUENCY" ;

    /*
    * The index position of the column FREQUENCY in the table.
    */
    public static final int FREQUENCY_IDX = 7 ;

    /**
              * <p> Comments about the medication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 8 ;

    /**
              * <p> no of days prescription taken.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DURATION_IN_DAYS= "DURATION_IN_DAYS" ;

    /*
    * The index position of the column DURATION_IN_DAYS in the table.
    */
    public static final int DURATION_IN_DAYS_IDX = 9 ;

}
