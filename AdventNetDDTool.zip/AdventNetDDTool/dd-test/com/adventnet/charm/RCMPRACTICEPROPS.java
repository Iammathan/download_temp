package com.adventnet.charm;

/** <p> Description of the table <code>RCMPracticeProps</code>.
 *  Column Name and Table Name of  database table  <code>RCMPracticeProps</code> is mapped
 * as constants in this util.</p> 
  To store RCM Practice Properties. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_PROP_ENTRY_ID}
  * </ul>
 */
 
public final class RCMPRACTICEPROPS
{
    private RCMPRACTICEPROPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMPracticeProps" ;
    /**
              * <p> Unique identifier for RCM Practice Property.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_PROP_ENTRY_ID= "RCM_PROP_ENTRY_ID" ;

    /*
    * The index position of the column RCM_PROP_ENTRY_ID in the table.
    */
    public static final int RCM_PROP_ENTRY_ID_IDX = 1 ;

    /**
              * <p> RCM Property Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RCM_PROP_NAME= "RCM_PROP_NAME" ;

    /*
    * The index position of the column RCM_PROP_NAME in the table.
    */
    public static final int RCM_PROP_NAME_IDX = 2 ;

    /**
              * <p> RCM Property Value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RCM_PROP_VALUE= "RCM_PROP_VALUE" ;

    /*
    * The index position of the column RCM_PROP_VALUE in the table.
    */
    public static final int RCM_PROP_VALUE_IDX = 3 ;

}
