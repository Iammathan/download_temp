package com.adventnet.charm;

/** <p> Description of the table <code>InsurancePostalAddress</code>.
 *  Column Name and Table Name of  database table  <code>InsurancePostalAddress</code> is mapped
 * as constants in this util.</p> 
  Address for User. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #POSTALADDRESS_ID}
  * </ul>
 */
 
public final class INSURANCEPOSTALADDRESS
{
    private INSURANCEPOSTALADDRESS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InsurancePostalAddress" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 1 ;

    /**
              * <p> Door number and street details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_1= "LINE_1" ;

    /*
    * The index position of the column LINE_1 in the table.
    */
    public static final int LINE_1_IDX = 2 ;

    /**
              * <p> Line 2 of the Address.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_2= "LINE_2" ;

    /*
    * The index position of the column LINE_2 in the table.
    */
    public static final int LINE_2_IDX = 3 ;

    /**
              * <p> Name of city.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CITY= "CITY" ;

    /*
    * The index position of the column CITY in the table.
    */
    public static final int CITY_IDX = 4 ;

    /**
              * <p> Name of the state.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATE= "STATE" ;

    /*
    * The index position of the column STATE in the table.
    */
    public static final int STATE_IDX = 5 ;

    /**
              * <p> Name of the country.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY= "COUNTRY" ;

    /*
    * The index position of the column COUNTRY in the table.
    */
    public static final int COUNTRY_IDX = 6 ;

    /**
              * <p> Postal code / PIN code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String POSTALCODE= "POSTALCODE" ;

    /*
    * The index position of the column POSTALCODE in the table.
    */
    public static final int POSTALCODE_IDX = 7 ;

}
