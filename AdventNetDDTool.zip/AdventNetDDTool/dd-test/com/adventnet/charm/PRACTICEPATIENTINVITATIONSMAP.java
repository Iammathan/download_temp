package com.adventnet.charm;

/** <p> Description of the table <code>PracticePatientInvitationsMap</code>.
 *  Column Name and Table Name of  database table  <code>PracticePatientInvitationsMap</code> is mapped
 * as constants in this util.</p> 
  Used to map patient invitations with practice in public space. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_PATIENT_INVITATION_ID}
  * </ul>
 */
 
public final class PRACTICEPATIENTINVITATIONSMAP
{
    private PRACTICEPATIENTINVITATIONSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticePatientInvitationsMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_INVITATION_ID= "PRACTICE_PATIENT_INVITATION_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_INVITATION_ID in the table.
    */
    public static final int PRACTICE_PATIENT_INVITATION_ID_IDX = 1 ;

    /**
              * <p>  EMail Id of the patient .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PATIENT_EMAILID= "PATIENT_EMAILID" ;

    /*
    * The index position of the column PATIENT_EMAILID in the table.
    */
    public static final int PATIENT_EMAILID_IDX = 2 ;

    /**
              * <p> Identifier of Practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

    /**
              * <p> Identifier of Patient invitation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVITATION_ID= "INVITATION_ID" ;

    /*
    * The index position of the column INVITATION_ID in the table.
    */
    public static final int INVITATION_ID_IDX = 4 ;

}
