package com.adventnet.charm;

/** <p> Description of the table <code>PHRQuesMap</code>.
 *  Column Name and Table Name of  database table  <code>PHRQuesMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Questionnaire and Patient and is answered. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PHR_QUES_MAP_ID}
  * </ul>
 */
 
public final class PHRQUESMAP
{
    private PHRQUESMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRQuesMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHR_QUES_MAP_ID= "PHR_QUES_MAP_ID" ;

    /*
    * The index position of the column PHR_QUES_MAP_ID in the table.
    */
    public static final int PHR_QUES_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of the patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Id of the Template.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 3 ;

    /**
              * <p> To check whether the questionnaire is filled or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_FILLED= "IS_FILLED" ;

    /*
    * The index position of the column IS_FILLED in the table.
    */
    public static final int IS_FILLED_IDX = 4 ;

    /**
              * <p> To check whether the questionnaire is submitted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SUBMITTED= "IS_SUBMITTED" ;

    /*
    * The index position of the column IS_SUBMITTED in the table.
    */
    public static final int IS_SUBMITTED_IDX = 5 ;

    /**
              * <p> Last time while saving Questionnaire.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 6 ;

    /**
              * <p> Added time into PHR.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 7 ;

}
