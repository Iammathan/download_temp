package com.adventnet.charm;

/** <p> Description of the table <code>InfantVaccinationCount</code>.
 *  Column Name and Table Name of  database table  <code>InfantVaccinationCount</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INFANT_VACC_ID}
  * </ul>
 */
 
public final class INFANTVACCINATIONCOUNT
{
    private INFANTVACCINATIONCOUNT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InfantVaccinationCount" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INFANT_VACC_ID= "INFANT_VACC_ID" ;

    /*
    * The index position of the column INFANT_VACC_ID in the table.
    */
    public static final int INFANT_VACC_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DTAP_COUNT= "DTAP_COUNT" ;

    /*
    * The index position of the column DTAP_COUNT in the table.
    */
    public static final int DTAP_COUNT_IDX = 3 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IPV_COUNT= "IPV_COUNT" ;

    /*
    * The index position of the column IPV_COUNT in the table.
    */
    public static final int IPV_COUNT_IDX = 4 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String MMR_COUNT= "MMR_COUNT" ;

    /*
    * The index position of the column MMR_COUNT in the table.
    */
    public static final int MMR_COUNT_IDX = 5 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String MUMPS_COUNT= "MUMPS_COUNT" ;

    /*
    * The index position of the column MUMPS_COUNT in the table.
    */
    public static final int MUMPS_COUNT_IDX = 6 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String MEASLES_COUNT= "MEASLES_COUNT" ;

    /*
    * The index position of the column MEASLES_COUNT in the table.
    */
    public static final int MEASLES_COUNT_IDX = 7 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RUBELLA_COUNT= "RUBELLA_COUNT" ;

    /*
    * The index position of the column RUBELLA_COUNT in the table.
    */
    public static final int RUBELLA_COUNT_IDX = 8 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String HIB_COUNT= "HIB_COUNT" ;

    /*
    * The index position of the column HIB_COUNT in the table.
    */
    public static final int HIB_COUNT_IDX = 9 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String HEPATITIS_B_COUNT= "HEPATITIS_B_COUNT" ;

    /*
    * The index position of the column HEPATITIS_B_COUNT in the table.
    */
    public static final int HEPATITIS_B_COUNT_IDX = 10 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String VZV_COUNT= "VZV_COUNT" ;

    /*
    * The index position of the column VZV_COUNT in the table.
    */
    public static final int VZV_COUNT_IDX = 11 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PNEUMOCOCCAL_COUNT= "PNEUMOCOCCAL_COUNT" ;

    /*
    * The index position of the column PNEUMOCOCCAL_COUNT in the table.
    */
    public static final int PNEUMOCOCCAL_COUNT_IDX = 12 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String HEPATITIS_A_COUNT= "HEPATITIS_A_COUNT" ;

    /*
    * The index position of the column HEPATITIS_A_COUNT in the table.
    */
    public static final int HEPATITIS_A_COUNT_IDX = 13 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String ROTAVIRUS_COUNT= "ROTAVIRUS_COUNT" ;

    /*
    * The index position of the column ROTAVIRUS_COUNT in the table.
    */
    public static final int ROTAVIRUS_COUNT_IDX = 14 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String INFLUENZA_COUNT= "INFLUENZA_COUNT" ;

    /*
    * The index position of the column INFLUENZA_COUNT in the table.
    */
    public static final int INFLUENZA_COUNT_IDX = 15 ;

}
