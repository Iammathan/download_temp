package com.adventnet.charm;

/** <p> Description of the table <code>PHRImagePracticeMap</code>.
 *  Column Name and Table Name of  database table  <code>PHRImagePracticeMap</code> is mapped
 * as constants in this util.</p> 
  Image Results  PHR Map table . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PHR_IMAGE_PRACTICE_MAP_ID}
  * </ul>
 */
 
public final class PHRIMAGEPRACTICEMAP
{
    private PHRIMAGEPRACTICEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRImagePracticeMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHR_IMAGE_PRACTICE_MAP_ID= "PHR_IMAGE_PRACTICE_MAP_ID" ;

    /*
    * The index position of the column PHR_IMAGE_PRACTICE_MAP_ID in the table.
    */
    public static final int PHR_IMAGE_PRACTICE_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Group Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_RESULT_GROUP_ID= "IMAGE_RESULT_GROUP_ID" ;

    /*
    * The index position of the column IMAGE_RESULT_GROUP_ID in the table.
    */
    public static final int IMAGE_RESULT_GROUP_ID_IDX = 4 ;

}
