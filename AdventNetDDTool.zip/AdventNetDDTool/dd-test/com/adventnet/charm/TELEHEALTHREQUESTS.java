package com.adventnet.charm;

/** <p> Description of the table <code>TeleHealthRequests</code>.
 *  Column Name and Table Name of  database table  <code>TeleHealthRequests</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TELEHEALTH_REQUEST_ID}
  * </ul>
 */
 
public final class TELEHEALTHREQUESTS
{
    private TELEHEALTHREQUESTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TeleHealthRequests" ;
    /**
              * <p> Provider request id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TELEHEALTH_REQUEST_ID= "TELEHEALTH_REQUEST_ID" ;

    /*
    * The index position of the column TELEHEALTH_REQUEST_ID in the table.
    */
    public static final int TELEHEALTH_REQUEST_ID_IDX = 1 ;

    /**
              * <p> Member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Video Consult feature enable initiate Time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INITIATED_TIME= "INITIATED_TIME" ;

    /*
    * The index position of the column INITIATED_TIME in the table.
    */
    public static final int INITIATED_TIME_IDX = 3 ;

    /**
              * <p> Video Consult-Archieving feature required.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ARCHIEVING_REQUIRED= "IS_ARCHIEVING_REQUIRED" ;

    /*
    * The index position of the column IS_ARCHIEVING_REQUIRED in the table.
    */
    public static final int IS_ARCHIEVING_REQUIRED_IDX = 4 ;

    /**
              * <p> Enabling status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                     * Default Value is <code>Not Enabled</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 5 ;

    /**
              * <p> practice id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 6 ;

    /**
              * <p> Provider name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROVIDER_NAME= "PROVIDER_NAME" ;

    /*
    * The index position of the column PROVIDER_NAME in the table.
    */
    public static final int PROVIDER_NAME_IDX = 7 ;

    /**
              * <p> Facility name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FACILITY_NAME= "FACILITY_NAME" ;

    /*
    * The index position of the column FACILITY_NAME in the table.
    */
    public static final int FACILITY_NAME_IDX = 8 ;

    /**
              * <p> Country name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY= "COUNTRY" ;

    /*
    * The index position of the column COUNTRY in the table.
    */
    public static final int COUNTRY_IDX = 9 ;

    /**
              * <p> Identifier of the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LOGIN_NAME= "LOGIN_NAME" ;

    /*
    * The index position of the column LOGIN_NAME in the table.
    */
    public static final int LOGIN_NAME_IDX = 10 ;

    /**
              * <p> Which platform to use.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                            * Default Value is <code>OPENTOK</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PLATFORM= "PLATFORM" ;

    /*
    * The index position of the column PLATFORM in the table.
    */
    public static final int PLATFORM_IDX = 11 ;

    /**
              * <p> Subscription plan Fixed plan or perMinute plan.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                            * Default Value is <code>FP</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SUBSCRIPTION_PLAN= "SUBSCRIPTION_PLAN" ;

    /*
    * The index position of the column SUBSCRIPTION_PLAN in the table.
    */
    public static final int SUBSCRIPTION_PLAN_IDX = 12 ;

    /**
              * <p> Request to move opentok platform to zoom platform.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MIGRATE_PLATFORM_REQUEST= "MIGRATE_PLATFORM_REQUEST" ;

    /*
    * The index position of the column MIGRATE_PLATFORM_REQUEST in the table.
    */
    public static final int MIGRATE_PLATFORM_REQUEST_IDX = 13 ;

    /**
              * <p> Is certified medical provider.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_CMP= "IS_CMP" ;

    /*
    * The index position of the column IS_CMP in the table.
    */
    public static final int IS_CMP_IDX = 14 ;

    /**
              * <p> non certify medical provider title.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NON_CMP_TITLE= "NON_CMP_TITLE" ;

    /*
    * The index position of the column NON_CMP_TITLE in the table.
    */
    public static final int NON_CMP_TITLE_IDX = 15 ;

}
