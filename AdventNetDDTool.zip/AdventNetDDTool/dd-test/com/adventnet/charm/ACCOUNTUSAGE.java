package com.adventnet.charm;

/** <p> Description of the table <code>AccountUsage</code>.
 *  Column Name and Table Name of  database table  <code>AccountUsage</code> is mapped
 * as constants in this util.</p> 
  This table for storing practice account usage info. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_ID}
  * </ul>
 */
 
public final class ACCOUNTUSAGE
{
    private ACCOUNTUSAGE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AccountUsage" ;
    /**
              * <p> Identifier of Practice.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 1 ;

    /**
              * <p> Full name of the practice contact person(usually practice admin).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CONTACT_PERSON= "CONTACT_PERSON" ;

    /*
    * The index position of the column CONTACT_PERSON in the table.
    */
    public static final int CONTACT_PERSON_IDX = 2 ;

    /**
              * <p> Email Id of practice(usually practice admin's email id).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMAILID= "EMAILID" ;

    /*
    * The index position of the column EMAILID in the table.
    */
    public static final int EMAILID_IDX = 3 ;

    /**
              * <p> No of Active Patients.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACTIVE_PATIENTS= "ACTIVE_PATIENTS" ;

    /*
    * The index position of the column ACTIVE_PATIENTS in the table.
    */
    public static final int ACTIVE_PATIENTS_IDX = 4 ;

    /**
              * <p> No of Prescribers.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRESCRIBERS_COUNT= "PRESCRIBERS_COUNT" ;

    /*
    * The index position of the column PRESCRIBERS_COUNT in the table.
    */
    public static final int PRESCRIBERS_COUNT_IDX = 5 ;

    /**
              * <p> No of Non-Prescribering Members.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTHER_MEMBERS_COUNT= "OTHER_MEMBERS_COUNT" ;

    /*
    * The index position of the column OTHER_MEMBERS_COUNT in the table.
    */
    public static final int OTHER_MEMBERS_COUNT_IDX = 6 ;

    /**
              * <p> Consulation in month-1.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_FOR_MONTH_1= "CONSULTATION_FOR_MONTH_1" ;

    /*
    * The index position of the column CONSULTATION_FOR_MONTH_1 in the table.
    */
    public static final int CONSULTATION_FOR_MONTH_1_IDX = 7 ;

    /**
              * <p> Consulation in month-2.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_FOR_MONTH_2= "CONSULTATION_FOR_MONTH_2" ;

    /*
    * The index position of the column CONSULTATION_FOR_MONTH_2 in the table.
    */
    public static final int CONSULTATION_FOR_MONTH_2_IDX = 8 ;

    /**
              * <p> Consultation in month-3.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_FOR_MONTH_3= "CONSULTATION_FOR_MONTH_3" ;

    /*
    * The index position of the column CONSULTATION_FOR_MONTH_3 in the table.
    */
    public static final int CONSULTATION_FOR_MONTH_3_IDX = 9 ;

    /**
              * <p> Type of Account.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCOUNT_TYPE= "ACCOUNT_TYPE" ;

    /*
    * The index position of the column ACCOUNT_TYPE in the table.
    */
    public static final int ACCOUNT_TYPE_IDX = 10 ;

    /**
              * <p> Bytes used by the practice in DFS.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DISK_USAGE= "DISK_USAGE" ;

    /*
    * The index position of the column DISK_USAGE in the table.
    */
    public static final int DISK_USAGE_IDX = 11 ;

    /**
              * <p> SMS in month-1.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MESSAGES_FOR_MONTH_1= "MESSAGES_FOR_MONTH_1" ;

    /*
    * The index position of the column MESSAGES_FOR_MONTH_1 in the table.
    */
    public static final int MESSAGES_FOR_MONTH_1_IDX = 12 ;

    /**
              * <p> SMS in month-2.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MESSAGES_FOR_MONTH_2= "MESSAGES_FOR_MONTH_2" ;

    /*
    * The index position of the column MESSAGES_FOR_MONTH_2 in the table.
    */
    public static final int MESSAGES_FOR_MONTH_2_IDX = 13 ;

    /**
              * <p> SMS in month-3.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MESSAGES_FOR_MONTH_3= "MESSAGES_FOR_MONTH_3" ;

    /*
    * The index position of the column MESSAGES_FOR_MONTH_3 in the table.
    */
    public static final int MESSAGES_FOR_MONTH_3_IDX = 14 ;

    /**
              * <p> Voice SMS in month-1.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_MESSAGES_FOR_MONTH_1= "VOICE_MESSAGES_FOR_MONTH_1" ;

    /*
    * The index position of the column VOICE_MESSAGES_FOR_MONTH_1 in the table.
    */
    public static final int VOICE_MESSAGES_FOR_MONTH_1_IDX = 15 ;

    /**
              * <p> Voice SMS in month-2.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_MESSAGES_FOR_MONTH_2= "VOICE_MESSAGES_FOR_MONTH_2" ;

    /*
    * The index position of the column VOICE_MESSAGES_FOR_MONTH_2 in the table.
    */
    public static final int VOICE_MESSAGES_FOR_MONTH_2_IDX = 16 ;

    /**
              * <p> Voice SMS in month-3.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_MESSAGES_FOR_MONTH_3= "VOICE_MESSAGES_FOR_MONTH_3" ;

    /*
    * The index position of the column VOICE_MESSAGES_FOR_MONTH_3 in the table.
    */
    public static final int VOICE_MESSAGES_FOR_MONTH_3_IDX = 17 ;

    /**
              * <p> Whether SMS subscription is Enabled for this practice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SMS_ENABLED= "IS_SMS_ENABLED" ;

    /*
    * The index position of the column IS_SMS_ENABLED in the table.
    */
    public static final int IS_SMS_ENABLED_IDX = 18 ;

    /**
              * <p> Last accessed time/date by the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_ACCESSED_TIME= "LAST_ACCESSED_TIME" ;

    /*
    * The index position of the column LAST_ACCESSED_TIME in the table.
    */
    public static final int LAST_ACCESSED_TIME_IDX = 19 ;

    /**
              * <p> Fax send page count for month - 1.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAX_OUTBOUND_FOR_MONTH_1= "FAX_OUTBOUND_FOR_MONTH_1" ;

    /*
    * The index position of the column FAX_OUTBOUND_FOR_MONTH_1 in the table.
    */
    public static final int FAX_OUTBOUND_FOR_MONTH_1_IDX = 20 ;

    /**
              * <p> Fax send page count for month - 2.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAX_OUTBOUND_FOR_MONTH_2= "FAX_OUTBOUND_FOR_MONTH_2" ;

    /*
    * The index position of the column FAX_OUTBOUND_FOR_MONTH_2 in the table.
    */
    public static final int FAX_OUTBOUND_FOR_MONTH_2_IDX = 21 ;

    /**
              * <p> Fax send page count for month - 3.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAX_OUTBOUND_FOR_MONTH_3= "FAX_OUTBOUND_FOR_MONTH_3" ;

    /*
    * The index position of the column FAX_OUTBOUND_FOR_MONTH_3 in the table.
    */
    public static final int FAX_OUTBOUND_FOR_MONTH_3_IDX = 22 ;

    /**
              * <p> Fax recieved page count for month - 1.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAX_INBOUND_FOR_MONTH_1= "FAX_INBOUND_FOR_MONTH_1" ;

    /*
    * The index position of the column FAX_INBOUND_FOR_MONTH_1 in the table.
    */
    public static final int FAX_INBOUND_FOR_MONTH_1_IDX = 23 ;

    /**
              * <p> Fax recieved page count for month - 2.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAX_INBOUND_FOR_MONTH_2= "FAX_INBOUND_FOR_MONTH_2" ;

    /*
    * The index position of the column FAX_INBOUND_FOR_MONTH_2 in the table.
    */
    public static final int FAX_INBOUND_FOR_MONTH_2_IDX = 24 ;

    /**
              * <p> Fax recieved page count for month - 3.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAX_INBOUND_FOR_MONTH_3= "FAX_INBOUND_FOR_MONTH_3" ;

    /*
    * The index position of the column FAX_INBOUND_FOR_MONTH_3 in the table.
    */
    public static final int FAX_INBOUND_FOR_MONTH_3_IDX = 25 ;

}
