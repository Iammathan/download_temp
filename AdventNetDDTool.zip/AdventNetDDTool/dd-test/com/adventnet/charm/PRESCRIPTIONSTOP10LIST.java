package com.adventnet.charm;

/** <p> Description of the table <code>PrescriptionsTop10List</code>.
 *  Column Name and Table Name of  database table  <code>PrescriptionsTop10List</code> is mapped
 * as constants in this util.</p> 
  Prescriptions Top10  List. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PRESCRIPTION_ID}
  * <li> {@link #REPORT_DATE}
  * </ul>
 */
 
public final class PRESCRIPTIONSTOP10LIST
{
    private PRESCRIPTIONSTOP10LIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PrescriptionsTop10List" ;
    /**
              * <p> Identifier of Prescription.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRESCRIPTION_ID= "PRESCRIPTION_ID" ;

    /*
    * The index position of the column PRESCRIPTION_ID in the table.
    */
    public static final int PRESCRIPTION_ID_IDX = 1 ;

    /**
              * <p> Number of patients.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_COUNT= "PATIENT_COUNT" ;

    /*
    * The index position of the column PATIENT_COUNT in the table.
    */
    public static final int PATIENT_COUNT_IDX = 2 ;

    /**
              * <p> Date for which the data was collected.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_DATE= "REPORT_DATE" ;

    /*
    * The index position of the column REPORT_DATE in the table.
    */
    public static final int REPORT_DATE_IDX = 3 ;

}
