package com.adventnet.charm;

/** <p> Description of the table <code>SHTemplateOptions</code>.
 *  Column Name and Table Name of  database table  <code>SHTemplateOptions</code> is mapped
 * as constants in this util.</p> 
  Table to hold Social History Template options. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #OPTION_ID}
  * </ul>
 */
 
public final class SHTEMPLATEOPTIONS
{
    private SHTEMPLATEOPTIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SHTemplateOptions" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OPTION_ID= "OPTION_ID" ;

    /*
    * The index position of the column OPTION_ID in the table.
    */
    public static final int OPTION_ID_IDX = 1 ;

    /**
              * <p> Mapping from Template SHTemplateEntries table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 2 ;

    /**
              * <p> Option value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OPTION= "OPTION" ;

    /*
    * The index position of the column OPTION in the table.
    */
    public static final int OPTION_IDX = 3 ;

}
