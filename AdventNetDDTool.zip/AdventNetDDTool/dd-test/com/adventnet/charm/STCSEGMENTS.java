package com.adventnet.charm;

/** <p> Description of the table <code>STCSegments</code>.
 *  Column Name and Table Name of  database table  <code>STCSegments</code> is mapped
 * as constants in this util.</p> 
  It contains STC segments information (reasons for rejection and accepted response). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #STC_SEGMENTS_ID}
  * </ul>
 */
 
public final class STCSEGMENTS
{
    private STCSEGMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "STCSegments" ;
    /**
              * <p> Unique ID(SAS KEY - PK) assigned by Mickey.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STC_SEGMENTS_ID= "STC_SEGMENTS_ID" ;

    /*
    * The index position of the column STC_SEGMENTS_ID in the table.
    */
    public static final int STC_SEGMENTS_ID_IDX = 1 ;

    /**
              * <p> Claim ID - PK of the ClaimCompleteDetails table which has the claim related detail.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_TXN_CLAIM_MAP_ID= "ECLAIM_TXN_CLAIM_MAP_ID" ;

    /*
    * The index position of the column ECLAIM_TXN_CLAIM_MAP_ID in the table.
    */
    public static final int ECLAIM_TXN_CLAIM_MAP_ID_IDX = 2 ;

    /**
              * <p> When STC details belongs to 277CA reports directly receveid from
                                clearinghouse, then this column holds the reference to the PK of the
                                EDI277CAReportDetails where that file and acknowledgment detail are maintained.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EDI_REPORT_DETAIL_ID= "EDI_REPORT_DETAIL_ID" ;

    /*
    * The index position of the column EDI_REPORT_DETAIL_ID in the table.
    */
    public static final int EDI_REPORT_DETAIL_ID_IDX = 3 ;

    /**
              * <p> STC01-1 Or STC10-1 Or STC11-1 - Claim Status Category Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_STATUS_CATEGORY_CODE= "CLAIM_STATUS_CATEGORY_CODE" ;

    /*
    * The index position of the column CLAIM_STATUS_CATEGORY_CODE in the table.
    */
    public static final int CLAIM_STATUS_CATEGORY_CODE_IDX = 4 ;

    /**
              * <p> STC01-2 Or STC10-2 Or STC11-2 - Claim Status Code .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_STATUS_CODE= "CLAIM_STATUS_CODE" ;

    /*
    * The index position of the column CLAIM_STATUS_CODE in the table.
    */
    public static final int CLAIM_STATUS_CODE_IDX = 5 ;

    /**
              * <p> STC01-3 Or STC10-3 Or STC11-3 - Entity Identifier Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ENTITY_IDENTIFIER_CODE= "ENTITY_IDENTIFIER_CODE" ;

    /*
    * The index position of the column ENTITY_IDENTIFIER_CODE in the table.
    */
    public static final int ENTITY_IDENTIFIER_CODE_IDX = 6 ;

    /**
              * <p> STC12 - Free Form Text Message of STC Segment .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FREE_FORM_TEXT_MESSAGE= "FREE_FORM_TEXT_MESSAGE" ;

    /*
    * The index position of the column FREE_FORM_TEXT_MESSAGE in the table.
    */
    public static final int FREE_FORM_TEXT_MESSAGE_IDX = 7 ;

    /**
              * <p> used for indication warning or error(ACE_WARNING|ERROR|WQ).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STC_STATUS= "STC_STATUS" ;

    /*
    * The index position of the column STC_STATUS in the table.
    */
    public static final int STC_STATUS_IDX = 8 ;

}
