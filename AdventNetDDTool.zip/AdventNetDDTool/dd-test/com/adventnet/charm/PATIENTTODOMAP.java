package com.adventnet.charm;

/** <p> Description of the table <code>PatientTodoMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientTodoMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient id  and Todo id. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TODO_ID}
  * </ul>
 */
 
public final class PATIENTTODOMAP
{
    private PATIENTTODOMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientTodoMap" ;
    /**
              * <p> ToDo ID .</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TODO_ID= "TODO_ID" ;

    /*
    * The index position of the column TODO_ID in the table.
    */
    public static final int TODO_ID_IDX = 1 ;

    /**
              * <p>  Patient ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

}
