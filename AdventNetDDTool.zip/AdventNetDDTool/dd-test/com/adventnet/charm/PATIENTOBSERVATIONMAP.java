package com.adventnet.charm;

/** <p> Description of the table <code>PatientObservationMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientObservationMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Observation. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #OBSERVATION_MAP_ID}
  * </ul>
 */
 
public final class PATIENTOBSERVATIONMAP
{
    private PATIENTOBSERVATIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientObservationMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OBSERVATION_MAP_ID= "OBSERVATION_MAP_ID" ;

    /*
    * The index position of the column OBSERVATION_MAP_ID in the table.
    */
    public static final int OBSERVATION_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OBSERVATION_ID= "OBSERVATION_ID" ;

    /*
    * The index position of the column OBSERVATION_ID in the table.
    */
    public static final int OBSERVATION_ID_IDX = 3 ;

    /**
              * <p> Nature of Observation.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String OBSERVATION_NATURE= "OBSERVATION_NATURE" ;

    /*
    * The index position of the column OBSERVATION_NATURE in the table.
    */
    public static final int OBSERVATION_NATURE_IDX = 4 ;

    /**
              * <p> positive threshould value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>3</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String POSITIVE= "POSITIVE" ;

    /*
    * The index position of the column POSITIVE in the table.
    */
    public static final int POSITIVE_IDX = 5 ;

    /**
              * <p> negative threshould value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>-3</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NEGATIVE= "NEGATIVE" ;

    /*
    * The index position of the column NEGATIVE in the table.
    */
    public static final int NEGATIVE_IDX = 6 ;

    /**
              * <p> To check whether the observation is de activated or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 7 ;

}
