package com.adventnet.charm;

/** <p> Description of the table <code>OutboundFaxDetails</code>.
 *  Column Name and Table Name of  database table  <code>OutboundFaxDetails</code> is mapped
 * as constants in this util.</p> 
  Fax Details sent/received. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FAXDETAILS_ID}
  * </ul>
 */
 
public final class OUTBOUNDFAXDETAILS
{
    private OUTBOUNDFAXDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "OutboundFaxDetails" ;
    /**
              * <p> Fax details ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FAXDETAILS_ID= "FAXDETAILS_ID" ;

    /*
    * The index position of the column FAXDETAILS_ID in the table.
    */
    public static final int FAXDETAILS_ID_IDX = 1 ;

    /**
              * <p> fax initiated time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INITIATED_TIME= "INITIATED_TIME" ;

    /*
    * The index position of the column INITIATED_TIME in the table.
    */
    public static final int INITIATED_TIME_IDX = 2 ;

    /**
              * <p> Fax sent time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SENT_TIME= "SENT_TIME" ;

    /*
    * The index position of the column SENT_TIME in the table.
    */
    public static final int SENT_TIME_IDX = 3 ;

    /**
              * <p> Unique Id of fax provided by provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROVIDER_FAX_ID= "PROVIDER_FAX_ID" ;

    /*
    * The index position of the column PROVIDER_FAX_ID in the table.
    */
    public static final int PROVIDER_FAX_ID_IDX = 4 ;

    /**
              * <p> Unique Id of fax provided by provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROVIDER_FAX_QUEUE_ID= "PROVIDER_FAX_QUEUE_ID" ;

    /*
    * The index position of the column PROVIDER_FAX_QUEUE_ID in the table.
    */
    public static final int PROVIDER_FAX_QUEUE_ID_IDX = 5 ;

    /**
              * <p> To which number the the fax sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_NUMBER= "TO_NUMBER" ;

    /*
    * The index position of the column TO_NUMBER in the table.
    */
    public static final int TO_NUMBER_IDX = 6 ;

    /**
              * <p> To which number the the fax sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TO_NAME= "TO_NAME" ;

    /*
    * The index position of the column TO_NAME in the table.
    */
    public static final int TO_NAME_IDX = 7 ;

    /**
              * <p> From which number the the fax sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_NUMBER= "FROM_NUMBER" ;

    /*
    * The index position of the column FROM_NUMBER in the table.
    */
    public static final int FROM_NUMBER_IDX = 8 ;

    /**
              * <p> From which number the the fax sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FROM_NAME= "FROM_NAME" ;

    /*
    * The index position of the column FROM_NAME in the table.
    */
    public static final int FROM_NAME_IDX = 9 ;

    /**
              * <p> DFS file id of sent fax content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 10 ;

    /**
              * <p> Status of fax Yet to sent /Sent/Failed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 11 ;

    /**
              * <p> Details of the status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS_DESCRIPTION= "STATUS_DESCRIPTION" ;

    /*
    * The index position of the column STATUS_DESCRIPTION in the table.
    */
    public static final int STATUS_DESCRIPTION_IDX = 12 ;

    /**
              * <p> No of segments in original fax content.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>1</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PAGES= "PAGES" ;

    /*
    * The index position of the column PAGES in the table.
    */
    public static final int PAGES_IDX = 13 ;

    /**
              * <p> Document retlated to.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 14 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 15 ;

    /**
              * <p> Description about the sent fax.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FAX_DESCRIPTION= "FAX_DESCRIPTION" ;

    /*
    * The index position of the column FAX_DESCRIPTION in the table.
    */
    public static final int FAX_DESCRIPTION_IDX = 16 ;

    /**
              * <p> Member who sends the Document .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SENDER_ID= "SENDER_ID" ;

    /*
    * The index position of the column SENDER_ID in the table.
    */
    public static final int SENDER_ID_IDX = 17 ;

    /**
              * <p> Status of the notification.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_READ= "IS_READ" ;

    /*
    * The index position of the column IS_READ in the table.
    */
    public static final int IS_READ_IDX = 18 ;

    /**
              * <p> Cover Page FaxRemarks.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARKS= "REMARKS" ;

    /*
    * The index position of the column REMARKS in the table.
    */
    public static final int REMARKS_IDX = 19 ;

    /**
              * <p> Cover Page Reference .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE= "REFERENCE" ;

    /*
    * The index position of the column REFERENCE in the table.
    */
    public static final int REFERENCE_IDX = 20 ;

}
