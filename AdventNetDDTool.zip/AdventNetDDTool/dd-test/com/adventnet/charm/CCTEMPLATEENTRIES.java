package com.adventnet.charm;

/** <p> Description of the table <code>CCTemplateEntries</code>.
 *  Column Name and Table Name of  database table  <code>CCTemplateEntries</code> is mapped
 * as constants in this util.</p> 
  Mapping Chief Complaints Notes to the Template. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class CCTEMPLATEENTRIES
{
    private CCTEMPLATEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CCTemplateEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from Template table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Notes/Questions for the templates.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 3 ;

    /**
              * <p> Type of Notes like General/Introgative/Optional etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES_TYPE= "NOTES_TYPE" ;

    /*
    * The index position of the column NOTES_TYPE in the table.
    */
    public static final int NOTES_TYPE_IDX = 4 ;

    /**
              * <p> To indicate whether the question is a multi choice one or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MULTI_CHOICE= "IS_MULTI_CHOICE" ;

    /*
    * The index position of the column IS_MULTI_CHOICE in the table.
    */
    public static final int IS_MULTI_CHOICE_IDX = 5 ;

    /**
              * <p> From scale if the NOTES_TYPE is 'RatingScale'.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_SCALE= "FROM_SCALE" ;

    /*
    * The index position of the column FROM_SCALE in the table.
    */
    public static final int FROM_SCALE_IDX = 6 ;

    /**
              * <p> To scale if the NOTES_TYPE is 'RatingScale'.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_SCALE= "TO_SCALE" ;

    /*
    * The index position of the column TO_SCALE in the table.
    */
    public static final int TO_SCALE_IDX = 7 ;

    /**
              * <p> Entry order of Notes for a template.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 8 ;

}
