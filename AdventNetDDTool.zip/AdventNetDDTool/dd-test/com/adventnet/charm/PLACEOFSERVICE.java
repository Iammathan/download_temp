package com.adventnet.charm;

/** <p> Description of the table <code>PlaceOfService</code>.
 *  Column Name and Table Name of  database table  <code>PlaceOfService</code> is mapped
 * as constants in this util.</p> 
  Place of service where the treament taken. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SERVICE_ID}
  * </ul>
 */
 
public final class PLACEOFSERVICE
{
    private PLACEOFSERVICE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PlaceOfService" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_ID= "SERVICE_ID" ;

    /*
    * The index position of the column SERVICE_ID in the table.
    */
    public static final int SERVICE_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_NUMBER= "SERVICE_NUMBER" ;

    /*
    * The index position of the column SERVICE_NUMBER in the table.
    */
    public static final int SERVICE_NUMBER_IDX = 2 ;

    /**
              * <p> Service Place.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_PLACE= "SERVICE_PLACE" ;

    /*
    * The index position of the column SERVICE_PLACE in the table.
    */
    public static final int SERVICE_PLACE_IDX = 3 ;

}
