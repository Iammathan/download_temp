package com.adventnet.charm;

/** <p> Description of the table <code>DirectoryServicePatients</code>.
 *  Column Name and Table Name of  database table  <code>DirectoryServicePatients</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DIR_SERVICE_PATIENT_ID}
  * </ul>
 */
 
public final class DIRECTORYSERVICEPATIENTS
{
    private DIRECTORYSERVICEPATIENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DirectoryServicePatients" ;
    /**
              * <p> PK of DirectoryServicePatients.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DIR_SERVICE_PATIENT_ID= "DIR_SERVICE_PATIENT_ID" ;

    /*
    * The index position of the column DIR_SERVICE_PATIENT_ID in the table.
    */
    public static final int DIR_SERVICE_PATIENT_ID_IDX = 1 ;

    /**
              * <p> FK to DirectoryServicePractices.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DIR_SERVICE_PRACTICE_ID= "DIR_SERVICE_PRACTICE_ID" ;

    /*
    * The index position of the column DIR_SERVICE_PRACTICE_ID in the table.
    */
    public static final int DIR_SERVICE_PRACTICE_ID_IDX = 2 ;

    /**
              * <p> FK to PracticePatientsList.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Stores Practice Patient ID from Participant Account.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXTERNAL_PATIENT_ID= "EXTERNAL_PATIENT_ID" ;

    /*
    * The index position of the column EXTERNAL_PATIENT_ID in the table.
    */
    public static final int EXTERNAL_PATIENT_ID_IDX = 4 ;

}
