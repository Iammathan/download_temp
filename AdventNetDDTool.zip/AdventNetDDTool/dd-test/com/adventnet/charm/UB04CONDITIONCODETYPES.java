package com.adventnet.charm;

/** <p> Description of the table <code>UB04ConditionCodeTypes</code>.
 *  Column Name and Table Name of  database table  <code>UB04ConditionCodeTypes</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_COND_CODE_ID}
  * </ul>
 */
 
public final class UB04CONDITIONCODETYPES
{
    private UB04CONDITIONCODETYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04ConditionCodeTypes" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_COND_CODE_ID= "UB04_COND_CODE_ID" ;

    /*
    * The index position of the column UB04_COND_CODE_ID in the table.
    */
    public static final int UB04_COND_CODE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_CLAIM_ID= "UB04_CLAIM_ID" ;

    /*
    * The index position of the column UB04_CLAIM_ID in the table.
    */
    public static final int UB04_CLAIM_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SEQUENCE_NUMBER= "SEQUENCE_NUMBER" ;

    /*
    * The index position of the column SEQUENCE_NUMBER in the table.
    */
    public static final int SEQUENCE_NUMBER_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONDITION_CODE= "CONDITION_CODE" ;

    /*
    * The index position of the column CONDITION_CODE in the table.
    */
    public static final int CONDITION_CODE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONDITION_DESC= "CONDITION_DESC" ;

    /*
    * The index position of the column CONDITION_DESC in the table.
    */
    public static final int CONDITION_DESC_IDX = 5 ;

}
