package com.adventnet.charm;

/** <p> Description of the table <code>PharmacyIdentifiers</code>.
 *  Column Name and Table Name of  database table  <code>PharmacyIdentifiers</code> is mapped
 * as constants in this util.</p> 
  Pharmacy Identifiers being received from Surescripts on pharmacy download process. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PHARMACY_ID}
  * </ul>
 */
 
public final class PHARMACYIDENTIFIERS
{
    private PHARMACYIDENTIFIERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PharmacyIdentifiers" ;
    /**
              * <p> Maps PharmacyInfo to PharmacyList table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PHARMACY_ID= "PHARMACY_ID" ;

    /*
    * The index position of the column PHARMACY_ID in the table.
    */
    public static final int PHARMACY_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATE_LICENSE_NUMBER= "STATE_LICENSE_NUMBER" ;

    /*
    * The index position of the column STATE_LICENSE_NUMBER in the table.
    */
    public static final int STATE_LICENSE_NUMBER_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MEDICARE_NUMBER= "MEDICARE_NUMBER" ;

    /*
    * The index position of the column MEDICARE_NUMBER in the table.
    */
    public static final int MEDICARE_NUMBER_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MEDICAID_NUMBER= "MEDICAID_NUMBER" ;

    /*
    * The index position of the column MEDICAID_NUMBER in the table.
    */
    public static final int MEDICAID_NUMBER_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PPO_NUMBER= "PPO_NUMBER" ;

    /*
    * The index position of the column PPO_NUMBER in the table.
    */
    public static final int PPO_NUMBER_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYER_ID= "PAYER_ID" ;

    /*
    * The index position of the column PAYER_ID in the table.
    */
    public static final int PAYER_ID_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String BIN_LOCATION_NUMBER= "BIN_LOCATION_NUMBER" ;

    /*
    * The index position of the column BIN_LOCATION_NUMBER in the table.
    */
    public static final int BIN_LOCATION_NUMBER_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DEA_NUMBER= "DEA_NUMBER" ;

    /*
    * The index position of the column DEA_NUMBER in the table.
    */
    public static final int DEA_NUMBER_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String HIN= "HIN" ;

    /*
    * The index position of the column HIN in the table.
    */
    public static final int HIN_IDX = 11 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SECONDARY_COVERAGE= "SECONDARY_COVERAGE" ;

    /*
    * The index position of the column SECONDARY_COVERAGE in the table.
    */
    public static final int SECONDARY_COVERAGE_IDX = 12 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAIC_CODE= "NAIC_CODE" ;

    /*
    * The index position of the column NAIC_CODE in the table.
    */
    public static final int NAIC_CODE_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROMOTION_NUMBER= "PROMOTION_NUMBER" ;

    /*
    * The index position of the column PROMOTION_NUMBER in the table.
    */
    public static final int PROMOTION_NUMBER_IDX = 14 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SOCIAL_SECURITY= "SOCIAL_SECURITY" ;

    /*
    * The index position of the column SOCIAL_SECURITY in the table.
    */
    public static final int SOCIAL_SECURITY_IDX = 15 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRIOR_AUTHORIZATION= "PRIOR_AUTHORIZATION" ;

    /*
    * The index position of the column PRIOR_AUTHORIZATION in the table.
    */
    public static final int PRIOR_AUTHORIZATION_IDX = 16 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MUTUALLY_DEFINED= "MUTUALLY_DEFINED" ;

    /*
    * The index position of the column MUTUALLY_DEFINED in the table.
    */
    public static final int MUTUALLY_DEFINED_IDX = 17 ;

}
