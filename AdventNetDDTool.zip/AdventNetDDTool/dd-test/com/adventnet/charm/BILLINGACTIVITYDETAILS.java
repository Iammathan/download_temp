package com.adventnet.charm;

/** <p> Description of the table <code>BillingActivityDetails</code>.
 *  Column Name and Table Name of  database table  <code>BillingActivityDetails</code> is mapped
 * as constants in this util.</p> 
  All activities of billing entities (Invoice, receipt, claim nd EOB) will be stored in this table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACTIVITY_ID}
  * </ul>
 */
 
public final class BILLINGACTIVITYDETAILS
{
    private BILLINGACTIVITYDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillingActivityDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTIVITY_ID= "ACTIVITY_ID" ;

    /*
    * The index position of the column ACTIVITY_ID in the table.
    */
    public static final int ACTIVITY_ID_IDX = 1 ;

    /**
              * <p> Bill_id/ Receipt_id/ Claim_id/ EOB_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENTITY_ID= "ENTITY_ID" ;

    /*
    * The index position of the column ENTITY_ID in the table.
    */
    public static final int ENTITY_ID_IDX = 2 ;

    /**
              * <p> Patient Id of the entiry.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Name of the entity : Invoice/Receipt/Claim/EOB.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENTITY_NAME= "ENTITY_NAME" ;

    /*
    * The index position of the column ENTITY_NAME in the table.
    */
    public static final int ENTITY_NAME_IDX = 4 ;

    /**
              * <p> Invoice#/ Receipt#/ EOB#.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENTITY_DISPLAY_ID= "ENTITY_DISPLAY_ID" ;

    /*
    * The index position of the column ENTITY_DISPLAY_ID in the table.
    */
    public static final int ENTITY_DISPLAY_ID_IDX = 5 ;

    /**
              * <p> Member's Name who has did the action.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

    /**
              * <p> timestamp of action.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 7 ;

    /**
              * <p> Activity details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACTION= "ACTION" ;

    /*
    * The index position of the column ACTION in the table.
    */
    public static final int ACTION_IDX = 8 ;

    /**
              * <p> Type of action: WRITE/MODIFY/DELETE.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACTION_TYPE= "ACTION_TYPE" ;

    /*
    * The index position of the column ACTION_TYPE in the table.
    */
    public static final int ACTION_TYPE_IDX = 9 ;

    /**
              * <p> Used to identitfy whether activity is a duplicated one. Duplicated ones will be excluded in daily sheet report.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_PRIMARY_ENTRY= "IS_PRIMARY_ENTRY" ;

    /*
    * The index position of the column IS_PRIMARY_ENTRY in the table.
    */
    public static final int IS_PRIMARY_ENTRY_IDX = 10 ;

    /**
              * <p> Used to identitfy activities that are financially related to patient/practice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_FINANCE_RELATED= "IS_FINANCE_RELATED" ;

    /*
    * The index position of the column IS_FINANCE_RELATED in the table.
    */
    public static final int IS_FINANCE_RELATED_IDX = 11 ;

    /**
              * <p> Used to identitfy whether notes is added by user or my system.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_USER_NOTES= "IS_USER_NOTES" ;

    /*
    * The index position of the column IS_USER_NOTES in the table.
    */
    public static final int IS_USER_NOTES_IDX = 12 ;

    /**
              * <p> This column specifies whether the activity is done after hard-closing or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>FALSE</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_HARD_CLOSED_ACTIVITY= "IS_HARD_CLOSED_ACTIVITY" ;

    /*
    * The index position of the column IS_HARD_CLOSED_ACTIVITY in the table.
    */
    public static final int IS_HARD_CLOSED_ACTIVITY_IDX = 13 ;

    /**
              * <p> Identifier of facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 14 ;

}
