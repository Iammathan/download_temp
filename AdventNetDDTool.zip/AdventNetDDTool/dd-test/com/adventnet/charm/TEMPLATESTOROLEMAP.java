package com.adventnet.charm;

/** <p> Description of the table <code>TemplatesToRoleMap</code>.
 *  Column Name and Table Name of  database table  <code>TemplatesToRoleMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between PhysicianTemplates and Roles table to define while templates to be loaded for which role . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TEMPLATE_TO_ROLE_MAP_ID}
  * </ul>
 */
 
public final class TEMPLATESTOROLEMAP
{
    private TEMPLATESTOROLEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TemplatesToRoleMap" ;
    /**
              * <p> PK identity.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_TO_ROLE_MAP_ID= "TEMPLATE_TO_ROLE_MAP_ID" ;

    /*
    * The index position of the column TEMPLATE_TO_ROLE_MAP_ID in the table.
    */
    public static final int TEMPLATE_TO_ROLE_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Template from PhysicianTemplates.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Identifier of provider's Role.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ROLE_ID= "ROLE_ID" ;

    /*
    * The index position of the column ROLE_ID in the table.
    */
    public static final int ROLE_ID_IDX = 3 ;

}
