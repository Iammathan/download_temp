package com.adventnet.charm;

/** <p> Description of the table <code>BillItemProductDetailsExt</code>.
 *  Column Name and Table Name of  database table  <code>BillItemProductDetailsExt</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_PRODUCT_DETAILS_EXT_ID}
  * </ul>
 */
 
public final class BILLITEMPRODUCTDETAILSEXT
{
    private BILLITEMPRODUCTDETAILSEXT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillItemProductDetailsExt" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_PRODUCT_DETAILS_EXT_ID= "BILL_PRODUCT_DETAILS_EXT_ID" ;

    /*
    * The index position of the column BILL_PRODUCT_DETAILS_EXT_ID in the table.
    */
    public static final int BILL_PRODUCT_DETAILS_EXT_ID_IDX = 1 ;

    /**
              * <p> BILL_ITEM_PRODUCT_DETAILS_ID of BillItemProductDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ITEM_PRODUCT_DETAILS_ID= "BILL_ITEM_PRODUCT_DETAILS_ID" ;

    /*
    * The index position of the column BILL_ITEM_PRODUCT_DETAILS_ID in the table.
    */
    public static final int BILL_ITEM_PRODUCT_DETAILS_ID_IDX = 2 ;

    /**
              * <p> BILL_ITEM_ID of BillDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ITEM_ID= "BILL_ITEM_ID" ;

    /*
    * The index position of the column BILL_ITEM_ID in the table.
    */
    public static final int BILL_ITEM_ID_IDX = 3 ;

    /**
              * <p> Generic NDC Code of the Product.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>12</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NDC_CODE= "NDC_CODE" ;

    /*
    * The index position of the column NDC_CODE in the table.
    */
    public static final int NDC_CODE_IDX = 4 ;

    /**
              * <p> Product code number .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>6</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE_NUMBER= "CODE_NUMBER" ;

    /*
    * The index position of the column CODE_NUMBER in the table.
    */
    public static final int CODE_NUMBER_IDX = 5 ;

    /**
              * <p> Product code description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE_DESC= "CODE_DESC" ;

    /*
    * The index position of the column CODE_DESC in the table.
    */
    public static final int CODE_DESC_IDX = 6 ;

    /**
              * <p> NDC Units Measurement of the Product.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NDC_UNITS_MEASUREMENT= "NDC_UNITS_MEASUREMENT" ;

    /*
    * The index position of the column NDC_UNITS_MEASUREMENT in the table.
    */
    public static final int NDC_UNITS_MEASUREMENT_IDX = 7 ;

}
