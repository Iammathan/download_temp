package com.adventnet.charm;

/** <p> Description of the table <code>TargetMasteryData</code>.
 *  Column Name and Table Name of  database table  <code>TargetMasteryData</code> is mapped
 * as constants in this util.</p> 
  Target's mastery data. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TGT_MASTERY_DATA_ID}
  * </ul>
 */
 
public final class TARGETMASTERYDATA
{
    private TARGETMASTERYDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TargetMasteryData" ;
    /**
              * <p> Unique Identifier of a Target Mastery Data.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TGT_MASTERY_DATA_ID= "TGT_MASTERY_DATA_ID" ;

    /*
    * The index position of the column TGT_MASTERY_DATA_ID in the table.
    */
    public static final int TGT_MASTERY_DATA_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of a Target.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TARGET_ID= "TARGET_ID" ;

    /*
    * The index position of the column TARGET_ID in the table.
    */
    public static final int TARGET_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Session identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SESSION_ID= "SESSION_ID" ;

    /*
    * The index position of the column SESSION_ID in the table.
    */
    public static final int SESSION_ID_IDX = 4 ;

    /**
              * <p> Unique Identifier of a Program Trial.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROG_TRIAL_ID= "PROG_TRIAL_ID" ;

    /*
    * The index position of the column PROG_TRIAL_ID in the table.
    */
    public static final int PROG_TRIAL_ID_IDX = 5 ;

    /**
              * <p> Percentage score in a session.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PERCENTAGE= "PERCENTAGE" ;

    /*
    * The index position of the column PERCENTAGE in the table.
    */
    public static final int PERCENTAGE_IDX = 6 ;

    /**
              * <p> Total number of trials taken in the session.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRIAL_COUNT= "TRIAL_COUNT" ;

    /*
    * The index position of the column TRIAL_COUNT in the table.
    */
    public static final int TRIAL_COUNT_IDX = 7 ;

    /**
              * <p> Status of this Session or Trial PASSED/FAILED/IGNORED. .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 8 ;

}
