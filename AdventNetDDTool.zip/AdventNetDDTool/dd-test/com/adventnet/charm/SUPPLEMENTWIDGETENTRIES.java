package com.adventnet.charm;

/** <p> Description of the table <code>SupplementWidgetEntries</code>.
 *  Column Name and Table Name of  database table  <code>SupplementWidgetEntries</code> is mapped
 * as constants in this util.</p> 
  Supplements added for a Questionnaire through PHR. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SUPPLEMENT_WIDGET_ENTRIES_ID}
  * </ul>
 */
 
public final class SUPPLEMENTWIDGETENTRIES
{
    private SUPPLEMENTWIDGETENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SupplementWidgetEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SUPPLEMENT_WIDGET_ENTRIES_ID= "SUPPLEMENT_WIDGET_ENTRIES_ID" ;

    /*
    * The index position of the column SUPPLEMENT_WIDGET_ENTRIES_ID in the table.
    */
    public static final int SUPPLEMENT_WIDGET_ENTRIES_ID_IDX = 1 ;

    /**
              * <p> Name of the supplement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUPPLEMENT_NAME= "SUPPLEMENT_NAME" ;

    /*
    * The index position of the column SUPPLEMENT_NAME in the table.
    */
    public static final int SUPPLEMENT_NAME_IDX = 2 ;

    /**
              * <p> Unique identifier for the Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Intake details of the supplement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTAKE_DETAILS= "INTAKE_DETAILS" ;

    /*
    * The index position of the column INTAKE_DETAILS in the table.
    */
    public static final int INTAKE_DETAILS_IDX = 4 ;

    /**
              * <p> Time of entry in milliseconds.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 5 ;

    /**
              * <p> 0=Pending, 1=Reconciled, 2=Ignored.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                     * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RECONCILE_STATUS= "RECONCILE_STATUS" ;

    /*
    * The index position of the column RECONCILE_STATUS in the table.
    */
    public static final int RECONCILE_STATUS_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SOURCE= "SOURCE" ;

    /*
    * The index position of the column SOURCE in the table.
    */
    public static final int SOURCE_IDX = 7 ;

    /**
              * <p> PK from PatientSupplements.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_SUPPLEMENT_ID= "PATIENT_SUPPLEMENT_ID" ;

    /*
    * The index position of the column PATIENT_SUPPLEMENT_ID in the table.
    */
    public static final int PATIENT_SUPPLEMENT_ID_IDX = 8 ;

    /**
              * <p> Start Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 9 ;

}
