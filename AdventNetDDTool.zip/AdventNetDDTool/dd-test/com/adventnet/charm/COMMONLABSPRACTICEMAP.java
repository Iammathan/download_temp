package com.adventnet.charm;

/** <p> Description of the table <code>CommonLabsPracticeMap</code>.
 *  Column Name and Table Name of  database table  <code>CommonLabsPracticeMap</code> is mapped
 * as constants in this util.</p> 
  Mapping publicSpace labs to practice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #COMMON_LAB_ID}
  * </ul>
 */
 
public final class COMMONLABSPRACTICEMAP
{
    private COMMONLABSPRACTICEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CommonLabsPracticeMap" ;
    /**
              * <p> Unique identifier in CommonLabsPracticeMap.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COMMON_LAB_ID= "COMMON_LAB_ID" ;

    /*
    * The index position of the column COMMON_LAB_ID in the table.
    */
    public static final int COMMON_LAB_ID_IDX = 1 ;

    /**
              * <p> Lab Record Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 2 ;

    /**
              * <p> should it be visible to the practice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String SHARED_STATUS= "SHARED_STATUS" ;

    /*
    * The index position of the column SHARED_STATUS in the table.
    */
    public static final int SHARED_STATUS_IDX = 3 ;

    /**
              * <p> comments.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 4 ;

}
