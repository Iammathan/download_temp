package com.adventnet.charm;

/** <p> Description of the table <code>AutomatedMeasureRequest2015</code>.
 *  Column Name and Table Name of  database table  <code>AutomatedMeasureRequest2015</code> is mapped
 * as constants in this util.</p> 
  To store each request of 2015 automated measure generation for the scheduler. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AUTOMATED_MEASURE_REQUEST_2015_ID}
  * </ul>
 */
 
public final class AUTOMATEDMEASUREREQUEST2015
{
    private AUTOMATEDMEASUREREQUEST2015()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AutomatedMeasureRequest2015" ;
    /**
              * <p> Unique id for AutomatedMeasureRequest2015 table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AUTOMATED_MEASURE_REQUEST_2015_ID= "AUTOMATED_MEASURE_REQUEST_2015_ID" ;

    /*
    * The index position of the column AUTOMATED_MEASURE_REQUEST_2015_ID in the table.
    */
    public static final int AUTOMATED_MEASURE_REQUEST_2015_ID_IDX = 1 ;

    /**
              * <p> Stage of report generation i.e. Modified Stage 2/Stage 3/ACI Transition/ACI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STAGE= "STAGE" ;

    /*
    * The index position of the column STAGE in the table.
    */
    public static final int STAGE_IDX = 2 ;

    /**
              * <p> Identifier of Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Individual/Group. This will be used for ACI and ACi Transition stage.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBMISSION_TYPE= "SUBMISSION_TYPE" ;

    /*
    * The index position of the column SUBMISSION_TYPE in the table.
    */
    public static final int SUBMISSION_TYPE_IDX = 4 ;

    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 5 ;

    /**
              * <p> List of MEMBER_ID seperated by comma for ACI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID_LIST= "MEMBER_ID_LIST" ;

    /*
    * The index position of the column MEMBER_ID_LIST in the table.
    */
    public static final int MEMBER_ID_LIST_IDX = 6 ;

    /**
              * <p> Time of at which request was submitted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_REQUEST= "TIME_OF_REQUEST" ;

    /*
    * The index position of the column TIME_OF_REQUEST in the table.
    */
    public static final int TIME_OF_REQUEST_IDX = 7 ;

    /**
              * <p> Staring date of the reporting period.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 8 ;

    /**
              * <p> Ending date of the reporting period.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 9 ;

    /**
              * <p> Status of report generation Pending / Completed.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 10 ;

}
