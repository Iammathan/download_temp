package com.adventnet.charm;

/** <p> Description of the table <code>NotificationModules</code>.
 *  Column Name and Table Name of  database table  <code>NotificationModules</code> is mapped
 * as constants in this util.</p> 
  Pincode details for Indian Practices. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #NOTIFICATION_MOD_ID}
  * </ul>
 */
 
public final class NOTIFICATIONMODULES
{
    private NOTIFICATIONMODULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "NotificationModules" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NOTIFICATION_MOD_ID= "NOTIFICATION_MOD_ID" ;

    /*
    * The index position of the column NOTIFICATION_MOD_ID in the table.
    */
    public static final int NOTIFICATION_MOD_ID_IDX = 1 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MODULE_NAME= "MODULE_NAME" ;

    /*
    * The index position of the column MODULE_NAME in the table.
    */
    public static final int MODULE_NAME_IDX = 2 ;

}
