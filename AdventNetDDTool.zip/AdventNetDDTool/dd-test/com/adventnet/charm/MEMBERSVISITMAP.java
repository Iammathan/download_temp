package com.adventnet.charm;

/** <p> Description of the table <code>MembersVisitMap</code>.
 *  Column Name and Table Name of  database table  <code>MembersVisitMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between PracticeMembers and VisitTypes (1 to N Mapping). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEMBER_VISIT_ID}
  * </ul>
 */
 
public final class MEMBERSVISITMAP
{
    private MEMBERSVISITMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MembersVisitMap" ;
    /**
              * <p> Unique value generator.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_VISIT_ID= "MEMBER_VISIT_ID" ;

    /*
    * The index position of the column MEMBER_VISIT_ID in the table.
    */
    public static final int MEMBER_VISIT_ID_IDX = 1 ;

    /**
              * <p> Identifier of Practice Member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Identifier of VisitType.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 3 ;

    /**
              * <p> Duration of visit type for the member in directory service.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DURATION= "DURATION" ;

    /*
    * The index position of the column DURATION in the table.
    */
    public static final int DURATION_IDX = 4 ;

    /**
              * <p> Fee for member in directory service.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FEE= "FEE" ;

    /*
    * The index position of the column FEE in the table.
    */
    public static final int FEE_IDX = 5 ;

    /**
              * <p> The next Date on which this provider is availble.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NEXT_AVAILABLE_DATE= "NEXT_AVAILABLE_DATE" ;

    /*
    * The index position of the column NEXT_AVAILABLE_DATE in the table.
    */
    public static final int NEXT_AVAILABLE_DATE_IDX = 6 ;

    /**
              * <p> Slots for the next availability date in JSON Format.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String AVAILABLE_SLOTS= "AVAILABLE_SLOTS" ;

    /*
    * The index position of the column AVAILABLE_SLOTS in the table.
    */
    public static final int AVAILABLE_SLOTS_IDX = 7 ;

    /**
              * <p> whether this membersvisitmap row is related to directory service or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DIRECTORY_SERVICE= "IS_DIRECTORY_SERVICE" ;

    /*
    * The index position of the column IS_DIRECTORY_SERVICE in the table.
    */
    public static final int IS_DIRECTORY_SERVICE_IDX = 8 ;

}
