package com.adventnet.charm;

/** <p> Description of the table <code>ReferralTransmission</code>.
 *  Column Name and Table Name of  database table  <code>ReferralTransmission</code> is mapped
 * as constants in this util.</p> 
  Referral Transmission. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REF_TRANS_ID}
  * </ul>
 */
 
public final class REFERRALTRANSMISSION
{
    private REFERRALTRANSMISSION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ReferralTransmission" ;
    /**
              * <p> Unique value generator.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_TRANS_ID= "REF_TRANS_ID" ;

    /*
    * The index position of the column REF_TRANS_ID in the table.
    */
    public static final int REF_TRANS_ID_IDX = 1 ;

    /**
              * <p> Identifier of Referral In.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_IN_ID= "REF_IN_ID" ;

    /*
    * The index position of the column REF_IN_ID in the table.
    */
    public static final int REF_IN_ID_IDX = 2 ;

    /**
              * <p> Identifier of Referral Out.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_OUT_ID= "REF_OUT_ID" ;

    /*
    * The index position of the column REF_OUT_ID in the table.
    */
    public static final int REF_OUT_ID_IDX = 3 ;

    /**
              * <p> data type is not boolean;0-SMTP_EDGE, 1-Fax,2-Direct.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String TRANSMISSION_TYPE= "TRANSMISSION_TYPE" ;

    /*
    * The index position of the column TRANSMISSION_TYPE in the table.
    */
    public static final int TRANSMISSION_TYPE_IDX = 4 ;

    /**
              * <p> Time of the Transmission.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 5 ;

    /**
              * <p> Message about transmission.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MESSAGE= "MESSAGE" ;

    /*
    * The index position of the column MESSAGE in the table.
    */
    public static final int MESSAGE_IDX = 6 ;

    /**
              * <p> Direct message Id.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DIRECT_MESSAGE_ID= "DIRECT_MESSAGE_ID" ;

    /*
    * The index position of the column DIRECT_MESSAGE_ID in the table.
    */
    public static final int DIRECT_MESSAGE_ID_IDX = 7 ;

    /**
              * <p> Direct msg status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DIRECT_MESSAGE_STATUS= "DIRECT_MESSAGE_STATUS" ;

    /*
    * The index position of the column DIRECT_MESSAGE_STATUS in the table.
    */
    public static final int DIRECT_MESSAGE_STATUS_IDX = 8 ;

    /**
              * <p> Fax Details Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FAXDETAILS_ID= "FAXDETAILS_ID" ;

    /*
    * The index position of the column FAXDETAILS_ID in the table.
    */
    public static final int FAXDETAILS_ID_IDX = 9 ;

}
