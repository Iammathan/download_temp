package com.adventnet.charm;

/** <p> Description of the table <code>DrugDetailsExt</code>.
 *  Column Name and Table Name of  database table  <code>DrugDetailsExt</code> is mapped
 * as constants in this util.</p> 
  Maintains ndc, csa and drug type details for custom drugs. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DRUG_DETAILS_EXTENSION_ID}
  * </ul>
 */
 
public final class DRUGDETAILSEXT
{
    private DRUGDETAILSEXT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DrugDetailsExt" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DRUG_DETAILS_EXTENSION_ID= "DRUG_DETAILS_EXTENSION_ID" ;

    /*
    * The index position of the column DRUG_DETAILS_EXTENSION_ID in the table.
    */
    public static final int DRUG_DETAILS_EXTENSION_ID_IDX = 1 ;

    /**
              * <p> Unique identifier from drug details table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DRUGDETAILS_ID= "DRUGDETAILS_ID" ;

    /*
    * The index position of the column DRUGDETAILS_ID in the table.
    */
    public static final int DRUGDETAILS_ID_IDX = 2 ;

    /**
              * <p> Drug type fo the scustom drug.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_TYPE= "DRUG_TYPE" ;

    /*
    * The index position of the column DRUG_TYPE in the table.
    */
    public static final int DRUG_TYPE_IDX = 3 ;

    /**
              * <p> csa of custom drug if present.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CSA= "CSA" ;

    /*
    * The index position of the column CSA in the table.
    */
    public static final int CSA_IDX = 4 ;

    /**
              * <p> ndc of custom drug if present.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>11</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NDC= "NDC" ;

    /*
    * The index position of the column NDC in the table.
    */
    public static final int NDC_IDX = 5 ;

}
