package com.adventnet.charm;

/** <p> Description of the table <code>QuickBooksDetails</code>.
 *  Column Name and Table Name of  database table  <code>QuickBooksDetails</code> is mapped
 * as constants in this util.</p> 
  QuickBooks Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #QB_SETTINGS_ID}
  * </ul>
 */
 
public final class QUICKBOOKSDETAILS
{
    private QUICKBOOKSDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QuickBooksDetails" ;
    /**
              * <p> QuickBooks ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QB_SETTINGS_ID= "QB_SETTINGS_ID" ;

    /*
    * The index position of the column QB_SETTINGS_ID in the table.
    */
    public static final int QB_SETTINGS_ID_IDX = 1 ;

    /**
              * <p> Is QuickBooks Enabled.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ENABLED= "IS_ENABLED" ;

    /*
    * The index position of the column IS_ENABLED in the table.
    */
    public static final int IS_ENABLED_IDX = 2 ;

    /**
              * <p> API key.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String API_KEY= "API_KEY" ;

    /*
    * The index position of the column API_KEY in the table.
    */
    public static final int API_KEY_IDX = 3 ;

    /**
              * <p> QuickBooks Version (Online or Desktop).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_QB_ONLINE= "IS_QB_ONLINE" ;

    /*
    * The index position of the column IS_QB_ONLINE in the table.
    */
    public static final int IS_QB_ONLINE_IDX = 4 ;

    /**
              * <p> Time of Request.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUESTED_TIME= "REQUESTED_TIME" ;

    /*
    * The index position of the column REQUESTED_TIME in the table.
    */
    public static final int REQUESTED_TIME_IDX = 5 ;

    /**
              * <p> Addons Requested by.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUESTED_BY= "REQUESTED_BY" ;

    /*
    * The index position of the column REQUESTED_BY in the table.
    */
    public static final int REQUESTED_BY_IDX = 6 ;

    /**
              * <p> Addons Requested by.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPROVED_TIME= "APPROVED_TIME" ;

    /*
    * The index position of the column APPROVED_TIME in the table.
    */
    public static final int APPROVED_TIME_IDX = 7 ;

    /**
              * <p> Addons Requested by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String APPROVED_BY= "APPROVED_BY" ;

    /*
    * The index position of the column APPROVED_BY in the table.
    */
    public static final int APPROVED_BY_IDX = 8 ;

    /**
              * <p> Addons disabled by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISABLED_BY= "DISABLED_BY" ;

    /*
    * The index position of the column DISABLED_BY in the table.
    */
    public static final int DISABLED_BY_IDX = 9 ;

    /**
              * <p> Disabled at.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DISABLED_TIME= "DISABLED_TIME" ;

    /*
    * The index position of the column DISABLED_TIME in the table.
    */
    public static final int DISABLED_TIME_IDX = 10 ;

}
