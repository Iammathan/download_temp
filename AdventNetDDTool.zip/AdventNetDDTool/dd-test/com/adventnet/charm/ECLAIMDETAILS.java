package com.adventnet.charm;

/** <p> Description of the table <code>EClaimDetails</code>.
 *  Column Name and Table Name of  database table  <code>EClaimDetails</code> is mapped
 * as constants in this util.</p> 
  It stores additional claim data required for eClaim(837P). For each claim this table will have data only if ECLAIM enabled that claim's practies and they have entered these additional detail. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ECLAIM_DETAILS_ID}
  * </ul>
 */
 
public final class ECLAIMDETAILS
{
    private ECLAIMDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EClaimDetails" ;
    /**
              * <p> Unquie ID(PK) provided by Mickey(SAS).</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_DETAILS_ID= "ECLAIM_DETAILS_ID" ;

    /*
    * The index position of the column ECLAIM_DETAILS_ID in the table.
    */
    public static final int ECLAIM_DETAILS_ID_IDX = 1 ;

    /**
              * <p> PK of the ClaimCompleteDetails table, which is the parent/main table for claim details.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> PK of the ClaimProviderDetails, where this claim's submitter detail is stored with type as 'eclaimsubmitter' (LOOP 1000A :: #74).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_SUBMITTER_ID= "ECLAIM_SUBMITTER_ID" ;

    /*
    * The index position of the column ECLAIM_SUBMITTER_ID in the table.
    */
    public static final int ECLAIM_SUBMITTER_ID_IDX = 3 ;

    /**
              * <p> Practice(Claim submitter)'s ETIN value  provided by Optum.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OPTUM_ETIN_VALUE= "OPTUM_ETIN_VALUE" ;

    /*
    * The index position of the column OPTUM_ETIN_VALUE in the table.
    */
    public static final int OPTUM_ETIN_VALUE_IDX = 4 ;

    /**
              * <p> PK of ClaimProviderDetails, where Pay-to-Address(provider) detail is stored with type as 'paytoaddress'. This will be available when payment address is different than Billing Provider address [LOOP 2010AB :: X222.pdf #101].</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAY_TO_ADDRESS_ID= "PAY_TO_ADDRESS_ID" ;

    /*
    * The index position of the column PAY_TO_ADDRESS_ID in the table.
    */
    public static final int PAY_TO_ADDRESS_ID_IDX = 5 ;

    /**
              * <p> A bool to indicate whether patient is deceased. Default value is false. If it is 'true' then we will get patient's  DECEASED_DATE(death date) and it will be sent in eClaim(837P).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PATIENT_DECEASED= "IS_PATIENT_DECEASED" ;

    /*
    * The index position of the column IS_PATIENT_DECEASED in the table.
    */
    public static final int IS_PATIENT_DECEASED_IDX = 6 ;

    /**
              * <p> Deceased date(death date) if patient is deceased and the date is known. This field may have value  when IS_PATIENT_DECEASED is true.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DECEASED_DATE= "DECEASED_DATE" ;

    /*
    * The index position of the column DECEASED_DATE in the table.
    */
    public static final int DECEASED_DATE_IDX = 7 ;

    /**
              * <p> Weight of the patient in pounds, when the consultation for this claim is happened.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WEIGHT= "WEIGHT" ;

    /*
    * The index position of the column WEIGHT in the table.
    */
    public static final int WEIGHT_IDX = 8 ;

    /**
              * <p> A bool to indicate whether patient is pregnant during this claim's consultation. If it is true then 'Y' will be sent in eClaim(837P).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PREGNANT= "IS_PREGNANT" ;

    /*
    * The index position of the column IS_PREGNANT in the table.
    */
    public static final int IS_PREGNANT_IDX = 9 ;

    /**
              * <p> Required on Early and Periodic Screening, Diagnostic, and Treatment (EPSDT) claims when the screening service is being billed. If 'N' is selected then EPSDT_COND_INDICATOR_1 must have 'NU' (LOOP 2300 :: CRC02 : EPSDT REFERRAL :: #223).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>Y</code></li>
              * <li><code>N</code></li>
              * </ul>
                         */
    public static final String IS_EPSDT_REFERRAL_GIVEN= "IS_EPSDT_REFERRAL_GIVEN" ;

    /*
    * The index position of the column IS_EPSDT_REFERRAL_GIVEN in the table.
    */
    public static final int IS_EPSDT_REFERRAL_GIVEN_IDX = 10 ;

    /**
              * <p> Code indicating the condition of the EPSDT Referral". Allowed values are 'AV' , 'NU' , 'S2' , 'ST' (LOOP 2300 :: CRC03 : EPSDT REFERRAL-#224).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>AV</code></li>
              * <li><code>NU</code></li>
              * <li><code>S2</code></li>
              * <li><code>ST</code></li>
              * </ul>
                         */
    public static final String EPSDT_COND_INDICATOR_1= "EPSDT_COND_INDICATOR_1" ;

    /*
    * The index position of the column EPSDT_COND_INDICATOR_1 in the table.
    */
    public static final int EPSDT_COND_INDICATOR_1_IDX = 11 ;

    /**
              * <p> Code indicating the condition of the EPSDT Referral". Allowed values are 'AV' , 'NU' , 'S2' , 'ST' (LOOP 2300 :: CRC04 : EPSDT REFERRAL-#224).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>AV</code></li>
              * <li><code>NU</code></li>
              * <li><code>S2</code></li>
              * <li><code>ST</code></li>
              * </ul>
                         */
    public static final String EPSDT_COND_INDICATOR_2= "EPSDT_COND_INDICATOR_2" ;

    /*
    * The index position of the column EPSDT_COND_INDICATOR_2 in the table.
    */
    public static final int EPSDT_COND_INDICATOR_2_IDX = 12 ;

    /**
              * <p> Code indicating the condition of the EPSDT Referral". Allowed values are 'AV' , 'NU' , 'S2' , 'ST' (LOOP 2300 :: CRC05 : EPSDT REFERRAL-#225).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>AV</code></li>
              * <li><code>NU</code></li>
              * <li><code>S2</code></li>
              * <li><code>ST</code></li>
              * </ul>
                         */
    public static final String EPSDT_COND_INDICATOR_3= "EPSDT_COND_INDICATOR_3" ;

    /*
    * The index position of the column EPSDT_COND_INDICATOR_3 in the table.
    */
    public static final int EPSDT_COND_INDICATOR_3_IDX = 13 ;

    /**
              * <p> 837P :: LOOP 2300 :: CLM10 - CMS1500 #--; Allowed value is P; Not used in CMS - Indicates whether Patient and/or Insured's signature obtained directly. If directly obtained value will be EMPTY/NULL; Else, value will be 'P'.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>P</code></li>
              * </ul>
                         */
    public static final String PATIENT_INSURED_SIGN_SRC_CODE= "PATIENT_INSURED_SIGN_SRC_CODE" ;

    /*
    * The index position of the column PATIENT_INSURED_SIGN_SRC_CODE in the table.
    */
    public static final int PATIENT_INSURED_SIGN_SRC_CODE_IDX = 14 ;

    /**
              * <p> Code indicating the Special Program, under which the services rendered to the patient, were performed (837P - X222.pdf #162 CLM12).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>02</code></li>
              * <li><code>03</code></li>
              * <li><code>05</code></li>
              * <li><code>09</code></li>
              * </ul>
                         */
    public static final String SPECIAL_PROGRAM_INDICATOR= "SPECIAL_PROGRAM_INDICATOR" ;

    /*
    * The index position of the column SPECIAL_PROGRAM_INDICATOR in the table.
    */
    public static final int SPECIAL_PROGRAM_INDICATOR_IDX = 15 ;

    /**
              * <p> Code indicating the reason why the claim submission delayed(837P - X222.pdf #162 CLM20).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * <li><code>6</code></li>
              * <li><code>7</code></li>
              * <li><code>8</code></li>
              * <li><code>9</code></li>
              * <li><code>10</code></li>
              * <li><code>11</code></li>
              * <li><code>15</code></li>
              * </ul>
                         */
    public static final String DELAY_REASON_CODE= "DELAY_REASON_CODE" ;

    /*
    * The index position of the column DELAY_REASON_CODE in the table.
    */
    public static final int DELAY_REASON_CODE_IDX = 16 ;

}
