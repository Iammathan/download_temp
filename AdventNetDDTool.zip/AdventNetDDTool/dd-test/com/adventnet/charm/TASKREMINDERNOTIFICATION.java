package com.adventnet.charm;

/** <p> Description of the table <code>TaskReminderNotification</code>.
 *  Column Name and Table Name of  database table  <code>TaskReminderNotification</code> is mapped
 * as constants in this util.</p> 
  Task Notification Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TASK_NOTIFICATION_ID}
  * </ul>
 */
 
public final class TASKREMINDERNOTIFICATION
{
    private TASKREMINDERNOTIFICATION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TaskReminderNotification" ;
    /**
              * <p> Unique Identifier  .</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TASK_NOTIFICATION_ID= "TASK_NOTIFICATION_ID" ;

    /*
    * The index position of the column TASK_NOTIFICATION_ID in the table.
    */
    public static final int TASK_NOTIFICATION_ID_IDX = 1 ;

    /**
              * <p> Practice member Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> weather task reminder email to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String TASK_REMINDER_EMAIL= "TASK_REMINDER_EMAIL" ;

    /*
    * The index position of the column TASK_REMINDER_EMAIL in the table.
    */
    public static final int TASK_REMINDER_EMAIL_IDX = 3 ;

    /**
              * <p> weather task reminder message to be send or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String TASK_REMINDER_MESSAGE= "TASK_REMINDER_MESSAGE" ;

    /*
    * The index position of the column TASK_REMINDER_MESSAGE in the table.
    */
    public static final int TASK_REMINDER_MESSAGE_IDX = 4 ;

    /**
              * <p> weather task assigned message to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String TASK_ASSIGNED_MESSAGE= "TASK_ASSIGNED_MESSAGE" ;

    /*
    * The index position of the column TASK_ASSIGNED_MESSAGE in the table.
    */
    public static final int TASK_ASSIGNED_MESSAGE_IDX = 5 ;

    /**
              * <p> weather task completed message to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String TASK_COMPLETED_MESSAGE= "TASK_COMPLETED_MESSAGE" ;

    /*
    * The index position of the column TASK_COMPLETED_MESSAGE in the table.
    */
    public static final int TASK_COMPLETED_MESSAGE_IDX = 6 ;

    /**
              * <p> Task sorting by created date or due date.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                     * Default Value is <code>CrDate</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>CrDate</code>" , 
       * will be taken.<br>
                         */
    public static final String SORT_TASKS_BY= "SORT_TASKS_BY" ;

    /*
    * The index position of the column SORT_TASKS_BY in the table.
    */
    public static final int SORT_TASKS_BY_IDX = 7 ;

}
