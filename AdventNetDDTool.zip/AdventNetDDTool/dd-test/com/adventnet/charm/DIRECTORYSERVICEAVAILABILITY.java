package com.adventnet.charm;

/** <p> Description of the table <code>DirectoryServiceAvailability</code>.
 *  Column Name and Table Name of  database table  <code>DirectoryServiceAvailability</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DIR_SERVICE_AVAILABILITY_ID}
  * </ul>
 */
 
public final class DIRECTORYSERVICEAVAILABILITY
{
    private DIRECTORYSERVICEAVAILABILITY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DirectoryServiceAvailability" ;
    /**
              * <p> PK of DirectoryServiceAvailability.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DIR_SERVICE_AVAILABILITY_ID= "DIR_SERVICE_AVAILABILITY_ID" ;

    /*
    * The index position of the column DIR_SERVICE_AVAILABILITY_ID in the table.
    */
    public static final int DIR_SERVICE_AVAILABILITY_ID_IDX = 1 ;

    /**
              * <p> FK to PracticeMembersList.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> FK to MembersVisitMap.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_VISIT_ID= "MEMBER_VISIT_ID" ;

    /*
    * The index position of the column MEMBER_VISIT_ID in the table.
    */
    public static final int MEMBER_VISIT_ID_IDX = 3 ;

    /**
              * <p> DATE on which the provider is available..</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 4 ;

    /**
              * <p> Slots for the day on which the provider is available in JSON Format..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SLOTS= "SLOTS" ;

    /*
    * The index position of the column SLOTS in the table.
    */
    public static final int SLOTS_IDX = 5 ;

}
