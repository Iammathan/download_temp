package com.adventnet.charm;

/** <p> Description of the table <code>LabRecordParamMap</code>.
 *  Column Name and Table Name of  database table  <code>LabRecordParamMap</code> is mapped
 * as constants in this util.</p> 
  Grouping of LabRecords and Params. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_RECORD_PARAM_ID}
  * </ul>
 */
 
public final class LABRECORDPARAMMAP
{
    private LABRECORDPARAMMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabRecordParamMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_PARAM_ID= "LAB_RECORD_PARAM_ID" ;

    /*
    * The index position of the column LAB_RECORD_PARAM_ID in the table.
    */
    public static final int LAB_RECORD_PARAM_ID_IDX = 1 ;

    /**
              * <p> LabRecord Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_RECORD_ID= "LAB_RECORD_ID" ;

    /*
    * The index position of the column LAB_RECORD_ID in the table.
    */
    public static final int LAB_RECORD_ID_IDX = 2 ;

    /**
              * <p> Param Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_PARAM_ID= "MEDICAL_RECORD_PARAM_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_PARAM_ID in the table.
    */
    public static final int MEDICAL_RECORD_PARAM_ID_IDX = 3 ;

    /**
              * <p> Code for this parameter as specified by the Lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_PARAM_CODE= "LAB_PARAM_CODE" ;

    /*
    * The index position of the column LAB_PARAM_CODE in the table.
    */
    public static final int LAB_PARAM_CODE_IDX = 4 ;

    /**
              * <p> Unit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORDUNIT= "RECORDUNIT" ;

    /*
    * The index position of the column RECORDUNIT in the table.
    */
    public static final int RECORDUNIT_IDX = 5 ;

    /**
              * <p> Maximum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MAX= "REFERENCE_MAX" ;

    /*
    * The index position of the column REFERENCE_MAX in the table.
    */
    public static final int REFERENCE_MAX_IDX = 6 ;

    /**
              * <p> Mininum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MIN= "REFERENCE_MIN" ;

    /*
    * The index position of the column REFERENCE_MIN in the table.
    */
    public static final int REFERENCE_MIN_IDX = 7 ;

    /**
              * <p> Reference range for String type of references.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE_RANGE= "REFERENCE_RANGE" ;

    /*
    * The index position of the column REFERENCE_RANGE in the table.
    */
    public static final int REFERENCE_RANGE_IDX = 8 ;

    /**
              * <p> To check the effectiveness of this order in the lab end.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 9 ;

    /**
              * <p> user defined order of parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 10 ;

    /**
              * <p> param description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PARAM_DESCRIPTION= "PARAM_DESCRIPTION" ;

    /*
    * The index position of the column PARAM_DESCRIPTION in the table.
    */
    public static final int PARAM_DESCRIPTION_IDX = 11 ;

}
