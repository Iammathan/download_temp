package com.adventnet.charm;

/** <p> Description of the table <code>ThirdPartyProps</code>.
 *  Column Name and Table Name of  database table  <code>ThirdPartyProps</code> is mapped
 * as constants in this util.</p> 
  Properties related to third party(ePrescription). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TP_PROP_ID}
  * </ul>
 */
 
public final class THIRDPARTYPROPS
{
    private THIRDPARTYPROPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ThirdPartyProps" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TP_PROP_ID= "TP_PROP_ID" ;

    /*
    * The index position of the column TP_PROP_ID in the table.
    */
    public static final int TP_PROP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROPERTY= "PROPERTY" ;

    /*
    * The index position of the column PROPERTY in the table.
    */
    public static final int PROPERTY_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VALUE= "VALUE" ;

    /*
    * The index position of the column VALUE in the table.
    */
    public static final int VALUE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TP_NAME= "TP_NAME" ;

    /*
    * The index position of the column TP_NAME in the table.
    */
    public static final int TP_NAME_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_UPDATED_TIME= "LAST_UPDATED_TIME" ;

    /*
    * The index position of the column LAST_UPDATED_TIME in the table.
    */
    public static final int LAST_UPDATED_TIME_IDX = 5 ;

    /**
              * <p> To check if the value is encrypted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ENCRYPTED= "IS_ENCRYPTED" ;

    /*
    * The index position of the column IS_ENCRYPTED in the table.
    */
    public static final int IS_ENCRYPTED_IDX = 6 ;

}
