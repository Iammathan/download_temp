package com.adventnet.charm;

/** <p> Description of the table <code>VoiceNotificationsQueue</code>.
 *  Column Name and Table Name of  database table  <code>VoiceNotificationsQueue</code> is mapped
 * as constants in this util.</p> 
  details of voice messages . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VOICE_NOTIFICATION_QUEUE_ID}
  * </ul>
 */
 
public final class VOICENOTIFICATIONSQUEUE
{
    private VOICENOTIFICATIONSQUEUE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VoiceNotificationsQueue" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_NOTIFICATION_QUEUE_ID= "VOICE_NOTIFICATION_QUEUE_ID" ;

    /*
    * The index position of the column VOICE_NOTIFICATION_QUEUE_ID in the table.
    */
    public static final int VOICE_NOTIFICATION_QUEUE_ID_IDX = 1 ;

    /**
              * <p> Practice Voice Notification Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_NOTIFICATION_ID= "VOICE_NOTIFICATION_ID" ;

    /*
    * The index position of the column VOICE_NOTIFICATION_ID in the table.
    */
    public static final int VOICE_NOTIFICATION_ID_IDX = 2 ;

    /**
              * <p> Practice Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

    /**
              * <p> To which number the voice message sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MOBILE_NUMBER= "MOBILE_NUMBER" ;

    /*
    * The index position of the column MOBILE_NUMBER in the table.
    */
    public static final int MOBILE_NUMBER_IDX = 4 ;

    /**
              * <p> Unique id of voice message sent (id from twilio).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_MESSAGE_ID= "VOICE_MESSAGE_ID" ;

    /*
    * The index position of the column VOICE_MESSAGE_ID in the table.
    */
    public static final int VOICE_MESSAGE_ID_IDX = 5 ;

    /**
              * <p> Voice message content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1600</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VOICE_CONTENT= "VOICE_CONTENT" ;

    /*
    * The index position of the column VOICE_CONTENT in the table.
    */
    public static final int VOICE_CONTENT_IDX = 6 ;

    /**
              * <p> Status of voice message - Queued/Initiated/Ringing/Completed.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CALL_STATUS= "CALL_STATUS" ;

    /*
    * The index position of the column CALL_STATUS in the table.
    */
    public static final int CALL_STATUS_IDX = 7 ;

    /**
              * <p> weather appointment conformation can be done by patient or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String CONFIRMATION_REQUIRED= "CONFIRMATION_REQUIRED" ;

    /*
    * The index position of the column CONFIRMATION_REQUIRED in the table.
    */
    public static final int CONFIRMATION_REQUIRED_IDX = 8 ;

    /**
              * <p> weather appointment conformation can be done by patient or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String CANCELLATION_REQUIRED= "CANCELLATION_REQUIRED" ;

    /*
    * The index position of the column CANCELLATION_REQUIRED in the table.
    */
    public static final int CANCELLATION_REQUIRED_IDX = 9 ;

    /**
              * <p> number of times tried for this voice call.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                     * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String RETRY_COUNT= "RETRY_COUNT" ;

    /*
    * The index position of the column RETRY_COUNT in the table.
    */
    public static final int RETRY_COUNT_IDX = 10 ;

    /**
              * <p> number of times voice call needs to be invoke in case of failure.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                     * Default Value is <code>1</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>1</code>" , 
       * will be taken.<br>
                         */
    public static final String MAX_RETRY_COUNT= "MAX_RETRY_COUNT" ;

    /*
    * The index position of the column MAX_RETRY_COUNT in the table.
    */
    public static final int MAX_RETRY_COUNT_IDX = 11 ;

    /**
              * <p> From Mobile number of practice for sending 2 WAY SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FROM_MOBILE_NUMBER= "FROM_MOBILE_NUMBER" ;

    /*
    * The index position of the column FROM_MOBILE_NUMBER in the table.
    */
    public static final int FROM_MOBILE_NUMBER_IDX = 12 ;

}
