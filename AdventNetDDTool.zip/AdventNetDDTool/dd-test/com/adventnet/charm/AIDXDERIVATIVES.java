package com.adventnet.charm;

/** <p> Description of the table <code>AIDxDerivatives</code>.
 *  Column Name and Table Name of  database table  <code>AIDxDerivatives</code> is mapped
 * as constants in this util.</p> 
  Populating Dx Derivatives from encounter data. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AI_DX_DERIVATIVES_ID}
  * </ul>
 */
 
public final class AIDXDERIVATIVES
{
    private AIDXDERIVATIVES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AIDxDerivatives" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AI_DX_DERIVATIVES_ID= "AI_DX_DERIVATIVES_ID" ;

    /*
    * The index position of the column AI_DX_DERIVATIVES_ID in the table.
    */
    public static final int AI_DX_DERIVATIVES_ID_IDX = 1 ;

    /**
              * <p> Index of the Consultation used during training.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INDEX= "INDEX" ;

    /*
    * The index position of the column INDEX in the table.
    */
    public static final int INDEX_IDX = 2 ;

    /**
              * <p> ConsultationHistory Foreign Key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 3 ;

    /**
              * <p> Group Concat of Dx Codes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DX_CODES= "DX_CODES" ;

    /*
    * The index position of the column DX_CODES in the table.
    */
    public static final int DX_CODES_IDX = 4 ;

    /**
              * <p> Treatment notes entered by physician.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TREATMENT_NOTES= "TREATMENT_NOTES" ;

    /*
    * The index position of the column TREATMENT_NOTES in the table.
    */
    public static final int TREATMENT_NOTES_IDX = 5 ;

    /**
              * <p> Notes entered by physician will be shared with pateint.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_NOTES= "PATIENT_NOTES" ;

    /*
    * The index position of the column PATIENT_NOTES in the table.
    */
    public static final int PATIENT_NOTES_IDX = 6 ;

    /**
              * <p> Diets recommended.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DIET_NOTES= "DIET_NOTES" ;

    /*
    * The index position of the column DIET_NOTES in the table.
    */
    public static final int DIET_NOTES_IDX = 7 ;

    /**
              * <p> Diets recommended.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LIFE_STYLE= "LIFE_STYLE" ;

    /*
    * The index position of the column LIFE_STYLE in the table.
    */
    public static final int LIFE_STYLE_IDX = 8 ;

    /**
              * <p> Group concat of Identifiers of handouts file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HANDOUTS= "HANDOUTS" ;

    /*
    * The index position of the column HANDOUTS in the table.
    */
    public static final int HANDOUTS_IDX = 9 ;

    /**
              * <p> Group concat of Rxs.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RX= "RX" ;

    /*
    * The index position of the column RX in the table.
    */
    public static final int RX_IDX = 10 ;

    /**
              * <p> Group concat of Injections given by physician.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INJECTIONS= "INJECTIONS" ;

    /*
    * The index position of the column INJECTIONS in the table.
    */
    public static final int INJECTIONS_IDX = 11 ;

    /**
              * <p> Group Concat of Vaccines given to the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINES= "VACCINES" ;

    /*
    * The index position of the column VACCINES in the table.
    */
    public static final int VACCINES_IDX = 12 ;

    /**
              * <p> JSON representation of lab and tests ordered.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_TEST_NAMES= "LAB_TEST_NAMES" ;

    /*
    * The index position of the column LAB_TEST_NAMES in the table.
    */
    public static final int LAB_TEST_NAMES_IDX = 13 ;

    /**
              * <p> Group Concat of Image Type Names.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IMAGE_TYPE= "IMAGE_TYPE" ;

    /*
    * The index position of the column IMAGE_TYPE in the table.
    */
    public static final int IMAGE_TYPE_IDX = 14 ;

    /**
              * <p>  Creation time of consultation .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 15 ;

    /**
              * <p> JSONObject format of CPTs vs DXs.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CPTS_VS_DXS= "CPTS_VS_DXS" ;

    /*
    * The index position of the column CPTS_VS_DXS in the table.
    */
    public static final int CPTS_VS_DXS_IDX = 16 ;

    /**
              * <p> Boolean to denote if the row is billed or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_BILLED= "IS_BILLED" ;

    /*
    * The index position of the column IS_BILLED in the table.
    */
    public static final int IS_BILLED_IDX = 17 ;

}
