package com.adventnet.charm;

/** <p> Description of the table <code>OutsideLabDetails</code>.
 *  Column Name and Table Name of  database table  <code>OutsideLabDetails</code> is mapped
 * as constants in this util.</p> 
  This table maintains the Outside Lab Provider ( i.e, outside entity from which services like diagnostic exam is purchased). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #OUTSIDE_LAB_ID}
  * </ul>
 */
 
public final class OUTSIDELABDETAILS
{
    private OUTSIDELABDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "OutsideLabDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OUTSIDE_LAB_ID= "OUTSIDE_LAB_ID" ;

    /*
    * The index position of the column OUTSIDE_LAB_ID in the table.
    */
    public static final int OUTSIDE_LAB_ID_IDX = 1 ;

    /**
              * <p> Denotes whether this lab service provider is an Individual provider or an Organizational entity..</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ORGANIZATION= "IS_ORGANIZATION" ;

    /*
    * The index position of the column IS_ORGANIZATION in the table.
    */
    public static final int IS_ORGANIZATION_IDX = 2 ;

    /**
              * <p> Name of the Outside Lab Service Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String OUTSIDE_LAB_NAME= "OUTSIDE_LAB_NAME" ;

    /*
    * The index position of the column OUTSIDE_LAB_NAME in the table.
    */
    public static final int OUTSIDE_LAB_NAME_IDX = 3 ;

    /**
              * <p> NPI of this Outside Lab Service Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 4 ;

    /**
              * <p> Unique Id(QualifiersList.QUALIFIER_ID) of the selected ID Type.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 5 ;

    /**
              * <p> Identifier value entered for the selected ID Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 6 ;

    /**
              * <p> Id for Mapping PostalAddress and Out Side Lab.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 7 ;

    /**
              * <p> Id for Mapping ContactDetails and Out Side Lab.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 8 ;

}
