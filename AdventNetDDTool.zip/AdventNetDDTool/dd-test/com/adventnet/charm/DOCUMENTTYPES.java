package com.adventnet.charm;

/** <p> Description of the table <code>DocumentTypes</code>.
 *  Column Name and Table Name of  database table  <code>DocumentTypes</code> is mapped
 * as constants in this util.</p> 
  To choose the document type while uploading the document. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DOCUMENT_TYPE_ID}
  * </ul>
 */
 
public final class DOCUMENTTYPES
{
    private DOCUMENTTYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DocumentTypes" ;
    /**
              * <p> Id of the document type.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DOCUMENT_TYPE_ID= "DOCUMENT_TYPE_ID" ;

    /*
    * The index position of the column DOCUMENT_TYPE_ID in the table.
    */
    public static final int DOCUMENT_TYPE_ID_IDX = 1 ;

    /**
              * <p> Name of the Document type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DOCUMENT_TYPE= "DOCUMENT_TYPE" ;

    /*
    * The index position of the column DOCUMENT_TYPE in the table.
    */
    public static final int DOCUMENT_TYPE_IDX = 2 ;

    /**
              * <p> To indicate whether document type has been deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 3 ;

}
