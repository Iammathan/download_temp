package com.adventnet.charm;

/** <p> Description of the table <code>ExostarShippingDetails</code>.
 *  Column Name and Table Name of  database table  <code>ExostarShippingDetails</code> is mapped
 * as constants in this util.</p> 
  Stores details about the txn with exostar. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXO_SHIP_ID}
  * </ul>
 */
 
public final class EXOSTARSHIPPINGDETAILS
{
    private EXOSTARSHIPPINGDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ExostarShippingDetails" ;
    /**
              * <p> Pk of ExostarShippingDetails.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXO_SHIP_ID= "EXO_SHIP_ID" ;

    /*
    * The index position of the column EXO_SHIP_ID in the table.
    */
    public static final int EXO_SHIP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXO_ORDER_ID= "EXO_ORDER_ID" ;

    /*
    * The index position of the column EXO_ORDER_ID in the table.
    */
    public static final int EXO_ORDER_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NUMBER= "NUMBER" ;

    /*
    * The index position of the column NUMBER in the table.
    */
    public static final int NUMBER_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>fedex</code></li>
              * <li><code>ups</code></li>
              * <li><code>usps</code></li>
              * </ul>
                         */
    public static final String SHIPPING_SERVICE= "SHIPPING_SERVICE" ;

    /*
    * The index position of the column SHIPPING_SERVICE in the table.
    */
    public static final int SHIPPING_SERVICE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SHIP_DATE= "SHIP_DATE" ;

    /*
    * The index position of the column SHIP_DATE in the table.
    */
    public static final int SHIP_DATE_IDX = 5 ;

}
