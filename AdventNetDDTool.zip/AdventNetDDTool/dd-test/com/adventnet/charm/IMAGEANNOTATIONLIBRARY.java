package com.adventnet.charm;

/** <p> Description of the table <code>ImageAnnotationLibrary</code>.
 *  Column Name and Table Name of  database table  <code>ImageAnnotationLibrary</code> is mapped
 * as constants in this util.</p> 
  Library(Scope : Practice) images for Annotation. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_ID}
  * </ul>
 */
 
public final class IMAGEANNOTATIONLIBRARY
{
    private IMAGEANNOTATIONLIBRARY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageAnnotationLibrary" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_ID= "IMAGE_ID" ;

    /*
    * The index position of the column IMAGE_ID in the table.
    */
    public static final int IMAGE_ID_IDX = 1 ;

    /**
              * <p> Member Id of the Person uploading this image. Refers PracticeMembersList.MEMBER_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> File Id of the uploaded Image. Refers UploadedFiles.FILE_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 3 ;

    /**
              * <p> Display Name of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_DISPLAY_NAME= "FILE_DISPLAY_NAME" ;

    /*
    * The index position of the column FILE_DISPLAY_NAME in the table.
    */
    public static final int FILE_DISPLAY_NAME_IDX = 4 ;

    /**
              * <p> Height of the file.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_HEIGHT= "FILE_HEIGHT" ;

    /*
    * The index position of the column FILE_HEIGHT in the table.
    */
    public static final int FILE_HEIGHT_IDX = 5 ;

    /**
              * <p> Width of the file.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_WIDTH= "FILE_WIDTH" ;

    /*
    * The index position of the column FILE_WIDTH in the table.
    */
    public static final int FILE_WIDTH_IDX = 6 ;

}
