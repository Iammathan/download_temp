package com.adventnet.charm;

/** <p> Description of the table <code>ImageLabAccounts</code>.
 *  Column Name and Table Name of  database table  <code>ImageLabAccounts</code> is mapped
 * as constants in this util.</p> 
  Stores the Quest account information of practices and facilities. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_LAB_ACCOUNT_ID}
  * </ul>
 */
 
public final class IMAGELABACCOUNTS
{
    private IMAGELABACCOUNTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageLabAccounts" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_LAB_ACCOUNT_ID= "IMAGE_LAB_ACCOUNT_ID" ;

    /*
    * The index position of the column IMAGE_LAB_ACCOUNT_ID in the table.
    */
    public static final int IMAGE_LAB_ACCOUNT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String INTERFACE_ACCOUNT_ID= "INTERFACE_ACCOUNT_ID" ;

    /*
    * The index position of the column INTERFACE_ACCOUNT_ID in the table.
    */
    public static final int INTERFACE_ACCOUNT_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_EORDER_ENABLED= "IS_EORDER_ENABLED" ;

    /*
    * The index position of the column IS_EORDER_ENABLED in the table.
    */
    public static final int IS_EORDER_ENABLED_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>180</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SENDING_APP_NAME= "SENDING_APP_NAME" ;

    /*
    * The index position of the column SENDING_APP_NAME in the table.
    */
    public static final int SENDING_APP_NAME_IDX = 6 ;

    /**
              * <p> e-Lab associating Practice and Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_LAB_ID= "IMAGE_LAB_ID" ;

    /*
    * The index position of the column IMAGE_LAB_ID in the table.
    */
    public static final int IMAGE_LAB_ID_IDX = 7 ;

    /**
              * <p> Defines the lab service type. 0 - Disabled, 1 - Result only, 2 - Bi-directional.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_SERVICE_TYPE= "LAB_SERVICE_TYPE" ;

    /*
    * The index position of the column LAB_SERVICE_TYPE in the table.
    */
    public static final int LAB_SERVICE_TYPE_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SHOW_PDF_RESULT= "SHOW_PDF_RESULT" ;

    /*
    * The index position of the column SHOW_PDF_RESULT in the table.
    */
    public static final int SHOW_PDF_RESULT_IDX = 9 ;

    /**
              * <p> Quest additional ids.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDITIONAL_ACCOUNT_IDS= "ADDITIONAL_ACCOUNT_IDS" ;

    /*
    * The index position of the column ADDITIONAL_ACCOUNT_IDS in the table.
    */
    public static final int ADDITIONAL_ACCOUNT_IDS_IDX = 10 ;

    /**
              * <p> Even if duplicate results are received, it will get added to client.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DO_NOT_DELETE_PREV_RESULTS= "DO_NOT_DELETE_PREV_RESULTS" ;

    /*
    * The index position of the column DO_NOT_DELETE_PREV_RESULTS in the table.
    */
    public static final int DO_NOT_DELETE_PREV_RESULTS_IDX = 11 ;

    /**
              * <p> latest result receiving Time.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LATEST_RESULT_UPDATED_TIME= "LATEST_RESULT_UPDATED_TIME" ;

    /*
    * The index position of the column LATEST_RESULT_UPDATED_TIME in the table.
    */
    public static final int LATEST_RESULT_UPDATED_TIME_IDX = 12 ;

}
