package com.adventnet.charm;

/** <p> Description of the table <code>UserTermsOfServiceDetails</code>.
 *  Column Name and Table Name of  database table  <code>UserTermsOfServiceDetails</code> is mapped
 * as constants in this util.</p> 
  Table to identify the user is accepted the time of service or not. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TERMSOFSERVICE_DETAILS_ID}
  * </ul>
 */
 
public final class USERTERMSOFSERVICEDETAILS
{
    private USERTERMSOFSERVICEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UserTermsOfServiceDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TERMSOFSERVICE_DETAILS_ID= "TERMSOFSERVICE_DETAILS_ID" ;

    /*
    * The index position of the column TERMSOFSERVICE_DETAILS_ID in the table.
    */
    public static final int TERMSOFSERVICE_DETAILS_ID_IDX = 1 ;

    /**
              * <p> Identifier of the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LOGIN_NAME= "LOGIN_NAME" ;

    /*
    * The index position of the column LOGIN_NAME in the table.
    */
    public static final int LOGIN_NAME_IDX = 2 ;

    /**
              * <p> Terms and service version.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VERSION= "VERSION" ;

    /*
    * The index position of the column VERSION in the table.
    */
    public static final int VERSION_IDX = 3 ;

    /**
              * <p> To check the terms of service is accepted by the user or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_ACCEPTED= "IS_ACCEPTED" ;

    /*
    * The index position of the column IS_ACCEPTED in the table.
    */
    public static final int IS_ACCEPTED_IDX = 4 ;

    /**
              * <p> Accepted time of Terms of service.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACCEPTED_TIME= "ACCEPTED_TIME" ;

    /*
    * The index position of the column ACCEPTED_TIME in the table.
    */
    public static final int ACCEPTED_TIME_IDX = 5 ;

    /**
              * <p> Is Related to EHR/RCM - Stores EHR or RCM as value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SERVICE= "SERVICE" ;

    /*
    * The index position of the column SERVICE in the table.
    */
    public static final int SERVICE_IDX = 6 ;

}
