package com.adventnet.charm;

/** <p> Description of the table <code>ImageResultRecordValues</code>.
 *  Column Name and Table Name of  database table  <code>ImageResultRecordValues</code> is mapped
 * as constants in this util.</p> 
  ImageTestResultEntry table is used to store image test results . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_RESULT_RECORD_VAL_ID}
  * </ul>
 */
 
public final class IMAGERESULTRECORDVALUES
{
    private IMAGERESULTRECORDVALUES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageResultRecordValues" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_RESULT_RECORD_VAL_ID= "IMAGE_RESULT_RECORD_VAL_ID" ;

    /*
    * The index position of the column IMAGE_RESULT_RECORD_VAL_ID in the table.
    */
    public static final int IMAGE_RESULT_RECORD_VAL_ID_IDX = 1 ;

    /**
              * <p> IMAGE TEST RESULT ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_TEST_RESULT_ID= "IMAGE_TEST_RESULT_ID" ;

    /*
    * The index position of the column IMAGE_TEST_RESULT_ID in the table.
    */
    public static final int IMAGE_TEST_RESULT_ID_IDX = 2 ;

    /**
              * <p> To matain message status(Preliminary or Final).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RESULT_VAL_STATUS= "RESULT_VAL_STATUS" ;

    /*
    * The index position of the column RESULT_VAL_STATUS in the table.
    */
    public static final int RESULT_VAL_STATUS_IDX = 3 ;

    /**
              * <p> To hold message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORDVALUE_CODE= "RECORDVALUE_CODE" ;

    /*
    * The index position of the column RECORDVALUE_CODE in the table.
    */
    public static final int RECORDVALUE_CODE_IDX = 4 ;

    /**
              * <p> To hold message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORDVALUE_NAME= "RECORDVALUE_NAME" ;

    /*
    * The index position of the column RECORDVALUE_NAME in the table.
    */
    public static final int RECORDVALUE_NAME_IDX = 5 ;

    /**
              * <p> To hold message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORDVALUE= "RECORDVALUE" ;

    /*
    * The index position of the column RECORDVALUE in the table.
    */
    public static final int RECORDVALUE_IDX = 6 ;

    /**
              * <p> To hold message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTERPRETATION= "INTERPRETATION" ;

    /*
    * The index position of the column INTERPRETATION in the table.
    */
    public static final int INTERPRETATION_IDX = 7 ;

    /**
              * <p> To hold sub header result message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESULT_VAL_HEADER= "RESULT_VAL_HEADER" ;

    /*
    * The index position of the column RESULT_VAL_HEADER in the table.
    */
    public static final int RESULT_VAL_HEADER_IDX = 8 ;

    /**
              * <p> To hold Result val message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESULT_VAL_COMMENTS= "RESULT_VAL_COMMENTS" ;

    /*
    * The index position of the column RESULT_VAL_COMMENTS in the table.
    */
    public static final int RESULT_VAL_COMMENTS_IDX = 9 ;

    /**
              * <p> IMAGE TEST RESULT ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_FACILITY_ID= "LAB_FACILITY_ID" ;

    /*
    * The index position of the column LAB_FACILITY_ID in the table.
    */
    public static final int LAB_FACILITY_ID_IDX = 10 ;

    /**
              * <p> Link to the PDF document.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VAL_IAMGE_FILE= "VAL_IAMGE_FILE" ;

    /*
    * The index position of the column VAL_IAMGE_FILE in the table.
    */
    public static final int VAL_IAMGE_FILE_IDX = 11 ;

    /**
              * <p> Link to the PDF document.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VAL_IAMGE_FILE_TYPE= "VAL_IAMGE_FILE_TYPE" ;

    /*
    * The index position of the column VAL_IAMGE_FILE_TYPE in the table.
    */
    public static final int VAL_IAMGE_FILE_TYPE_IDX = 12 ;

    /**
              * <p> To hold message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 13 ;

}
