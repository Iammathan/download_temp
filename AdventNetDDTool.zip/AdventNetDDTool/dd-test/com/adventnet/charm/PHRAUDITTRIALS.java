package com.adventnet.charm;

/** <p> Description of the table <code>PHRAuditTrials</code>.
 *  Column Name and Table Name of  database table  <code>PHRAuditTrials</code> is mapped
 * as constants in this util.</p> 
  Audits will be saved here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AUDIT_ID}
  * </ul>
 */
 
public final class PHRAUDITTRIALS
{
    private PHRAUDITTRIALS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRAuditTrials" ;
    /**
              * <p> Unique identifier of AUDIT message.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AUDIT_ID= "AUDIT_ID" ;

    /*
    * The index position of the column AUDIT_ID in the table.
    */
    public static final int AUDIT_ID_IDX = 1 ;

    /**
              * <p> Time of generating the Audit.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 2 ;

    /**
              * <p> Member ID who did the operation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Practice ID which practice communication.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 4 ;

    /**
              * <p> PHR Patient Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 5 ;

    /**
              * <p>  Patient/Representative name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_NAME= "PATIENT_NAME" ;

    /*
    * The index position of the column PATIENT_NAME in the table.
    */
    public static final int PATIENT_NAME_IDX = 6 ;

    /**
              * <p> Identified as patient representative or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_REPRESENTATIVE= "IS_REPRESENTATIVE" ;

    /*
    * The index position of the column IS_REPRESENTATIVE in the table.
    */
    public static final int IS_REPRESENTATIVE_IDX = 7 ;

    /**
              * <p> Action Carried Out.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ACTION= "ACTION" ;

    /*
    * The index position of the column ACTION in the table.
    */
    public static final int ACTION_IDX = 8 ;

    /**
              * <p> 0-READ/1-WRITE/2-MODIFY/3-DELETE/4-PRINT/5-IMPORT/6-EXPORT.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTION_TYPE= "ACTION_TYPE" ;

    /*
    * The index position of the column ACTION_TYPE in the table.
    */
    public static final int ACTION_TYPE_IDX = 9 ;

    /**
              * <p> 0-READ/1-WRITE/2-MODIFY/3-DELETE/4-PRINT/5-IMPORT/6-EXPORT.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTION_TYPE_STRING= "ACTION_TYPE_STRING" ;

    /*
    * The index position of the column ACTION_TYPE_STRING in the table.
    */
    public static final int ACTION_TYPE_STRING_IDX = 10 ;

    /**
              * <p> Audit Module Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AUDIT_MODULE_ID= "AUDIT_MODULE_ID" ;

    /*
    * The index position of the column AUDIT_MODULE_ID in the table.
    */
    public static final int AUDIT_MODULE_ID_IDX = 11 ;

    /**
              * <p> Any additional comment or remark about the action.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 12 ;

    /**
              * <p> Patient's Account ZUID in accounts.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROXY_ZUID= "PROXY_ZUID" ;

    /*
    * The index position of the column PROXY_ZUID in the table.
    */
    public static final int PROXY_ZUID_IDX = 13 ;

}
