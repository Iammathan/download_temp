package com.adventnet.charm;

/** <p> Description of the table <code>LabOrdersVsBodySiteInfo</code>.
 *  Column Name and Table Name of  database table  <code>LabOrdersVsBodySiteInfo</code> is mapped
 * as constants in this util.</p> 
  Lab order Vs Body site information - Practice Space(Data duplicated in Practice space). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ORDER_BODY_SITE_ID}
  * </ul>
 */
 
public final class LABORDERSVSBODYSITEINFO
{
    private LABORDERSVSBODYSITEINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabOrdersVsBodySiteInfo" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORDER_BODY_SITE_ID= "ORDER_BODY_SITE_ID" ;

    /*
    * The index position of the column ORDER_BODY_SITE_ID in the table.
    */
    public static final int ORDER_BODY_SITE_ID_IDX = 1 ;

    /**
              * <p> Lab order Id - Foreign key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ORDER_ID= "LAB_ORDER_ID" ;

    /*
    * The index position of the column LAB_ORDER_ID in the table.
    */
    public static final int LAB_ORDER_ID_IDX = 2 ;

    /**
              * <p> Body Site code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String BODY_SITE_CODE= "BODY_SITE_CODE" ;

    /*
    * The index position of the column BODY_SITE_CODE in the table.
    */
    public static final int BODY_SITE_CODE_IDX = 3 ;

    /**
              * <p> Body Site Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String BODY_SITE_TEXT= "BODY_SITE_TEXT" ;

    /*
    * The index position of the column BODY_SITE_TEXT in the table.
    */
    public static final int BODY_SITE_TEXT_IDX = 4 ;

    /**
              * <p> Body Site descriptor Info in JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BODY_SITE_DESCRIPTOR= "BODY_SITE_DESCRIPTOR" ;

    /*
    * The index position of the column BODY_SITE_DESCRIPTOR in the table.
    */
    public static final int BODY_SITE_DESCRIPTOR_IDX = 5 ;

    /**
              * <p> Specimen Type Details code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_TYPE_CODE= "SPECIMEN_TYPE_CODE" ;

    /*
    * The index position of the column SPECIMEN_TYPE_CODE in the table.
    */
    public static final int SPECIMEN_TYPE_CODE_IDX = 6 ;

    /**
              * <p> Specimen Type Details desc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_TYPE_DESC= "SPECIMEN_TYPE_DESC" ;

    /*
    * The index position of the column SPECIMEN_TYPE_DESC in the table.
    */
    public static final int SPECIMEN_TYPE_DESC_IDX = 7 ;

    /**
              * <p> Specimen description for each body site.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USER_DESCRIPTION= "USER_DESCRIPTION" ;

    /*
    * The index position of the column USER_DESCRIPTION in the table.
    */
    public static final int USER_DESCRIPTION_IDX = 8 ;

}
