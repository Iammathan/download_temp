package com.adventnet.charm;

/** <p> Description of the table <code>EClaimSubmissionQueue</code>.
 *  Column Name and Table Name of  database table  <code>EClaimSubmissionQueue</code> is mapped
 * as constants in this util.</p> 
  This is the common table used as a Queue. This maintains all e-claims submitted from
        different practices. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ECLAIM_QUEUE_ID}
  * </ul>
 */
 
public final class ECLAIMSUBMISSIONQUEUE
{
    private ECLAIMSUBMISSIONQUEUE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EClaimSubmissionQueue" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_QUEUE_ID= "ECLAIM_QUEUE_ID" ;

    /*
    * The index position of the column ECLAIM_QUEUE_ID in the table.
    */
    public static final int ECLAIM_QUEUE_ID_IDX = 1 ;

    /**
              * <p> Practice Space key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Unique ID of the Facility from which that claim is being submitted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Unique ID of the e-Claim Transaction in the practice space -
                EClaimTransactions.ECLAIM_TRANSACTION_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_TRANSACTION_ID= "ECLAIM_TRANSACTION_ID" ;

    /*
    * The index position of the column ECLAIM_TRANSACTION_ID in the table.
    */
    public static final int ECLAIM_TRANSACTION_ID_IDX = 4 ;

    /**
              * <p> Name of the Clearinghouse.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>1</code>. <br>
                            * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * </ul>
                         */
    public static final String CLEARINGHOUSE= "CLEARINGHOUSE" ;

    /*
    * The index position of the column CLEARINGHOUSE in the table.
    */
    public static final int CLEARINGHOUSE_IDX = 5 ;

    /**
              * <p> Status of the submission.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String QUEUE_STATUS= "QUEUE_STATUS" ;

    /*
    * The index position of the column QUEUE_STATUS in the table.
    */
    public static final int QUEUE_STATUS_IDX = 6 ;

    /**
              * <p> Time on which this 837P transaction was added to Queue.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRXN_ADDED_TIME= "TRXN_ADDED_TIME" ;

    /*
    * The index position of the column TRXN_ADDED_TIME in the table.
    */
    public static final int TRXN_ADDED_TIME_IDX = 7 ;

    /**
              * <p> Time on which this 837P transaction was downloaded by the SFTP Agent to submit to
                clearinghouse(Capario).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRXN_DOWNLOADED_TIME= "TRXN_DOWNLOADED_TIME" ;

    /*
    * The index position of the column TRXN_DOWNLOADED_TIME in the table.
    */
    public static final int TRXN_DOWNLOADED_TIME_IDX = 8 ;

    /**
              * <p> Time on which this 837P transaction was submitted to clearinghouse and status of all the
                claims in this transaction was chagned to 'Submitted Electronically' or
                'Rejected by Clearing House'.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRXN_ACKNOWLEDGED_TIME= "TRXN_ACKNOWLEDGED_TIME" ;

    /*
    * The index position of the column TRXN_ACKNOWLEDGED_TIME in the table.
    */
    public static final int TRXN_ACKNOWLEDGED_TIME_IDX = 9 ;

    /**
              * <p> Denotes whether the claim is being submitted from EHR or MBP. Default value is TRUE i.e, MBP.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>TRUE</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 10 ;

}
