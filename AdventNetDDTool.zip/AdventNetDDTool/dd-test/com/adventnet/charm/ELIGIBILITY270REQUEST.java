package com.adventnet.charm;

/** <p> Description of the table <code>Eligibility270Request</code>.
 *  Column Name and Table Name of  database table  <code>Eligibility270Request</code> is mapped
 * as constants in this util.</p> 
  Information about Eligibility Inquiry Request(270) being sent with necessary details such as Payer data, Provider reference, Subscriber/Insured-Person data, patient/dependent reference if any . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ELIGIBILITY_270_REQUEST_ID}
  * </ul>
 */
 
public final class ELIGIBILITY270REQUEST
{
    private ELIGIBILITY270REQUEST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Eligibility270Request" ;
    /**
              * <p> Unique Identifier for each Eligibility Inquiry Request.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELIGIBILITY_270_REQUEST_ID= "ELIGIBILITY_270_REQUEST_ID" ;

    /*
    * The index position of the column ELIGIBILITY_270_REQUEST_ID in the table.
    */
    public static final int ELIGIBILITY_270_REQUEST_ID_IDX = 1 ;

    /**
              * <p> ID of the Insurance Payer in which patient has insurance and to whom Eligibility Request was sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYER_ID= "PAYER_ID" ;

    /*
    * The index position of the column PAYER_ID in the table.
    */
    public static final int PAYER_ID_IDX = 2 ;

    /**
              * <p> ID of the Insurance Payer in which patient has insurance and to whom Eligibility Request was sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYER_NAME= "PAYER_NAME" ;

    /*
    * The index position of the column PAYER_NAME in the table.
    */
    public static final int PAYER_NAME_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INQUIRY_DATE= "INQUIRY_DATE" ;

    /*
    * The index position of the column INQUIRY_DATE in the table.
    */
    public static final int INQUIRY_DATE_IDX = 4 ;

    /**
              * <p> Unique Identifier of the Information Receiver; it can be either Physician or Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIVER_ID= "RECEIVER_ID" ;

    /*
    * The index position of the column RECEIVER_ID in the table.
    */
    public static final int RECEIVER_ID_IDX = 5 ;

    /**
              * <p> Stores the type of the Information Receiver, i.e Facility(1) , Physician(0).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * </ul>
                         */
    public static final String RECEIVER_TYPE= "RECEIVER_TYPE" ;

    /*
    * The index position of the column RECEIVER_TYPE in the table.
    */
    public static final int RECEIVER_TYPE_IDX = 6 ;

    /**
              * <p> Insured Person's Last Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBSCRIBER_LAST_NAME= "SUBSCRIBER_LAST_NAME" ;

    /*
    * The index position of the column SUBSCRIBER_LAST_NAME in the table.
    */
    public static final int SUBSCRIBER_LAST_NAME_IDX = 7 ;

    /**
              * <p> Insured Person's First Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBSCRIBER_FIRST_NAME= "SUBSCRIBER_FIRST_NAME" ;

    /*
    * The index position of the column SUBSCRIBER_FIRST_NAME in the table.
    */
    public static final int SUBSCRIBER_FIRST_NAME_IDX = 8 ;

    /**
              * <p> Insured Person's Middle Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBSCRIBER_MIDDLE_NAME= "SUBSCRIBER_MIDDLE_NAME" ;

    /*
    * The index position of the column SUBSCRIBER_MIDDLE_NAME in the table.
    */
    public static final int SUBSCRIBER_MIDDLE_NAME_IDX = 9 ;

    /**
              * <p> Member ID of the Insured Person.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBSCRIBER_MEMBER_ID= "SUBSCRIBER_MEMBER_ID" ;

    /*
    * The index position of the column SUBSCRIBER_MEMBER_ID in the table.
    */
    public static final int SUBSCRIBER_MEMBER_ID_IDX = 10 ;

    /**
              * <p> Date of Birth of Insured Person.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SUBSCRIBER_DATE_OF_BIRTH= "SUBSCRIBER_DATE_OF_BIRTH" ;

    /*
    * The index position of the column SUBSCRIBER_DATE_OF_BIRTH in the table.
    */
    public static final int SUBSCRIBER_DATE_OF_BIRTH_IDX = 11 ;

    /**
              * <p> Gender of Insured Person.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBSCRIBER_GENDER= "SUBSCRIBER_GENDER" ;

    /*
    * The index position of the column SUBSCRIBER_GENDER in the table.
    */
    public static final int SUBSCRIBER_GENDER_IDX = 12 ;

    /**
              * <p> This field denotes who is the subscriber; the following allowed-value comments gives the detail.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String SUBSCRIBER_TYPE= "SUBSCRIBER_TYPE" ;

    /*
    * The index position of the column SUBSCRIBER_TYPE in the table.
    */
    public static final int SUBSCRIBER_TYPE_IDX = 13 ;

    /**
              * <p> Unique Identifier of the Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 14 ;

    /**
              * <p> Service Type(s) for which Eligibility Inquiry was sent. More than one service types will be stored as comma separated values.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SERVICE_TYPES= "SERVICE_TYPES" ;

    /*
    * The index position of the column SERVICE_TYPES in the table.
    */
    public static final int SERVICE_TYPES_IDX = 15 ;

    /**
              * <p> Is it from RCM or Billing.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 16 ;

    /**
              * <p> ID of the facility of the respective member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 17 ;

}
