package com.adventnet.charm;

/** <p> Description of the table <code>UB04RevenueCategory</code>.
 *  Column Name and Table Name of  database table  <code>UB04RevenueCategory</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_REV_CAT_ID}
  * </ul>
 */
 
public final class UB04REVENUECATEGORY
{
    private UB04REVENUECATEGORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04RevenueCategory" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_REV_CAT_ID= "UB04_REV_CAT_ID" ;

    /*
    * The index position of the column UB04_REV_CAT_ID in the table.
    */
    public static final int UB04_REV_CAT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String UB04_REV_CAT_CODE= "UB04_REV_CAT_CODE" ;

    /*
    * The index position of the column UB04_REV_CAT_CODE in the table.
    */
    public static final int UB04_REV_CAT_CODE_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String UB04_REV_CAT_DESC= "UB04_REV_CAT_DESC" ;

    /*
    * The index position of the column UB04_REV_CAT_DESC in the table.
    */
    public static final int UB04_REV_CAT_DESC_IDX = 3 ;

}
