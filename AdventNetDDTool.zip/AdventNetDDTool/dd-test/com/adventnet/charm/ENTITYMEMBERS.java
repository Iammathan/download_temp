package com.adventnet.charm;

/** <p> Description of the table <code>EntityMembers</code>.
 *  Column Name and Table Name of  database table  <code>EntityMembers</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEMBER_MAP_ID}
  * </ul>
 */
 
public final class ENTITYMEMBERS
{
    private ENTITYMEMBERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EntityMembers" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_MAP_ID= "MEMBER_MAP_ID" ;

    /*
    * The index position of the column MEMBER_MAP_ID in the table.
    */
    public static final int MEMBER_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHATLET_MAP_ID= "CHATLET_MAP_ID" ;

    /*
    * The index position of the column CHATLET_MAP_ID in the table.
    */
    public static final int CHATLET_MAP_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ZUID= "MEMBER_ZUID" ;

    /*
    * The index position of the column MEMBER_ZUID in the table.
    */
    public static final int MEMBER_ZUID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 5 ;

    /**
              * <p> status to know about member like 1-ACTIVE/0-DELETED.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 6 ;

    /**
              * <p> User type will be represent as INT 1-EHR Member/2-Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String USER_TYPE= "USER_TYPE" ;

    /*
    * The index position of the column USER_TYPE in the table.
    */
    public static final int USER_TYPE_IDX = 7 ;

}
