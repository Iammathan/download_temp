package com.adventnet.charm;

/** <p> Description of the table <code>MedicationWidgetEntries</code>.
 *  Column Name and Table Name of  database table  <code>MedicationWidgetEntries</code> is mapped
 * as constants in this util.</p> 
  Medications added for a Questionnaire through PHR. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEDICATION_WIDGET_ENTRIES_ID}
  * </ul>
 */
 
public final class MEDICATIONWIDGETENTRIES
{
    private MEDICATIONWIDGETENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MedicationWidgetEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEDICATION_WIDGET_ENTRIES_ID= "MEDICATION_WIDGET_ENTRIES_ID" ;

    /*
    * The index position of the column MEDICATION_WIDGET_ENTRIES_ID in the table.
    */
    public static final int MEDICATION_WIDGET_ENTRIES_ID_IDX = 1 ;

    /**
              * <p> Name of the medication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MEDICATION_NAME= "MEDICATION_NAME" ;

    /*
    * The index position of the column MEDICATION_NAME in the table.
    */
    public static final int MEDICATION_NAME_IDX = 2 ;

    /**
              * <p> Unique identifier for the Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Intake details of the medication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTAKE_DETAILS= "INTAKE_DETAILS" ;

    /*
    * The index position of the column INTAKE_DETAILS in the table.
    */
    public static final int INTAKE_DETAILS_IDX = 4 ;

    /**
              * <p> Time of entry in milliseconds.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 5 ;

    /**
              * <p> 0=Pending, 1=Reconciled, 2=Ignored.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                     * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RECONCILE_STATUS= "RECONCILE_STATUS" ;

    /*
    * The index position of the column RECONCILE_STATUS in the table.
    */
    public static final int RECONCILE_STATUS_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SOURCE= "SOURCE" ;

    /*
    * The index position of the column SOURCE in the table.
    */
    public static final int SOURCE_IDX = 7 ;

    /**
              * <p> PK from PatientMedications.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_MEDICATION_ID= "PATIENT_MEDICATION_ID" ;

    /*
    * The index position of the column PATIENT_MEDICATION_ID in the table.
    */
    public static final int PATIENT_MEDICATION_ID_IDX = 8 ;

    /**
              * <p> Code of Medication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE= "CODE" ;

    /*
    * The index position of the column CODE in the table.
    */
    public static final int CODE_IDX = 9 ;

    /**
              * <p> Start Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 10 ;

    /**
              * <p> End Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 11 ;

    /**
              * <p> Last Modification Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_DATE= "LAST_MODIFIED_DATE" ;

    /*
    * The index position of the column LAST_MODIFIED_DATE in the table.
    */
    public static final int LAST_MODIFIED_DATE_IDX = 12 ;

}
