package com.adventnet.charm;

/** <p> Description of the table <code>EmailTemplateEntries</code>.
 *  Column Name and Table Name of  database table  <code>EmailTemplateEntries</code> is mapped
 * as constants in this util.</p> 
  Mapping Reports to the Template. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class EMAILTEMPLATEENTRIES
{
    private EMAILTEMPLATEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EmailTemplateEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from Template table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Location of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_PATH= "FILE_PATH" ;

    /*
    * The index position of the column FILE_PATH in the table.
    */
    public static final int FILE_PATH_IDX = 3 ;

    /**
              * <p> Name of the template.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 4 ;

    /**
              * <p> Subject of the email.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUBJECT= "SUBJECT" ;

    /*
    * The index position of the column SUBJECT in the table.
    */
    public static final int SUBJECT_IDX = 5 ;

}
