package com.adventnet.charm;

/** <p> Description of the table <code>FlowsheetLabParamMap</code>.
 *  Column Name and Table Name of  database table  <code>FlowsheetLabParamMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FLOW_SHEET_ENTRY_ID}
  * </ul>
 */
 
public final class FLOWSHEETLABPARAMMAP
{
    private FLOWSHEETLABPARAMMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FlowsheetLabParamMap" ;
    /**
              * <p> Id from FlowsheetEntries table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FLOW_SHEET_ENTRY_ID= "FLOW_SHEET_ENTRY_ID" ;

    /*
    * The index position of the column FLOW_SHEET_ENTRY_ID in the table.
    */
    public static final int FLOW_SHEET_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Unique Id from MedicalRecordParams table (publicSpace).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_PARAM_ID= "MEDICAL_RECORD_PARAM_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_PARAM_ID in the table.
    */
    public static final int MEDICAL_RECORD_PARAM_ID_IDX = 2 ;

    /**
              * <p> Unique Id from MedicalRecordList table (publicSpace).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ID= "MEDICAL_RECORD_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ID in the table.
    */
    public static final int MEDICAL_RECORD_ID_IDX = 3 ;

}
