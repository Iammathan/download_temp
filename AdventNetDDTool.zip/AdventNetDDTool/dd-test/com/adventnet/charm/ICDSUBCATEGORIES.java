package com.adventnet.charm;

/** <p> Description of the table <code>ICDSubCategories</code>.
 *  Column Name and Table Name of  database table  <code>ICDSubCategories</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SUB_CATEGORY_ID}
  * </ul>
 */
 
public final class ICDSUBCATEGORIES
{
    private ICDSUBCATEGORIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ICDSubCategories" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SUB_CATEGORY_ID= "SUB_CATEGORY_ID" ;

    /*
    * The index position of the column SUB_CATEGORY_ID in the table.
    */
    public static final int SUB_CATEGORY_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MAIN_CATEGORY_ID= "MAIN_CATEGORY_ID" ;

    /*
    * The index position of the column MAIN_CATEGORY_ID in the table.
    */
    public static final int MAIN_CATEGORY_ID_IDX = 2 ;

    /**
              * <p> Sub Category name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUB_CATEGORY= "SUB_CATEGORY" ;

    /*
    * The index position of the column SUB_CATEGORY in the table.
    */
    public static final int SUB_CATEGORY_IDX = 3 ;

    /**
              * <p> category ranges from.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_RANGE= "FROM_RANGE" ;

    /*
    * The index position of the column FROM_RANGE in the table.
    */
    public static final int FROM_RANGE_IDX = 4 ;

    /**
              * <p> category to range.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_RANGE= "TO_RANGE" ;

    /*
    * The index position of the column TO_RANGE in the table.
    */
    public static final int TO_RANGE_IDX = 5 ;

}
