package com.adventnet.charm;

/** <p> Description of the table <code>LabCorpLabFacility</code>.
 *  Column Name and Table Name of  database table  <code>LabCorpLabFacility</code> is mapped
 * as constants in this util.</p> 
  LabCorp Lab orderable Facility . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LABCORP_LAB_FACILITY_ID}
  * </ul>
 */
 
public final class LABCORPLABFACILITY
{
    private LABCORPLABFACILITY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabCorpLabFacility" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LABCORP_LAB_FACILITY_ID= "LABCORP_LAB_FACILITY_ID" ;

    /*
    * The index position of the column LABCORP_LAB_FACILITY_ID in the table.
    */
    public static final int LABCORP_LAB_FACILITY_ID_IDX = 1 ;

    /**
              * <p> Lab facility code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAB_FACILITY_CODE= "LAB_FACILITY_CODE" ;

    /*
    * The index position of the column LAB_FACILITY_CODE in the table.
    */
    public static final int LAB_FACILITY_CODE_IDX = 2 ;

    /**
              * <p> Lab Facility name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_FACILITY_NAME= "LAB_FACILITY_NAME" ;

    /*
    * The index position of the column LAB_FACILITY_NAME in the table.
    */
    public static final int LAB_FACILITY_NAME_IDX = 3 ;

}
