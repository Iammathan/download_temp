package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimInvoiceReportDetails</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimInvoiceReportDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_CLAIM_INVOICE_REPORT_ID}
  * </ul>
 */
 
public final class RCMCLAIMINVOICEREPORTDETAILS
{
    private RCMCLAIMINVOICEREPORTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimInvoiceReportDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_CLAIM_INVOICE_REPORT_ID= "RCM_CLAIM_INVOICE_REPORT_ID" ;

    /*
    * The index position of the column RCM_CLAIM_INVOICE_REPORT_ID in the table.
    */
    public static final int RCM_CLAIM_INVOICE_REPORT_ID_IDX = 1 ;

    /**
              * <p> Member whom added this account.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 2 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVOICE_DATE= "INVOICE_DATE" ;

    /*
    * The index position of the column INVOICE_DATE in the table.
    */
    public static final int INVOICE_DATE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PERCENTAGE= "PERCENTAGE" ;

    /*
    * The index position of the column PERCENTAGE in the table.
    */
    public static final int PERCENTAGE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 5 ;

    /**
              * <p> JSON object containing All the amount.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INVOICE_DETAILS= "INVOICE_DETAILS" ;

    /*
    * The index position of the column INVOICE_DETAILS in the table.
    */
    public static final int INVOICE_DETAILS_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 7 ;

    /**
              * <p> Indicates if the Report was a Practice Level report.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PRACTICE_LEVEL_REPORT= "IS_PRACTICE_LEVEL_REPORT" ;

    /*
    * The index position of the column IS_PRACTICE_LEVEL_REPORT in the table.
    */
    public static final int IS_PRACTICE_LEVEL_REPORT_IDX = 8 ;

    /**
              * <p> PracticeId of MBP for RCM Service Invoice Report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 9 ;

}
