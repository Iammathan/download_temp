package com.adventnet.charm;

/** <p> Description of the table <code>CQMWeightAssessment</code>.
 *  Column Name and Table Name of  database table  <code>CQMWeightAssessment</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ASSESSMENT_MAPPING_ID}
  * </ul>
 */
 
public final class CQMWEIGHTASSESSMENT
{
    private CQMWEIGHTASSESSMENT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMWeightAssessment" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ASSESSMENT_MAPPING_ID= "ASSESSMENT_MAPPING_ID" ;

    /*
    * The index position of the column ASSESSMENT_MAPPING_ID in the table.
    */
    public static final int ASSESSMENT_MAPPING_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISIT_TYPE_ID= "VISIT_TYPE_ID" ;

    /*
    * The index position of the column VISIT_TYPE_ID in the table.
    */
    public static final int VISIT_TYPE_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 5 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AGE= "AGE" ;

    /*
    * The index position of the column AGE in the table.
    */
    public static final int AGE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_DATE= "CONSULTATION_DATE" ;

    /*
    * The index position of the column CONSULTATION_DATE in the table.
    */
    public static final int CONSULTATION_DATE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_MET_1= "IS_PERFORMANCE_MET_1" ;

    /*
    * The index position of the column IS_PERFORMANCE_MET_1 in the table.
    */
    public static final int IS_PERFORMANCE_MET_1_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_MET_2= "IS_PERFORMANCE_MET_2" ;

    /*
    * The index position of the column IS_PERFORMANCE_MET_2 in the table.
    */
    public static final int IS_PERFORMANCE_MET_2_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_MET_3= "IS_PERFORMANCE_MET_3" ;

    /*
    * The index position of the column IS_PERFORMANCE_MET_3 in the table.
    */
    public static final int IS_PERFORMANCE_MET_3_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_EXCLUDED= "IS_PERFORMANCE_EXCLUDED" ;

    /*
    * The index position of the column IS_PERFORMANCE_EXCLUDED in the table.
    */
    public static final int IS_PERFORMANCE_EXCLUDED_IDX = 11 ;

}
