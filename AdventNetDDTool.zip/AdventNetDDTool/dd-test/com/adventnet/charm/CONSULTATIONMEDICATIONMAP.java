package com.adventnet.charm;

/** <p> Description of the table <code>ConsultationMedicationMap</code>.
 *  Column Name and Table Name of  database table  <code>ConsultationMedicationMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Medication. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_MEDICATION_ID}
  * </ul>
 */
 
public final class CONSULTATIONMEDICATIONMAP
{
    private CONSULTATIONMEDICATIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ConsultationMedicationMap" ;
    /**
              * <p> Identifier of the medication map.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_MEDICATION_ID= "PATIENT_MEDICATION_ID" ;

    /*
    * The index position of the column PATIENT_MEDICATION_ID in the table.
    */
    public static final int PATIENT_MEDICATION_ID_IDX = 1 ;

    /**
              * <p> Identifier of the consultation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

}
