package com.adventnet.charm;

/** <p> Description of the table <code>ReceiptVsPaymentDetails</code>.
 *  Column Name and Table Name of  database table  <code>ReceiptVsPaymentDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RECEIPT_VS_PAYMENT_ID}
  * </ul>
 */
 
public final class RECEIPTVSPAYMENTDETAILS
{
    private RECEIPTVSPAYMENTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ReceiptVsPaymentDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_VS_PAYMENT_ID= "RECEIPT_VS_PAYMENT_ID" ;

    /*
    * The index position of the column RECEIPT_VS_PAYMENT_ID in the table.
    */
    public static final int RECEIPT_VS_PAYMENT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 2 ;

    /**
              * <p> Amount Paid.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_AMOUNT= "RECEIPT_AMOUNT" ;

    /*
    * The index position of the column RECEIPT_AMOUNT in the table.
    */
    public static final int RECEIPT_AMOUNT_IDX = 3 ;

    /**
              * <p> Refers total unused amount available in the receipt.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String TOTAL_UNUSED_AMOUNT= "TOTAL_UNUSED_AMOUNT" ;

    /*
    * The index position of the column TOTAL_UNUSED_AMOUNT in the table.
    */
    public static final int TOTAL_UNUSED_AMOUNT_IDX = 4 ;

    /**
              * <p> Refers sum of all refunds issued/given from the receipt.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String TOTAL_REFUND_AMOUNT= "TOTAL_REFUND_AMOUNT" ;

    /*
    * The index position of the column TOTAL_REFUND_AMOUNT in the table.
    */
    public static final int TOTAL_REFUND_AMOUNT_IDX = 5 ;

    /**
              * <p> Mode Of Payment (By cash/card/claim).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECEIPT_MODE= "RECEIPT_MODE" ;

    /*
    * The index position of the column RECEIPT_MODE in the table.
    */
    public static final int RECEIPT_MODE_IDX = 6 ;

    /**
              * <p> Check No For Bill Payment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CHECK_NUMBER= "CHECK_NUMBER" ;

    /*
    * The index position of the column CHECK_NUMBER in the table.
    */
    public static final int CHECK_NUMBER_IDX = 7 ;

    /**
              * <p> Other Reference # For Bill Payment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DETAILS= "DETAILS" ;

    /*
    * The index position of the column DETAILS in the table.
    */
    public static final int DETAILS_IDX = 8 ;

}
