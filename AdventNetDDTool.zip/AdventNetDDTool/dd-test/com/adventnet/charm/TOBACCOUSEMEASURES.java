package com.adventnet.charm;

/** <p> Description of the table <code>TobaccoUseMeasures</code>.
 *  Column Name and Table Name of  database table  <code>TobaccoUseMeasures</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TOBACCO_USE_MEASURE_ID}
  * </ul>
 */
 
public final class TOBACCOUSEMEASURES
{
    private TOBACCOUSEMEASURES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TobaccoUseMeasures" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOBACCO_USE_MEASURE_ID= "TOBACCO_USE_MEASURE_ID" ;

    /*
    * The index position of the column TOBACCO_USE_MEASURE_ID in the table.
    */
    public static final int TOBACCO_USE_MEASURE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_DATE= "CONSULTATION_DATE" ;

    /*
    * The index position of the column CONSULTATION_DATE in the table.
    */
    public static final int CONSULTATION_DATE_IDX = 5 ;

    /**
              * <p> Visit type of the appointment.Foreign key from PQRIEncounterTypes table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PQRI_ENCOUNTER_TYPE_ID= "PQRI_ENCOUNTER_TYPE_ID" ;

    /*
    * The index position of the column PQRI_ENCOUNTER_TYPE_ID in the table.
    */
    public static final int PQRI_ENCOUNTER_TYPE_ID_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_MET= "IS_PERFORMANCE_MET" ;

    /*
    * The index position of the column IS_PERFORMANCE_MET in the table.
    */
    public static final int IS_PERFORMANCE_MET_IDX = 7 ;

}
