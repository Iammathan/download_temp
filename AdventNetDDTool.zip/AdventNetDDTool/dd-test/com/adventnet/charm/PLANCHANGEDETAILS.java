package com.adventnet.charm;

/** <p> Description of the table <code>PlanChangeDetails</code>.
 *  Column Name and Table Name of  database table  <code>PlanChangeDetails</code> is mapped
 * as constants in this util.</p> 
  table containing plan change details about the practices. . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PLAN_CHANGE_ID}
  * </ul>
 */
 
public final class PLANCHANGEDETAILS
{
    private PLANCHANGEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PlanChangeDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PLAN_CHANGE_ID= "PLAN_CHANGE_ID" ;

    /*
    * The index position of the column PLAN_CHANGE_ID in the table.
    */
    public static final int PLAN_CHANGE_ID_IDX = 1 ;

    /**
              * <p> Identifier of the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> The date from which the plan needs to be changed.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EFFECTIVE_FROM= "EFFECTIVE_FROM" ;

    /*
    * The index position of the column EFFECTIVE_FROM in the table.
    */
    public static final int EFFECTIVE_FROM_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PLAN_DETAILS= "PLAN_DETAILS" ;

    /*
    * The index position of the column PLAN_DETAILS in the table.
    */
    public static final int PLAN_DETAILS_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SCHEDULED_BY= "SCHEDULED_BY" ;

    /*
    * The index position of the column SCHEDULED_BY in the table.
    */
    public static final int SCHEDULED_BY_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 6 ;

    /**
              * <p> Last updated time for the plan scheduled.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_UPDATED_TIME= "LAST_UPDATED_TIME" ;

    /*
    * The index position of the column LAST_UPDATED_TIME in the table.
    */
    public static final int LAST_UPDATED_TIME_IDX = 7 ;

}
