package com.adventnet.charm;

/** <p> Description of the table <code>MailComments</code>.
 *  Column Name and Table Name of  database table  <code>MailComments</code> is mapped
 * as constants in this util.</p> 
  Mail Comments details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAIL_COMMENTS_ID}
  * </ul>
 */
 
public final class MAILCOMMENTS
{
    private MAILCOMMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MailComments" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAIL_COMMENTS_ID= "MAIL_COMMENTS_ID" ;

    /*
    * The index position of the column MAIL_COMMENTS_ID in the table.
    */
    public static final int MAIL_COMMENTS_ID_IDX = 1 ;

    /**
              * <p> Bill sent id  of BillSentDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_SENT_DETAILS_ID= "BILL_SENT_DETAILS_ID" ;

    /*
    * The index position of the column BILL_SENT_DETAILS_ID in the table.
    */
    public static final int BILL_SENT_DETAILS_ID_IDX = 2 ;

    /**
              * <p> Comment of send mails.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 3 ;

    /**
              * <p> Date and Time on which this data is sent to patient.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_USER= "ADDED_USER" ;

    /*
    * The index position of the column ADDED_USER in the table.
    */
    public static final int ADDED_USER_IDX = 5 ;

}
