package com.adventnet.charm;

/** <p> Description of the table <code>BloodSugarsList</code>.
 *  Column Name and Table Name of  database table  <code>BloodSugarsList</code> is mapped
 * as constants in this util.</p> 
  Blood Sugars List. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BLOOD_SUGARS_ID}
  * </ul>
 */
 
public final class BLOODSUGARSLIST
{
    private BLOODSUGARSLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BloodSugarsList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BLOOD_SUGARS_ID= "BLOOD_SUGARS_ID" ;

    /*
    * The index position of the column BLOOD_SUGARS_ID in the table.
    */
    public static final int BLOOD_SUGARS_ID_IDX = 1 ;

    /**
              * <p> When the test is done.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TEST_TYPE= "TEST_TYPE" ;

    /*
    * The index position of the column TEST_TYPE in the table.
    */
    public static final int TEST_TYPE_IDX = 2 ;

    /**
              * <p> Maximum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MAX= "REFERENCE_MAX" ;

    /*
    * The index position of the column REFERENCE_MAX in the table.
    */
    public static final int REFERENCE_MAX_IDX = 3 ;

    /**
              * <p> Mininum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MIN= "REFERENCE_MIN" ;

    /*
    * The index position of the column REFERENCE_MIN in the table.
    */
    public static final int REFERENCE_MIN_IDX = 4 ;

}
