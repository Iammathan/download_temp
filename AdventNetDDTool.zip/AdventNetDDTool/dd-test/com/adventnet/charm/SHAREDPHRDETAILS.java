package com.adventnet.charm;

/** <p> Description of the table <code>SharedPHRDetails</code>.
 *  Column Name and Table Name of  database table  <code>SharedPHRDetails</code> is mapped
 * as constants in this util.</p> 
  Share To PHR Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SHARE_ID}
  * </ul>
 */
 
public final class SHAREDPHRDETAILS
{
    private SHAREDPHRDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SharedPHRDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SHARE_ID= "SHARE_ID" ;

    /*
    * The index position of the column SHARE_ID in the table.
    */
    public static final int SHARE_ID_IDX = 1 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Module Forgien Key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MODULE_FK_ID= "MODULE_FK_ID" ;

    /*
    * The index position of the column MODULE_FK_ID in the table.
    */
    public static final int MODULE_FK_ID_IDX = 3 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MODULE= "MODULE" ;

    /*
    * The index position of the column MODULE in the table.
    */
    public static final int MODULE_IDX = 4 ;

    /**
              * <p> Date and Time on which this data is entered.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SHARED_ON= "SHARED_ON" ;

    /*
    * The index position of the column SHARED_ON in the table.
    */
    public static final int SHARED_ON_IDX = 5 ;

    /**
              * <p> the guy who is sharing the result.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SHARED_BY= "SHARED_BY" ;

    /*
    * The index position of the column SHARED_BY in the table.
    */
    public static final int SHARED_BY_IDX = 6 ;

    /**
              * <p> phr side key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PHR_MODULE_FK_ID= "PHR_MODULE_FK_ID" ;

    /*
    * The index position of the column PHR_MODULE_FK_ID in the table.
    */
    public static final int PHR_MODULE_FK_ID_IDX = 7 ;

}
