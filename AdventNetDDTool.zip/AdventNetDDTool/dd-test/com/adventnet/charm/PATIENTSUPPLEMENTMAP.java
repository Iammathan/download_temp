package com.adventnet.charm;

/** <p> Description of the table <code>PatientSupplementMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientSupplementMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Supplement. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SUPPLEMENT_MAP_ID}
  * </ul>
 */
 
public final class PATIENTSUPPLEMENTMAP
{
    private PATIENTSUPPLEMENTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientSupplementMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SUPPLEMENT_MAP_ID= "SUPPLEMENT_MAP_ID" ;

    /*
    * The index position of the column SUPPLEMENT_MAP_ID in the table.
    */
    public static final int SUPPLEMENT_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SUPPLEMENT_ID= "SUPPLEMENT_ID" ;

    /*
    * The index position of the column SUPPLEMENT_ID in the table.
    */
    public static final int SUPPLEMENT_ID_IDX = 3 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MANUFACTURER_ID= "MANUFACTURER_ID" ;

    /*
    * The index position of the column MANUFACTURER_ID in the table.
    */
    public static final int MANUFACTURER_ID_IDX = 4 ;

}
