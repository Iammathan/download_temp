package com.adventnet.charm;

/** <p> Description of the table <code>ConsultationAnnotationMap</code>.
 *  Column Name and Table Name of  database table  <code>ConsultationAnnotationMap</code> is mapped
 * as constants in this util.</p> 
  This table maps Consultations with Image Annotations. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CA_ID}
  * </ul>
 */
 
public final class CONSULTATIONANNOTATIONMAP
{
    private CONSULTATIONANNOTATIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ConsultationAnnotationMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CA_ID= "CA_ID" ;

    /*
    * The index position of the column CA_ID in the table.
    */
    public static final int CA_ID_IDX = 1 ;

    /**
              * <p> Refers ImageAnnotation.ANNOTATION_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ANNOTATION_ID= "ANNOTATION_ID" ;

    /*
    * The index position of the column ANNOTATION_ID in the table.
    */
    public static final int ANNOTATION_ID_IDX = 2 ;

    /**
              * <p> Member Id of the Person creating this annotation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Concern Patient Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
              * <p> Concern Encounter Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 5 ;

}
