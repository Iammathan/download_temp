package com.adventnet.charm;

/** <p> Description of the table <code>HealthPassportPasscodeSession</code>.
 *  Column Name and Table Name of  database table  <code>HealthPassportPasscodeSession</code> is mapped
 * as constants in this util.</p> 
  Health Passport Passcode Session. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PASSCODE_SESSION_ID}
  * </ul>
 */
 
public final class HEALTHPASSPORTPASSCODESESSION
{
    private HEALTHPASSPORTPASSCODESESSION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HealthPassportPasscodeSession" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PASSCODE_SESSION_ID= "PASSCODE_SESSION_ID" ;

    /*
    * The index position of the column PASSCODE_SESSION_ID in the table.
    */
    public static final int PASSCODE_SESSION_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String HEALTH_PASSPORT_ID= "HEALTH_PASSPORT_ID" ;

    /*
    * The index position of the column HEALTH_PASSPORT_ID in the table.
    */
    public static final int HEALTH_PASSPORT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PASSCODE_SESSION= "PASSCODE_SESSION" ;

    /*
    * The index position of the column PASSCODE_SESSION in the table.
    */
    public static final int PASSCODE_SESSION_IDX = 3 ;

    /**
              * <p> Ip address of user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IP_ADDRESS= "IP_ADDRESS" ;

    /*
    * The index position of the column IP_ADDRESS in the table.
    */
    public static final int IP_ADDRESS_IDX = 4 ;

    /**
              * <p> Time of creating the session.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SESSION_CREATED_TIME= "SESSION_CREATED_TIME" ;

    /*
    * The index position of the column SESSION_CREATED_TIME in the table.
    */
    public static final int SESSION_CREATED_TIME_IDX = 5 ;

}
