package com.adventnet.charm;

/** <p> Description of the table <code>CommandLangOps</code>.
 *  Column Name and Table Name of  database table  <code>CommandLangOps</code> is mapped
 * as constants in this util.</p> 
  Operation types. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CMMND_LANG_OP_ID}
  * </ul>
 */
 
public final class COMMANDLANGOPS
{
    private COMMANDLANGOPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CommandLangOps" ;
    /**
              * <p> Pk of CommandLangOps.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CMMND_LANG_OP_ID= "CMMND_LANG_OP_ID" ;

    /*
    * The index position of the column CMMND_LANG_OP_ID in the table.
    */
    public static final int CMMND_LANG_OP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OPR_TYPE= "OPR_TYPE" ;

    /*
    * The index position of the column OPR_TYPE in the table.
    */
    public static final int OPR_TYPE_IDX = 2 ;

}
