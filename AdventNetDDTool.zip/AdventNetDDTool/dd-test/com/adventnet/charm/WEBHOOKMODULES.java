package com.adventnet.charm;

/** <p> Description of the table <code>WebhookModules</code>.
 *  Column Name and Table Name of  database table  <code>WebhookModules</code> is mapped
 * as constants in this util.</p> 
  Table for storing modules for webhooks. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #WEBHOOK_MODULE_ID}
  * </ul>
 */
 
public final class WEBHOOKMODULES
{
    private WEBHOOKMODULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "WebhookModules" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WEBHOOK_MODULE_ID= "WEBHOOK_MODULE_ID" ;

    /*
    * The index position of the column WEBHOOK_MODULE_ID in the table.
    */
    public static final int WEBHOOK_MODULE_ID_IDX = 1 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MODULE_NAME= "MODULE_NAME" ;

    /*
    * The index position of the column MODULE_NAME in the table.
    */
    public static final int MODULE_NAME_IDX = 2 ;

    /**
              * <p> Type of events for the module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EVENT_TYPES= "EVENT_TYPES" ;

    /*
    * The index position of the column EVENT_TYPES in the table.
    */
    public static final int EVENT_TYPES_IDX = 3 ;

    /**
              * <p> Response Types allowed for the module(JSON-0, HL7-1, etc).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RESPONSE_TYPES= "RESPONSE_TYPES" ;

    /*
    * The index position of the column RESPONSE_TYPES in the table.
    */
    public static final int RESPONSE_TYPES_IDX = 4 ;

}
