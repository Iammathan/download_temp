package com.adventnet.charm;

/** <p> Description of the table <code>VaccineNDCCodeMap</code>.
 *  Column Name and Table Name of  database table  <code>VaccineNDCCodeMap</code> is mapped
 * as constants in this util.</p> 
  Fetch NDC Code by passing CVX and MVX Code as Criteria. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VACCINE_NDC_CODE_MAP_ID}
  * </ul>
 */
 
public final class VACCINENDCCODEMAP
{
    private VACCINENDCCODEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VaccineNDCCodeMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VACCINE_NDC_CODE_MAP_ID= "VACCINE_NDC_CODE_MAP_ID" ;

    /*
    * The index position of the column VACCINE_NDC_CODE_MAP_ID in the table.
    */
    public static final int VACCINE_NDC_CODE_MAP_ID_IDX = 1 ;

    /**
              * <p> CX Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CVX_CODE= "CVX_CODE" ;

    /*
    * The index position of the column CVX_CODE in the table.
    */
    public static final int CVX_CODE_IDX = 2 ;

    /**
              * <p> Name of Vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_NAME= "VACCINE_NAME" ;

    /*
    * The index position of the column VACCINE_NAME in the table.
    */
    public static final int VACCINE_NAME_IDX = 3 ;

    /**
              * <p> Sale name of the Vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_SALE_NAME= "VACCINE_SALE_NAME" ;

    /*
    * The index position of the column VACCINE_SALE_NAME in the table.
    */
    public static final int VACCINE_SALE_NAME_IDX = 4 ;

    /**
              * <p> Manufacturer code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MVX_CODE= "MVX_CODE" ;

    /*
    * The index position of the column MVX_CODE in the table.
    */
    public static final int MVX_CODE_IDX = 5 ;

    /**
              * <p> NDC code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NDC_CODE= "NDC_CODE" ;

    /*
    * The index position of the column NDC_CODE in the table.
    */
    public static final int NDC_CODE_IDX = 6 ;

    /**
              * <p> False - Added by Practice, True - Added by Charm as a default List.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_APPROVED= "IS_APPROVED" ;

    /*
    * The index position of the column IS_APPROVED in the table.
    */
    public static final int IS_APPROVED_IDX = 7 ;

}
