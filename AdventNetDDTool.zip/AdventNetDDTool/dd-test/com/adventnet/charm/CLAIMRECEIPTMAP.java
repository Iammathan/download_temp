package com.adventnet.charm;

/** <p> Description of the table <code>ClaimReceiptMap</code>.
 *  Column Name and Table Name of  database table  <code>ClaimReceiptMap</code> is mapped
 * as constants in this util.</p> 
  
            All the payment details related to a claim,
            will be saved in ClaimReceiptMap table.
        . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_RECEIPT_MAP_ID}
  * </ul>
 */
 
public final class CLAIMRECEIPTMAP
{
    private CLAIMRECEIPTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ClaimReceiptMap" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_RECEIPT_MAP_ID= "CLAIM_RECEIPT_MAP_ID" ;

    /*
    * The index position of the column CLAIM_RECEIPT_MAP_ID in the table.
    */
    public static final int CLAIM_RECEIPT_MAP_ID_IDX = 1 ;

    /**
              * <p> Claim Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> Receipt Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 3 ;

    /**
              * <p> Whether the payment is from Primary insurance or secondary.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_FROM_PRIMARY= "IS_FROM_PRIMARY" ;

    /*
    * The index position of the column IS_FROM_PRIMARY in the table.
    */
    public static final int IS_FROM_PRIMARY_IDX = 4 ;

    /**
              * <p> Payer Id of the insurance.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURANCE_COMPANY_CODE= "INSURANCE_COMPANY_CODE" ;

    /*
    * The index position of the column INSURANCE_COMPANY_CODE in the table.
    */
    public static final int INSURANCE_COMPANY_CODE_IDX = 5 ;

}
