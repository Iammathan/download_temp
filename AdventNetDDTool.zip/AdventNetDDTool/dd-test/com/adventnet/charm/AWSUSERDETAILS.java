package com.adventnet.charm;

/** <p> Description of the table <code>AWSUserDetails</code>.
 *  Column Name and Table Name of  database table  <code>AWSUserDetails</code> is mapped
 * as constants in this util.</p> 
   Contains the user details which opt for aws services . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AWS_USER_DETAILS_ID}
  * </ul>
 */
 
public final class AWSUSERDETAILS
{
    private AWSUSERDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AWSUserDetails" ;
    /**
              * <p> Primary Key for AWS user details table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_USER_DETAILS_ID= "AWS_USER_DETAILS_ID" ;

    /*
    * The index position of the column AWS_USER_DETAILS_ID in the table.
    */
    public static final int AWS_USER_DETAILS_ID_IDX = 1 ;

    /**
              * <p> This will contain the practice id..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_AWS_USER_NAME= "PRACTICE_AWS_USER_NAME" ;

    /*
    * The index position of the column PRACTICE_AWS_USER_NAME in the table.
    */
    public static final int PRACTICE_AWS_USER_NAME_IDX = 2 ;

    /**
              * <p> Contains the region name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REGION_NAME= "REGION_NAME" ;

    /*
    * The index position of the column REGION_NAME in the table.
    */
    public static final int REGION_NAME_IDX = 3 ;

    /**
              * <p>  Contains the timestamp that when the user is created.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String USER_CREATED_ON= "USER_CREATED_ON" ;

    /*
    * The index position of the column USER_CREATED_ON in the table.
    */
    public static final int USER_CREATED_ON_IDX = 4 ;

    /**
              * <p> Contains the IAM user name who created the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CREATED_BY_IAM_USER= "CREATED_BY_IAM_USER" ;

    /*
    * The index position of the column CREATED_BY_IAM_USER in the table.
    */
    public static final int CREATED_BY_IAM_USER_IDX = 5 ;

    /**
              * <p> Contains boolean value that whether user is active or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 6 ;

    /**
              * <p>  Contains the time that when the user is deactivated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DEACTIVATED_DATE= "DEACTIVATED_DATE" ;

    /*
    * The index position of the column DEACTIVATED_DATE in the table.
    */
    public static final int DEACTIVATED_DATE_IDX = 7 ;

    /**
              * <p>  Contains the time that when the user is last billed. Usage at billing side.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_BILLED_DATE= "LAST_BILLED_DATE" ;

    /*
    * The index position of the column LAST_BILLED_DATE in the table.
    */
    public static final int LAST_BILLED_DATE_IDX = 8 ;

}
