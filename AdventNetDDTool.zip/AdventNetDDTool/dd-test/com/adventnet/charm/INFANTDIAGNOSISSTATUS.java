package com.adventnet.charm;

/** <p> Description of the table <code>InfantDiagnosisStatus</code>.
 *  Column Name and Table Name of  database table  <code>InfantDiagnosisStatus</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INFANT_DIAGNOSIS_ID}
  * </ul>
 */
 
public final class INFANTDIAGNOSISSTATUS
{
    private INFANTDIAGNOSISSTATUS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InfantDiagnosisStatus" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INFANT_DIAGNOSIS_ID= "INFANT_DIAGNOSIS_ID" ;

    /*
    * The index position of the column INFANT_DIAGNOSIS_ID in the table.
    */
    public static final int INFANT_DIAGNOSIS_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ENCEPHALOPATHY= "ENCEPHALOPATHY" ;

    /*
    * The index position of the column ENCEPHALOPATHY in the table.
    */
    public static final int ENCEPHALOPATHY_IDX = 3 ;

    /**
              * <p> Progressive neurological disorder.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NEUROLOGICAL_DISORDER= "NEUROLOGICAL_DISORDER" ;

    /*
    * The index position of the column NEUROLOGICAL_DISORDER in the table.
    */
    public static final int NEUROLOGICAL_DISORDER_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEASLES= "MEASLES" ;

    /*
    * The index position of the column MEASLES in the table.
    */
    public static final int MEASLES_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MUMPS= "MUMPS" ;

    /*
    * The index position of the column MUMPS in the table.
    */
    public static final int MUMPS_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RUBELLA= "RUBELLA" ;

    /*
    * The index position of the column RUBELLA in the table.
    */
    public static final int RUBELLA_IDX = 7 ;

    /**
              * <p> Cancer of lymphoreticular or histiocytic tissue.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CANCER_OF_LYMPH_OR_HIS_TISSUE= "CANCER_OF_LYMPH_OR_HIS_TISSUE" ;

    /*
    * The index position of the column CANCER_OF_LYMPH_OR_HIS_TISSUE in the table.
    */
    public static final int CANCER_OF_LYMPH_OR_HIS_TISSUE_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ASYMPTOMATIC_HIV= "ASYMPTOMATIC_HIV" ;

    /*
    * The index position of the column ASYMPTOMATIC_HIV in the table.
    */
    public static final int ASYMPTOMATIC_HIV_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MULTIPLE_MYELOMA= "MULTIPLE_MYELOMA" ;

    /*
    * The index position of the column MULTIPLE_MYELOMA in the table.
    */
    public static final int MULTIPLE_MYELOMA_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LEUKEMIA= "LEUKEMIA" ;

    /*
    * The index position of the column LEUKEMIA in the table.
    */
    public static final int LEUKEMIA_IDX = 11 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IMMUNODEFICIENCY= "IMMUNODEFICIENCY" ;

    /*
    * The index position of the column IMMUNODEFICIENCY in the table.
    */
    public static final int IMMUNODEFICIENCY_IDX = 12 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HEPATITIS_B= "HEPATITIS_B" ;

    /*
    * The index position of the column HEPATITIS_B in the table.
    */
    public static final int HEPATITIS_B_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HEPATITIS_A= "HEPATITIS_A" ;

    /*
    * The index position of the column HEPATITIS_A in the table.
    */
    public static final int HEPATITIS_A_IDX = 14 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VZV= "VZV" ;

    /*
    * The index position of the column VZV in the table.
    */
    public static final int VZV_IDX = 15 ;

}
