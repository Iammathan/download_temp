package com.adventnet.charm;

/** <p> Description of the table <code>RCMPatientVsRuleUsage</code>.
 *  Column Name and Table Name of  database table  <code>RCMPatientVsRuleUsage</code> is mapped
 * as constants in this util.</p> 
  rule usage for a patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_PATIENT_VS_RULE_USAGE_ID}
  * </ul>
 */
 
public final class RCMPATIENTVSRULEUSAGE
{
    private RCMPATIENTVSRULEUSAGE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMPatientVsRuleUsage" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_PATIENT_VS_RULE_USAGE_ID= "RCM_PATIENT_VS_RULE_USAGE_ID" ;

    /*
    * The index position of the column RCM_PATIENT_VS_RULE_USAGE_ID in the table.
    */
    public static final int RCM_PATIENT_VS_RULE_USAGE_ID_IDX = 1 ;

    /**
              * <p> Practice Patient ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_NEW_CPT_USED= "IS_NEW_CPT_USED" ;

    /*
    * The index position of the column IS_NEW_CPT_USED in the table.
    */
    public static final int IS_NEW_CPT_USED_IDX = 3 ;

}
