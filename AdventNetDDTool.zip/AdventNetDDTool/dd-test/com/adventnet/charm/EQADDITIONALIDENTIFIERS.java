package com.adventnet.charm;

/** <p> Description of the table <code>EQAdditionalIdentifiers</code>.
 *  Column Name and Table Name of  database table  <code>EQAdditionalIdentifiers</code> is mapped
 * as constants in this util.</p> 
  This table maintains any identifiers used in the 270 request message to get the eligibility/benefit info. Such as Subscriber SSN, Provider Tax ID, Subscriber Group # etc.. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #EQ_IDENTIFIERS_UNIQUE_ID}
  * <li> {@link #ELIGIBILITY_270_REQUEST_ID}
  * </ul>
 */
 
public final class EQADDITIONALIDENTIFIERS
{
    private EQADDITIONALIDENTIFIERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EQAdditionalIdentifiers" ;
    /**
              * <p> Unique Identifier to denote/refer each set of Additional Identifiers used in the 270 Request.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EQ_IDENTIFIERS_UNIQUE_ID= "EQ_IDENTIFIERS_UNIQUE_ID" ;

    /*
    * The index position of the column EQ_IDENTIFIERS_UNIQUE_ID in the table.
    */
    public static final int EQ_IDENTIFIERS_UNIQUE_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of the Eligibility 270 Request.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ELIGIBILITY_270_REQUEST_ID= "ELIGIBILITY_270_REQUEST_ID" ;

    /*
    * The index position of the column ELIGIBILITY_270_REQUEST_ID in the table.
    */
    public static final int ELIGIBILITY_270_REQUEST_ID_IDX = 2 ;

    /**
              * <p> This column stores the qualifier code of the identifier. For eg: Qual.Code for Subscriber SSN is SY, Group # is 6P, Provider SSN is 34, etc .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_QUALIFIER= "IDENTIFIER_QUALIFIER" ;

    /*
    * The index position of the column IDENTIFIER_QUALIFIER in the table.
    */
    public static final int IDENTIFIER_QUALIFIER_IDX = 3 ;

    /**
              * <p> This column stores the name of the identifier. Such as SSN, Group #, etc..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_NAME= "IDENTIFIER_NAME" ;

    /*
    * The index position of the column IDENTIFIER_NAME in the table.
    */
    public static final int IDENTIFIER_NAME_IDX = 4 ;

    /**
              * <p> This column stores the identifier's value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_VALUE= "IDENTIFIER_VALUE" ;

    /*
    * The index position of the column IDENTIFIER_VALUE in the table.
    */
    public static final int IDENTIFIER_VALUE_IDX = 5 ;

    /**
              * <p> This column is used to get, to whom this identifier belongs to. Allowed values are 0 - Provider, 1 - Subscriber/Paitent , 2 - Dependent/Patient.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String GROUP= "GROUP" ;

    /*
    * The index position of the column GROUP in the table.
    */
    public static final int GROUP_IDX = 6 ;

}
