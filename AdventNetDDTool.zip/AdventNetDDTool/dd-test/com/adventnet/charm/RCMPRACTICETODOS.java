package com.adventnet.charm;

/** <p> Description of the table <code>RCMPracticeToDos</code>.
 *  Column Name and Table Name of  database table  <code>RCMPracticeToDos</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_PRACTICE_TODO_ID}
  * </ul>
 */
 
public final class RCMPRACTICETODOS
{
    private RCMPRACTICETODOS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMPracticeToDos" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_PRACTICE_TODO_ID= "RCM_PRACTICE_TODO_ID" ;

    /*
    * The index position of the column RCM_PRACTICE_TODO_ID in the table.
    */
    public static final int RCM_PRACTICE_TODO_ID_IDX = 1 ;

    /**
              * <p> Contain Practice TODO Data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>8192</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 2 ;

    /**
              * <p> Last edited Date.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_DATE= "LAST_EDITED_DATE" ;

    /*
    * The index position of the column LAST_EDITED_DATE in the table.
    */
    public static final int LAST_EDITED_DATE_IDX = 3 ;

    /**
              * <p> Member whom last added this Data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_USER_NAME= "LAST_EDITED_USER_NAME" ;

    /*
    * The index position of the column LAST_EDITED_USER_NAME in the table.
    */
    public static final int LAST_EDITED_USER_NAME_IDX = 4 ;

    /**
              * <p> For handling delete.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

    /**
              * <p> PracticeId of MBP for RCM Practice ToDos.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 6 ;

}
