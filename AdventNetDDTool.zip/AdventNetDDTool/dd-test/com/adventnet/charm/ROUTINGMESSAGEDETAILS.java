package com.adventnet.charm;

/** <p> Description of the table <code>RoutingMessageDetails</code>.
 *  Column Name and Table Name of  database table  <code>RoutingMessageDetails</code> is mapped
 * as constants in this util.</p> 
  Stores details about individual Prescription Messages. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MESSAGE_ID}
  * </ul>
 */
 
public final class ROUTINGMESSAGEDETAILS
{
    private ROUTINGMESSAGEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RoutingMessageDetails" ;
    /**
              * <p> Message ID from Messages table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 1 ;

    /**
              * <p> The message to be saved.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MESSAGE_JSON= "MESSAGE_JSON" ;

    /*
    * The index position of the column MESSAGE_JSON in the table.
    */
    public static final int MESSAGE_JSON_IDX = 2 ;

}
