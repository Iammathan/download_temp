package com.adventnet.charm;

/** <p> Description of the table <code>DFSMigrationDetails</code>.
 *  Column Name and Table Name of  database table  <code>DFSMigrationDetails</code> is mapped
 * as constants in this util.</p> 
  DFS Migration - Number of rows migrated in each module in each user space inserted here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DFS_MIGRATION_ID}
  * </ul>
 */
 
public final class DFSMIGRATIONDETAILS
{
    private DFSMIGRATIONDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DFSMigrationDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DFS_MIGRATION_ID= "DFS_MIGRATION_ID" ;

    /*
    * The index position of the column DFS_MIGRATION_ID in the table.
    */
    public static final int DFS_MIGRATION_ID_IDX = 1 ;

    /**
              * <p> Practice ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Name of hospital.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRACTICE_NAME= "PRACTICE_NAME" ;

    /*
    * The index position of the column PRACTICE_NAME in the table.
    */
    public static final int PRACTICE_NAME_IDX = 3 ;

    /**
              * <p> Name of module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MODULE_NAME= "MODULE_NAME" ;

    /*
    * The index position of the column MODULE_NAME in the table.
    */
    public static final int MODULE_NAME_IDX = 4 ;

    /**
              * <p> Rows migrated in the module.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MIGRATED_COUNT= "MIGRATED_COUNT" ;

    /*
    * The index position of the column MIGRATED_COUNT in the table.
    */
    public static final int MIGRATED_COUNT_IDX = 5 ;

    /**
              * <p> Total Rows in the module.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TOTAL_COUNT= "TOTAL_COUNT" ;

    /*
    * The index position of the column TOTAL_COUNT in the table.
    */
    public static final int TOTAL_COUNT_IDX = 6 ;

}
