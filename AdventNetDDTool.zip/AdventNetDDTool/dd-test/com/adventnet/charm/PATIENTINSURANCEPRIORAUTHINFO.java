package com.adventnet.charm;

/** <p> Description of the table <code>PatientInsurancePriorAuthInfo</code>.
 *  Column Name and Table Name of  database table  <code>PatientInsurancePriorAuthInfo</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAT_INS_PRIOR_AUTH_INFO_ID}
  * </ul>
 */
 
public final class PATIENTINSURANCEPRIORAUTHINFO
{
    private PATIENTINSURANCEPRIORAUTHINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientInsurancePriorAuthInfo" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAT_INS_PRIOR_AUTH_INFO_ID= "PAT_INS_PRIOR_AUTH_INFO_ID" ;

    /*
    * The index position of the column PAT_INS_PRIOR_AUTH_INFO_ID in the table.
    */
    public static final int PAT_INS_PRIOR_AUTH_INFO_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_INSURANCE_DETAILS_ID= "PATIENT_INSURANCE_DETAILS_ID" ;

    /*
    * The index position of the column PATIENT_INSURANCE_DETAILS_ID in the table.
    */
    public static final int PATIENT_INSURANCE_DETAILS_ID_IDX = 2 ;

    /**
              * <p> Prior Authorization Number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRIOR_AUTH_NUMBER= "PRIOR_AUTH_NUMBER" ;

    /*
    * The index position of the column PRIOR_AUTH_NUMBER in the table.
    */
    public static final int PRIOR_AUTH_NUMBER_IDX = 3 ;

    /**
              * <p> Prior Authorization Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                     * Default Value is <code>G1</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>G1</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>G1</code></li>
              * <li><code>9F</code></li>
              * <li><code>EW</code></li>
              * <li><code>X4</code></li>
              * </ul>
                         */
    public static final String PRIOR_AUTH_TYPE= "PRIOR_AUTH_TYPE" ;

    /*
    * The index position of the column PRIOR_AUTH_TYPE in the table.
    */
    public static final int PRIOR_AUTH_TYPE_IDX = 4 ;

    /**
              * <p> Prior Authorization starting date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRIOR_AUTH_START_DATE= "PRIOR_AUTH_START_DATE" ;

    /*
    * The index position of the column PRIOR_AUTH_START_DATE in the table.
    */
    public static final int PRIOR_AUTH_START_DATE_IDX = 5 ;

    /**
              * <p> Prior Authorization ending date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRIOR_AUTH_END_DATE= "PRIOR_AUTH_END_DATE" ;

    /*
    * The index position of the column PRIOR_AUTH_END_DATE in the table.
    */
    public static final int PRIOR_AUTH_END_DATE_IDX = 6 ;

    /**
              * <p> Speciality / Additional info.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SPECIALITY_INFO= "SPECIALITY_INFO" ;

    /*
    * The index position of the column SPECIALITY_INFO in the table.
    */
    public static final int SPECIALITY_INFO_IDX = 7 ;

    /**
              * <p> Specifies the allowed visit count for this prior auth.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ALLOWED_COUNT= "ALLOWED_COUNT" ;

    /*
    * The index position of the column ALLOWED_COUNT in the table.
    */
    public static final int ALLOWED_COUNT_IDX = 8 ;

    /**
              * <p> Specifies the used visit count for this prior auth.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String USED_COUNT= "USED_COUNT" ;

    /*
    * The index position of the column USED_COUNT in the table.
    */
    public static final int USED_COUNT_IDX = 9 ;

    /**
              * <p> Procedure codes associated with this prior auth. Will be stored as JSONArray.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROCEDURE_CODES= "PROCEDURE_CODES" ;

    /*
    * The index position of the column PROCEDURE_CODES in the table.
    */
    public static final int PROCEDURE_CODES_IDX = 10 ;

    /**
              * <p> Prior Authorization counter type.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>1</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>1</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String COUNTER_TYPE= "COUNTER_TYPE" ;

    /*
    * The index position of the column COUNTER_TYPE in the table.
    */
    public static final int COUNTER_TYPE_IDX = 11 ;

    /**
              * <p> Will warn user if available count is less than equal warning count .</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WARNING_COUNT= "WARNING_COUNT" ;

    /*
    * The index position of the column WARNING_COUNT in the table.
    */
    public static final int WARNING_COUNT_IDX = 12 ;

    /**
              * <p> Idendifier of the physician.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHYSICIAN_ID= "PHYSICIAN_ID" ;

    /*
    * The index position of the column PHYSICIAN_ID in the table.
    */
    public static final int PHYSICIAN_ID_IDX = 13 ;

}
