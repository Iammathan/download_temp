package com.adventnet.charm;

/** <p> Description of the table <code>OrderGuarantorDetails</code>.
 *  Column Name and Table Name of  database table  <code>OrderGuarantorDetails</code> is mapped
 * as constants in this util.</p> 
  Guarantor details on orders.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ORDER_GUARANTOR_ID}
  * </ul>
 */
 
public final class ORDERGUARANTORDETAILS
{
    private ORDERGUARANTORDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "OrderGuarantorDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORDER_GUARANTOR_ID= "ORDER_GUARANTOR_ID" ;

    /*
    * The index position of the column ORDER_GUARANTOR_ID in the table.
    */
    public static final int ORDER_GUARANTOR_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ORDER_ID= "LAB_ORDER_ID" ;

    /*
    * The index position of the column LAB_ORDER_ID in the table.
    */
    public static final int LAB_ORDER_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_FIRST_NAME= "GUARANTOR_FIRST_NAME" ;

    /*
    * The index position of the column GUARANTOR_FIRST_NAME in the table.
    */
    public static final int GUARANTOR_FIRST_NAME_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_LAST_NAME= "GUARANTOR_LAST_NAME" ;

    /*
    * The index position of the column GUARANTOR_LAST_NAME in the table.
    */
    public static final int GUARANTOR_LAST_NAME_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_ADDRESS_LINE_1= "GUARANTOR_ADDRESS_LINE_1" ;

    /*
    * The index position of the column GUARANTOR_ADDRESS_LINE_1 in the table.
    */
    public static final int GUARANTOR_ADDRESS_LINE_1_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_ADDRESS_LINE_2= "GUARANTOR_ADDRESS_LINE_2" ;

    /*
    * The index position of the column GUARANTOR_ADDRESS_LINE_2 in the table.
    */
    public static final int GUARANTOR_ADDRESS_LINE_2_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_CITY= "GUARANTOR_CITY" ;

    /*
    * The index position of the column GUARANTOR_CITY in the table.
    */
    public static final int GUARANTOR_CITY_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_STATE= "GUARANTOR_STATE" ;

    /*
    * The index position of the column GUARANTOR_STATE in the table.
    */
    public static final int GUARANTOR_STATE_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_COUNTRY= "GUARANTOR_COUNTRY" ;

    /*
    * The index position of the column GUARANTOR_COUNTRY in the table.
    */
    public static final int GUARANTOR_COUNTRY_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_ZIP= "GUARANTOR_ZIP" ;

    /*
    * The index position of the column GUARANTOR_ZIP in the table.
    */
    public static final int GUARANTOR_ZIP_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_PHONE= "GUARANTOR_PHONE" ;

    /*
    * The index position of the column GUARANTOR_PHONE in the table.
    */
    public static final int GUARANTOR_PHONE_IDX = 11 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_SSN= "GUARANTOR_SSN" ;

    /*
    * The index position of the column GUARANTOR_SSN in the table.
    */
    public static final int GUARANTOR_SSN_IDX = 12 ;

    /**
              * <p> Date of Birth of Guarantor.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GUARANTOR_DATE_OF_BIRTH= "GUARANTOR_DATE_OF_BIRTH" ;

    /*
    * The index position of the column GUARANTOR_DATE_OF_BIRTH in the table.
    */
    public static final int GUARANTOR_DATE_OF_BIRTH_IDX = 13 ;

    /**
              * <p> Gender of Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>male</code></li>
              * <li><code>female</code></li>
              * <li><code>unknown</code></li>
              * <li><code>other</code></li>
              * </ul>
                         */
    public static final String GUARANTOR_GENDER= "GUARANTOR_GENDER" ;

    /*
    * The index position of the column GUARANTOR_GENDER in the table.
    */
    public static final int GUARANTOR_GENDER_IDX = 14 ;

    /**
              * <p> Patient relationship with Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_RELATIONSHIP= "GUARANTOR_RELATIONSHIP" ;

    /*
    * The index position of the column GUARANTOR_RELATIONSHIP in the table.
    */
    public static final int GUARANTOR_RELATIONSHIP_IDX = 15 ;

    /**
              * <p> Guarantor Employer name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GUARANTOR_EMPLOYER_NAME= "GUARANTOR_EMPLOYER_NAME" ;

    /*
    * The index position of the column GUARANTOR_EMPLOYER_NAME in the table.
    */
    public static final int GUARANTOR_EMPLOYER_NAME_IDX = 16 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 17 ;

}
