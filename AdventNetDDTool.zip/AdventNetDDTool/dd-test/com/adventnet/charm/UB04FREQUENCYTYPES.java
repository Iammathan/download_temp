package com.adventnet.charm;

/** <p> Description of the table <code>UB04FrequencyTypes</code>.
 *  Column Name and Table Name of  database table  <code>UB04FrequencyTypes</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_FREQUENCY_ID}
  * </ul>
 */
 
public final class UB04FREQUENCYTYPES
{
    private UB04FREQUENCYTYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04FrequencyTypes" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_FREQUENCY_ID= "UB04_FREQUENCY_ID" ;

    /*
    * The index position of the column UB04_FREQUENCY_ID in the table.
    */
    public static final int UB04_FREQUENCY_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FREQUENCY_CODE= "FREQUENCY_CODE" ;

    /*
    * The index position of the column FREQUENCY_CODE in the table.
    */
    public static final int FREQUENCY_CODE_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FREQUENCY_DESC= "FREQUENCY_DESC" ;

    /*
    * The index position of the column FREQUENCY_DESC in the table.
    */
    public static final int FREQUENCY_DESC_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 6 ;

}
