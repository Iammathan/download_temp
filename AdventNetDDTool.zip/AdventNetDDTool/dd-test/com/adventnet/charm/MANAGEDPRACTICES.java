package com.adventnet.charm;

/** <p> Description of the table <code>ManagedPractices</code>.
 *  Column Name and Table Name of  database table  <code>ManagedPractices</code> is mapped
 * as constants in this util.</p> 
  List of practices managed by the reseller. Reseller space information. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MANAGED_PRACTICE_ID}
  * </ul>
 */
 
public final class MANAGEDPRACTICES
{
    private MANAGEDPRACTICES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ManagedPractices" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MANAGED_PRACTICE_ID= "MANAGED_PRACTICE_ID" ;

    /*
    * The index position of the column MANAGED_PRACTICE_ID in the table.
    */
    public static final int MANAGED_PRACTICE_ID_IDX = 1 ;

    /**
              * <p> practice id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Name of hospital.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRACTICE_NAME= "PRACTICE_NAME" ;

    /*
    * The index position of the column PRACTICE_NAME in the table.
    */
    public static final int PRACTICE_NAME_IDX = 3 ;

    /**
              * <p> Speciality for corresponding practice..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SPECIALITY= "SPECIALITY" ;

    /*
    * The index position of the column SPECIALITY in the table.
    */
    public static final int SPECIALITY_IDX = 4 ;

    /**
              * <p> practice zoho app account id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ZAAID= "PRACTICE_ZAAID" ;

    /*
    * The index position of the column PRACTICE_ZAAID in the table.
    */
    public static final int PRACTICE_ZAAID_IDX = 5 ;

    /**
              * <p> Created time of the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME_OF_ADDITION= "TIME_OF_ADDITION" ;

    /*
    * The index position of the column TIME_OF_ADDITION in the table.
    */
    public static final int TIME_OF_ADDITION_IDX = 6 ;

    /**
              * <p> ResellerMembersList.RESELLER_MEMBER_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 7 ;

    /**
              * <p> Can reseller edit practice settings.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_EDIT_SETTINGS= "ALLOW_EDIT_SETTINGS" ;

    /*
    * The index position of the column ALLOW_EDIT_SETTINGS in the table.
    */
    public static final int ALLOW_EDIT_SETTINGS_IDX = 8 ;

    /**
              * <p> Can reseller view analytics data of practice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_VIEW_ANALYTICS= "ALLOW_VIEW_ANALYTICS" ;

    /*
    * The index position of the column ALLOW_VIEW_ANALYTICS in the table.
    */
    public static final int ALLOW_VIEW_ANALYTICS_IDX = 9 ;

}
