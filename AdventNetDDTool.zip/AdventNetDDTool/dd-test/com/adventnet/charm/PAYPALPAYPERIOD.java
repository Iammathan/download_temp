package com.adventnet.charm;

/** <p> Description of the table <code>PayPalPayPeriod</code>.
 *  Column Name and Table Name of  database table  <code>PayPalPayPeriod</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAYPERIOD_ID}
  * </ul>
 */
 
public final class PAYPALPAYPERIOD
{
    private PAYPALPAYPERIOD()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PayPalPayPeriod" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String PAYPERIOD_ID= "PAYPERIOD_ID" ;

    /*
    * The index position of the column PAYPERIOD_ID in the table.
    */
    public static final int PAYPERIOD_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYPERIOD= "PAYPERIOD" ;

    /*
    * The index position of the column PAYPERIOD in the table.
    */
    public static final int PAYPERIOD_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DISPLAY_NAME= "DISPLAY_NAME" ;

    /*
    * The index position of the column DISPLAY_NAME in the table.
    */
    public static final int DISPLAY_NAME_IDX = 3 ;

}
