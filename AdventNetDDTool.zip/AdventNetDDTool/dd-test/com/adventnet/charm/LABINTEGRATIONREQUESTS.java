package com.adventnet.charm;

/** <p> Description of the table <code>LabIntegrationRequests</code>.
 *  Column Name and Table Name of  database table  <code>LabIntegrationRequests</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_INTEG_REQ_ID}
  * </ul>
 */
 
public final class LABINTEGRATIONREQUESTS
{
    private LABINTEGRATIONREQUESTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabIntegrationRequests" ;
    /**
              * <p> Unique value for Lab Request.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_INTEG_REQ_ID= "LAB_INTEG_REQ_ID" ;

    /*
    * The index position of the column LAB_INTEG_REQ_ID in the table.
    */
    public static final int LAB_INTEG_REQ_ID_IDX = 1 ;

    /**
              * <p> Unique ID for the Practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Name of the lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAB_NAME= "LAB_NAME" ;

    /*
    * The index position of the column LAB_NAME in the table.
    */
    public static final int LAB_NAME_IDX = 3 ;

    /**
              * <p> Unique ID of the Lab.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 4 ;

    /**
              * <p> Type of Lab: Lab Corp or Other Labs.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>Lab Corp</code></li>
              * <li><code>Other Labs</code></li>
              * </ul>
                         */
    public static final String LAB_TYPE= "LAB_TYPE" ;

    /*
    * The index position of the column LAB_TYPE in the table.
    */
    public static final int LAB_TYPE_IDX = 5 ;

    /**
              * <p> The Date when the request is made.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUEST_DATE= "REQUEST_DATE" ;

    /*
    * The index position of the column REQUEST_DATE in the table.
    */
    public static final int REQUEST_DATE_IDX = 6 ;

    /**
              * <p> The Last Update Date.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_UPDATED_DATE= "LAST_UPDATED_DATE" ;

    /*
    * The index position of the column LAST_UPDATED_DATE in the table.
    */
    public static final int LAST_UPDATED_DATE_IDX = 7 ;

    /**
              * <p> Unique ID for the video tutorial.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VIDEO_TUTORIAL_ID= "VIDEO_TUTORIAL_ID" ;

    /*
    * The index position of the column VIDEO_TUTORIAL_ID in the table.
    */
    public static final int VIDEO_TUTORIAL_ID_IDX = 8 ;

    /**
              * <p> The Type of request Uni/Bi-directional.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>Bi-Directional</code></li>
              * <li><code>Uni-Directional</code></li>
              * </ul>
                         */
    public static final String REQUEST_TYPE= "REQUEST_TYPE" ;

    /*
    * The index position of the column REQUEST_TYPE in the table.
    */
    public static final int REQUEST_TYPE_IDX = 9 ;

    /**
              * <p> The Notification message to be sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTIFICATION_MESSAGE= "NOTIFICATION_MESSAGE" ;

    /*
    * The index position of the column NOTIFICATION_MESSAGE in the table.
    */
    public static final int NOTIFICATION_MESSAGE_IDX = 10 ;

    /**
              * <p> Unique ID for Notification.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NOTIFICATION_ID= "NOTIFICATION_ID" ;

    /*
    * The index position of the column NOTIFICATION_ID in the table.
    */
    public static final int NOTIFICATION_ID_IDX = 11 ;

    /**
              * <p> By whom the data is added.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 12 ;

    /**
              * <p> Can be Approved by Client/Support/Lab-Team.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>Client</code></li>
              * <li><code>Support</code></li>
              * <li><code>Lab-Team</code></li>
              * </ul>
                         */
    public static final String CAN_BE_APPROVED_BY= "CAN_BE_APPROVED_BY" ;

    /*
    * The index position of the column CAN_BE_APPROVED_BY in the table.
    */
    public static final int CAN_BE_APPROVED_BY_IDX = 13 ;

    /**
              * <p> Contact of the Approved Client.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPROVED_CLIENT_CONTACT= "APPROVED_CLIENT_CONTACT" ;

    /*
    * The index position of the column APPROVED_CLIENT_CONTACT in the table.
    */
    public static final int APPROVED_CLIENT_CONTACT_IDX = 14 ;

    /**
              * <p> Enabled by whom.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENABLED_BY= "ENABLED_BY" ;

    /*
    * The index position of the column ENABLED_BY in the table.
    */
    public static final int ENABLED_BY_IDX = 15 ;

    /**
              * <p> The Go Live Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String GO_LIVE_DATE= "GO_LIVE_DATE" ;

    /*
    * The index position of the column GO_LIVE_DATE in the table.
    */
    public static final int GO_LIVE_DATE_IDX = 16 ;

    /**
              * <p> The Status of the request.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>Enabled</code></li>
              * <li><code>Cancelled</code></li>
              * <li><code>Waiting</code></li>
              * <li><code>Scheduled</code></li>
              * <li><code>Approved</code></li>
              * <li><code>Rejected</code></li>
              * <li><code>Live</code></li>
              * <li><code>Testing</code></li>
              * <li><code>Cancelled by ChARM</code></li>
              * </ul>
                         */
    public static final String REQUEST_STATUS= "REQUEST_STATUS" ;

    /*
    * The index position of the column REQUEST_STATUS in the table.
    */
    public static final int REQUEST_STATUS_IDX = 17 ;

    /**
              * <p> The Configuration details as JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CONFIG_DETAILS= "CONFIG_DETAILS" ;

    /*
    * The index position of the column CONFIG_DETAILS in the table.
    */
    public static final int CONFIG_DETAILS_IDX = 18 ;

    /**
              * <p> Any Additional Comments while adding data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 19 ;

    /**
              * <p> Is the request Closed or on hold.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_REQUEST_CLOSED= "IS_REQUEST_CLOSED" ;

    /*
    * The index position of the column IS_REQUEST_CLOSED in the table.
    */
    public static final int IS_REQUEST_CLOSED_IDX = 20 ;

    /**
              * <p> Any additional details to be added in future as JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 21 ;

    /**
              * <p> Name of the lab invoice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_INVOICE_ID= "LAB_INVOICE_ID" ;

    /*
    * The index position of the column LAB_INVOICE_ID in the table.
    */
    public static final int LAB_INVOICE_ID_IDX = 22 ;

}
