package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimNotes</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimNotes</code> is mapped
 * as constants in this util.</p> 
  Claim notes of the claim - added by user . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_NOTES_ID}
  * </ul>
 */
 
public final class RCMCLAIMNOTES
{
    private RCMCLAIMNOTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimNotes" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_NOTES_ID= "CLAIM_NOTES_ID" ;

    /*
    * The index position of the column CLAIM_NOTES_ID in the table.
    */
    public static final int CLAIM_NOTES_ID_IDX = 1 ;

    /**
              * <p> Claim Id of RCMClaimCompleteDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> Notes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 3 ;

    /**
              * <p> When the notes get added - On_Status_Change or Stand_Alone.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTES_TYPE= "NOTES_TYPE" ;

    /*
    * The index position of the column NOTES_TYPE in the table.
    */
    public static final int NOTES_TYPE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE_TIME= "ADDED_DATE_TIME" ;

    /*
    * The index position of the column ADDED_DATE_TIME in the table.
    */
    public static final int ADDED_DATE_TIME_IDX = 5 ;

    /**
              * <p> User ID adding the notes .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

    /**
              * <p> notes is chart note Modifier.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_CHART_NOTE_MODIFIED= "IS_CHART_NOTE_MODIFIED" ;

    /*
    * The index position of the column IS_CHART_NOTE_MODIFIED in the table.
    */
    public static final int IS_CHART_NOTE_MODIFIED_IDX = 7 ;

    /**
              * <p> identifies if a notes is added as flagged.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_FLAGGED= "IS_FLAGGED" ;

    /*
    * The index position of the column IS_FLAGGED in the table.
    */
    public static final int IS_FLAGGED_IDX = 8 ;

    /**
              * <p> identifies if it is >>> 0-Claim Notes (also applicable for notes with status change)  1-AR Caller Notes   2-Patient Calling Notes .</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String CATEGORY= "CATEGORY" ;

    /*
    * The index position of the column CATEGORY in the table.
    */
    public static final int CATEGORY_IDX = 9 ;

}
