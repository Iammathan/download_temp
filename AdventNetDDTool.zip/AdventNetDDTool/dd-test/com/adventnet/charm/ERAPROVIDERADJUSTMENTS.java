package com.adventnet.charm;

/** <p> Description of the table <code>ERAProviderAdjustments</code>.
 *  Column Name and Table Name of  database table  <code>ERAProviderAdjustments</code> is mapped
 * as constants in this util.</p> 
  stores the provider level adjustments for the received ERA Report in ERADetail table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_PROVIDER_ADJUSTMENT_ID}
  * </ul>
 */
 
public final class ERAPROVIDERADJUSTMENTS
{
    private ERAPROVIDERADJUSTMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERAProviderAdjustments" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_PROVIDER_ADJUSTMENT_ID= "ERA_PROVIDER_ADJUSTMENT_ID" ;

    /*
    * The index position of the column ERA_PROVIDER_ADJUSTMENT_ID in the table.
    */
    public static final int ERA_PROVIDER_ADJUSTMENT_ID_IDX = 1 ;

    /**
              * <p> PK of ERADetail, where the respective basic ERA detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_DETAIL_ID= "ERA_DETAIL_ID" ;

    /*
    * The index position of the column ERA_DETAIL_ID in the table.
    */
    public static final int ERA_DETAIL_ID_IDX = 2 ;

    /**
              * <p> PLB01 : #218 - Provider Identifiers. It is NPI if NPI mandated and provider is a covered health care provider. Else it is payer assigned provider id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROPVIDER_IDENTIFIER= "PROPVIDER_IDENTIFIER" ;

    /*
    * The index position of the column PROPVIDER_IDENTIFIER in the table.
    */
    public static final int PROPVIDER_IDENTIFIER_IDX = 3 ;

    /**
              * <p> PLB02 : #128 - Last day of Provider's Fiscal Period. If fiscal period not known then it will be Dec 31st of that year.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FISCAL_PERIOD_DATE= "FISCAL_PERIOD_DATE" ;

    /*
    * The index position of the column FISCAL_PERIOD_DATE in the table.
    */
    public static final int FISCAL_PERIOD_DATE_IDX = 4 ;

    /**
              * <p> PLB03-1 : #219 / PLB05-1 : #223 / PLB07-1 : #224 / PLB09-1 : #225.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_REASON_CODE= "ADJUSTMENT_REASON_CODE" ;

    /*
    * The index position of the column ADJUSTMENT_REASON_CODE in the table.
    */
    public static final int ADJUSTMENT_REASON_CODE_IDX = 5 ;

    /**
              * <p> PLB03-2 : #222 / PLB05-2 : #223 / PLB07-2 : #224 / PLB09-2 : #225.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_IDENTIFIER= "ADJUSTMENT_IDENTIFIER" ;

    /*
    * The index position of the column ADJUSTMENT_IDENTIFIER in the table.
    */
    public static final int ADJUSTMENT_IDENTIFIER_IDX = 6 ;

    /**
              * <p> PLB04 : #223 / PLB06 : #224 / PLB08 : #224 / PLB10 : #225.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROVIDER_ADJUSTMENT_AMOUNT= "PROVIDER_ADJUSTMENT_AMOUNT" ;

    /*
    * The index position of the column PROVIDER_ADJUSTMENT_AMOUNT in the table.
    */
    public static final int PROVIDER_ADJUSTMENT_AMOUNT_IDX = 7 ;

}
