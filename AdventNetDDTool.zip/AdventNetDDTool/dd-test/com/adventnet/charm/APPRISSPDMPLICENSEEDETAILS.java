package com.adventnet.charm;

/** <p> Description of the table <code>ApprissPDMPLicenseeDetails</code>.
 *  Column Name and Table Name of  database table  <code>ApprissPDMPLicenseeDetails</code> is mapped
 * as constants in this util.</p> 
  Share To PHR Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LICENSEE_PRIMARY_KEY}
  * </ul>
 */
 
public final class APPRISSPDMPLICENSEEDETAILS
{
    private APPRISSPDMPLICENSEEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ApprissPDMPLicenseeDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LICENSEE_PRIMARY_KEY= "LICENSEE_PRIMARY_KEY" ;

    /*
    * The index position of the column LICENSEE_PRIMARY_KEY in the table.
    */
    public static final int LICENSEE_PRIMARY_KEY_IDX = 1 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LICENSEE_NAME= "LICENSEE_NAME" ;

    /*
    * The index position of the column LICENSEE_NAME in the table.
    */
    public static final int LICENSEE_NAME_IDX = 2 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALLOWED_STATES= "ALLOWED_STATES" ;

    /*
    * The index position of the column ALLOWED_STATES in the table.
    */
    public static final int ALLOWED_STATES_IDX = 4 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String GATEWAY_STATUS= "GATEWAY_STATUS" ;

    /*
    * The index position of the column GATEWAY_STATUS in the table.
    */
    public static final int GATEWAY_STATUS_IDX = 5 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 6 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LICENSEE_ADDED_DATE= "LICENSEE_ADDED_DATE" ;

    /*
    * The index position of the column LICENSEE_ADDED_DATE in the table.
    */
    public static final int LICENSEE_ADDED_DATE_IDX = 7 ;

}
