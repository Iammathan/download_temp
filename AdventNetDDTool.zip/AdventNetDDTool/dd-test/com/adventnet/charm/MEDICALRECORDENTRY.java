package com.adventnet.charm;

/** <p> Description of the table <code>MedicalRecordEntry</code>.
 *  Column Name and Table Name of  database table  <code>MedicalRecordEntry</code> is mapped
 * as constants in this util.</p> 
  Medical Records entered (or imported from pdf) by users on date basis. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEDICAL_RECORD_ENTRY_ID}
  * </ul>
 */
 
public final class MEDICALRECORDENTRY
{
    private MEDICALRECORDENTRY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MedicalRecordEntry" ;
    /**
              * <p> Unique identifier of Medical Record ENTRY.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ENTRY_ID= "MEDICAL_RECORD_ENTRY_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ENTRY_ID in the table.
    */
    public static final int MEDICAL_RECORD_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 2 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ID= "MEDICAL_RECORD_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ID in the table.
    */
    public static final int MEDICAL_RECORD_ID_IDX = 3 ;

    /**
              * <p> Patient ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 4 ;

    /**
              * <p> Date on which the data is entered.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 5 ;

    /**
              * <p> Time on which the data is imported.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMPORTED_TIME= "IMPORTED_TIME" ;

    /*
    * The index position of the column IMPORTED_TIME in the table.
    */
    public static final int IMPORTED_TIME_IDX = 6 ;

    /**
              * <p> Link to the PDF document.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PDF_DOCUMENT= "PDF_DOCUMENT" ;

    /*
    * The index position of the column PDF_DOCUMENT in the table.
    */
    public static final int PDF_DOCUMENT_IDX = 7 ;

    /**
              * <p> MemberId, who imports this lab report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMPORTED_BY= "IMPORTED_BY" ;

    /*
    * The index position of the column IMPORTED_BY in the table.
    */
    public static final int IMPORTED_BY_IDX = 8 ;

    /**
              * <p> To check whether the report is imported by patient or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_IMPORTED_BY_PATIENT= "IS_IMPORTED_BY_PATIENT" ;

    /*
    * The index position of the column IS_IMPORTED_BY_PATIENT in the table.
    */
    public static final int IS_IMPORTED_BY_PATIENT_IDX = 9 ;

    /**
              * <p> Says who has added this record entry : Patient / LabCorp / etc....</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 10 ;

    /**
              * <p> Comments.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 11 ;

    /**
              * <p> Specimen Number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_NUMBER= "SPECIMEN_NUMBER" ;

    /*
    * The index position of the column SPECIMEN_NUMBER in the table.
    */
    public static final int SPECIMEN_NUMBER_IDX = 12 ;

    /**
              * <p> Specimen Collection Date. Record of the date and time the specimen was collected by LabCorp.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_COLLECTION_DATE= "SPECIMEN_COLLECTION_DATE" ;

    /*
    * The index position of the column SPECIMEN_COLLECTION_DATE in the table.
    */
    public static final int SPECIMEN_COLLECTION_DATE_IDX = 13 ;

    /**
              * <p> To maintain status of the lab order sent by Labcorp.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ORDER_STATUS= "ORDER_STATUS" ;

    /*
    * The index position of the column ORDER_STATUS in the table.
    */
    public static final int ORDER_STATUS_IDX = 14 ;

    /**
              * <p> Source of the specimen.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SOURCE_OF_SPECIMEN= "SOURCE_OF_SPECIMEN" ;

    /*
    * The index position of the column SOURCE_OF_SPECIMEN in the table.
    */
    public static final int SOURCE_OF_SPECIMEN_IDX = 15 ;

    /**
              * <p> Condition of the specimen.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONDITION_OF_SPECIMEN= "CONDITION_OF_SPECIMEN" ;

    /*
    * The index position of the column CONDITION_OF_SPECIMEN in the table.
    */
    public static final int CONDITION_OF_SPECIMEN_IDX = 16 ;

    /**
              * <p> Associated facility Id..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 17 ;

    /**
              * <p> GROUP_ID from MedicalRecordGroup table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GROUP_ID= "GROUP_ID" ;

    /*
    * The index position of the column GROUP_ID in the table.
    */
    public static final int GROUP_ID_IDX = 18 ;

    /**
              * <p> Status of the result 0-Normal / 1-Abnormal / 2-Unremarkable / NULL-Unknown.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESULT_STATUS= "RESULT_STATUS" ;

    /*
    * The index position of the column RESULT_STATUS in the table.
    */
    public static final int RESULT_STATUS_IDX = 19 ;

    /**
              * <p> Order Test map of the result.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ORDER_TEST_MAP_ID= "ORDER_TEST_MAP_ID" ;

    /*
    * The index position of the column ORDER_TEST_MAP_ID in the table.
    */
    public static final int ORDER_TEST_MAP_ID_IDX = 20 ;

    /**
              * <p> Stores additional details in JSON format.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 21 ;

    /**
              * <p> Associated lab facility Id. If lab facility is common for all the associated parameters, corresponding facility id has to be set here. If not common, facility id has to be set at the parameter level but not here..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_FACILITY_ID= "LAB_FACILITY_ID" ;

    /*
    * The index position of the column LAB_FACILITY_ID in the table.
    */
    public static final int LAB_FACILITY_ID_IDX = 22 ;

    /**
              * <p> Name of LAB.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_NAME= "LAB_NAME" ;

    /*
    * The index position of the column LAB_NAME in the table.
    */
    public static final int LAB_NAME_IDX = 23 ;

    /**
              * <p> Name of MedicalRecord.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEDICAL_RECORD_NAME= "MEDICAL_RECORD_NAME" ;

    /*
    * The index position of the column MEDICAL_RECORD_NAME in the table.
    */
    public static final int MEDICAL_RECORD_NAME_IDX = 24 ;

    /**
              * <p> lab_record_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_ID= "LAB_RECORD_ID" ;

    /*
    * The index position of the column LAB_RECORD_ID in the table.
    */
    public static final int LAB_RECORD_ID_IDX = 25 ;

    /**
              * <p> Test code specific to the associated lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_CODE= "LAB_RECORD_CODE" ;

    /*
    * The index position of the column LAB_RECORD_CODE in the table.
    */
    public static final int LAB_RECORD_CODE_IDX = 26 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 27 ;

    /**
              * <p> Name of Depatment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DEPARTMENT_NAME= "DEPARTMENT_NAME" ;

    /*
    * The index position of the column DEPARTMENT_NAME in the table.
    */
    public static final int DEPARTMENT_NAME_IDX = 28 ;

    /**
              * <p> test description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_DESCRIPTION= "TEST_DESCRIPTION" ;

    /*
    * The index position of the column TEST_DESCRIPTION in the table.
    */
    public static final int TEST_DESCRIPTION_IDX = 29 ;

}
