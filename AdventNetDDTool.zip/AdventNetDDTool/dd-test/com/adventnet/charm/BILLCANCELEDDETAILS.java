package com.adventnet.charm;

/** <p> Description of the table <code>BillCanceledDetails</code>.
 *  Column Name and Table Name of  database table  <code>BillCanceledDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_CANCEL_ID}
  * </ul>
 */
 
public final class BILLCANCELEDDETAILS
{
    private BILLCANCELEDDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillCanceledDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_CANCEL_ID= "BILL_CANCEL_ID" ;

    /*
    * The index position of the column BILL_CANCEL_ID in the table.
    */
    public static final int BILL_CANCEL_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ORIGNAL_BILL_ID= "ORIGNAL_BILL_ID" ;

    /*
    * The index position of the column ORIGNAL_BILL_ID in the table.
    */
    public static final int ORIGNAL_BILL_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREDIT_INVOICE_BILL_ID= "CREDIT_INVOICE_BILL_ID" ;

    /*
    * The index position of the column CREDIT_INVOICE_BILL_ID in the table.
    */
    public static final int CREDIT_INVOICE_BILL_ID_IDX = 3 ;

    /**
              * <p> Date and Time of Bill cancellation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CANCEL_DATE= "CANCEL_DATE" ;

    /*
    * The index position of the column CANCEL_DATE in the table.
    */
    public static final int CANCEL_DATE_IDX = 4 ;

    /**
              * <p> Person who has CANCELLED Bill.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CANCELLED_BY= "CANCELLED_BY" ;

    /*
    * The index position of the column CANCELLED_BY in the table.
    */
    public static final int CANCELLED_BY_IDX = 5 ;

    /**
              * <p>  Reason for cancelling this Bill .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 6 ;

}
