package com.adventnet.charm;

/** <p> Description of the table <code>FailedAppointmentSync</code>.
 *  Column Name and Table Name of  database table  <code>FailedAppointmentSync</code> is mapped
 * as constants in this util.</p> 
  Entries on the failed appointment synchronization. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #APPOINTMENT_ID}
  * </ul>
 */
 
public final class FAILEDAPPOINTMENTSYNC
{
    private FAILEDAPPOINTMENTSYNC()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FailedAppointmentSync" ;
    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 1 ;

    /**
              * <p> Appointment Id from AppointmentHistory table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 2 ;

    /**
              * <p> Action which is failed.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACTION_TYPE= "ACTION_TYPE" ;

    /*
    * The index position of the column ACTION_TYPE in the table.
    */
    public static final int ACTION_TYPE_IDX = 3 ;

    /**
              * <p> Number of Times the appointment is synced.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAILED_APP_COUNT= "FAILED_APP_COUNT" ;

    /*
    * The index position of the column FAILED_APP_COUNT in the table.
    */
    public static final int FAILED_APP_COUNT_IDX = 4 ;

}
