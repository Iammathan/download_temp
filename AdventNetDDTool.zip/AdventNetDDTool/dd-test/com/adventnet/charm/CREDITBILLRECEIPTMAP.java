package com.adventnet.charm;

/** <p> Description of the table <code>CreditBillReceiptMap</code>.
 *  Column Name and Table Name of  database table  <code>CreditBillReceiptMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CREDIT_BILL_RECEIPT_ID}
  * </ul>
 */
 
public final class CREDITBILLRECEIPTMAP
{
    private CREDITBILLRECEIPTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CreditBillReceiptMap" ;
    /**
              * <p> Unique Identifier for Credit Note, Credit Note Entry and Credit Receipt mapping.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CREDIT_BILL_RECEIPT_ID= "CREDIT_BILL_RECEIPT_ID" ;

    /*
    * The index position of the column CREDIT_BILL_RECEIPT_ID in the table.
    */
    public static final int CREDIT_BILL_RECEIPT_ID_IDX = 1 ;

    /**
              * <p> Refers BillDetails.BILL_ID of Credit Note.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREDIT_BILL_ID= "CREDIT_BILL_ID" ;

    /*
    * The index position of the column CREDIT_BILL_ID in the table.
    */
    public static final int CREDIT_BILL_ID_IDX = 2 ;

    /**
              * <p> Refers BillDetails.BILL_ID of Credit Note Entry.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREDIT_ENTRY_BILL_ID= "CREDIT_ENTRY_BILL_ID" ;

    /*
    * The index position of the column CREDIT_ENTRY_BILL_ID in the table.
    */
    public static final int CREDIT_ENTRY_BILL_ID_IDX = 3 ;

    /**
              * <p> Refers BillDetails.BILL_ID of Invoice for which this Credit Note is created.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORIGINAL_BILL_ID= "ORIGINAL_BILL_ID" ;

    /*
    * The index position of the column ORIGINAL_BILL_ID in the table.
    */
    public static final int ORIGINAL_BILL_ID_IDX = 4 ;

    /**
              * <p> Refers ReceiptDetails.RECEIPT_ID of Credit Receipt.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREDIT_RECEIPT_ID= "CREDIT_RECEIPT_ID" ;

    /*
    * The index position of the column CREDIT_RECEIPT_ID in the table.
    */
    public static final int CREDIT_RECEIPT_ID_IDX = 5 ;

}
