package com.adventnet.charm;

/** <p> Description of the table <code>AONESurveyAnswers</code>.
 *  Column Name and Table Name of  database table  <code>AONESurveyAnswers</code> is mapped
 * as constants in this util.</p> 
  Table to store multiple choice answers from Survey. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MULTIPLE_ENTRY_ID}
  * </ul>
 */
 
public final class AONESURVEYANSWERS
{
    private AONESURVEYANSWERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AONESurveyAnswers" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MULTIPLE_ENTRY_ID= "MULTIPLE_ENTRY_ID" ;

    /*
    * The index position of the column MULTIPLE_ENTRY_ID in the table.
    */
    public static final int MULTIPLE_ENTRY_ID_IDX = 1 ;

    /**
              * <p> One of the Multiple Choice for Intake questionnaire.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OPTION= "OPTION" ;

    /*
    * The index position of the column OPTION in the table.
    */
    public static final int OPTION_IDX = 2 ;

    /**
              * <p> One of the Multiple Choice Answer for Intake questionnaire.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ANSWER= "ANSWER" ;

    /*
    * The index position of the column ANSWER in the table.
    */
    public static final int ANSWER_IDX = 3 ;

    /**
              * <p> Mapping to SurveyEntries table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 4 ;

}
