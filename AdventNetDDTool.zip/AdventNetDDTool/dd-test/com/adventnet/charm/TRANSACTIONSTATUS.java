package com.adventnet.charm;

/** <p> Description of the table <code>TransactionStatus</code>.
 *  Column Name and Table Name of  database table  <code>TransactionStatus</code> is mapped
 * as constants in this util.</p> 
  Claim Transaction Status List of a practice used in EHR Billing Claim. Schema is similar to RCMTransactionStatus. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TRANSACTION_STATUS_ID}
  * </ul>
 */
 
public final class TRANSACTIONSTATUS
{
    private TRANSACTIONSTATUS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TransactionStatus" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_STATUS_ID= "TRANSACTION_STATUS_ID" ;

    /*
    * The index position of the column TRANSACTION_STATUS_ID in the table.
    */
    public static final int TRANSACTION_STATUS_ID_IDX = 1 ;

    /**
              * <p> Type The Transaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TRANSACTION_TYPE= "TRANSACTION_TYPE" ;

    /*
    * The index position of the column TRANSACTION_TYPE in the table.
    */
    public static final int TRANSACTION_TYPE_IDX = 2 ;

    /**
              * <p> Details of Your Transaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_DESCRIPTION= "TRANSACTION_DESCRIPTION" ;

    /*
    * The index position of the column TRANSACTION_DESCRIPTION in the table.
    */
    public static final int TRANSACTION_DESCRIPTION_IDX = 3 ;

    /**
              * <p> Date of The Transaction.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_ON= "ADDED_ON" ;

    /*
    * The index position of the column ADDED_ON in the table.
    */
    public static final int ADDED_ON_IDX = 4 ;

    /**
              * <p> Trasaction Status deletable or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String CANNOT_BE_DELETED= "CANNOT_BE_DELETED" ;

    /*
    * The index position of the column CANNOT_BE_DELETED in the table.
    */
    public static final int CANNOT_BE_DELETED_IDX = 5 ;

    /**
              * <p> Reason for cannot deleting the transaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NO_DELETE_REASON= "NO_DELETE_REASON" ;

    /*
    * The index position of the column NO_DELETE_REASON in the table.
    */
    public static final int NO_DELETE_REASON_IDX = 6 ;

    /**
              * <p> This is a code used to map status detail received in e-status inquiry with the respective transaction status. List is available in 'conf/Charm/realtime_claims/status/CharmTransactionCodeVsStatus.properties'.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ESTATUS_CODE= "ESTATUS_CODE" ;

    /*
    * The index position of the column ESTATUS_CODE in the table.
    */
    public static final int ESTATUS_CODE_IDX = 7 ;

}
