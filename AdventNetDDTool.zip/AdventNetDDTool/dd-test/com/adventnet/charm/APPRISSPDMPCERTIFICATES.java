package com.adventnet.charm;

/** <p> Description of the table <code>ApprissPDMPCertificates</code>.
 *  Column Name and Table Name of  database table  <code>ApprissPDMPCertificates</code> is mapped
 * as constants in this util.</p> 
  Share To PHR Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CERTIFICATE_PRIMARY_KEY}
  * </ul>
 */
 
public final class APPRISSPDMPCERTIFICATES
{
    private APPRISSPDMPCERTIFICATES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ApprissPDMPCertificates" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CERTIFICATE_PRIMARY_KEY= "CERTIFICATE_PRIMARY_KEY" ;

    /*
    * The index position of the column CERTIFICATE_PRIMARY_KEY in the table.
    */
    public static final int CERTIFICATE_PRIMARY_KEY_IDX = 1 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLIENT_KEY_LOCATION= "CLIENT_KEY_LOCATION" ;

    /*
    * The index position of the column CLIENT_KEY_LOCATION in the table.
    */
    public static final int CLIENT_KEY_LOCATION_IDX = 2 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CSR_LOCATION= "CSR_LOCATION" ;

    /*
    * The index position of the column CSR_LOCATION in the table.
    */
    public static final int CSR_LOCATION_IDX = 3 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CERT_LOCATION= "CERT_LOCATION" ;

    /*
    * The index position of the column CERT_LOCATION in the table.
    */
    public static final int CERT_LOCATION_IDX = 4 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PFX_LOCATION= "PFX_LOCATION" ;

    /*
    * The index position of the column PFX_LOCATION in the table.
    */
    public static final int PFX_LOCATION_IDX = 5 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PASS_PHRASE= "PASS_PHRASE" ;

    /*
    * The index position of the column PASS_PHRASE in the table.
    */
    public static final int PASS_PHRASE_IDX = 6 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String ACTIVE= "ACTIVE" ;

    /*
    * The index position of the column ACTIVE in the table.
    */
    public static final int ACTIVE_IDX = 7 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 8 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 9 ;

    /**
              * <p> Surescripts/Appriss/Exostar..etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VENDOR= "VENDOR" ;

    /*
    * The index position of the column VENDOR in the table.
    */
    public static final int VENDOR_IDX = 10 ;

}
