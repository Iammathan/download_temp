package com.adventnet.charm;

/** <p> Description of the table <code>ActivityReferralMap</code>.
 *  Column Name and Table Name of  database table  <code>ActivityReferralMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Activity and Referral Template. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACTIVITY_LOG_ID}
  * </ul>
 */
 
public final class ACTIVITYREFERRALMAP
{
    private ACTIVITYREFERRALMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ActivityReferralMap" ;
    /**
              * <p> Activity Log id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACTIVITY_LOG_ID= "ACTIVITY_LOG_ID" ;

    /*
    * The index position of the column ACTIVITY_LOG_ID in the table.
    */
    public static final int ACTIVITY_LOG_ID_IDX = 1 ;

    /**
              * <p> File Id .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 2 ;

}
