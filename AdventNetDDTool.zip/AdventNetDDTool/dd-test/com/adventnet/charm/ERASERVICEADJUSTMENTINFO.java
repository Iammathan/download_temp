package com.adventnet.charm;

/** <p> Description of the table <code>ERAServiceAdjustmentInfo</code>.
 *  Column Name and Table Name of  database table  <code>ERAServiceAdjustmentInfo</code> is mapped
 * as constants in this util.</p> 
  stores the adjustment detail of any service in the ERAServiceDetail table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_SERVICE_ADJUSTMENT_INFO_ID}
  * </ul>
 */
 
public final class ERASERVICEADJUSTMENTINFO
{
    private ERASERVICEADJUSTMENTINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERAServiceAdjustmentInfo" ;
    /**
              * <p> SAS Key - Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_SERVICE_ADJUSTMENT_INFO_ID= "ERA_SERVICE_ADJUSTMENT_INFO_ID" ;

    /*
    * The index position of the column ERA_SERVICE_ADJUSTMENT_INFO_ID in the table.
    */
    public static final int ERA_SERVICE_ADJUSTMENT_INFO_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERAServiceDetail table, where the respective line item detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_SERVICE_DETAIL_ID= "ERA_SERVICE_DETAIL_ID" ;

    /*
    * The index position of the column ERA_SERVICE_DETAIL_ID in the table.
    */
    public static final int ERA_SERVICE_DETAIL_ID_IDX = 2 ;

    /**
              * <p> 2110 : CAS01 : #198 - Claim Adjustment Group Code. Code description is present in ClaimAdjustmentGroupCodes.properties.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_GROUP_CODE= "ADJUSTMENT_GROUP_CODE" ;

    /*
    * The index position of the column ADJUSTMENT_GROUP_CODE in the table.
    */
    public static final int ADJUSTMENT_GROUP_CODE_IDX = 3 ;

    /**
              * <p> 21110 : CAS02 : #198 / CAS05 : #199 / CAS08 : #200 / CAS11 : #201 / CAS14 : #202 / CAS17 : #203 - Claim Adjustment Reason Codes - description is in ClaimAdjustmentReasonCodes.properties file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_REASON_CODE= "ADJUSTMENT_REASON_CODE" ;

    /*
    * The index position of the column ADJUSTMENT_REASON_CODE in the table.
    */
    public static final int ADJUSTMENT_REASON_CODE_IDX = 4 ;

    /**
              * <p> 2110 : CAS03 : #199 / CAS06 : #199 / CAS09 : #200 / CAS12 : #201 / CAS15 : #202 / CAS18 : #203 - Amount which has been adjusted; either positive or negative, which either decreases or increases the payment respectively.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_AMOUNT= "ADJUSTMENT_AMOUNT" ;

    /*
    * The index position of the column ADJUSTMENT_AMOUNT in the table.
    */
    public static final int ADJUSTMENT_AMOUNT_IDX = 5 ;

    /**
              * <p> 2110 : CAS04 : #199 / CAS07 : #200 / CAS10 : #200 / CAS13 : #201 / CAS16 : #202 / CAS19 : #203; Adjusted quantity.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_QUANTITY= "ADJUSTMENT_QUANTITY" ;

    /*
    * The index position of the column ADJUSTMENT_QUANTITY in the table.
    */
    public static final int ADJUSTMENT_QUANTITY_IDX = 6 ;

}
