package com.adventnet.charm;

/** <p> Description of the table <code>RenderingProviderList</code>.
 *  Column Name and Table Name of  database table  <code>RenderingProviderList</code> is mapped
 * as constants in this util.</p> 
  Information about Practice Members. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROVIDER_ID}
  * </ul>
 */
 
public final class RENDERINGPROVIDERLIST
{
    private RENDERINGPROVIDERLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RenderingProviderList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROVIDER_ID= "PROVIDER_ID" ;

    /*
    * The index position of the column PROVIDER_ID in the table.
    */
    public static final int PROVIDER_ID_IDX = 1 ;

    /**
              * <p> First name of the practice member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 2 ;

    /**
              * <p> Last name of the practice member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 3 ;

    /**
              * <p> Physician identification number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DEA_NUMBER= "DEA_NUMBER" ;

    /*
    * The index position of the column DEA_NUMBER in the table.
    */
    public static final int DEA_NUMBER_IDX = 4 ;

    /**
              * <p> National Provider Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 5 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUALIFIER_NUMBER= "QUALIFIER_NUMBER" ;

    /*
    * The index position of the column QUALIFIER_NUMBER in the table.
    */
    public static final int QUALIFIER_NUMBER_IDX = 6 ;

    /**
              * <p> Name of the qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUALIFIER_NAME= "QUALIFIER_NAME" ;

    /*
    * The index position of the column QUALIFIER_NAME in the table.
    */
    public static final int QUALIFIER_NAME_IDX = 7 ;

    /**
              * <p> Non National Provider Identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NON_NPI= "NON_NPI" ;

    /*
    * The index position of the column NON_NPI in the table.
    */
    public static final int NON_NPI_IDX = 8 ;

}
