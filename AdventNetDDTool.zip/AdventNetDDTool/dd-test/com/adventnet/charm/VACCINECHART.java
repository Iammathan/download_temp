package com.adventnet.charm;

/** <p> Description of the table <code>VaccineChart</code>.
 *  Column Name and Table Name of  database table  <code>VaccineChart</code> is mapped
 * as constants in this util.</p> 
  List of Vaccine Chart templates. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VACCINE_CHART_ID}
  * </ul>
 */
 
public final class VACCINECHART
{
    private VACCINECHART()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VaccineChart" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VACCINE_CHART_ID= "VACCINE_CHART_ID" ;

    /*
    * The index position of the column VACCINE_CHART_ID in the table.
    */
    public static final int VACCINE_CHART_ID_IDX = 1 ;

    /**
              * <p> Name of Vaccine Chart.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VACCINE_CHART_NAME= "VACCINE_CHART_NAME" ;

    /*
    * The index position of the column VACCINE_CHART_NAME in the table.
    */
    public static final int VACCINE_CHART_NAME_IDX = 2 ;

}
