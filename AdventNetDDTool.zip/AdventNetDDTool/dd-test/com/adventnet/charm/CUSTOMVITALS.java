package com.adventnet.charm;

/** <p> Description of the table <code>CustomVitals</code>.
 *  Column Name and Table Name of  database table  <code>CustomVitals</code> is mapped
 * as constants in this util.</p> 
  Entries for Custom Vitals. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VITAL_ID}
  * </ul>
 */
 
public final class CUSTOMVITALS
{
    private CUSTOMVITALS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CustomVitals" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VITAL_ID= "VITAL_ID" ;

    /*
    * The index position of the column VITAL_ID in the table.
    */
    public static final int VITAL_ID_IDX = 1 ;

    /**
              * <p> Name of the vital.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 2 ;

    /**
              * <p> Vital Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 3 ;

    /**
              * <p> Unit for custom vital.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String UNIT= "UNIT" ;

    /*
    * The index position of the column UNIT in the table.
    */
    public static final int UNIT_IDX = 4 ;

    /**
              * <p> Status of the vital.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

    /**
              * <p> Options for Custom Vital.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String OPTIONS= "OPTIONS" ;

    /*
    * The index position of the column OPTIONS in the table.
    */
    public static final int OPTIONS_IDX = 6 ;

    /**
              * <p> True when added for custom vitals section. False when added from flowsheet.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_VITAL= "IS_VITAL" ;

    /*
    * The index position of the column IS_VITAL in the table.
    */
    public static final int IS_VITAL_IDX = 7 ;

    /**
              * <p> Display data as combo/radio/checkbox.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISPLAY_VIEW= "DISPLAY_VIEW" ;

    /*
    * The index position of the column DISPLAY_VIEW in the table.
    */
    public static final int DISPLAY_VIEW_IDX = 8 ;

    /**
              * <p> Include additional notes for flowsheet options.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String INCLUDE_ADDITIONAL_NOTES= "INCLUDE_ADDITIONAL_NOTES" ;

    /*
    * The index position of the column INCLUDE_ADDITIONAL_NOTES in the table.
    */
    public static final int INCLUDE_ADDITIONAL_NOTES_IDX = 9 ;

    /**
              * <p> Placeholder for additional notes, if added.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS_PLACEHOLDER= "COMMENTS_PLACEHOLDER" ;

    /*
    * The index position of the column COMMENTS_PLACEHOLDER in the table.
    */
    public static final int COMMENTS_PLACEHOLDER_IDX = 10 ;

}
