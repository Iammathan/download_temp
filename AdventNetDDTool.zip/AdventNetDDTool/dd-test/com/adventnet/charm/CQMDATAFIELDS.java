package com.adventnet.charm;

/** <p> Description of the table <code>CQMDataFields</code>.
 *  Column Name and Table Name of  database table  <code>CQMDataFields</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CQM_DATA_FIELD_ID}
  * </ul>
 */
 
public final class CQMDATAFIELDS
{
    private CQMDATAFIELDS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMDataFields" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CQM_DATA_FIELD_ID= "CQM_DATA_FIELD_ID" ;

    /*
    * The index position of the column CQM_DATA_FIELD_ID in the table.
    */
    public static final int CQM_DATA_FIELD_ID_IDX = 1 ;

    /**
              * <p> Unique identifier of the measure.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEASURE_ID= "MEASURE_ID" ;

    /*
    * The index position of the column MEASURE_ID in the table.
    */
    public static final int MEASURE_ID_IDX = 2 ;

    /**
              * <p> Action Performed description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DATA_FIELD= "DATA_FIELD" ;

    /*
    * The index position of the column DATA_FIELD in the table.
    */
    public static final int DATA_FIELD_IDX = 3 ;

    /**
              * <p> Action / Exclusion / Exception.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DATA_TYPE= "DATA_TYPE" ;

    /*
    * The index position of the column DATA_TYPE in the table.
    */
    public static final int DATA_TYPE_IDX = 4 ;

    /**
              * <p> Value set for the data field.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VALUE_SET= "VALUE_SET" ;

    /*
    * The index position of the column VALUE_SET in the table.
    */
    public static final int VALUE_SET_IDX = 5 ;

    /**
              * <p> Code for the data field.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE= "CODE" ;

    /*
    * The index position of the column CODE in the table.
    */
    public static final int CODE_IDX = 6 ;

}
