package com.adventnet.charm;

/** <p> Description of the table <code>MemberWorkTimingsException</code>.
 *  Column Name and Table Name of  database table  <code>MemberWorkTimingsException</code> is mapped
 * as constants in this util.</p> 
  Members to work with exception on particular date. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXCEPTION_ID}
  * </ul>
 */
 
public final class MEMBERWORKTIMINGSEXCEPTION
{
    private MEMBERWORKTIMINGSEXCEPTION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MemberWorkTimingsException" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXCEPTION_ID= "EXCEPTION_ID" ;

    /*
    * The index position of the column EXCEPTION_ID in the table.
    */
    public static final int EXCEPTION_ID_IDX = 1 ;

    /**
              * <p> Id of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Id of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Column to identify the exception configuration is working or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_WORKING= "IS_WORKING" ;

    /*
    * The index position of the column IS_WORKING in the table.
    */
    public static final int IS_WORKING_IDX = 4 ;

    /**
              * <p> Column to identify the exception configuration will affect online or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ONLINE= "IS_ONLINE" ;

    /*
    * The index position of the column IS_ONLINE in the table.
    */
    public static final int IS_ONLINE_IDX = 5 ;

    /**
              * <p> Date from which exception days starts .</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 6 ;

    /**
              * <p> Date to which exception days ends.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 7 ;

}
