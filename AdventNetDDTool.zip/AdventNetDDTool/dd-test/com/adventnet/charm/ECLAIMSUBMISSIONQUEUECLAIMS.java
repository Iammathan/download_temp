package com.adventnet.charm;

/** <p> Description of the table <code>EClaimSubmissionQueueClaims</code>.
 *  Column Name and Table Name of  database table  <code>EClaimSubmissionQueueClaims</code> is mapped
 * as constants in this util.</p> 
  This table maintains all the claims associated to an e-Claim Submission Queue. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ECLAIM_QUEUE_CLAIM_ID}
  * </ul>
 */
 
public final class ECLAIMSUBMISSIONQUEUECLAIMS
{
    private ECLAIMSUBMISSIONQUEUECLAIMS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EClaimSubmissionQueueClaims" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_QUEUE_CLAIM_ID= "ECLAIM_QUEUE_CLAIM_ID" ;

    /*
    * The index position of the column ECLAIM_QUEUE_CLAIM_ID in the table.
    */
    public static final int ECLAIM_QUEUE_CLAIM_ID_IDX = 1 ;

    /**
              * <p> Practice Space key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_QUEUE_ID= "ECLAIM_QUEUE_ID" ;

    /*
    * The index position of the column ECLAIM_QUEUE_ID in the table.
    */
    public static final int ECLAIM_QUEUE_ID_IDX = 2 ;

    /**
              * <p> Unique ID of the Claim (RCM)ClaimCompleteDetails - PK.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 3 ;

    /**
              * <p> Billing Provider's NPI present in the claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILLING_NPI= "BILLING_NPI" ;

    /*
    * The index position of the column BILLING_NPI in the table.
    */
    public static final int BILLING_NPI_IDX = 4 ;

    /**
              * <p> Billing Provider's Tax Id present in the claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILLING_TAX_ID= "BILLING_TAX_ID" ;

    /*
    * The index position of the column BILLING_TAX_ID in the table.
    */
    public static final int BILLING_TAX_ID_IDX = 5 ;

    /**
              * <p> Billing Provider's Id Qualifier present in the claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 6 ;

    /**
              * <p> Billing Provider's Id present in the claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 7 ;

    /**
              * <p> This is the Patient record id used to identify the practice of the 277 or 835.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_CLAIM_CONTROL_NO= "PATIENT_CLAIM_CONTROL_NO" ;

    /*
    * The index position of the column PATIENT_CLAIM_CONTROL_NO in the table.
    */
    public static final int PATIENT_CLAIM_CONTROL_NO_IDX = 8 ;

    /**
              * <p> Date of Service of a specific claim.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_SERVICE= "DATE_OF_SERVICE" ;

    /*
    * The index position of the column DATE_OF_SERVICE in the table.
    */
    public static final int DATE_OF_SERVICE_IDX = 9 ;

}
