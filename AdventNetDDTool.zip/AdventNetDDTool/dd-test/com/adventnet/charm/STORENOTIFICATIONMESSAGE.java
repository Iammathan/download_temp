package com.adventnet.charm;

/** <p> Description of the table <code>StoreNotificationMessage</code>.
 *  Column Name and Table Name of  database table  <code>StoreNotificationMessage</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SNM_ID}
  * </ul>
 */
 
public final class STORENOTIFICATIONMESSAGE
{
    private STORENOTIFICATIONMESSAGE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "StoreNotificationMessage" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String SNM_ID= "SNM_ID" ;

    /*
    * The index position of the column SNM_ID in the table.
    */
    public static final int SNM_ID_IDX = 1 ;

    /**
              * <p>  PLAN_CUSTOMER_ID available in the ServiceCustomerPlan .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PLAN_CUSTOMER_ID= "PLAN_CUSTOMER_ID" ;

    /*
    * The index position of the column PLAN_CUSTOMER_ID in the table.
    */
    public static final int PLAN_CUSTOMER_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SERVICE_CUSTOMER_ID= "SERVICE_CUSTOMER_ID" ;

    /*
    * The index position of the column SERVICE_CUSTOMER_ID in the table.
    */
    public static final int SERVICE_CUSTOMER_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MESSAGE_TYPE= "MESSAGE_TYPE" ;

    /*
    * The index position of the column MESSAGE_TYPE in the table.
    */
    public static final int MESSAGE_TYPE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_MESSAGE= "NOTIFICATION_MESSAGE" ;

    /*
    * The index position of the column NOTIFICATION_MESSAGE in the table.
    */
    public static final int NOTIFICATION_MESSAGE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 6 ;

}
