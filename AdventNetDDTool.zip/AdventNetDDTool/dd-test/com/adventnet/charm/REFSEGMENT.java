package com.adventnet.charm;

/** <p> Description of the table <code>REFSegment</code>.
 *  Column Name and Table Name of  database table  <code>REFSegment</code> is mapped
 * as constants in this util.</p> 
  REF Segment values (from REF01 to REF04) Additional Identifiers that may be required by Source in the Subsequent EDI Transactions. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REF_SEGMENT_ID}
  * </ul>
 */
 
public final class REFSEGMENT
{
    private REFSEGMENT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "REFSegment" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_SEGMENT_ID= "REF_SEGMENT_ID" ;

    /*
    * The index position of the column REF_SEGMENT_ID in the table.
    */
    public static final int REF_SEGMENT_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of the respective Eligibility Information Group.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ELIGIBILITY_BENEFIT_INFO_ID= "ELIGIBILITY_BENEFIT_INFO_ID" ;

    /*
    * The index position of the column ELIGIBILITY_BENEFIT_INFO_ID in the table.
    */
    public static final int ELIGIBILITY_BENEFIT_INFO_ID_IDX = 2 ;

    /**
              * <p> REF01 - Qualifier of the Identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_QUALIFIER= "IDENTIFIER_QUALIFIER" ;

    /*
    * The index position of the column IDENTIFIER_QUALIFIER in the table.
    */
    public static final int IDENTIFIER_QUALIFIER_IDX = 3 ;

    /**
              * <p> Name of Identifier from 271_CodeDescription.xml .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_NAME= "IDENTIFIER_NAME" ;

    /*
    * The index position of the column IDENTIFIER_NAME in the table.
    */
    public static final int IDENTIFIER_NAME_IDX = 4 ;

    /**
              * <p> REF02 - Identifier Value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_VALUE= "IDENTIFIER_VALUE" ;

    /*
    * The index position of the column IDENTIFIER_VALUE in the table.
    */
    public static final int IDENTIFIER_VALUE_IDX = 5 ;

    /**
              * <p> REF03 - Description about the Identifier .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 6 ;

    /**
              * <p> Group the Identifer occurs such as SUBSCRIBER, DEPDEDENT, PROVIDER.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER_GROUP= "IDENTIFIER_GROUP" ;

    /*
    * The index position of the column IDENTIFIER_GROUP in the table.
    */
    public static final int IDENTIFIER_GROUP_IDX = 7 ;

    /**
              * <p> Unique Identifier of the respective Eligibility Information Group.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NM1_SEGMENT_ID= "NM1_SEGMENT_ID" ;

    /*
    * The index position of the column NM1_SEGMENT_ID in the table.
    */
    public static final int NM1_SEGMENT_ID_IDX = 8 ;

}
