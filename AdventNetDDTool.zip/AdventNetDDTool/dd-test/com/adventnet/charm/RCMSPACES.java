package com.adventnet.charm;

/** <p> Description of the table <code>RCMSpaces</code>.
 *  Column Name and Table Name of  database table  <code>RCMSpaces</code> is mapped
 * as constants in this util.</p> 
  List of rcmspaces. Data is dumped in profilespace. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_PRACT_ID}
  * </ul>
 */
 
public final class RCMSPACES
{
    private RCMSPACES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMSpaces" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_PRACT_ID= "RCM_PRACT_ID" ;

    /*
    * The index position of the column RCM_PRACT_ID in the table.
    */
    public static final int RCM_PRACT_ID_IDX = 1 ;

    /**
              * <p> Id of the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Date and time on which it is added.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 3 ;

    /**
              * <p> To check whether it is active or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 4 ;

    /**
              * <p> To mark the RCMSpace as test account.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_TEST_SETUP= "IS_TEST_SETUP" ;

    /*
    * The index position of the column IS_TEST_SETUP in the table.
    */
    public static final int IS_TEST_SETUP_IDX = 5 ;

    /**
              * <p> Type of account.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                            * Default Value is <code>null</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>null</code>" , 
       * will be taken.<br>
                         */
    public static final String ACCOUNT_TYPE= "ACCOUNT_TYPE" ;

    /*
    * The index position of the column ACCOUNT_TYPE in the table.
    */
    public static final int ACCOUNT_TYPE_IDX = 6 ;

    /**
              * <p> Privilege to acces Ivoice TAB.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_BILLING_TAB= "ALLOW_BILLING_TAB" ;

    /*
    * The index position of the column ALLOW_BILLING_TAB in the table.
    */
    public static final int ALLOW_BILLING_TAB_IDX = 7 ;

    /**
              * <p> Privilege to acces Patient Details.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_PATIENT_DEMOGRAPHICS= "ALLOW_PATIENT_DEMOGRAPHICS" ;

    /*
    * The index position of the column ALLOW_PATIENT_DEMOGRAPHICS in the table.
    */
    public static final int ALLOW_PATIENT_DEMOGRAPHICS_IDX = 8 ;

    /**
              * <p> Rule Engine feature.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_RULE_ENGINE_ENABLED= "IS_RULE_ENGINE_ENABLED" ;

    /*
    * The index position of the column IS_RULE_ENGINE_ENABLED in the table.
    */
    public static final int IS_RULE_ENGINE_ENABLED_IDX = 9 ;

    /**
              * <p> Privilege to acces CMS Form.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_EDIT_CMS_FORM= "ALLOW_EDIT_CMS_FORM" ;

    /*
    * The index position of the column ALLOW_EDIT_CMS_FORM in the table.
    */
    public static final int ALLOW_EDIT_CMS_FORM_IDX = 10 ;

    /**
              * <p> Privilege to mark claims if payment reversal is expected.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_REVERSAL_MARKING_ENABLED= "IS_REVERSAL_MARKING_ENABLED" ;

    /*
    * The index position of the column IS_REVERSAL_MARKING_ENABLED in the table.
    */
    public static final int IS_REVERSAL_MARKING_ENABLED_IDX = 11 ;

    /**
              * <p> Privilege to show bulk claims generation option by import.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_BULK_CLAIM_IMPORT= "ALLOW_BULK_CLAIM_IMPORT" ;

    /*
    * The index position of the column ALLOW_BULK_CLAIM_IMPORT in the table.
    */
    public static final int ALLOW_BULK_CLAIM_IMPORT_IDX = 12 ;

}
