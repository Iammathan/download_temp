package com.adventnet.charm;

/** <p> Description of the table <code>ERAClaimOutPatAdjudicInfo</code>.
 *  Column Name and Table Name of  database table  <code>ERAClaimOutPatAdjudicInfo</code> is mapped
 * as constants in this util.</p> 
  stores remittance advice remarks(codes) for out-patient / professional claims. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_CLAIM_OUT_PAT_ADJUD_ID}
  * </ul>
 */
 
public final class ERACLAIMOUTPATADJUDICINFO
{
    private ERACLAIMOUTPATADJUDICINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERAClaimOutPatAdjudicInfo" ;
    /**
              * <p> SAS Key - Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_CLAIM_OUT_PAT_ADJUD_ID= "ERA_CLAIM_OUT_PAT_ADJUD_ID" ;

    /*
    * The index position of the column ERA_CLAIM_OUT_PAT_ADJUD_ID in the table.
    */
    public static final int ERA_CLAIM_OUT_PAT_ADJUD_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERAClaimDetail table, where the respective claim detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_CLAIM_DETAIL_ID= "ERA_CLAIM_DETAIL_ID" ;

    /*
    * The index position of the column ERA_CLAIM_DETAIL_ID in the table.
    */
    public static final int ERA_CLAIM_DETAIL_ID_IDX = 2 ;

    /**
              * <p> 2100 : MOA01 : #166 - Non-zero reimbursement rate for out-patient institutional claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REIMBURSEMENT_RATE= "REIMBURSEMENT_RATE" ;

    /*
    * The index position of the column REIMBURSEMENT_RATE in the table.
    */
    public static final int REIMBURSEMENT_RATE_IDX = 3 ;

    /**
              * <p> 2100 : MOA02 : #167 - Non-zero HCPCS Payable Amount for out-patient institutional claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_HCPCS_PAYABLE_AMOUNT= "CLAIM_HCPCS_PAYABLE_AMOUNT" ;

    /*
    * The index position of the column CLAIM_HCPCS_PAYABLE_AMOUNT in the table.
    */
    public static final int CLAIM_HCPCS_PAYABLE_AMOUNT_IDX = 4 ;

    /**
              * <p> 2100 : MOA03 : #167 - Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_1= "REMARK_CODE_1" ;

    /*
    * The index position of the column REMARK_CODE_1 in the table.
    */
    public static final int REMARK_CODE_1_IDX = 5 ;

    /**
              * <p> 2100 : MOA04 : #167 - Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_2= "REMARK_CODE_2" ;

    /*
    * The index position of the column REMARK_CODE_2 in the table.
    */
    public static final int REMARK_CODE_2_IDX = 6 ;

    /**
              * <p> 2100 : MOA05 : #167 - Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_3= "REMARK_CODE_3" ;

    /*
    * The index position of the column REMARK_CODE_3 in the table.
    */
    public static final int REMARK_CODE_3_IDX = 7 ;

    /**
              * <p> 2100 : MOA06 : #168 - Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_4= "REMARK_CODE_4" ;

    /*
    * The index position of the column REMARK_CODE_4 in the table.
    */
    public static final int REMARK_CODE_4_IDX = 8 ;

    /**
              * <p> 2100 : MOA07 : #168 - Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_5= "REMARK_CODE_5" ;

    /*
    * The index position of the column REMARK_CODE_5 in the table.
    */
    public static final int REMARK_CODE_5_IDX = 9 ;

    /**
              * <p> 2100 : MOA08 : #168 - Available when out-patient institutional claim ESRD Payment amount is non-zero for Medicare or Medicaid Claims.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESRD_PAYMENT_AMOUNT= "ESRD_PAYMENT_AMOUNT" ;

    /*
    * The index position of the column ESRD_PAYMENT_AMOUNT in the table.
    */
    public static final int ESRD_PAYMENT_AMOUNT_IDX = 10 ;

    /**
              * <p> 2100 : MOA09 : #168 - Available when the outpatient institutional claim Nonpayable Professional Component Amount is not zero for a Medicare or Medicaid claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NON_PAYABLE_PROF_COMP_AMOUNT= "NON_PAYABLE_PROF_COMP_AMOUNT" ;

    /*
    * The index position of the column NON_PAYABLE_PROF_COMP_AMOUNT in the table.
    */
    public static final int NON_PAYABLE_PROF_COMP_AMOUNT_IDX = 11 ;

}
