package com.adventnet.charm;

/** <p> Description of the table <code>BillingSchedulerJobs</code>.
 *  Column Name and Table Name of  database table  <code>BillingSchedulerJobs</code> is mapped
 * as constants in this util.</p> 
  Scheduler Jobs related to Billing. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILLING_SCHEDULER_JOB_ID}
  * </ul>
 */
 
public final class BILLINGSCHEDULERJOBS
{
    private BILLINGSCHEDULERJOBS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillingSchedulerJobs" ;
    /**
              * <p> Billing Scheduler Job ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILLING_SCHEDULER_JOB_ID= "BILLING_SCHEDULER_JOB_ID" ;

    /*
    * The index position of the column BILLING_SCHEDULER_JOB_ID in the table.
    */
    public static final int BILLING_SCHEDULER_JOB_ID_IDX = 1 ;

    /**
              * <p> Type of the Job.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String JOB_TYPE= "JOB_TYPE" ;

    /*
    * The index position of the column JOB_TYPE in the table.
    */
    public static final int JOB_TYPE_IDX = 2 ;

    /**
              * <p> Job Created Time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String JOB_CREATED_TIME= "JOB_CREATED_TIME" ;

    /*
    * The index position of the column JOB_CREATED_TIME in the table.
    */
    public static final int JOB_CREATED_TIME_IDX = 3 ;

    /**
              * <p> Job Started Time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String JOB_STARTED_TIME= "JOB_STARTED_TIME" ;

    /*
    * The index position of the column JOB_STARTED_TIME in the table.
    */
    public static final int JOB_STARTED_TIME_IDX = 4 ;

    /**
              * <p> Job Completed Time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String JOB_COMPLETED_TIME= "JOB_COMPLETED_TIME" ;

    /*
    * The index position of the column JOB_COMPLETED_TIME in the table.
    */
    public static final int JOB_COMPLETED_TIME_IDX = 5 ;

    /**
              * <p> Job Status.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                     * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String JOB_STATUS= "JOB_STATUS" ;

    /*
    * The index position of the column JOB_STATUS in the table.
    */
    public static final int JOB_STATUS_IDX = 6 ;

    /**
              * <p> Job Status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String JOB_PARAMETERS= "JOB_PARAMETERS" ;

    /*
    * The index position of the column JOB_PARAMETERS in the table.
    */
    public static final int JOB_PARAMETERS_IDX = 7 ;

    /**
              * <p> Created By.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String JOB_CREATED_BY= "JOB_CREATED_BY" ;

    /*
    * The index position of the column JOB_CREATED_BY in the table.
    */
    public static final int JOB_CREATED_BY_IDX = 8 ;

    /**
              * <p> Total number of items in the job.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TOTAL_ITEM_COUNT= "TOTAL_ITEM_COUNT" ;

    /*
    * The index position of the column TOTAL_ITEM_COUNT in the table.
    */
    public static final int TOTAL_ITEM_COUNT_IDX = 9 ;

    /**
              * <p> Total number of successful items in the job.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SUCCESS_ITEM_COUNT= "SUCCESS_ITEM_COUNT" ;

    /*
    * The index position of the column SUCCESS_ITEM_COUNT in the table.
    */
    public static final int SUCCESS_ITEM_COUNT_IDX = 10 ;

    /**
              * <p> Facility ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 11 ;

    /**
              * <p> Is Job initiated by RCM.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_RCM_JOB= "IS_RCM_JOB" ;

    /*
    * The index position of the column IS_RCM_JOB in the table.
    */
    public static final int IS_RCM_JOB_IDX = 12 ;

    /**
              * <p> RCM Practice ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_PRACTICE_ID= "RCM_PRACTICE_ID" ;

    /*
    * The index position of the column RCM_PRACTICE_ID in the table.
    */
    public static final int RCM_PRACTICE_ID_IDX = 13 ;

    /**
              * <p> Job Completion Comments.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String JOB_COMPLETION_COMMENTS= "JOB_COMPLETION_COMMENTS" ;

    /*
    * The index position of the column JOB_COMPLETION_COMMENTS in the table.
    */
    public static final int JOB_COMPLETION_COMMENTS_IDX = 14 ;

    /**
              * <p> The pointer to the file stored.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_POINTER= "FILE_POINTER" ;

    /*
    * The index position of the column FILE_POINTER in the table.
    */
    public static final int FILE_POINTER_IDX = 15 ;

    /**
              * <p> The name of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 16 ;

    /**
              * <p> Is Scheduler Job deleted?.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 17 ;

}
