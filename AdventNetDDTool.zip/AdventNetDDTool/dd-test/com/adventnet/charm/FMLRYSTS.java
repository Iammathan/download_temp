package com.adventnet.charm;

/** <p> Description of the table <code>FmlrySts</code>.
 *  Column Name and Table Name of  database table  <code>FmlrySts</code> is mapped
 * as constants in this util.</p> 
  Weekly downloaded list from surescripts for formulary. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FORMULARY_STATUS_ID}
  * </ul>
 */
 
public final class FMLRYSTS
{
    private FMLRYSTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FmlrySts" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FORMULARY_STATUS_ID= "FORMULARY_STATUS_ID" ;

    /*
    * The index position of the column FORMULARY_STATUS_ID in the table.
    */
    public static final int FORMULARY_STATUS_ID_IDX = 1 ;

    /**
              * <p> PBM unique ID for surescripts.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PBM_PARTICIPANT_ID= "PBM_PARTICIPANT_ID" ;

    /*
    * The index position of the column PBM_PARTICIPANT_ID in the table.
    */
    public static final int PBM_PARTICIPANT_ID_IDX = 2 ;

    /**
              * <p> Unique identifier of FormularyDownloadCommonList.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FORMULARY_COMMON_ID= "FORMULARY_COMMON_ID" ;

    /*
    * The index position of the column FORMULARY_COMMON_ID in the table.
    */
    public static final int FORMULARY_COMMON_ID_IDX = 3 ;

    /**
              * <p> only Add is supported now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHANGE_IDENTIFIER= "CHANGE_IDENTIFIER" ;

    /*
    * The index position of the column CHANGE_IDENTIFIER in the table.
    */
    public static final int CHANGE_IDENTIFIER_IDX = 4 ;

    /**
              * <p> Formulary ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FORMULARY_ID= "FORMULARY_ID" ;

    /*
    * The index position of the column FORMULARY_ID in the table.
    */
    public static final int FORMULARY_ID_IDX = 5 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_ID= "DRUG_ID" ;

    /*
    * The index position of the column DRUG_ID in the table.
    */
    public static final int DRUG_ID_IDX = 6 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_ID_QUALIFIER= "DRUG_ID_QUALIFIER" ;

    /*
    * The index position of the column DRUG_ID_QUALIFIER in the table.
    */
    public static final int DRUG_ID_QUALIFIER_IDX = 7 ;

    /**
              * <p> Identifier for the drug from proprietary code sources.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DRUG_REFERENCE_NUMBER= "DRUG_REFERENCE_NUMBER" ;

    /*
    * The index position of the column DRUG_REFERENCE_NUMBER in the table.
    */
    public static final int DRUG_REFERENCE_NUMBER_IDX = 8 ;

    /**
              * <p> Type of drug reference number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DRUG_REFERENCE_QUALIFIER= "DRUG_REFERENCE_QUALIFIER" ;

    /*
    * The index position of the column DRUG_REFERENCE_QUALIFIER in the table.
    */
    public static final int DRUG_REFERENCE_QUALIFIER_IDX = 9 ;

    /**
              * <p> Rxnorm code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_CODE= "RXNORM_CODE" ;

    /*
    * The index position of the column RXNORM_CODE in the table.
    */
    public static final int RXNORM_CODE_IDX = 10 ;

    /**
              * <p> Rxnorm qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_QUALIFIER= "RXNORM_QUALIFIER" ;

    /*
    * The index position of the column RXNORM_QUALIFIER in the table.
    */
    public static final int RXNORM_QUALIFIER_IDX = 11 ;

    /**
              * <p> Formulary status for the NDC.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FORMULARY_STATUS= "FORMULARY_STATUS" ;

    /*
    * The index position of the column FORMULARY_STATUS in the table.
    */
    public static final int FORMULARY_STATUS_IDX = 12 ;

    /**
              * <p> Relative cost.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RELATIVE_COST= "RELATIVE_COST" ;

    /*
    * The index position of the column RELATIVE_COST in the table.
    */
    public static final int RELATIVE_COST_IDX = 13 ;

}
