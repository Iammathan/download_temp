package com.adventnet.charm;

/** <p> Description of the table <code>GoogleVsAppointment</code>.
 *  Column Name and Table Name of  database table  <code>GoogleVsAppointment</code> is mapped
 * as constants in this util.</p> 
  Synchronize Google Calendar with Charm Calendar Appointment. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #APPOINTMENT_ID}
  * </ul>
 */
 
public final class GOOGLEVSAPPOINTMENT
{
    private GOOGLEVSAPPOINTMENT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "GoogleVsAppointment" ;
    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 1 ;

    /**
              * <p> Appointment Id from AppointmentHistory table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 2 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GOOGLE_EVENT_ID= "GOOGLE_EVENT_ID" ;

    /*
    * The index position of the column GOOGLE_EVENT_ID in the table.
    */
    public static final int GOOGLE_EVENT_ID_IDX = 3 ;

}
