package com.adventnet.charm;

/** <p> Description of the table <code>EligibilityBenefitInfo</code>.
 *  Column Name and Table Name of  database table  <code>EligibilityBenefitInfo</code> is mapped
 * as constants in this util.</p> 
  This table maintains EB segment values from EB01 to EB12 . <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #ELIGIBILITY_BENEFIT_INFO_ID}
  * <li> {@link #ELIGIBILITY_270_REQUEST_ID}
  * </ul>
 */
 
public final class ELIGIBILITYBENEFITINFO
{
    private ELIGIBILITYBENEFITINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EligibilityBenefitInfo" ;
    /**
              * <p> Unique Identifier for each Eligibility Information; Single Eligibility Inquiry Request may contain multiple EB Information.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELIGIBILITY_BENEFIT_INFO_ID= "ELIGIBILITY_BENEFIT_INFO_ID" ;

    /*
    * The index position of the column ELIGIBILITY_BENEFIT_INFO_ID in the table.
    */
    public static final int ELIGIBILITY_BENEFIT_INFO_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of the Eligibility 270 Request.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ELIGIBILITY_270_REQUEST_ID= "ELIGIBILITY_270_REQUEST_ID" ;

    /*
    * The index position of the column ELIGIBILITY_270_REQUEST_ID in the table.
    */
    public static final int ELIGIBILITY_270_REQUEST_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INQUIRY_DATE= "INQUIRY_DATE" ;

    /*
    * The index position of the column INQUIRY_DATE in the table.
    */
    public static final int INQUIRY_DATE_IDX = 3 ;

    /**
              * <p> EB01 - Eligibility or Benefit Information Code which specifies status/coverage/patient's responsibility/related-entity detail etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EB_INFO_CODE= "EB_INFO_CODE" ;

    /*
    * The index position of the column EB_INFO_CODE in the table.
    */
    public static final int EB_INFO_CODE_IDX = 4 ;

    /**
              * <p> EB02 - Coverage Level Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COVERAGE_LEVEL_CODE= "COVERAGE_LEVEL_CODE" ;

    /*
    * The index position of the column COVERAGE_LEVEL_CODE in the table.
    */
    public static final int COVERAGE_LEVEL_CODE_IDX = 5 ;

    /**
              * <p> EB03 - Service Type Codes received in EB segment .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_TYPE_CODES= "SERVICE_TYPE_CODES" ;

    /*
    * The index position of the column SERVICE_TYPE_CODES in the table.
    */
    public static final int SERVICE_TYPE_CODES_IDX = 6 ;

    /**
              * <p> EB04 - Insurance Type Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURANCE_TYPE_CODE= "INSURANCE_TYPE_CODE" ;

    /*
    * The index position of the column INSURANCE_TYPE_CODE in the table.
    */
    public static final int INSURANCE_TYPE_CODE_IDX = 7 ;

    /**
              * <p> EB05 - Plan Coverage Description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PLAN_COVERAGE_DESC= "PLAN_COVERAGE_DESC" ;

    /*
    * The index position of the column PLAN_COVERAGE_DESC in the table.
    */
    public static final int PLAN_COVERAGE_DESC_IDX = 8 ;

    /**
              * <p> EB06 - Time Period Qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TIME_PERIOD_QUALIFIER= "TIME_PERIOD_QUALIFIER" ;

    /*
    * The index position of the column TIME_PERIOD_QUALIFIER in the table.
    */
    public static final int TIME_PERIOD_QUALIFIER_IDX = 9 ;

    /**
              * <p> EB07 - Monetary Amount - denotes the Patient's Portion of Responsibility($ value for Co-Pay/Deductible/Out-of-Pocket Stop Loss/Cost Containment/Sepnd Down Amount).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>18</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MONETARY_AMOUNT= "MONETARY_AMOUNT" ;

    /*
    * The index position of the column MONETARY_AMOUNT in the table.
    */
    public static final int MONETARY_AMOUNT_IDX = 10 ;

    /**
              * <p> EB08 - Percentage value usually represents Co-Insurance(Patient's Portion of Responsibility).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PERCENTAGE= "PERCENTAGE" ;

    /*
    * The index position of the column PERCENTAGE in the table.
    */
    public static final int PERCENTAGE_IDX = 11 ;

    /**
              * <p> EB09 - Quantity Qualifier denotes quantity type/unit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUANTITY_QUALIFIER= "QUANTITY_QUALIFIER" ;

    /*
    * The index position of the column QUANTITY_QUALIFIER in the table.
    */
    public static final int QUANTITY_QUALIFIER_IDX = 12 ;

    /**
              * <p> EB10 - Quantity value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUANTITY= "QUANTITY" ;

    /*
    * The index position of the column QUANTITY in the table.
    */
    public static final int QUANTITY_IDX = 13 ;

    /**
              * <p> EB11 - Authorization or Certification Indicator, value indicates whether authorization or certification is required per plan provisions..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AUTHORIZATION_INDICATOR= "AUTHORIZATION_INDICATOR" ;

    /*
    * The index position of the column AUTHORIZATION_INDICATOR in the table.
    */
    public static final int AUTHORIZATION_INDICATOR_IDX = 14 ;

    /**
              * <p> EB12 - Plan Network Indicator, indicates whether benefits identified are part of In-Plan-Network or Out-of-Plan-Network or Unknown.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PLAN_NETWORK_INDICATOR= "PLAN_NETWORK_INDICATOR" ;

    /*
    * The index position of the column PLAN_NETWORK_INDICATOR in the table.
    */
    public static final int PLAN_NETWORK_INDICATOR_IDX = 15 ;

}
