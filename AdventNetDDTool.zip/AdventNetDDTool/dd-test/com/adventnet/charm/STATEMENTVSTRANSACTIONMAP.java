package com.adventnet.charm;

/** <p> Description of the table <code>StatementVsTransactionMap</code>.
 *  Column Name and Table Name of  database table  <code>StatementVsTransactionMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAP_ID}
  * </ul>
 */
 
public final class STATEMENTVSTRANSACTIONMAP
{
    private STATEMENTVSTRANSACTIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "StatementVsTransactionMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAP_ID= "MAP_ID" ;

    /*
    * The index position of the column MAP_ID in the table.
    */
    public static final int MAP_ID_IDX = 1 ;

    /**
              * <p> Transaction ID of Statement transaction.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_ID= "TRANSACTION_ID" ;

    /*
    * The index position of the column TRANSACTION_ID in the table.
    */
    public static final int TRANSACTION_ID_IDX = 2 ;

    /**
              * <p> Statement Id of Patient Online Payment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATEMENT_ID= "STATEMENT_ID" ;

    /*
    * The index position of the column STATEMENT_ID in the table.
    */
    public static final int STATEMENT_ID_IDX = 3 ;

    /**
              * <p>  Amount paid .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String AMOUNT= "AMOUNT" ;

    /*
    * The index position of the column AMOUNT in the table.
    */
    public static final int AMOUNT_IDX = 4 ;

}
