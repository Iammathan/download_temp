package com.adventnet.charm;

/** <p> Description of the table <code>SMSSettings</code>.
 *  Column Name and Table Name of  database table  <code>SMSSettings</code> is mapped
 * as constants in this util.</p> 
  Store SMS settings Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SETTINGS_ID}
  * </ul>
 */
 
public final class SMSSETTINGS
{
    private SMSSETTINGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SMSSettings" ;
    /**
              * <p> Unique Identifier  .</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SETTINGS_ID= "SETTINGS_ID" ;

    /*
    * The index position of the column SETTINGS_ID in the table.
    */
    public static final int SETTINGS_ID_IDX = 1 ;

    /**
              * <p> weather appointment conformation SMS to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_APPCONFIRMATION= "IS_APPCONFIRMATION" ;

    /*
    * The index position of the column IS_APPCONFIRMATION in the table.
    */
    public static final int IS_APPCONFIRMATION_IDX = 2 ;

    /**
              * <p> weather reschedule appointment SMS to be send or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_APPRESCHEDULE= "IS_APPRESCHEDULE" ;

    /*
    * The index position of the column IS_APPRESCHEDULE in the table.
    */
    public static final int IS_APPRESCHEDULE_IDX = 3 ;

    /**
              * <p> weather appointment cancellation SMS to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_APPCANCELLATION= "IS_APPCANCELLATION" ;

    /*
    * The index position of the column IS_APPCANCELLATION in the table.
    */
    public static final int IS_APPCANCELLATION_IDX = 4 ;

    /**
              * <p> weather appointment remainder SMS to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_APPREMAINDER= "IS_APPREMAINDER" ;

    /*
    * The index position of the column IS_APPREMAINDER in the table.
    */
    public static final int IS_APPREMAINDER_IDX = 5 ;

    /**
              * <p> weather lab results shared SMS to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_LABSHARED= "IS_LABSHARED" ;

    /*
    * The index position of the column IS_LABSHARED in the table.
    */
    public static final int IS_LABSHARED_IDX = 6 ;

    /**
              * <p> weather document shared SMS to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DOCSHARED= "IS_DOCSHARED" ;

    /*
    * The index position of the column IS_DOCSHARED in the table.
    */
    public static final int IS_DOCSHARED_IDX = 7 ;

    /**
              * <p> weather visit summary shared SMS to be send or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_VISITSHARED= "IS_VISITSHARED" ;

    /*
    * The index position of the column IS_VISITSHARED in the table.
    */
    public static final int IS_VISITSHARED_IDX = 8 ;

    /**
              * <p> Whether vaccine reminder sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_VACCINEREMINDER= "IS_VACCINEREMINDER" ;

    /*
    * The index position of the column IS_VACCINEREMINDER in the table.
    */
    public static final int IS_VACCINEREMINDER_IDX = 9 ;

    /**
              * <p> Whether recall reminder sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_RECALLREMINDER= "IS_RECALLREMINDER" ;

    /*
    * The index position of the column IS_RECALLREMINDER in the table.
    */
    public static final int IS_RECALLREMINDER_IDX = 10 ;

    /**
              * <p> Whether invoice summary to Mail sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_INVOICE_MAIL= "IS_INVOICE_MAIL" ;

    /*
    * The index position of the column IS_INVOICE_MAIL in the table.
    */
    public static final int IS_INVOICE_MAIL_IDX = 11 ;

    /**
              * <p> Whether to send sms only on due for invoice summary to Mail.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_INVOICE_MAIL_ON_DUE= "IS_INVOICE_MAIL_ON_DUE" ;

    /*
    * The index position of the column IS_INVOICE_MAIL_ON_DUE in the table.
    */
    public static final int IS_INVOICE_MAIL_ON_DUE_IDX = 12 ;

    /**
              * <p> Whether invoice summary to PHR sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_INVOICE_PHR= "IS_INVOICE_PHR" ;

    /*
    * The index position of the column IS_INVOICE_PHR in the table.
    */
    public static final int IS_INVOICE_PHR_IDX = 13 ;

    /**
              * <p> Whether to send sms only on due for invoice summary to PHR.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_INVOICE_PHR_ON_DUE= "IS_INVOICE_PHR_ON_DUE" ;

    /*
    * The index position of the column IS_INVOICE_PHR_ON_DUE in the table.
    */
    public static final int IS_INVOICE_PHR_ON_DUE_IDX = 14 ;

    /**
              * <p> Whether invoice statement to Mail sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_STATEMENT_MAIL= "IS_STATEMENT_MAIL" ;

    /*
    * The index position of the column IS_STATEMENT_MAIL in the table.
    */
    public static final int IS_STATEMENT_MAIL_IDX = 15 ;

    /**
              * <p> Whether invoice statement to PHR sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_STATEMENT_PHR= "IS_STATEMENT_PHR" ;

    /*
    * The index position of the column IS_STATEMENT_PHR in the table.
    */
    public static final int IS_STATEMENT_PHR_IDX = 16 ;

    /**
              * <p> Whether invoice marked as mailed sms must be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_MARK_AS_MAILED= "IS_MARK_AS_MAILED" ;

    /*
    * The index position of the column IS_MARK_AS_MAILED in the table.
    */
    public static final int IS_MARK_AS_MAILED_IDX = 17 ;

    /**
              * <p> Whether 2 way/Inbound SMS is enabled for patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_2WAYSMS_ENABLED= "IS_2WAYSMS_ENABLED" ;

    /*
    * The index position of the column IS_2WAYSMS_ENABLED in the table.
    */
    public static final int IS_2WAYSMS_ENABLED_IDX = 18 ;

    /**
              * <p> Whether patient can reply to app reminder msg to confirm/cancel/reschedule appointment.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_REPLYCONFIRM_ENABLED= "IS_REPLYCONFIRM_ENABLED" ;

    /*
    * The index position of the column IS_REPLYCONFIRM_ENABLED in the table.
    */
    public static final int IS_REPLYCONFIRM_ENABLED_IDX = 19 ;

    /**
              * <p> status of the appointment when the patient confirms the appointment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONFIRMATION_STATUS_ID= "CONFIRMATION_STATUS_ID" ;

    /*
    * The index position of the column CONFIRMATION_STATUS_ID in the table.
    */
    public static final int CONFIRMATION_STATUS_ID_IDX = 20 ;

    /**
              * <p> Whether to msg waitlisted patient if slot is available.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_REPLYWAITLIST_ENABLED= "IS_REPLYWAITLIST_ENABLED" ;

    /*
    * The index position of the column IS_REPLYWAITLIST_ENABLED in the table.
    */
    public static final int IS_REPLYWAITLIST_ENABLED_IDX = 21 ;

    /**
              * <p> Content of appointment confirmation notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_APPCONFIRM_MESSAGE= "SMS_APPCONFIRM_MESSAGE" ;

    /*
    * The index position of the column SMS_APPCONFIRM_MESSAGE in the table.
    */
    public static final int SMS_APPCONFIRM_MESSAGE_IDX = 22 ;

    /**
              * <p> Content of appointment confirmation notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_APPDAILYCONFIRM_MESSAGE= "SMS_APPDAILYCONFIRM_MESSAGE" ;

    /*
    * The index position of the column SMS_APPDAILYCONFIRM_MESSAGE in the table.
    */
    public static final int SMS_APPDAILYCONFIRM_MESSAGE_IDX = 23 ;

    /**
              * <p> Content of appointment confirmation notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_APPWEEKLYCONFIRM_MESSAGE= "SMS_APPWEEKLYCONFIRM_MESSAGE" ;

    /*
    * The index position of the column SMS_APPWEEKLYCONFIRM_MESSAGE in the table.
    */
    public static final int SMS_APPWEEKLYCONFIRM_MESSAGE_IDX = 24 ;

    /**
              * <p> Content of appointment reschedule notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_APPRESCHEDULE_MESSAGE= "SMS_APPRESCHEDULE_MESSAGE" ;

    /*
    * The index position of the column SMS_APPRESCHEDULE_MESSAGE in the table.
    */
    public static final int SMS_APPRESCHEDULE_MESSAGE_IDX = 25 ;

    /**
              * <p> Content of appointment cancellation notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_APPCANCEL_MESSAGE= "SMS_APPCANCEL_MESSAGE" ;

    /*
    * The index position of the column SMS_APPCANCEL_MESSAGE in the table.
    */
    public static final int SMS_APPCANCEL_MESSAGE_IDX = 26 ;

    /**
              * <p> Content of appointment remainder notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_APPREMINDER_MESSAGE= "SMS_APPREMINDER_MESSAGE" ;

    /*
    * The index position of the column SMS_APPREMINDER_MESSAGE in the table.
    */
    public static final int SMS_APPREMINDER_MESSAGE_IDX = 27 ;

    /**
              * <p> Content of lab shared notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_LABSHARED_MESSAGE= "SMS_LABSHARED_MESSAGE" ;

    /*
    * The index position of the column SMS_LABSHARED_MESSAGE in the table.
    */
    public static final int SMS_LABSHARED_MESSAGE_IDX = 28 ;

    /**
              * <p> Content of document shared notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_DOCSHARED_MESSAGE= "SMS_DOCSHARED_MESSAGE" ;

    /*
    * The index position of the column SMS_DOCSHARED_MESSAGE in the table.
    */
    public static final int SMS_DOCSHARED_MESSAGE_IDX = 29 ;

    /**
              * <p> Content of visit summary shared notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_VISITSHARED_MESSAGE= "SMS_VISITSHARED_MESSAGE" ;

    /*
    * The index position of the column SMS_VISITSHARED_MESSAGE in the table.
    */
    public static final int SMS_VISITSHARED_MESSAGE_IDX = 30 ;

    /**
              * <p> Content of vaccine reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_VACCINEREMINDER_MESSAGE= "SMS_VACCINEREMINDER_MESSAGE" ;

    /*
    * The index position of the column SMS_VACCINEREMINDER_MESSAGE in the table.
    */
    public static final int SMS_VACCINEREMINDER_MESSAGE_IDX = 31 ;

    /**
              * <p> Content of recall reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_RECALLREMINDER_MESSAGE= "SMS_RECALLREMINDER_MESSAGE" ;

    /*
    * The index position of the column SMS_RECALLREMINDER_MESSAGE in the table.
    */
    public static final int SMS_RECALLREMINDER_MESSAGE_IDX = 32 ;

    /**
              * <p> Content of recall reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_INVOICE_MAIL_MESSAGE= "SMS_INVOICE_MAIL_MESSAGE" ;

    /*
    * The index position of the column SMS_INVOICE_MAIL_MESSAGE in the table.
    */
    public static final int SMS_INVOICE_MAIL_MESSAGE_IDX = 33 ;

    /**
              * <p> Content of recall reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_INVOICE_PHR_MESSAGE= "SMS_INVOICE_PHR_MESSAGE" ;

    /*
    * The index position of the column SMS_INVOICE_PHR_MESSAGE in the table.
    */
    public static final int SMS_INVOICE_PHR_MESSAGE_IDX = 34 ;

    /**
              * <p> Content of recall reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_STATEMENT_MAIL_MESSAGE= "SMS_STATEMENT_MAIL_MESSAGE" ;

    /*
    * The index position of the column SMS_STATEMENT_MAIL_MESSAGE in the table.
    */
    public static final int SMS_STATEMENT_MAIL_MESSAGE_IDX = 35 ;

    /**
              * <p> Content of recall reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_STATEMENT_PHR_MESSAGE= "SMS_STATEMENT_PHR_MESSAGE" ;

    /*
    * The index position of the column SMS_STATEMENT_PHR_MESSAGE in the table.
    */
    public static final int SMS_STATEMENT_PHR_MESSAGE_IDX = 36 ;

    /**
              * <p> Content of recall reminder SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_INVOICE_MARK_AS_MAILED_MESSAGE= "SMS_INVOICE_MARK_AS_MAILED_MESSAGE" ;

    /*
    * The index position of the column SMS_INVOICE_MARK_AS_MAILED_MESSAGE in the table.
    */
    public static final int SMS_INVOICE_MARK_AS_MAILED_MESSAGE_IDX = 37 ;

    /**
              * <p> id of the practice member who report needs to send.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SEND_REPORT_TO_MEMBERS= "SEND_REPORT_TO_MEMBERS" ;

    /*
    * The index position of the column SEND_REPORT_TO_MEMBERS in the table.
    */
    public static final int SEND_REPORT_TO_MEMBERS_IDX = 38 ;

    /**
              * <p> weather add waitlist SMS to be sent or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ADD_WAITLIST= "IS_ADD_WAITLIST" ;

    /*
    * The index position of the column IS_ADD_WAITLIST in the table.
    */
    public static final int IS_ADD_WAITLIST_IDX = 39 ;

    /**
              * <p> Content of adding waitlist notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_WAITLIST_MESSAGE= "SMS_WAITLIST_MESSAGE" ;

    /*
    * The index position of the column SMS_WAITLIST_MESSAGE in the table.
    */
    public static final int SMS_WAITLIST_MESSAGE_IDX = 40 ;

    /**
              * <p> whether feedback notification SMS to be sent to patient or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_FEEDBACK_MESSAGE= "IS_FEEDBACK_MESSAGE" ;

    /*
    * The index position of the column IS_FEEDBACK_MESSAGE in the table.
    */
    public static final int IS_FEEDBACK_MESSAGE_IDX = 41 ;

    /**
              * <p> Content of sending feedback notification SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_FEEDBACK_MESSAGE= "SMS_FEEDBACK_MESSAGE" ;

    /*
    * The index position of the column SMS_FEEDBACK_MESSAGE in the table.
    */
    public static final int SMS_FEEDBACK_MESSAGE_IDX = 42 ;

    /**
              * <p> to enable no show reschedule.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_NOSHOW_RESCHEDULE= "IS_NOSHOW_RESCHEDULE" ;

    /*
    * The index position of the column IS_NOSHOW_RESCHEDULE in the table.
    */
    public static final int IS_NOSHOW_RESCHEDULE_IDX = 43 ;

    /**
              * <p> Content of no show reschedule SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SMS_NOSHOW_MESSAGE= "SMS_NOSHOW_MESSAGE" ;

    /*
    * The index position of the column SMS_NOSHOW_MESSAGE in the table.
    */
    public static final int SMS_NOSHOW_MESSAGE_IDX = 44 ;

    /**
              * <p> EncounterWorkFlow ID to mark No show Status.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NOSHOW_WFID= "NOSHOW_WFID" ;

    /*
    * The index position of the column NOSHOW_WFID in the table.
    */
    public static final int NOSHOW_WFID_IDX = 45 ;

    /**
              * <p> to enable/disable timeout message in ABA for all cases.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_TIMEOUTMSG_ENABLED= "IS_TIMEOUTMSG_ENABLED" ;

    /*
    * The index position of the column IS_TIMEOUTMSG_ENABLED in the table.
    */
    public static final int IS_TIMEOUTMSG_ENABLED_IDX = 46 ;

}
