package com.adventnet.charm;

/** <p> Description of the table <code>ImageTemplateEntries</code>.
 *  Column Name and Table Name of  database table  <code>ImageTemplateEntries</code> is mapped
 * as constants in this util.</p> 
  Mapping Image to the Template. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class IMAGETEMPLATEENTRIES
{
    private IMAGETEMPLATEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageTemplateEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from Template table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Id of image type.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_TYPE_ID= "IMAGE_TYPE_ID" ;

    /*
    * The index position of the column IMAGE_TYPE_ID in the table.
    */
    public static final int IMAGE_TYPE_ID_IDX = 3 ;

    /**
              * <p> Image test id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_TEST_ID= "IMAGE_TEST_ID" ;

    /*
    * The index position of the column IMAGE_TEST_ID in the table.
    */
    public static final int IMAGE_TEST_ID_IDX = 4 ;

    /**
              * <p> Entry order of Notes for a template.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 5 ;

    /**
              * <p> Lab test Map Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_LAB_TEST_MAP_ID= "IMAGE_LAB_TEST_MAP_ID" ;

    /*
    * The index position of the column IMAGE_LAB_TEST_MAP_ID in the table.
    */
    public static final int IMAGE_LAB_TEST_MAP_ID_IDX = 6 ;

    /**
              * <p> Image lab id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_LAB_ID= "IMAGE_LAB_ID" ;

    /*
    * The index position of the column IMAGE_LAB_ID in the table.
    */
    public static final int IMAGE_LAB_ID_IDX = 7 ;

}
