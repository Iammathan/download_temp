package com.adventnet.charm;

/** <p> Description of the table <code>PaymentLink</code>.
 *  Column Name and Table Name of  database table  <code>PaymentLink</code> is mapped
 * as constants in this util.</p> 
   Stores payment links sent to patient in practice space . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAYMENT_LINK_ID}
  * </ul>
 */
 
public final class PAYMENTLINK
{
    private PAYMENTLINK()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PaymentLink" ;
    /**
              * <p> Payment Link identity.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PAYMENT_LINK_ID= "PAYMENT_LINK_ID" ;

    /*
    * The index position of the column PAYMENT_LINK_ID in the table.
    */
    public static final int PAYMENT_LINK_ID_IDX = 1 ;

    /**
              * <p> Time on which the payment link was added.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 2 ;

    /**
              * <p> Identifier of member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 3 ;

    /**
              * <p> Time on which the payment link was updated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_UPDATED_TIME= "LAST_UPDATED_TIME" ;

    /*
    * The index position of the column LAST_UPDATED_TIME in the table.
    */
    public static final int LAST_UPDATED_TIME_IDX = 4 ;

    /**
              * <p> POPaymentRequest.PO_PAYMENT_REQUEST_ID from PAYMENTDATASPACE.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PO_PAYMENT_REQUEST_ID= "PO_PAYMENT_REQUEST_ID" ;

    /*
    * The index position of the column PO_PAYMENT_REQUEST_ID in the table.
    */
    public static final int PO_PAYMENT_REQUEST_ID_IDX = 5 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 6 ;

    /**
              * <p> Identifier of Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 7 ;

    /**
              * <p> Identifier of AppointmentHistory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 8 ;

    /**
              * <p> Identifier of Invoice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVOICE_ID= "INVOICE_ID" ;

    /*
    * The index position of the column INVOICE_ID in the table.
    */
    public static final int INVOICE_ID_IDX = 9 ;

    /**
              * <p> Merchant Account Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MERCHANT_ACCOUNT_ID= "MERCHANT_ACCOUNT_ID" ;

    /*
    * The index position of the column MERCHANT_ACCOUNT_ID in the table.
    */
    public static final int MERCHANT_ACCOUNT_ID_IDX = 10 ;

    /**
              * <p>  Amount requested to Pay .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String AMOUNT= "AMOUNT" ;

    /*
    * The index position of the column AMOUNT in the table.
    */
    public static final int AMOUNT_IDX = 11 ;

    /**
              * <p>  Payment status of the payment link.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 12 ;

    /**
              * <p> Email Id of patient comma separated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TO_EMAIL_ID= "TO_EMAIL_ID" ;

    /*
    * The index position of the column TO_EMAIL_ID in the table.
    */
    public static final int TO_EMAIL_ID_IDX = 13 ;

    /**
              * <p> Patient, Guarantor Mobile Number comma separated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TO_MOBILE_NO= "TO_MOBILE_NO" ;

    /*
    * The index position of the column TO_MOBILE_NO in the table.
    */
    public static final int TO_MOBILE_NO_IDX = 14 ;

    /**
              * <p> Description to be shown at the time of payment request.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 15 ;

    /**
              * <p> Payment URL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYMENT_URL= "PAYMENT_URL" ;

    /*
    * The index position of the column PAYMENT_URL in the table.
    */
    public static final int PAYMENT_URL_IDX = 16 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_NOTIFICATION_SENT= "IS_NOTIFICATION_SENT" ;

    /*
    * The index position of the column IS_NOTIFICATION_SENT in the table.
    */
    public static final int IS_NOTIFICATION_SENT_IDX = 17 ;

}
