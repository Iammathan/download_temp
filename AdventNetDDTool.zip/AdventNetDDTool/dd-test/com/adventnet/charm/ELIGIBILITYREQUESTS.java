package com.adventnet.charm;

/** <p> Description of the table <code>EligibilityRequests</code>.
 *  Column Name and Table Name of  database table  <code>EligibilityRequests</code> is mapped
 * as constants in this util.</p> 
  Stores the eligibility request details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ELG_REQ_ID}
  * </ul>
 */
 
public final class ELIGIBILITYREQUESTS
{
    private ELIGIBILITYREQUESTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EligibilityRequests" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELG_REQ_ID= "ELG_REQ_ID" ;

    /*
    * The index position of the column ELG_REQ_ID in the table.
    */
    public static final int ELG_REQ_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_FIRST_NAME= "PATIENT_FIRST_NAME" ;

    /*
    * The index position of the column PATIENT_FIRST_NAME in the table.
    */
    public static final int PATIENT_FIRST_NAME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_LAST_NAME= "PATIENT_LAST_NAME" ;

    /*
    * The index position of the column PATIENT_LAST_NAME in the table.
    */
    public static final int PATIENT_LAST_NAME_IDX = 3 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_DOB= "PATIENT_DOB" ;

    /*
    * The index position of the column PATIENT_DOB in the table.
    */
    public static final int PATIENT_DOB_IDX = 4 ;

    /**
              * <p> Gender of Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>male</code></li>
              * <li><code>female</code></li>
              * </ul>
                         */
    public static final String PATIENT_GENDER= "PATIENT_GENDER" ;

    /*
    * The index position of the column PATIENT_GENDER in the table.
    */
    public static final int PATIENT_GENDER_IDX = 5 ;

    /**
              * <p> Social Security Number.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_SSN= "PATIENT_SSN" ;

    /*
    * The index position of the column PATIENT_SSN in the table.
    */
    public static final int PATIENT_SSN_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String POLICY_NUMBER= "POLICY_NUMBER" ;

    /*
    * The index position of the column POLICY_NUMBER in the table.
    */
    public static final int POLICY_NUMBER_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RELATIONSHIP_TO_INSURED= "RELATIONSHIP_TO_INSURED" ;

    /*
    * The index position of the column RELATIONSHIP_TO_INSURED in the table.
    */
    public static final int RELATIONSHIP_TO_INSURED_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURED_FIRST_NAME= "INSURED_FIRST_NAME" ;

    /*
    * The index position of the column INSURED_FIRST_NAME in the table.
    */
    public static final int INSURED_FIRST_NAME_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURED_LAST_NAME= "INSURED_LAST_NAME" ;

    /*
    * The index position of the column INSURED_LAST_NAME in the table.
    */
    public static final int INSURED_LAST_NAME_IDX = 10 ;

    /**
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INSURED_SSN= "INSURED_SSN" ;

    /*
    * The index position of the column INSURED_SSN in the table.
    */
    public static final int INSURED_SSN_IDX = 11 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_RECORD_ID= "PATIENT_RECORD_ID" ;

    /*
    * The index position of the column PATIENT_RECORD_ID in the table.
    */
    public static final int PATIENT_RECORD_ID_IDX = 12 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_NAME= "PAYER_NAME" ;

    /*
    * The index position of the column PAYER_NAME in the table.
    */
    public static final int PAYER_NAME_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_ID= "PAYER_ID" ;

    /*
    * The index position of the column PAYER_ID in the table.
    */
    public static final int PAYER_ID_IDX = 14 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_NAME= "FACILITY_NAME" ;

    /*
    * The index position of the column FACILITY_NAME in the table.
    */
    public static final int FACILITY_NAME_IDX = 15 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_NPI= "FACILITY_NPI" ;

    /*
    * The index position of the column FACILITY_NPI in the table.
    */
    public static final int FACILITY_NPI_IDX = 16 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_TAX_ID= "FACILITY_TAX_ID" ;

    /*
    * The index position of the column FACILITY_TAX_ID in the table.
    */
    public static final int FACILITY_TAX_ID_IDX = 17 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_FIRST_NAME= "PROVIDER_FIRST_NAME" ;

    /*
    * The index position of the column PROVIDER_FIRST_NAME in the table.
    */
    public static final int PROVIDER_FIRST_NAME_IDX = 18 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_LAST_NAME= "PROVIDER_LAST_NAME" ;

    /*
    * The index position of the column PROVIDER_LAST_NAME in the table.
    */
    public static final int PROVIDER_LAST_NAME_IDX = 19 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROVIDER_NPI= "PROVIDER_NPI" ;

    /*
    * The index position of the column PROVIDER_NPI in the table.
    */
    public static final int PROVIDER_NPI_IDX = 20 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_TYPE= "SERVICE_TYPE" ;

    /*
    * The index position of the column SERVICE_TYPE in the table.
    */
    public static final int SERVICE_TYPE_IDX = 21 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_DATE= "SERVICE_DATE" ;

    /*
    * The index position of the column SERVICE_DATE in the table.
    */
    public static final int SERVICE_DATE_IDX = 22 ;

    /**
              * <p> (MANUAL/ELECTRONIC).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESPONSE_MODE= "RESPONSE_MODE" ;

    /*
    * The index position of the column RESPONSE_MODE in the table.
    */
    public static final int RESPONSE_MODE_IDX = 23 ;

    /**
              * <p> (PENDING/INCOMPLETE/COMPLETED).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESPONSE_STATUS= "RESPONSE_STATUS" ;

    /*
    * The index position of the column RESPONSE_STATUS in the table.
    */
    public static final int RESPONSE_STATUS_IDX = 24 ;

}
