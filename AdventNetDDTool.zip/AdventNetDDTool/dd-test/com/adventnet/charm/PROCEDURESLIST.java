package com.adventnet.charm;

/** <p> Description of the table <code>ProceduresList</code>.
 *  Column Name and Table Name of  database table  <code>ProceduresList</code> is mapped
 * as constants in this util.</p> 
  List of Procedures . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROCEDURE_ID}
  * </ul>
 */
 
public final class PROCEDURESLIST
{
    private PROCEDURESLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ProceduresList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROCEDURE_ID= "PROCEDURE_ID" ;

    /*
    * The index position of the column PROCEDURE_ID in the table.
    */
    public static final int PROCEDURE_ID_IDX = 1 ;

    /**
              * <p> Name of the Procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROCEDURE= "PROCEDURE" ;

    /*
    * The index position of the column PROCEDURE in the table.
    */
    public static final int PROCEDURE_IDX = 2 ;

    /**
              * <p> Type of the Procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROCEDURE_TYPE= "PROCEDURE_TYPE" ;

    /*
    * The index position of the column PROCEDURE_TYPE in the table.
    */
    public static final int PROCEDURE_TYPE_IDX = 3 ;

    /**
              * <p> Identifier of the Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
              * <p> Procedure starting date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 5 ;

    /**
              * <p> Procedure finishing date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 6 ;

    /**
              * <p> Date at which the procedure is entered.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE_OF_ENTRY= "DATE_OF_ENTRY" ;

    /*
    * The index position of the column DATE_OF_ENTRY in the table.
    */
    public static final int DATE_OF_ENTRY_IDX = 7 ;

    /**
              * <p> Details about the procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>600</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 8 ;

    /**
              * <p> Snomed code for procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SNOMED_CODE= "SNOMED_CODE" ;

    /*
    * The index position of the column SNOMED_CODE in the table.
    */
    public static final int SNOMED_CODE_IDX = 9 ;

    /**
              * <p> Identifier of practice member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 10 ;

    /**
              * <p> Time of entry in milliseconds.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 11 ;

}
