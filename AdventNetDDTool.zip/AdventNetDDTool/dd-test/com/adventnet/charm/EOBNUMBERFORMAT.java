package com.adventnet.charm;

/** <p> Description of the table <code>EOBNumberFormat</code>.
 *  Column Name and Table Name of  database table  <code>EOBNumberFormat</code> is mapped
 * as constants in this util.</p> 
  Contains EOB Number to be stored in EOBDetails Table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EOB_FORMAT_ID}
  * </ul>
 */
 
public final class EOBNUMBERFORMAT
{
    private EOBNUMBERFORMAT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EOBNumberFormat" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EOB_FORMAT_ID= "EOB_FORMAT_ID" ;

    /*
    * The index position of the column EOB_FORMAT_ID in the table.
    */
    public static final int EOB_FORMAT_ID_IDX = 1 ;

    /**
              * <p> Holds the Starting count OF Bill Number.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EOB_NUMBER_START_COUNT= "EOB_NUMBER_START_COUNT" ;

    /*
    * The index position of the column EOB_NUMBER_START_COUNT in the table.
    */
    public static final int EOB_NUMBER_START_COUNT_IDX = 2 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

}
