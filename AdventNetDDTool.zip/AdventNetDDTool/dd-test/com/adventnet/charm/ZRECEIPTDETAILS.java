package com.adventnet.charm;

/** <p> Description of the table <code>ZReceiptDetails</code>.
 *  Column Name and Table Name of  database table  <code>ZReceiptDetails</code> is mapped
 * as constants in this util.</p> 
  Will be storing the Zoho Books Customer Payments Mapping. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ZOHO_RECEIPT_DETAILS_ID}
  * </ul>
 */
 
public final class ZRECEIPTDETAILS
{
    private ZRECEIPTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ZReceiptDetails" ;
    /**
              * <p> Pk for ZReceiptDetails table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_RECEIPT_DETAILS_ID= "ZOHO_RECEIPT_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_RECEIPT_DETAILS_ID in the table.
    */
    public static final int ZOHO_RECEIPT_DETAILS_ID_IDX = 1 ;

    /**
              * <p> Added time into EHR.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 3 ;

    /**
              * <p> ZohoOrganizationDetails.ZOHO_ORG_DETAILS_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_ORG_DETAILS_ID= "ZOHO_ORG_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_ORG_DETAILS_ID in the table.
    */
    public static final int ZOHO_ORG_DETAILS_ID_IDX = 4 ;

    /**
              * <p> External Id from Zoho.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXTERNAL_ID= "EXTERNAL_ID" ;

    /*
    * The index position of the column EXTERNAL_ID in the table.
    */
    public static final int EXTERNAL_ID_IDX = 5 ;

    /**
              * <p> Zoho Branch Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZBRANCH_ID= "ZBRANCH_ID" ;

    /*
    * The index position of the column ZBRANCH_ID in the table.
    */
    public static final int ZBRANCH_ID_IDX = 6 ;

    /**
              * <p> ReceiptDetails.RECEIPT_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String SEND_TO_ZOHO= "SEND_TO_ZOHO" ;

    /*
    * The index position of the column SEND_TO_ZOHO in the table.
    */
    public static final int SEND_TO_ZOHO_IDX = 8 ;

    /**
              * <p> Will be storing error info in JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_LOG= "ERROR_LOG" ;

    /*
    * The index position of the column ERROR_LOG in the table.
    */
    public static final int ERROR_LOG_IDX = 9 ;

}
