package com.adventnet.charm;

/** <p> Description of the table <code>MDScriptsRxResponse</code>.
 *  Column Name and Table Name of  database table  <code>MDScriptsRxResponse</code> is mapped
 * as constants in this util.</p> 
  Stores the response from MDScripts. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MDSCRIPTS_RX_RESPONSE_ID}
  * </ul>
 */
 
public final class MDSCRIPTSRXRESPONSE
{
    private MDSCRIPTSRXRESPONSE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MDScriptsRxResponse" ;
    /**
              * <p> Surrogate Key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MDSCRIPTS_RX_RESPONSE_ID= "MDSCRIPTS_RX_RESPONSE_ID" ;

    /*
    * The index position of the column MDSCRIPTS_RX_RESPONSE_ID in the table.
    */
    public static final int MDSCRIPTS_RX_RESPONSE_ID_IDX = 1 ;

    /**
              * <p> Medication Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_MEDICATION_ID= "PATIENT_MEDICATION_ID" ;

    /*
    * The index position of the column PATIENT_MEDICATION_ID in the table.
    */
    public static final int PATIENT_MEDICATION_ID_IDX = 2 ;

    /**
              * <p> Stores the response from MDScripts as a JSON object.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MDSCRIPTS_RESPONSE= "MDSCRIPTS_RESPONSE" ;

    /*
    * The index position of the column MDSCRIPTS_RESPONSE in the table.
    */
    public static final int MDSCRIPTS_RESPONSE_IDX = 3 ;

}
