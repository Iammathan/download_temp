package com.adventnet.charm;

/** <p> Description of the table <code>PatientGeneMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientGeneMap</code> is mapped
 * as constants in this util.</p> 
  gene. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #GENE_MAP_ID}
  * </ul>
 */
 
public final class PATIENTGENEMAP
{
    private PATIENTGENEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientGeneMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String GENE_MAP_ID= "GENE_MAP_ID" ;

    /*
    * The index position of the column GENE_MAP_ID in the table.
    */
    public static final int GENE_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GENE_ID= "GENE_ID" ;

    /*
    * The index position of the column GENE_ID in the table.
    */
    public static final int GENE_ID_IDX = 3 ;

    /**
              * <p> Daily Intake.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESULT= "RESULT" ;

    /*
    * The index position of the column RESULT in the table.
    */
    public static final int RESULT_IDX = 4 ;

}
