package com.adventnet.charm;

/** <p> Description of the table <code>OpenTokSessions</code>.
 *  Column Name and Table Name of  database table  <code>OpenTokSessions</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ID}
  * </ul>
 */
 
public final class OPENTOKSESSIONS
{
    private OPENTOKSESSIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "OpenTokSessions" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 1 ;

    /**
              * <p> session id for join session.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SESSION_ID= "SESSION_ID" ;

    /*
    * The index position of the column SESSION_ID in the table.
    */
    public static final int SESSION_ID_IDX = 2 ;

    /**
              * <p> session creation time.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATION_TIME= "CREATION_TIME" ;

    /*
    * The index position of the column CREATION_TIME in the table.
    */
    public static final int CREATION_TIME_IDX = 3 ;

}
