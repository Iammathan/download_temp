package com.adventnet.charm;

/** <p> Description of the table <code>ConsFeedbackSchedule</code>.
 *  Column Name and Table Name of  database table  <code>ConsFeedbackSchedule</code> is mapped
 * as constants in this util.</p> 
  Send Feedback Days Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CONS_FB_SCHEDULE_ID}
  * </ul>
 */
 
public final class CONSFEEDBACKSCHEDULE
{
    private CONSFEEDBACKSCHEDULE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ConsFeedbackSchedule" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONS_FB_SCHEDULE_ID= "CONS_FB_SCHEDULE_ID" ;

    /*
    * The index position of the column CONS_FB_SCHEDULE_ID in the table.
    */
    public static final int CONS_FB_SCHEDULE_ID_IDX = 1 ;

    /**
              * <p> Consultation ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Questionnaire ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QUESTIONNAIRE_ID= "QUESTIONNAIRE_ID" ;

    /*
    * The index position of the column QUESTIONNAIRE_ID in the table.
    */
    public static final int QUESTIONNAIRE_ID_IDX = 3 ;

    /**
              * <p> members to be notified in submitting fb.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTIFY_MEMBERS= "NOTIFY_MEMBERS" ;

    /*
    * The index position of the column NOTIFY_MEMBERS in the table.
    */
    public static final int NOTIFY_MEMBERS_IDX = 4 ;

    /**
              * <p> Send schedule date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SCHEDULE_DATE= "SCHEDULE_DATE" ;

    /*
    * The index position of the column SCHEDULE_DATE in the table.
    */
    public static final int SCHEDULE_DATE_IDX = 5 ;

}
