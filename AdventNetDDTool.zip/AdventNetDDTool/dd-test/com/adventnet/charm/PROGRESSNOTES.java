package com.adventnet.charm;

/** <p> Description of the table <code>ProgressNotes</code>.
 *  Column Name and Table Name of  database table  <code>ProgressNotes</code> is mapped
 * as constants in this util.</p> 
  Progress Notes for the treatment goals. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROGRESS_ID}
  * </ul>
 */
 
public final class PROGRESSNOTES
{
    private PROGRESSNOTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ProgressNotes" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROGRESS_ID= "PROGRESS_ID" ;

    /*
    * The index position of the column PROGRESS_ID in the table.
    */
    public static final int PROGRESS_ID_IDX = 1 ;

    /**
              * <p> Progress Notes for the goal.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROGRESS_NOTES= "PROGRESS_NOTES" ;

    /*
    * The index position of the column PROGRESS_NOTES in the table.
    */
    public static final int PROGRESS_NOTES_IDX = 2 ;

    /**
              * <p> Treatment goals Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GOAL_ID= "GOAL_ID" ;

    /*
    * The index position of the column GOAL_ID in the table.
    */
    public static final int GOAL_ID_IDX = 3 ;

    /**
              * <p> Patient Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 4 ;

    /**
              * <p> Added time of progress notes.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 5 ;

    /**
              * <p> Physician Id who has added this notes.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

    /**
              * <p> To check if it is deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 7 ;

}
