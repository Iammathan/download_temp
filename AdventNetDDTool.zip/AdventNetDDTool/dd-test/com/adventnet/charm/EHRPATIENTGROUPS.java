package com.adventnet.charm;

/** <p> Description of the table <code>EHRPatientGroups</code>.
 *  Column Name and Table Name of  database table  <code>EHRPatientGroups</code> is mapped
 * as constants in this util.</p> 
  Patient group table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_GROUP_ID}
  * </ul>
 */
 
public final class EHRPATIENTGROUPS
{
    private EHRPATIENTGROUPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EHRPatientGroups" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_GROUP_ID= "PATIENT_GROUP_ID" ;

    /*
    * The index position of the column PATIENT_GROUP_ID in the table.
    */
    public static final int PATIENT_GROUP_ID_IDX = 1 ;

    /**
              * <p> Title of the group.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GROUP_TITLE= "GROUP_TITLE" ;

    /*
    * The index position of the column GROUP_TITLE in the table.
    */
    public static final int GROUP_TITLE_IDX = 2 ;

    /**
              * <p> Type of the group[family,organization].</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GROUP_TYPE= "GROUP_TYPE" ;

    /*
    * The index position of the column GROUP_TYPE in the table.
    */
    public static final int GROUP_TYPE_IDX = 3 ;

}
