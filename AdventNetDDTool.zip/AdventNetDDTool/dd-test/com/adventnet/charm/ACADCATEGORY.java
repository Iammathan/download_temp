package com.adventnet.charm;

/** <p> Description of the table <code>AcadCategory</code>.
 *  Column Name and Table Name of  database table  <code>AcadCategory</code> is mapped
 * as constants in this util.</p> 
  Category in Academic Tracking. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CATEGORY_ID}
  * </ul>
 */
 
public final class ACADCATEGORY
{
    private ACADCATEGORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AcadCategory" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CATEGORY_ID= "CATEGORY_ID" ;

    /*
    * The index position of the column CATEGORY_ID in the table.
    */
    public static final int CATEGORY_ID_IDX = 1 ;

    /**
              * <p> Academic Category Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CATEGORY_NAME= "CATEGORY_NAME" ;

    /*
    * The index position of the column CATEGORY_NAME in the table.
    */
    public static final int CATEGORY_NAME_IDX = 2 ;

}
