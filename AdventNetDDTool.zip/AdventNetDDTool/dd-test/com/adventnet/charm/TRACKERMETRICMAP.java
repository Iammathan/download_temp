package com.adventnet.charm;

/** <p> Description of the table <code>TrackerMetricMap</code>.
 *  Column Name and Table Name of  database table  <code>TrackerMetricMap</code> is mapped
 * as constants in this util.</p> 
  Map for Tracker and Metric. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TRACKER_MAP_ID}
  * </ul>
 */
 
public final class TRACKERMETRICMAP
{
    private TRACKERMETRICMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TrackerMetricMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRACKER_MAP_ID= "TRACKER_MAP_ID" ;

    /*
    * The index position of the column TRACKER_MAP_ID in the table.
    */
    public static final int TRACKER_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Tracker.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRACKER_ID= "TRACKER_ID" ;

    /*
    * The index position of the column TRACKER_ID in the table.
    */
    public static final int TRACKER_ID_IDX = 2 ;

    /**
              * <p> Identifier of current Metric.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String HEALTH_METRIC_ID= "HEALTH_METRIC_ID" ;

    /*
    * The index position of the column HEALTH_METRIC_ID in the table.
    */
    public static final int HEALTH_METRIC_ID_IDX = 3 ;

}
