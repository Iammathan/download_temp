package com.adventnet.charm;

/** <p> Description of the table <code>UploadedFiles</code>.
 *  Column Name and Table Name of  database table  <code>UploadedFiles</code> is mapped
 * as constants in this util.</p> 
  To store the file details of Practice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FILE_ID}
  * </ul>
 */
 
public final class UPLOADEDFILES
{
    private UPLOADEDFILES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UploadedFiles" ;
    /**
              * <p> Unique identifier .</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 1 ;

    /**
              * <p> Location of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_LOCATION= "FILE_LOCATION" ;

    /*
    * The index position of the column FILE_LOCATION in the table.
    */
    public static final int FILE_LOCATION_IDX = 2 ;

    /**
              * <p> Name of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 3 ;

    /**
              * <p> Size of the file.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_SIZE= "FILE_SIZE" ;

    /*
    * The index position of the column FILE_SIZE in the table.
    */
    public static final int FILE_SIZE_IDX = 4 ;

    /**
              * <p>  File uploaded time .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_UPLOAD= "TIME_OF_UPLOAD" ;

    /*
    * The index position of the column TIME_OF_UPLOAD in the table.
    */
    public static final int TIME_OF_UPLOAD_IDX = 5 ;

    /**
              * <p> To check whether the file is deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 6 ;

    /**
              * <p> Identifier of User.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String UPLOADED_BY= "UPLOADED_BY" ;

    /*
    * The index position of the column UPLOADED_BY in the table.
    */
    public static final int UPLOADED_BY_IDX = 7 ;

    /**
              * <p> Date on which the report(document) is taken.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 8 ;

    /**
              * <p> Date on which the document is modified.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_ON= "LAST_MODIFIED_ON" ;

    /*
    * The index position of the column LAST_MODIFIED_ON in the table.
    */
    public static final int LAST_MODIFIED_ON_IDX = 9 ;

    /**
              * <p> Type of the document.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_TYPE= "FILE_TYPE" ;

    /*
    * The index position of the column FILE_TYPE in the table.
    */
    public static final int FILE_TYPE_IDX = 10 ;

}
