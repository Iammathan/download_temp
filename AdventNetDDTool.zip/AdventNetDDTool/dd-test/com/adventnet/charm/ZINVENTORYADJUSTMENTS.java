package com.adventnet.charm;

/** <p> Description of the table <code>ZInventoryAdjustments</code>.
 *  Column Name and Table Name of  database table  <code>ZInventoryAdjustments</code> is mapped
 * as constants in this util.</p> 
  Will be storing the Zoho Inventory Adjustments pulled from Zoho To ChARM. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ZOHO_INVENTORY_ADJUSTMENT_ID}
  * </ul>
 */
 
public final class ZINVENTORYADJUSTMENTS
{
    private ZINVENTORYADJUSTMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ZInventoryAdjustments" ;
    /**
              * <p> Pk for ZInventoryAdjustments table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_INVENTORY_ADJUSTMENT_ID= "ZOHO_INVENTORY_ADJUSTMENT_ID" ;

    /*
    * The index position of the column ZOHO_INVENTORY_ADJUSTMENT_ID in the table.
    */
    public static final int ZOHO_INVENTORY_ADJUSTMENT_ID_IDX = 1 ;

    /**
              * <p> Added time into EHR.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 3 ;

    /**
              * <p> Type of adjustment.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * </ul>
                         */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 4 ;

    /**
              * <p> Zoho Adjustment Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZADJUSTMENT_ID= "ZADJUSTMENT_ID" ;

    /*
    * The index position of the column ZADJUSTMENT_ID in the table.
    */
    public static final int ZADJUSTMENT_ID_IDX = 5 ;

    /**
              * <p> Zoho Adjustment number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ZADJUSTMENT_NUMBER= "ZADJUSTMENT_NUMBER" ;

    /*
    * The index position of the column ZADJUSTMENT_NUMBER in the table.
    */
    public static final int ZADJUSTMENT_NUMBER_IDX = 6 ;

    /**
              * <p> ZohoOrganizationDetails.ZOHO_ORG_DETAILS_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZOHO_ORG_DETAILS_ID= "ZOHO_ORG_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_ORG_DETAILS_ID in the table.
    */
    public static final int ZOHO_ORG_DETAILS_ID_IDX = 7 ;

    /**
              * <p> Status of the incoming Adjustment.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * </ul>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 8 ;

    /**
              * <p> Will be storing Adjustment JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ZADJUSTMENT= "ZADJUSTMENT" ;

    /*
    * The index position of the column ZADJUSTMENT in the table.
    */
    public static final int ZADJUSTMENT_IDX = 9 ;

    /**
              * <p> Will be storing error info in JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_LOG= "ERROR_LOG" ;

    /*
    * The index position of the column ERROR_LOG in the table.
    */
    public static final int ERROR_LOG_IDX = 10 ;

}
