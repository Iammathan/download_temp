package com.adventnet.charm;

/** <p> Description of the table <code>VaccinesList</code>.
 *  Column Name and Table Name of  database table  <code>VaccinesList</code> is mapped
 * as constants in this util.</p> 
  Master Immunizations(Vaccines) list. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VACCINE_ID}
  * </ul>
 */
 
public final class VACCINESLIST
{
    private VACCINESLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VaccinesList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VACCINE_ID= "VACCINE_ID" ;

    /*
    * The index position of the column VACCINE_ID in the table.
    */
    public static final int VACCINE_ID_IDX = 1 ;

    /**
              * <p> CVX code of the vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CVX_CODE= "CVX_CODE" ;

    /*
    * The index position of the column CVX_CODE in the table.
    */
    public static final int CVX_CODE_IDX = 2 ;

    /**
              * <p> Name of Vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VACCINE_NAME= "VACCINE_NAME" ;

    /*
    * The index position of the column VACCINE_NAME in the table.
    */
    public static final int VACCINE_NAME_IDX = 3 ;

    /**
              * <p> Details of Vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_DETAILS= "VACCINE_DETAILS" ;

    /*
    * The index position of the column VACCINE_DETAILS in the table.
    */
    public static final int VACCINE_DETAILS_IDX = 4 ;

    /**
              * <p> Identifier of practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 5 ;

}
