package com.adventnet.charm;

/** <p> Description of the table <code>PatientMedicationRTPBDetails</code>.
 *  Column Name and Table Name of  database table  <code>PatientMedicationRTPBDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_MED_RTPB_ID}
  * </ul>
 */
 
public final class PATIENTMEDICATIONRTPBDETAILS
{
    private PATIENTMEDICATIONRTPBDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientMedicationRTPBDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_MED_RTPB_ID= "PATIENT_MED_RTPB_ID" ;

    /*
    * The index position of the column PATIENT_MED_RTPB_ID in the table.
    */
    public static final int PATIENT_MED_RTPB_ID_IDX = 1 ;

    /**
              * <p> EligibilityResponse table foreign key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELIGIBILITY_RESPONSE_ID= "ELIGIBILITY_RESPONSE_ID" ;

    /*
    * The index position of the column ELIGIBILITY_RESPONSE_ID in the table.
    */
    public static final int ELIGIBILITY_RESPONSE_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHARMACY_ID= "PHARMACY_ID" ;

    /*
    * The index position of the column PHARMACY_ID in the table.
    */
    public static final int PHARMACY_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 5 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_TIME= "DATE_TIME" ;

    /*
    * The index position of the column DATE_TIME in the table.
    */
    public static final int DATE_TIME_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 8 ;

}
