package com.adventnet.charm;

/** <p> Description of the table <code>ZohoOrganizationDetails</code>.
 *  Column Name and Table Name of  database table  <code>ZohoOrganizationDetails</code> is mapped
 * as constants in this util.</p> 
  Will be storing the Zoho Organization details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ZOHO_ORG_DETAILS_ID}
  * </ul>
 */
 
public final class ZOHOORGANIZATIONDETAILS
{
    private ZOHOORGANIZATIONDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ZohoOrganizationDetails" ;
    /**
              * <p> Pk for ZohoOrganizationDetails table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_ORG_DETAILS_ID= "ZOHO_ORG_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_ORG_DETAILS_ID in the table.
    */
    public static final int ZOHO_ORG_DETAILS_ID_IDX = 1 ;

    /**
              * <p> OAUTH with which Zoho Org is accessed..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_OAUTH_ID= "MEMBER_OAUTH_ID" ;

    /*
    * The index position of the column MEMBER_OAUTH_ID in the table.
    */
    public static final int MEMBER_OAUTH_ID_IDX = 2 ;

    /**
              * <p> Added time into EHR.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 4 ;

    /**
              * <p> Zoho Org Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOID= "ZOID" ;

    /*
    * The index position of the column ZOID in the table.
    */
    public static final int ZOID_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY= "COUNTRY" ;

    /*
    * The index position of the column COUNTRY in the table.
    */
    public static final int COUNTRY_IDX = 6 ;

    /**
              * <p> Will be storing organization additional info in JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_INFO= "ADDITIONAL_INFO" ;

    /*
    * The index position of the column ADDITIONAL_INFO in the table.
    */
    public static final int ADDITIONAL_INFO_IDX = 7 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * </ul>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 8 ;

}
