package com.adventnet.charm;

/** <p> Description of the table <code>EStatusClaimDetail</code>.
 *  Column Name and Table Name of  database table  <code>EStatusClaimDetail</code> is mapped
 * as constants in this util.</p> 
  Claim level detail returned in the status response. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ESTATUS_CLAIM_ID}
  * </ul>
 */
 
public final class ESTATUSCLAIMDETAIL
{
    private ESTATUSCLAIMDETAIL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EStatusClaimDetail" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_CLAIM_ID= "ESTATUS_CLAIM_ID" ;

    /*
    * The index position of the column ESTATUS_CLAIM_ID in the table.
    */
    public static final int ESTATUS_CLAIM_ID_IDX = 1 ;

    /**
              * <p> Holds the transaction reference id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_TXN_ID= "ESTATUS_TXN_ID" ;

    /*
    * The index position of the column ESTATUS_TXN_ID in the table.
    */
    public static final int ESTATUS_TXN_ID_IDX = 2 ;

    /**
              * <p> Associated Claim ID; PK of RCMClaimCompleteDetails or ClaimCompleteDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 3 ;

    /**
              * <p> This the status value created by ChARM from the electronic status details fetched.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>120</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ELECTRONIC_STATUS= "ELECTRONIC_STATUS" ;

    /*
    * The index position of the column ELECTRONIC_STATUS in the table.
    */
    public static final int ELECTRONIC_STATUS_IDX = 4 ;

    /**
              * <p> Time the status was added.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MODIFIED_TIME= "MODIFIED_TIME" ;

    /*
    * The index position of the column MODIFIED_TIME in the table.
    */
    public static final int MODIFIED_TIME_IDX = 5 ;

    /**
              * <p> Who modified the status(manual status change/manual estatus inquiry/estatus inquiry scheduler).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>105</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIED_BY= "MODIFIED_BY" ;

    /*
    * The index position of the column MODIFIED_BY in the table.
    */
    public static final int MODIFIED_BY_IDX = 6 ;

    /**
              * <p> Date on which this status was changed to in the payer/clearinghouse system.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATUS_EFFECTIVE_DATE= "STATUS_EFFECTIVE_DATE" ;

    /*
    * The index position of the column STATUS_EFFECTIVE_DATE in the table.
    */
    public static final int STATUS_EFFECTIVE_DATE_IDX = 7 ;

    /**
              * <p> PK of the ElectronicStatusDetail table where the claim status is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID_1= "ESTATUS_ID_1" ;

    /*
    * The index position of the column ESTATUS_ID_1 in the table.
    */
    public static final int ESTATUS_ID_1_IDX = 8 ;

    /**
              * <p> PK of the ElectronicStatusDetail table where the additional status detail of the claim is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID_2= "ESTATUS_ID_2" ;

    /*
    * The index position of the column ESTATUS_ID_2 in the table.
    */
    public static final int ESTATUS_ID_2_IDX = 9 ;

    /**
              * <p> PK of the ElectronicStatusDetail table where the additional status detail of the claim is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID_3= "ESTATUS_ID_3" ;

    /*
    * The index position of the column ESTATUS_ID_3 in the table.
    */
    public static final int ESTATUS_ID_3_IDX = 10 ;

    /**
              * <p> Claim tracking no which we sent from ChARM and returned in the claim status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRACKING_NO= "TRACKING_NO" ;

    /*
    * The index position of the column TRACKING_NO in the table.
    */
    public static final int TRACKING_NO_IDX = 11 ;

    /**
              * <p> Payer's internal control number for this claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_CLAIM_CONTROL_NO= "PAYER_CLAIM_CONTROL_NO" ;

    /*
    * The index position of the column PAYER_CLAIM_CONTROL_NO in the table.
    */
    public static final int PAYER_CLAIM_CONTROL_NO_IDX = 12 ;

    /**
              * <p> Bill type id returned in the claim(institutional) status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BILLTYPE_ID= "BILLTYPE_ID" ;

    /*
    * The index position of the column BILLTYPE_ID in the table.
    */
    public static final int BILLTYPE_ID_IDX = 13 ;

    /**
              * <p> Patient Claim control no returned in the status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_CLAIM_CONTROL_NO= "PATIENT_CLAIM_CONTROL_NO" ;

    /*
    * The index position of the column PATIENT_CLAIM_CONTROL_NO in the table.
    */
    public static final int PATIENT_CLAIM_CONTROL_NO_IDX = 14 ;

    /**
              * <p> Pharmacy prescription no returned in the status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHARMACY_PRESCRIPTION_NO= "PHARMACY_PRESCRIPTION_NO" ;

    /*
    * The index position of the column PHARMACY_PRESCRIPTION_NO in the table.
    */
    public static final int PHARMACY_PRESCRIPTION_NO_IDX = 15 ;

    /**
              * <p> Voucher number associated with the claim in payer system if available.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VOUCHER_ID= "VOUCHER_ID" ;

    /*
    * The index position of the column VOUCHER_ID in the table.
    */
    public static final int VOUCHER_ID_IDX = 16 ;

    /**
              * <p> Clearinghouse tracking identifier returned in the status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLEARINGHOUSE_TRACKING_ID= "CLEARINGHOUSE_TRACKING_ID" ;

    /*
    * The index position of the column CLEARINGHOUSE_TRACKING_ID in the table.
    */
    public static final int CLEARINGHOUSE_TRACKING_ID_IDX = 17 ;

    /**
              * <p> Service Start Date in claim level if available in the the status response.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_START_DATE= "SERVICE_START_DATE" ;

    /*
    * The index position of the column SERVICE_START_DATE in the table.
    */
    public static final int SERVICE_START_DATE_IDX = 18 ;

    /**
              * <p> Service End Date in claim level if available in the the status response.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_END_DATE= "SERVICE_END_DATE" ;

    /*
    * The index position of the column SERVICE_END_DATE in the table.
    */
    public static final int SERVICE_END_DATE_IDX = 19 ;

    /**
              * <p> Claim charge as per the status response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_CHARGE= "CLAIM_CHARGE" ;

    /*
    * The index position of the column CLAIM_CHARGE in the table.
    */
    public static final int CLAIM_CHARGE_IDX = 20 ;

    /**
              * <p> Claim Payment amount if given in the status response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_PAYMENT= "CLAIM_PAYMENT" ;

    /*
    * The index position of the column CLAIM_PAYMENT in the table.
    */
    public static final int CLAIM_PAYMENT_IDX = 21 ;

    /**
              * <p> If claim adjudication is completed and it is given in the status response.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUDICATION_DATE= "ADJUDICATION_DATE" ;

    /*
    * The index position of the column ADJUDICATION_DATE in the table.
    */
    public static final int ADJUDICATION_DATE_IDX = 22 ;

    /**
              * <p> Check/EFT effective date if the claim adjudication is completed and the date is available in the status response.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CHECK_OR_EFT_DATE= "CHECK_OR_EFT_DATE" ;

    /*
    * The index position of the column CHECK_OR_EFT_DATE in the table.
    */
    public static final int CHECK_OR_EFT_DATE_IDX = 23 ;

    /**
              * <p> Check/EFT Number if the claim adjudication is completed and available in the status response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>16</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CHECK_OR_EFT_NUMBER= "CHECK_OR_EFT_NUMBER" ;

    /*
    * The index position of the column CHECK_OR_EFT_NUMBER in the table.
    */
    public static final int CHECK_OR_EFT_NUMBER_IDX = 24 ;

    /**
              * <p> Is the status change done from RCM(true) or EHR-Billing(false).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 25 ;

}
