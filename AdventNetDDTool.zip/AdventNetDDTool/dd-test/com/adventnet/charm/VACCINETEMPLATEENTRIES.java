package com.adventnet.charm;

/** <p> Description of the table <code>VaccineTemplateEntries</code>.
 *  Column Name and Table Name of  database table  <code>VaccineTemplateEntries</code> is mapped
 * as constants in this util.</p> 
  Vaccine Templates Entries. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class VACCINETEMPLATEENTRIES
{
    private VACCINETEMPLATEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VaccineTemplateEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from Template table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Name of Vaccine given in the template.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VACCINE_NAME= "VACCINE_NAME" ;

    /*
    * The index position of the column VACCINE_NAME in the table.
    */
    public static final int VACCINE_NAME_IDX = 3 ;

    /**
              * <p> CVX code of the vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CVX_CODE= "CVX_CODE" ;

    /*
    * The index position of the column CVX_CODE in the table.
    */
    public static final int CVX_CODE_IDX = 4 ;

    /**
              * <p> Name of the manufacturer of the given vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_MANUFACTURER_NAME= "VACCINE_MANUFACTURER_NAME" ;

    /*
    * The index position of the column VACCINE_MANUFACTURER_NAME in the table.
    */
    public static final int VACCINE_MANUFACTURER_NAME_IDX = 5 ;

    /**
              * <p> Vaccine manufacturer code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_MANUFACTURER_CODE= "VACCINE_MANUFACTURER_CODE" ;

    /*
    * The index position of the column VACCINE_MANUFACTURER_CODE in the table.
    */
    public static final int VACCINE_MANUFACTURER_CODE_IDX = 6 ;

    /**
              * <p> Administered amount.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMINISTERED_AMOUNT= "ADMINISTERED_AMOUNT" ;

    /*
    * The index position of the column ADMINISTERED_AMOUNT in the table.
    */
    public static final int ADMINISTERED_AMOUNT_IDX = 7 ;

    /**
              * <p> Administered Unit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMINISTERED_UNITS= "ADMINISTERED_UNITS" ;

    /*
    * The index position of the column ADMINISTERED_UNITS in the table.
    */
    public static final int ADMINISTERED_UNITS_IDX = 8 ;

    /**
              * <p> Lot number of vaccine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_LOT_NUMBER= "VACCINE_LOT_NUMBER" ;

    /*
    * The index position of the column VACCINE_LOT_NUMBER in the table.
    */
    public static final int VACCINE_LOT_NUMBER_IDX = 9 ;

    /**
              * <p> Vaccine notes given by physician.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VACCINE_NOTES= "VACCINE_NOTES" ;

    /*
    * The index position of the column VACCINE_NOTES in the table.
    */
    public static final int VACCINE_NOTES_IDX = 10 ;

    /**
              * <p> Code of the route through which vaccine is given.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ROUTE= "ROUTE" ;

    /*
    * The index position of the column ROUTE in the table.
    */
    public static final int ROUTE_IDX = 11 ;

    /**
              * <p> Code of Vaccine Site.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SITE= "SITE" ;

    /*
    * The index position of the column SITE in the table.
    */
    public static final int SITE_IDX = 12 ;

    /**
              * <p> Code for VFC eligibility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VFC_ELIGIBILITY= "VFC_ELIGIBILITY" ;

    /*
    * The index position of the column VFC_ELIGIBILITY in the table.
    */
    public static final int VFC_ELIGIBILITY_IDX = 13 ;

    /**
              * <p> Entry order of Notes for a template.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 14 ;

    /**
              * <p> Date of Expiry .</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE_OF_EXPIRY= "DATE_OF_EXPIRY" ;

    /*
    * The index position of the column DATE_OF_EXPIRY in the table.
    */
    public static final int DATE_OF_EXPIRY_IDX = 15 ;

}
