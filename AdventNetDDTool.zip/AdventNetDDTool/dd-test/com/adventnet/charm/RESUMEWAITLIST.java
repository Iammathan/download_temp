package com.adventnet.charm;

/** <p> Description of the table <code>ResumeWaitlist</code>.
 *  Column Name and Table Name of  database table  <code>ResumeWaitlist</code> is mapped
 * as constants in this util.</p> 
  List of Appointment ids for which waitlist confirmation messages should be sent after late hour. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RESUME_ID}
  * </ul>
 */
 
public final class RESUMEWAITLIST
{
    private RESUMEWAITLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ResumeWaitlist" ;
    /**
              * <p> Pk for ResumeWaitlist table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESUME_ID= "RESUME_ID" ;

    /*
    * The index position of the column RESUME_ID in the table.
    */
    public static final int RESUME_ID_IDX = 1 ;

    /**
              * <p> Mapping from AppointmentHistory table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 2 ;

}
