package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimHistory</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimHistory</code> is mapped
 * as constants in this util.</p> 
  Claim history - operations done by user . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_HISTORY_ID}
  * </ul>
 */
 
public final class RCMCLAIMHISTORY
{
    private RCMCLAIMHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimHistory" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_HISTORY_ID= "CLAIM_HISTORY_ID" ;

    /*
    * The index position of the column CLAIM_HISTORY_ID in the table.
    */
    public static final int CLAIM_HISTORY_ID_IDX = 1 ;

    /**
              * <p> Claim Id of RCMClaimCompleteDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> Action type - short description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ACTION_TYPE= "ACTION_TYPE" ;

    /*
    * The index position of the column ACTION_TYPE in the table.
    */
    public static final int ACTION_TYPE_IDX = 3 ;

    /**
              * <p> History comment that can be displayed to user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COMMENT_TO_DISPLAY= "COMMENT_TO_DISPLAY" ;

    /*
    * The index position of the column COMMENT_TO_DISPLAY in the table.
    */
    public static final int COMMENT_TO_DISPLAY_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE_TIME= "ADDED_DATE_TIME" ;

    /*
    * The index position of the column ADDED_DATE_TIME in the table.
    */
    public static final int ADDED_DATE_TIME_IDX = 5 ;

    /**
              * <p> User ID adding the notes .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

    /**
              * <p> Additional details in JSON format - for internal auditing purpose.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 7 ;

    /**
              * <p> data-type is not boolean; 0-NON_FINANCIAL_BOTH; 1-FINANCIAL_BOTH; 2-FINANCIAL_CLAIM_VIEW; 3-FINANCIAL_PATIENT_LEDGER.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String HISTORY_TYPE= "HISTORY_TYPE" ;

    /*
    * The index position of the column HISTORY_TYPE in the table.
    */
    public static final int HISTORY_TYPE_IDX = 8 ;

    /**
              * <p> Charge of the claim at this instant(after generating, editing).</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0.00</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0.00</code>" , 
       * will be taken.<br>
                         */
    public static final String CLAIM_CHARGE= "CLAIM_CHARGE" ;

    /*
    * The index position of the column CLAIM_CHARGE in the table.
    */
    public static final int CLAIM_CHARGE_IDX = 9 ;

    /**
              * <p> Payment Done for the claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0.00</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0.00</code>" , 
       * will be taken.<br>
                         */
    public static final String CREDIT_TOWARDS_CLAIM= "CREDIT_TOWARDS_CLAIM" ;

    /*
    * The index position of the column CREDIT_TOWARDS_CLAIM in the table.
    */
    public static final int CREDIT_TOWARDS_CLAIM_IDX = 10 ;

}
