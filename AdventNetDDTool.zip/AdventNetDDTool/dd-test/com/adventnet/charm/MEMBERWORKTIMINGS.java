package com.adventnet.charm;

/** <p> Description of the table <code>MemberWorkTimings</code>.
 *  Column Name and Table Name of  database table  <code>MemberWorkTimings</code> is mapped
 * as constants in this util.</p> 
  It contains work timings for each members in a practice. . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEMBER_TIMING_ID}
  * </ul>
 */
 
public final class MEMBERWORKTIMINGS
{
    private MEMBERWORKTIMINGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MemberWorkTimings" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_TIMING_ID= "MEMBER_TIMING_ID" ;

    /*
    * The index position of the column MEMBER_TIMING_ID in the table.
    */
    public static final int MEMBER_TIMING_ID_IDX = 1 ;

    /**
              * <p> Unique Idendifier of the practice member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Day of the week i.e, Sunday as 0 and Monday as 1 to Saturday as 6.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * <li><code>6</code></li>
              * </ul>
                         */
    public static final String DAY_OF_WEEK= "DAY_OF_WEEK" ;

    /*
    * The index position of the column DAY_OF_WEEK in the table.
    */
    public static final int DAY_OF_WEEK_IDX = 4 ;

    /**
              * <p> Indicates whether doctor visits that facility on a particular day.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_VISITING= "IS_VISITING" ;

    /*
    * The index position of the column IS_VISITING in the table.
    */
    public static final int IS_VISITING_IDX = 5 ;

    /**
              * <p> In a particular day a physician may visit a facility more than one time such as morning evening etc. This column denotes that.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISIT_NO= "VISIT_NO" ;

    /*
    * The index position of the column VISIT_NO in the table.
    */
    public static final int VISIT_NO_IDX = 6 ;

    /**
              * <p> String denoting start time like 1:00.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String START_TIME= "START_TIME" ;

    /*
    * The index position of the column START_TIME in the table.
    */
    public static final int START_TIME_IDX = 7 ;

    /**
              * <p> String denoting start session like am/pm.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>am</code></li>
              * <li><code>pm</code></li>
              * </ul>
                         */
    public static final String START_SESSION= "START_SESSION" ;

    /*
    * The index position of the column START_SESSION in the table.
    */
    public static final int START_SESSION_IDX = 8 ;

    /**
              * <p> String denoting end time like 1:00.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String END_TIME= "END_TIME" ;

    /*
    * The index position of the column END_TIME in the table.
    */
    public static final int END_TIME_IDX = 9 ;

    /**
              * <p> String denoting end session like am/pm.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>am</code></li>
              * <li><code>pm</code></li>
              * </ul>
                         */
    public static final String END_SESSION= "END_SESSION" ;

    /*
    * The index position of the column END_SESSION in the table.
    */
    public static final int END_SESSION_IDX = 10 ;

    /**
              * <p> Indicates whether to show this slot or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ONLINE_APP_SLOT= "ONLINE_APP_SLOT" ;

    /*
    * The index position of the column ONLINE_APP_SLOT in the table.
    */
    public static final int ONLINE_APP_SLOT_IDX = 11 ;

    /**
              * <p> In a particular slot,the maximum token count of patients,member can consult.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TOKEN_COUNT= "TOKEN_COUNT" ;

    /*
    * The index position of the column TOKEN_COUNT in the table.
    */
    public static final int TOKEN_COUNT_IDX = 12 ;

}
