package com.adventnet.charm;

/** <p> Description of the table <code>PatientAppointmentRemainder</code>.
 *  Column Name and Table Name of  database table  <code>PatientAppointmentRemainder</code> is mapped
 * as constants in this util.</p> 
  Appointment Remainder Time Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SCHEDULE_ID}
  * </ul>
 */
 
public final class PATIENTAPPOINTMENTREMAINDER
{
    private PATIENTAPPOINTMENTREMAINDER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientAppointmentRemainder" ;
    /**
              * <p> Scheduler ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SCHEDULE_ID= "SCHEDULE_ID" ;

    /*
    * The index position of the column SCHEDULE_ID in the table.
    */
    public static final int SCHEDULE_ID_IDX = 1 ;

    /**
              * <p> remainder notification time.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 2 ;

    /**
              * <p> remainder notification time is AM/PM.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AM_PM= "AM_PM" ;

    /*
    * The index position of the column AM_PM in the table.
    */
    public static final int AM_PM_IDX = 3 ;

    /**
              * <p> remainder notification day before.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DAYS_BEFORE= "DAYS_BEFORE" ;

    /*
    * The index position of the column DAYS_BEFORE in the table.
    */
    public static final int DAYS_BEFORE_IDX = 4 ;

}
