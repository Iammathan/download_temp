package com.adventnet.charm;

/** <p> Description of the table <code>LabOrdersTestAOEDetails</code>.
 *  Column Name and Table Name of  database table  <code>LabOrdersTestAOEDetails</code> is mapped
 * as constants in this util.</p> 
  AOE details as entered by user in client.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ORDER_AOE_ID}
  * </ul>
 */
 
public final class LABORDERSTESTAOEDETAILS
{
    private LABORDERSTESTAOEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabOrdersTestAOEDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORDER_AOE_ID= "ORDER_AOE_ID" ;

    /*
    * The index position of the column ORDER_AOE_ID in the table.
    */
    public static final int ORDER_AOE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ORDER_TEST_MAP_ID= "ORDER_TEST_MAP_ID" ;

    /*
    * The index position of the column ORDER_TEST_MAP_ID in the table.
    */
    public static final int ORDER_TEST_MAP_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AOE_QUESTION_CODE= "AOE_QUESTION_CODE" ;

    /*
    * The index position of the column AOE_QUESTION_CODE in the table.
    */
    public static final int AOE_QUESTION_CODE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AOE_QUESTION_DESCRIPTION= "AOE_QUESTION_DESCRIPTION" ;

    /*
    * The index position of the column AOE_QUESTION_DESCRIPTION in the table.
    */
    public static final int AOE_QUESTION_DESCRIPTION_IDX = 4 ;

    /**
              * <p> will be used as description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4096</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AOE_RESULT_FILTER= "AOE_RESULT_FILTER" ;

    /*
    * The index position of the column AOE_RESULT_FILTER in the table.
    */
    public static final int AOE_RESULT_FILTER_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AOE_ANSWER= "AOE_ANSWER" ;

    /*
    * The index position of the column AOE_ANSWER in the table.
    */
    public static final int AOE_ANSWER_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AOE_VALIDATION_REGEX= "AOE_VALIDATION_REGEX" ;

    /*
    * The index position of the column AOE_VALIDATION_REGEX in the table.
    */
    public static final int AOE_VALIDATION_REGEX_IDX = 7 ;

    /**
              * <p> a json array [{"option_text":"xxx","option_val":"xxx"}].</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>512</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String AOE_OPTION_LIST= "AOE_OPTION_LIST" ;

    /*
    * The index position of the column AOE_OPTION_LIST in the table.
    */
    public static final int AOE_OPTION_LIST_IDX = 8 ;

}
