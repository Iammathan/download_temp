package com.adventnet.charm;

/** <p> Description of the table <code>PHRInvitations</code>.
 *  Column Name and Table Name of  database table  <code>PHRInvitations</code> is mapped
 * as constants in this util.</p> 
  Table to hold details about invitations sent to Patients . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INVITATION_ID}
  * </ul>
 */
 
public final class PHRINVITATIONS
{
    private PHRINVITATIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRInvitations" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVITATION_ID= "INVITATION_ID" ;

    /*
    * The index position of the column INVITATION_ID in the table.
    */
    public static final int INVITATION_ID_IDX = 1 ;

    /**
              * <p> Secure code generated and stored in emr to avoid hacking.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SECURE_CODE= "SECURE_CODE" ;

    /*
    * The index position of the column SECURE_CODE in the table.
    */
    public static final int SECURE_CODE_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Invited time in long.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVITED_TIME= "INVITED_TIME" ;

    /*
    * The index position of the column INVITED_TIME in the table.
    */
    public static final int INVITED_TIME_IDX = 4 ;

    /**
              * <p> Present status of the Invitation.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                     * Default Value is <code>Pending</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 5 ;

    /**
              * <p> Number of Times an invitation is processed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAILURE_COUNT= "FAILURE_COUNT" ;

    /*
    * The index position of the column FAILURE_COUNT in the table.
    */
    public static final int FAILURE_COUNT_IDX = 6 ;

    /**
              * <p> First name of Representative.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REP_FIRST_NAME= "REP_FIRST_NAME" ;

    /*
    * The index position of the column REP_FIRST_NAME in the table.
    */
    public static final int REP_FIRST_NAME_IDX = 7 ;

    /**
              * <p> Last name of Representative.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REP_LAST_NAME= "REP_LAST_NAME" ;

    /*
    * The index position of the column REP_LAST_NAME in the table.
    */
    public static final int REP_LAST_NAME_IDX = 8 ;

    /**
              * <p> To indicate proxy/main account invitation.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PROXY= "IS_PROXY" ;

    /*
    * The index position of the column IS_PROXY in the table.
    */
    public static final int IS_PROXY_IDX = 9 ;

    /**
              * <p> Email address of the proxy account.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROXY_EMAIL= "PROXY_EMAIL" ;

    /*
    * The index position of the column PROXY_EMAIL in the table.
    */
    public static final int PROXY_EMAIL_IDX = 10 ;

}
