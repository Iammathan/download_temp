package com.adventnet.charm;

/** <p> Description of the table <code>SurescriptsServiceLevel</code>.
 *  Column Name and Table Name of  database table  <code>SurescriptsServiceLevel</code> is mapped
 * as constants in this util.</p> 
  Surescripts service level. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SURESCRIPTS_SERVICE_LEVEL_ID}
  * </ul>
 */
 
public final class SURESCRIPTSSERVICELEVEL
{
    private SURESCRIPTSSERVICELEVEL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SurescriptsServiceLevel" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SURESCRIPTS_SERVICE_LEVEL_ID= "SURESCRIPTS_SERVICE_LEVEL_ID" ;

    /*
    * The index position of the column SURESCRIPTS_SERVICE_LEVEL_ID in the table.
    */
    public static final int SURESCRIPTS_SERVICE_LEVEL_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NEW= "NEW" ;

    /*
    * The index position of the column NEW in the table.
    */
    public static final int NEW_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String REFILL= "REFILL" ;

    /*
    * The index position of the column REFILL in the table.
    */
    public static final int REFILL_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CHANGE= "CHANGE" ;

    /*
    * The index position of the column CHANGE in the table.
    */
    public static final int CHANGE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CANCEL= "CANCEL" ;

    /*
    * The index position of the column CANCEL in the table.
    */
    public static final int CANCEL_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CONTROLLED_SUBSTANCE= "CONTROLLED_SUBSTANCE" ;

    /*
    * The index position of the column CONTROLLED_SUBSTANCE in the table.
    */
    public static final int CONTROLLED_SUBSTANCE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RXFILL= "RXFILL" ;

    /*
    * The index position of the column RXFILL in the table.
    */
    public static final int RXFILL_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RXFILL_INDICATOR_CHANGE= "RXFILL_INDICATOR_CHANGE" ;

    /*
    * The index position of the column RXFILL_INDICATOR_CHANGE in the table.
    */
    public static final int RXFILL_INDICATOR_CHANGE_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String EPA= "EPA" ;

    /*
    * The index position of the column EPA in the table.
    */
    public static final int EPA_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RTF= "RTF" ;

    /*
    * The index position of the column RTF in the table.
    */
    public static final int RTF_IDX = 10 ;

}
