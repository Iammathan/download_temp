package com.adventnet.charm;

/** <p> Description of the table <code>GoogleCalendarAccess</code>.
 *  Column Name and Table Name of  database table  <code>GoogleCalendarAccess</code> is mapped
 * as constants in this util.</p> 
  Information about the tokens required to authenticate Google Account. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACCESS_ID}
  * </ul>
 */
 
public final class GOOGLECALENDARACCESS
{
    private GOOGLECALENDARACCESS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "GoogleCalendarAccess" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACCESS_ID= "ACCESS_ID" ;

    /*
    * The index position of the column ACCESS_ID in the table.
    */
    public static final int ACCESS_ID_IDX = 1 ;

    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Gmail Id of the user's calendar.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 3 ;

    /**
              * <p> Calendar Id of the user's calendar.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CALENDAR_ID= "CALENDAR_ID" ;

    /*
    * The index position of the column CALENDAR_ID in the table.
    */
    public static final int CALENDAR_ID_IDX = 4 ;

    /**
              * <p> Calendar Id used in ChARM->Google sync.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CALENDAR_OUT_ID= "CALENDAR_OUT_ID" ;

    /*
    * The index position of the column CALENDAR_OUT_ID in the table.
    */
    public static final int CALENDAR_OUT_ID_IDX = 5 ;

    /**
              * <p> Calendar Id used in Google->ChARM sync.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CALENDAR_IN_ID= "CALENDAR_IN_ID" ;

    /*
    * The index position of the column CALENDAR_IN_ID in the table.
    */
    public static final int CALENDAR_IN_ID_IDX = 6 ;

    /**
              * <p> Access Token for authentication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCESS_TOKEN= "ACCESS_TOKEN" ;

    /*
    * The index position of the column ACCESS_TOKEN in the table.
    */
    public static final int ACCESS_TOKEN_IDX = 7 ;

    /**
              * <p> Token Type for authentication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TOKEN_TYPE= "TOKEN_TYPE" ;

    /*
    * The index position of the column TOKEN_TYPE in the table.
    */
    public static final int TOKEN_TYPE_IDX = 8 ;

    /**
              * <p> Refresh Token for getting access token after it expires.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REFRESH_TOKEN= "REFRESH_TOKEN" ;

    /*
    * The index position of the column REFRESH_TOKEN in the table.
    */
    public static final int REFRESH_TOKEN_IDX = 9 ;

    /**
              * <p> Expire time of access token.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXPIRE_TIME= "EXPIRE_TIME" ;

    /*
    * The index position of the column EXPIRE_TIME in the table.
    */
    public static final int EXPIRE_TIME_IDX = 10 ;

    /**
              * <p> Last Synchronized Time with Google Calendar.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_SYNC_TIME= "LAST_SYNC_TIME" ;

    /*
    * The index position of the column LAST_SYNC_TIME in the table.
    */
    public static final int LAST_SYNC_TIME_IDX = 11 ;

    /**
              * <p> Last Synchronized Time for ChARM->Google sync.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_OUTSYNC_TIME= "LAST_OUTSYNC_TIME" ;

    /*
    * The index position of the column LAST_OUTSYNC_TIME in the table.
    */
    public static final int LAST_OUTSYNC_TIME_IDX = 12 ;

    /**
              * <p> Last Synchronized Time with Google->ChARM sync.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_INSYNC_TIME= "LAST_INSYNC_TIME" ;

    /*
    * The index position of the column LAST_INSYNC_TIME in the table.
    */
    public static final int LAST_INSYNC_TIME_IDX = 13 ;

    /**
              * <p> Status of the user's calendar sync.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 14 ;

    /**
              * <p> Status of the user's calendar ChARM->Google sync.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS_OUTSYNC= "STATUS_OUTSYNC" ;

    /*
    * The index position of the column STATUS_OUTSYNC in the table.
    */
    public static final int STATUS_OUTSYNC_IDX = 15 ;

    /**
              * <p> Status of the user's calendar Google->ChARM sync.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS_INSYNC= "STATUS_INSYNC" ;

    /*
    * The index position of the column STATUS_INSYNC in the table.
    */
    public static final int STATUS_INSYNC_IDX = 16 ;

    /**
              * <p> Google Calendar sync type (1/2/3).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String SYNC_TYPE= "SYNC_TYPE" ;

    /*
    * The index position of the column SYNC_TYPE in the table.
    */
    public static final int SYNC_TYPE_IDX = 17 ;

    /**
              * <p> Next Sync token for fetching Google Calendar events.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NEXT_SYNC_TOKEN= "NEXT_SYNC_TOKEN" ;

    /*
    * The index position of the column NEXT_SYNC_TOKEN in the table.
    */
    public static final int NEXT_SYNC_TOKEN_IDX = 18 ;

    /**
              * <p> Preference to show event details in ChARM.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SHOW_GEVENT_DESC= "SHOW_GEVENT_DESC" ;

    /*
    * The index position of the column SHOW_GEVENT_DESC in the table.
    */
    public static final int SHOW_GEVENT_DESC_IDX = 19 ;

    /**
              * <p> Facility ID to which the events get synced (For Timezone).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 20 ;

    /**
              * <p> For implementing webhook of Google Calendar.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RESOURCE_ID= "RESOURCE_ID" ;

    /*
    * The index position of the column RESOURCE_ID in the table.
    */
    public static final int RESOURCE_ID_IDX = 21 ;

}
