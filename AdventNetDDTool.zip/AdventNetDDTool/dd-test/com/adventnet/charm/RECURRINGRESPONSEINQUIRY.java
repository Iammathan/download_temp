package com.adventnet.charm;

/** <p> Description of the table <code>RecurringResponseInquiry</code>.
 *  Column Name and Table Name of  database table  <code>RecurringResponseInquiry</code> is mapped
 * as constants in this util.</p> 
  table containing renewed profiles. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ID}
  * </ul>
 */
 
public final class RECURRINGRESPONSEINQUIRY
{
    private RECURRINGRESPONSEINQUIRY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RecurringResponseInquiry" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String AMOUNT= "AMOUNT" ;

    /*
    * The index position of the column AMOUNT in the table.
    */
    public static final int AMOUNT_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROFILEID= "PROFILEID" ;

    /*
    * The index position of the column PROFILEID in the table.
    */
    public static final int PROFILEID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RESULT= "RESULT" ;

    /*
    * The index position of the column RESULT in the table.
    */
    public static final int RESULT_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAID_DATE= "PAID_DATE" ;

    /*
    * The index position of the column PAID_DATE in the table.
    */
    public static final int PAID_DATE_IDX = 5 ;

}
