package com.adventnet.charm;

/** <p> Description of the table <code>ImageResultGroup</code>.
 *  Column Name and Table Name of  database table  <code>ImageResultGroup</code> is mapped
 * as constants in this util.</p> 
  ImageResultGroup table is used to store image results . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_RESULT_GROUP_ID}
  * </ul>
 */
 
public final class IMAGERESULTGROUP
{
    private IMAGERESULTGROUP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageResultGroup" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_RESULT_GROUP_ID= "IMAGE_RESULT_GROUP_ID" ;

    /*
    * The index position of the column IMAGE_RESULT_GROUP_ID in the table.
    */
    public static final int IMAGE_RESULT_GROUP_ID_IDX = 1 ;

    /**
              * <p> PATIENT ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> LAB ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_LAB_ID= "IMAGE_LAB_ID" ;

    /*
    * The index position of the column IMAGE_LAB_ID in the table.
    */
    public static final int IMAGE_LAB_ID_IDX = 3 ;

    /**
              * <p> DATE.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 4 ;

    /**
              * <p> DATE.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMPORTED_TIME= "IMPORTED_TIME" ;

    /*
    * The index position of the column IMPORTED_TIME in the table.
    */
    public static final int IMPORTED_TIME_IDX = 5 ;

    /**
              * <p> ADDED BY.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMPORTED_BY= "IMPORTED_BY" ;

    /*
    * The index position of the column IMPORTED_BY in the table.
    */
    public static final int IMPORTED_BY_IDX = 6 ;

    /**
              * <p> Full name of the member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IMPORTED_BY_NAME= "IMPORTED_BY_NAME" ;

    /*
    * The index position of the column IMPORTED_BY_NAME in the table.
    */
    public static final int IMPORTED_BY_NAME_IDX = 7 ;

    /**
              * <p> To hold message level comments(Interpretations).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 8 ;

    /**
              * <p> To know whether msg came Electronically or Manual Result.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ELECTRONICALLY_RECEIVED= "IS_ELECTRONICALLY_RECEIVED" ;

    /*
    * The index position of the column IS_ELECTRONICALLY_RECEIVED in the table.
    */
    public static final int IS_ELECTRONICALLY_RECEIVED_IDX = 9 ;

    /**
              * <p> FACILITY ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 10 ;

    /**
              * <p> Link to the document.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IAMGE_FILE= "IAMGE_FILE" ;

    /*
    * The index position of the column IAMGE_FILE in the table.
    */
    public static final int IAMGE_FILE_IDX = 11 ;

    /**
              * <p> Linked to the document type .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IAMGE_FILE_TYPE= "IAMGE_FILE_TYPE" ;

    /*
    * The index position of the column IAMGE_FILE_TYPE in the table.
    */
    public static final int IAMGE_FILE_TYPE_IDX = 12 ;

    /**
              * <p> To matain message status Normal or Abnormal.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 13 ;

    /**
              * <p> To know whether msg is deleted or Not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 14 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 15 ;

}
