package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimCompleteDetails</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimCompleteDetails</code> is mapped
 * as constants in this util.</p> 
  Stores complete details related to RCM claim. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_ID}
  * </ul>
 */
 
public final class RCMCLAIMCOMPLETEDETAILS
{
    private RCMCLAIMCOMPLETEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimCompleteDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 1 ;

    /**
              * <p> id of the patient in the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Record id used to display in CMS1500 form as claim id (to be added).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_RECORD_ID= "CLAIM_RECORD_ID" ;

    /*
    * The index position of the column CLAIM_RECORD_ID in the table.
    */
    public static final int CLAIM_RECORD_ID_IDX = 3 ;

    /**
              * <p> Patient id in this claim - PK of RCMClaimPatientDemographics.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_PATIENT_ID= "CLAIM_PATIENT_ID" ;

    /*
    * The index position of the column CLAIM_PATIENT_ID in the table.
    */
    public static final int CLAIM_PATIENT_ID_IDX = 4 ;

    /**
              * <p> Guarantor id in this claim - PK of RCMClaimGuarantorDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_GUARANTOR_ID= "CLAIM_GUARANTOR_ID" ;

    /*
    * The index position of the column CLAIM_GUARANTOR_ID in the table.
    */
    public static final int CLAIM_GUARANTOR_ID_IDX = 5 ;

    /**
              * <p> Claim Primary Insurance Id - PK of RCMClaimInsuranceDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_INSURANCE_ID= "CLAIM_INSURANCE_ID" ;

    /*
    * The index position of the column CLAIM_INSURANCE_ID in the table.
    */
    public static final int CLAIM_INSURANCE_ID_IDX = 6 ;

    /**
              * <p> Claim Secondary Insurance Id - PK of RCMClaimInsuranceDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_OTHER_INSURANCE_ID= "CLAIM_OTHER_INSURANCE_ID" ;

    /*
    * The index position of the column CLAIM_OTHER_INSURANCE_ID in the table.
    */
    public static final int CLAIM_OTHER_INSURANCE_ID_IDX = 7 ;

    /**
              * <p> Claim related details id - PK of RCMClaimRelatedDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_RELATED_DETAILS_ID= "CLAIM_RELATED_DETAILS_ID" ;

    /*
    * The index position of the column CLAIM_RELATED_DETAILS_ID in the table.
    */
    public static final int CLAIM_RELATED_DETAILS_ID_IDX = 8 ;

    /**
              * <p> Claim Service facility id - PK of RCMClaimProviderDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_SERVICE_PROVIDER_ID= "CLAIM_SERVICE_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_SERVICE_PROVIDER_ID in the table.
    */
    public static final int CLAIM_SERVICE_PROVIDER_ID_IDX = 9 ;

    /**
              * <p> Claim billing provider id - PK of RCMClaimProviderDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_BILLING_PROVIDER_ID= "CLAIM_BILLING_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_BILLING_PROVIDER_ID in the table.
    */
    public static final int CLAIM_BILLING_PROVIDER_ID_IDX = 10 ;

    /**
              * <p> Claim referring provider id - PK of RCMClaimProviderDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_REF_PROVIDER_ID= "CLAIM_REF_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_REF_PROVIDER_ID in the table.
    */
    public static final int CLAIM_REF_PROVIDER_ID_IDX = 11 ;

    /**
              * <p> Claim Consulting provider id - PK of RCMClaimProviderDetails. This is used in e-Claim to get First name Middle Name and Last name.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_CONSULTING_PROVIDER_ID= "CLAIM_CONSULTING_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_CONSULTING_PROVIDER_ID in the table.
    */
    public static final int CLAIM_CONSULTING_PROVIDER_ID_IDX = 12 ;

    /**
              * <p> Consultation id for which claim is generated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 13 ;

    /**
              * <p> Total charge of procedures.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOTAL_CHARGE= "TOTAL_CHARGE" ;

    /*
    * The index position of the column TOTAL_CHARGE in the table.
    */
    public static final int TOTAL_CHARGE_IDX = 14 ;

    /**
              * <p> Amount paid.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AMOUNT_PAID= "AMOUNT_PAID" ;

    /*
    * The index position of the column AMOUNT_PAID in the table.
    */
    public static final int AMOUNT_PAID_IDX = 15 ;

    /**
              * <p> Balance due.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BALANCE_DUE= "BALANCE_DUE" ;

    /*
    * The index position of the column BALANCE_DUE in the table.
    */
    public static final int BALANCE_DUE_IDX = 16 ;

    /**
              * <p> Date on which claim is generated/Updated.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_GENERATED_DATE= "CLAIM_GENERATED_DATE" ;

    /*
    * The index position of the column CLAIM_GENERATED_DATE in the table.
    */
    public static final int CLAIM_GENERATED_DATE_IDX = 17 ;

    /**
              * <p> Date on which claim is lastly Updated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_UPDATED_DATE= "LAST_UPDATED_DATE" ;

    /*
    * The index position of the column LAST_UPDATED_DATE in the table.
    */
    public static final int LAST_UPDATED_DATE_IDX = 18 ;

    /**
              * <p> Status of a claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 19 ;

    /**
              * <p> This the status value created by ChARM from the electronic status details fetched.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>120</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ELECTRONIC_STATUS= "ELECTRONIC_STATUS" ;

    /*
    * The index position of the column ELECTRONIC_STATUS in the table.
    */
    public static final int ELECTRONIC_STATUS_IDX = 20 ;

    /**
              * <p> This holds the last when e-status verfied time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_VERIFIED_TIME= "ESTATUS_VERIFIED_TIME" ;

    /*
    * The index position of the column ESTATUS_VERIFIED_TIME in the table.
    */
    public static final int ESTATUS_VERIFIED_TIME_IDX = 21 ;

    /**
              * <p> Status Effective Date in Payer system retrieved through e-Status inquiry.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_EFFECTIVE_DATE= "ESTATUS_EFFECTIVE_DATE" ;

    /*
    * The index position of the column ESTATUS_EFFECTIVE_DATE in the table.
    */
    public static final int ESTATUS_EFFECTIVE_DATE_IDX = 22 ;

    /**
              * <p> Date on which claim is submitted.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_SUBMISSION_DATE= "CLAIM_SUBMISSION_DATE" ;

    /*
    * The index position of the column CLAIM_SUBMISSION_DATE in the table.
    */
    public static final int CLAIM_SUBMISSION_DATE_IDX = 23 ;

    /**
              * <p> Date on which consultation is done.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSULTATION_DATE= "CONSULTATION_DATE" ;

    /*
    * The index position of the column CONSULTATION_DATE in the table.
    */
    public static final int CONSULTATION_DATE_IDX = 24 ;

    /**
              * <p> Date on which payment is closed.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_CLOSE_DATE= "PAYMENT_CLOSE_DATE" ;

    /*
    * The index position of the column PAYMENT_CLOSE_DATE in the table.
    */
    public static final int PAYMENT_CLOSE_DATE_IDX = 25 ;

    /**
              * <p> Consulting Provider ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSULTING_PROVIDER_ID= "CONSULTING_PROVIDER_ID" ;

    /*
    * The index position of the column CONSULTING_PROVIDER_ID in the table.
    */
    public static final int CONSULTING_PROVIDER_ID_IDX = 26 ;

    /**
              * <p> Adjustment Amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_AMOUNT= "ADJUSTMENT_AMOUNT" ;

    /*
    * The index position of the column ADJUSTMENT_AMOUNT in the table.
    */
    public static final int ADJUSTMENT_AMOUNT_IDX = 27 ;

    /**
              * <p> Claim Write off Amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WRITE_OFF= "WRITE_OFF" ;

    /*
    * The index position of the column WRITE_OFF in the table.
    */
    public static final int WRITE_OFF_IDX = 28 ;

    /**
              * <p> Date on which claim is submitted.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SUBMITTED_DATE= "SUBMITTED_DATE" ;

    /*
    * The index position of the column SUBMITTED_DATE in the table.
    */
    public static final int SUBMITTED_DATE_IDX = 29 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 30 ;

    /**
              * <p> Date on which claim is Rejected.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REJECTED_DATE= "REJECTED_DATE" ;

    /*
    * The index position of the column REJECTED_DATE in the table.
    */
    public static final int REJECTED_DATE_IDX = 31 ;

    /**
              * <p> Date on which claim is Rejected.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_REJECTION_DATE= "CLAIM_REJECTION_DATE" ;

    /*
    * The index position of the column CLAIM_REJECTION_DATE in the table.
    */
    public static final int CLAIM_REJECTION_DATE_IDX = 32 ;

    /**
              * <p> 'Outside Lab Provider' selected for the claim is stored in 'ClaimProviderDetails' table with TYPE as 'outsidelab; corrosponding PK is stored here.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OUTSIDE_LAB_ID= "OUTSIDE_LAB_ID" ;

    /*
    * The index position of the column OUTSIDE_LAB_ID in the table.
    */
    public static final int OUTSIDE_LAB_ID_IDX = 33 ;

    /**
              * <p> Copay Amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COPAY_AMOUNT= "COPAY_AMOUNT" ;

    /*
    * The index position of the column COPAY_AMOUNT in the table.
    */
    public static final int COPAY_AMOUNT_IDX = 34 ;

    /**
              * <p> Indicates that the RCM claim is completed.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_MARKED_AS_COMPLETED= "IS_MARKED_AS_COMPLETED" ;

    /*
    * The index position of the column IS_MARKED_AS_COMPLETED in the table.
    */
    public static final int IS_MARKED_AS_COMPLETED_IDX = 35 ;

    /**
              * <p> Date on which PIF is generated.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PIF_GENERATED_DATE= "PIF_GENERATED_DATE" ;

    /*
    * The index position of the column PIF_GENERATED_DATE in the table.
    */
    public static final int PIF_GENERATED_DATE_IDX = 36 ;

    /**
              * <p> patient resposibility amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAT_RESP_AMT= "PAT_RESP_AMT" ;

    /*
    * The index position of the column PAT_RESP_AMT in the table.
    */
    public static final int PAT_RESP_AMT_IDX = 37 ;

    /**
              * <p> This is the unique no to identify the claim of the 277CA or EOB. Now it is RCMClaimCompleteDetails.CLAIM_RECORD_ID, but may change in future. Hence updating it in this column whenever we create/send a claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_CLAIM_CONTROL_NO= "PATIENT_CLAIM_CONTROL_NO" ;

    /*
    * The index position of the column PATIENT_CLAIM_CONTROL_NO in the table.
    */
    public static final int PATIENT_CLAIM_CONTROL_NO_IDX = 38 ;

    /**
              * <p> Total denied-by-payer amount for the claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DENIED_BY_PAYER= "DENIED_BY_PAYER" ;

    /*
    * The index position of the column DENIED_BY_PAYER in the table.
    */
    public static final int DENIED_BY_PAYER_IDX = 39 ;

    /**
              * <p> Has any denials.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String HAS_DENY_IN_EOB= "HAS_DENY_IN_EOB" ;

    /*
    * The index position of the column HAS_DENY_IN_EOB in the table.
    */
    public static final int HAS_DENY_IN_EOB_IDX = 40 ;

    /**
              * <p> Date on which claim is ReSubmitted .</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESUBMITTED_DATE= "RESUBMITTED_DATE" ;

    /*
    * The index position of the column RESUBMITTED_DATE in the table.
    */
    public static final int RESUBMITTED_DATE_IDX = 41 ;

    /**
              * <p> Date on which claim is ReSubmitted user Given Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_RESUBMITTED_DATE= "CLAIM_RESUBMITTED_DATE" ;

    /*
    * The index position of the column CLAIM_RESUBMITTED_DATE in the table.
    */
    public static final int CLAIM_RESUBMITTED_DATE_IDX = 42 ;

    /**
              * <p> Primary claim ID of this claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRIMARY_CLAIM_ID= "PRIMARY_CLAIM_ID" ;

    /*
    * The index position of the column PRIMARY_CLAIM_ID in the table.
    */
    public static final int PRIMARY_CLAIM_ID_IDX = 43 ;

    /**
              * <p> Record id used as Secondary claim id (to be added).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SEC_CLAIM_RECORD_ID= "SEC_CLAIM_RECORD_ID" ;

    /*
    * The index position of the column SEC_CLAIM_RECORD_ID in the table.
    */
    public static final int SEC_CLAIM_RECORD_ID_IDX = 44 ;

    /**
              * <p> This column specifies whether any related EOB's available for this claim.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_EOB_AVAILABLE= "IS_EOB_AVAILABLE" ;

    /*
    * The index position of the column IS_EOB_AVAILABLE in the table.
    */
    public static final int IS_EOB_AVAILABLE_IDX = 45 ;

    /**
              * <p> This column specifies the number of EOB's available for this claim. Default value is zero to denote no EOB's available for this claim.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NO_OF_AVAILABLE_EOB= "NO_OF_AVAILABLE_EOB" ;

    /*
    * The index position of the column NO_OF_AVAILABLE_EOB in the table.
    */
    public static final int NO_OF_AVAILABLE_EOB_IDX = 46 ;

    /**
              * <p> This column specifies whether to generate receipt for claim via encounters..</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String GENERATE_RECEIPT= "GENERATE_RECEIPT" ;

    /*
    * The index position of the column GENERATE_RECEIPT in the table.
    */
    public static final int GENERATE_RECEIPT_IDX = 47 ;

    /**
              * <p> Last Transaction History Of RCMClaimTransactionHistory.RCM_CLAIM_TRNXN_HIST_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_TXN_HISTORY_ID= "LAST_TXN_HISTORY_ID" ;

    /*
    * The index position of the column LAST_TXN_HISTORY_ID in the table.
    */
    public static final int LAST_TXN_HISTORY_ID_IDX = 48 ;

    /**
              * <p> Type Of Claim Generated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                     * Default Value is <code>PRIMARY</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>PRIMARY</code>" , 
       * will be taken.<br>
                         */
    public static final String CLAIM_TYPE= "CLAIM_TYPE" ;

    /*
    * The index position of the column CLAIM_TYPE in the table.
    */
    public static final int CLAIM_TYPE_IDX = 49 ;

    /**
              * <p> Record id used as Vaccine claim id (to be added).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VAC_CLAIM_RECORD_ID= "VAC_CLAIM_RECORD_ID" ;

    /*
    * The index position of the column VAC_CLAIM_RECORD_ID in the table.
    */
    public static final int VAC_CLAIM_RECORD_ID_IDX = 50 ;

    /**
              * <p> This column specifies this claim payment pay through patient or not..</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_PAY_TO_PATIENT= "IS_PAY_TO_PATIENT" ;

    /*
    * The index position of the column IS_PAY_TO_PATIENT in the table.
    */
    public static final int IS_PAY_TO_PATIENT_IDX = 51 ;

    /**
              * <p> This column specifies this Code type of Diagnosis Codes..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                     * Default Value is <code>9</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>9</code>" , 
       * will be taken.<br>
                         */
    public static final String ICD_CODE_TYPE= "ICD_CODE_TYPE" ;

    /*
    * The index position of the column ICD_CODE_TYPE in the table.
    */
    public static final int ICD_CODE_TYPE_IDX = 52 ;

    /**
              * <p> Bill id for which claim is generated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 53 ;

    /**
              * <p> Total denied  amount for the claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DENIAL_AMOUNT= "DENIAL_AMOUNT" ;

    /*
    * The index position of the column DENIAL_AMOUNT in the table.
    */
    public static final int DENIAL_AMOUNT_IDX = 54 ;

    /**
              * <p>  0 - Has NO Attachment; 1 - Has RCM Claim Attachment only; 2 - Has only Manual EOB; 3 - Has both Claim Attachment and Manual EOB.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String HAS_ATTACHMENTS= "HAS_ATTACHMENTS" ;

    /*
    * The index position of the column HAS_ATTACHMENTS in the table.
    */
    public static final int HAS_ATTACHMENTS_IDX = 55 ;

    /**
              * <p> identifies if claim is flagged or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_FLAGGED= "IS_FLAGGED" ;

    /*
    * The index position of the column IS_FLAGGED in the table.
    */
    public static final int IS_FLAGGED_IDX = 56 ;

    /**
              * <p> identifies if the claim has double payments(manually marked).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_PAYMENT_REVERSAL_EXPECTED= "IS_PAYMENT_REVERSAL_EXPECTED" ;

    /*
    * The index position of the column IS_PAYMENT_REVERSAL_EXPECTED in the table.
    */
    public static final int IS_PAYMENT_REVERSAL_EXPECTED_IDX = 57 ;

    /**
              * <p> Send Service Facility if equal to billing provider, as per specification should not send if same.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SEND_SERV_FAC_IF_EQ_BILL_PRV= "SEND_SERV_FAC_IF_EQ_BILL_PRV" ;

    /*
    * The index position of the column SEND_SERV_FAC_IF_EQ_BILL_PRV in the table.
    */
    public static final int SEND_SERV_FAC_IF_EQ_BILL_PRV_IDX = 58 ;

    /**
              * <p> Send Rendering Provider if equal to billing provider, as per specification should not send if same.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SEND_REND_PRV_IF_EQ_BILL_PRV= "SEND_REND_PRV_IF_EQ_BILL_PRV" ;

    /*
    * The index position of the column SEND_REND_PRV_IF_EQ_BILL_PRV in the table.
    */
    public static final int SEND_REND_PRV_IF_EQ_BILL_PRV_IDX = 59 ;

    /**
              * <p> Send additional identifiers even NPI is available.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SEND_ADDNL_IDS_WITH_NPI= "SEND_ADDNL_IDS_WITH_NPI" ;

    /*
    * The index position of the column SEND_ADDNL_IDS_WITH_NPI in the table.
    */
    public static final int SEND_ADDNL_IDS_WITH_NPI_IDX = 60 ;

    /**
              * <p> Time of the very first successful(i.e, acknowledged by clearinghouse) electronic Submission of the RCM claim in milliseconds. It will be NULL for all other claims.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FIRST_ECLAIM_SUBMISSION_TIME= "FIRST_ECLAIM_SUBMISSION_TIME" ;

    /*
    * The index position of the column FIRST_ECLAIM_SUBMISSION_TIME in the table.
    */
    public static final int FIRST_ECLAIM_SUBMISSION_TIME_IDX = 61 ;

    /**
              * <p> RCMClaimCategories.RCM_CLAIM_CAT_ID in publicSpace.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_CLAIM_CAT_ID= "RCM_CLAIM_CAT_ID" ;

    /*
    * The index position of the column RCM_CLAIM_CAT_ID in the table.
    */
    public static final int RCM_CLAIM_CAT_ID_IDX = 62 ;

    /**
              * <p> UB04ClaimDetailsExt.UB04_CLAIM_EXT_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_CLAIM_EXT_ID= "UB04_CLAIM_EXT_ID" ;

    /*
    * The index position of the column UB04_CLAIM_EXT_ID in the table.
    */
    public static final int UB04_CLAIM_EXT_ID_IDX = 63 ;

    /**
              * <p> PracticeId of MBP which generated/processed the claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 64 ;

}
