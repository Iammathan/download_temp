package com.adventnet.charm;

/** <p> Description of the table <code>Directory</code>.
 *  Column Name and Table Name of  database table  <code>Directory</code> is mapped
 * as constants in this util.</p> 
  Store the contacts used to fax. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DIRECTORY_ID}
  * </ul>
 */
 
public final class DIRECTORY
{
    private DIRECTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Directory" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DIRECTORY_ID= "DIRECTORY_ID" ;

    /*
    * The index position of the column DIRECTORY_ID in the table.
    */
    public static final int DIRECTORY_ID_IDX = 1 ;

    /**
              * <p> Type of the fax no [ Others, Lab ].</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                     * Default Value is <code>Others</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 2 ;

    /**
              * <p> Contact name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 3 ;

    /**
              * <p> Description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 4 ;

    /**
              * <p> is_deleted / not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

    /**
              * <p> Added by member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

    /**
              * <p> Contact created time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_TIME= "CREATED_TIME" ;

    /*
    * The index position of the column CREATED_TIME in the table.
    */
    public static final int CREATED_TIME_IDX = 7 ;

    /**
              * <p> Id for Mapping ContactDetails and directory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 8 ;

    /**
              * <p> Id for Mapping PostalAddress and directory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 9 ;

}
