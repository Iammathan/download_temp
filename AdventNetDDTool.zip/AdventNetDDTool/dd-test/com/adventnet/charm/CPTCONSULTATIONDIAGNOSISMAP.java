package com.adventnet.charm;

/** <p> Description of the table <code>CPTConsultationDiagnosisMap</code>.
 *  Column Name and Table Name of  database table  <code>CPTConsultationDiagnosisMap</code> is mapped
 * as constants in this util.</p> 
  Maintains Consultation CPT Procedure Code Vs Diagnosis mapping. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CPT_DIAGNOSIS_MAP_ID}
  * </ul>
 */
 
public final class CPTCONSULTATIONDIAGNOSISMAP
{
    private CPTCONSULTATIONDIAGNOSISMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CPTConsultationDiagnosisMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CPT_DIAGNOSIS_MAP_ID= "CPT_DIAGNOSIS_MAP_ID" ;

    /*
    * The index position of the column CPT_DIAGNOSIS_MAP_ID in the table.
    */
    public static final int CPT_DIAGNOSIS_MAP_ID_IDX = 1 ;

    /**
              * <p> Consultation Versus CPT Map Idenitifer - PK of ConsultationCPTMap .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_CPT_MAP_ID= "CONSULTATION_CPT_MAP_ID" ;

    /*
    * The index position of the column CONSULTATION_CPT_MAP_ID in the table.
    */
    public static final int CONSULTATION_CPT_MAP_ID_IDX = 2 ;

    /**
              * <p> Diagnosis map id of PatientDiagnosisMap table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DIAGNOSIS_MAP_ID= "DIAGNOSIS_MAP_ID" ;

    /*
    * The index position of the column DIAGNOSIS_MAP_ID in the table.
    */
    public static final int DIAGNOSIS_MAP_ID_IDX = 3 ;

    /**
              * <p> Position of the DX on CPT Level.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DIAGNOSIS_ORDER= "DIAGNOSIS_ORDER" ;

    /*
    * The index position of the column DIAGNOSIS_ORDER in the table.
    */
    public static final int DIAGNOSIS_ORDER_IDX = 4 ;

}
