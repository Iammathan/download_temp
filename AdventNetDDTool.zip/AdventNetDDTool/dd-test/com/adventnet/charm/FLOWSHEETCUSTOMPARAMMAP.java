package com.adventnet.charm;

/** <p> Description of the table <code>FlowsheetCustomParamMap</code>.
 *  Column Name and Table Name of  database table  <code>FlowsheetCustomParamMap</code> is mapped
 * as constants in this util.</p> 
  Table to store VITAL_ID from CustomVitals table for IS_VITAL = true entries. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FLOW_SHEET_ENTRY_ID}
  * </ul>
 */
 
public final class FLOWSHEETCUSTOMPARAMMAP
{
    private FLOWSHEETCUSTOMPARAMMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FlowsheetCustomParamMap" ;
    /**
              * <p> Id from FlowsheetEntries table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FLOW_SHEET_ENTRY_ID= "FLOW_SHEET_ENTRY_ID" ;

    /*
    * The index position of the column FLOW_SHEET_ENTRY_ID in the table.
    */
    public static final int FLOW_SHEET_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Unique Id from CustomVitals table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VITAL_ID= "VITAL_ID" ;

    /*
    * The index position of the column VITAL_ID in the table.
    */
    public static final int VITAL_ID_IDX = 2 ;

}
