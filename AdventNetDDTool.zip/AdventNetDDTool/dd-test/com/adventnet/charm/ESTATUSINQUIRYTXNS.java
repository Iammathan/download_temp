package com.adventnet.charm;

/** <p> Description of the table <code>EStatusInquiryTxns</code>.
 *  Column Name and Table Name of  database table  <code>EStatusInquiryTxns</code> is mapped
 * as constants in this util.</p> 
  Stores all the Electronic Status Inquiry (276/277) transactions performed either manually or through scheduler. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ESTATUS_TXN_ID}
  * </ul>
 */
 
public final class ESTATUSINQUIRYTXNS
{
    private ESTATUSINQUIRYTXNS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EStatusInquiryTxns" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_TXN_ID= "ESTATUS_TXN_ID" ;

    /*
    * The index position of the column ESTATUS_TXN_ID in the table.
    */
    public static final int ESTATUS_TXN_ID_IDX = 1 ;

    /**
              * <p> Date and time on which status inquiry transaction was performed.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INQUIRY_DATE_TIME= "INQUIRY_DATE_TIME" ;

    /*
    * The index position of the column INQUIRY_DATE_TIME in the table.
    */
    public static final int INQUIRY_DATE_TIME_IDX = 2 ;

    /**
              * <p> Denotes whether this inquiry transaction is scheduled or initiated manually. Default is FALSE to indicate manual status inquiry.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SCHEDULED_INQUIRY= "IS_SCHEDULED_INQUIRY" ;

    /*
    * The index position of the column IS_SCHEDULED_INQUIRY in the table.
    */
    public static final int IS_SCHEDULED_INQUIRY_IDX = 3 ;

    /**
              * <p> User who has done the status inquiry; for scheduled inquiry it will be "Status Inquiry Scheduler".</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USER_NAME= "USER_NAME" ;

    /*
    * The index position of the column USER_NAME in the table.
    */
    public static final int USER_NAME_IDX = 4 ;

    /**
              * <p> Indicates the type of error, If any error occured during the Status Inquiry process.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_TYPE= "ERROR_TYPE" ;

    /*
    * The index position of the column ERROR_TYPE in the table.
    */
    public static final int ERROR_TYPE_IDX = 5 ;

    /**
              * <p> Contains the error message, If any error occured during the Status Inquiry process.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_MESSAGE= "ERROR_MESSAGE" ;

    /*
    * The index position of the column ERROR_MESSAGE in the table.
    */
    public static final int ERROR_MESSAGE_IDX = 6 ;

    /**
              * <p> Total Number of claims to be inquired for status.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>-1</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TOTAL_NO_OF_CLAIMS= "TOTAL_NO_OF_CLAIMS" ;

    /*
    * The index position of the column TOTAL_NO_OF_CLAIMS in the table.
    */
    public static final int TOTAL_NO_OF_CLAIMS_IDX = 7 ;

    /**
              * <p> Number of claims for which status inquiry was performed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>-1</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NO_OF_INQUIRED_CLAIMS= "NO_OF_INQUIRED_CLAIMS" ;

    /*
    * The index position of the column NO_OF_INQUIRED_CLAIMS in the table.
    */
    public static final int NO_OF_INQUIRED_CLAIMS_IDX = 8 ;

    /**
              * <p> Number of claims for which status(other than error related) was received after the inquiry.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>-1</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NO_OF_CLAIMS_HAS_STATUS= "NO_OF_CLAIMS_HAS_STATUS" ;

    /*
    * The index position of the column NO_OF_CLAIMS_HAS_STATUS in the table.
    */
    public static final int NO_OF_CLAIMS_HAS_STATUS_IDX = 9 ;

    /**
              * <p> Is the estatus inquiry done from RCM(true) or EHR-Billing(false).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 10 ;

    /**
              * <p> When this transaction is a retry transaction, this column will have ESTATUS_TXN_ID of the previously failed transaction.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PREV_FAILED_TXN_ID= "PREV_FAILED_TXN_ID" ;

    /*
    * The index position of the column PREV_FAILED_TXN_ID in the table.
    */
    public static final int PREV_FAILED_TXN_ID_IDX = 11 ;

    /**
              * <p> Stores the retry count of this (group of) transaction.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RETRY_COUNT= "RETRY_COUNT" ;

    /*
    * The index position of the column RETRY_COUNT in the table.
    */
    public static final int RETRY_COUNT_IDX = 12 ;

    /**
              * <p> This is a serialized object (ArrayList(String)) of claim id, for which e-status inquiry failed.</p>
                            * Data Type of this field is <code>BLOB</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FAILED_CLAIM_ID_LIST= "FAILED_CLAIM_ID_LIST" ;

    /*
    * The index position of the column FAILED_CLAIM_ID_LIST in the table.
    */
    public static final int FAILED_CLAIM_ID_LIST_IDX = 13 ;

}
