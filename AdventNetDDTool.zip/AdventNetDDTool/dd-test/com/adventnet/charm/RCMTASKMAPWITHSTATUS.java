package com.adventnet.charm;

/** <p> Description of the table <code>RCMTaskMapWithStatus</code>.
 *  Column Name and Table Name of  database table  <code>RCMTaskMapWithStatus</code> is mapped
 * as constants in this util.</p> 
  Task sub table. Consist Claim/Invoice/Patients map info and task status. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_TASK_MAP_ID}
  * </ul>
 */
 
public final class RCMTASKMAPWITHSTATUS
{
    private RCMTASKMAPWITHSTATUS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMTaskMapWithStatus" ;
    /**
              * <p> Primary Key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_TASK_MAP_ID= "RCM_TASK_MAP_ID" ;

    /*
    * The index position of the column RCM_TASK_MAP_ID in the table.
    */
    public static final int RCM_TASK_MAP_ID_IDX = 1 ;

    /**
              * <p> RCMTask.RCM_TASK_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_TASK_ID= "RCM_TASK_ID" ;

    /*
    * The index position of the column RCM_TASK_ID in the table.
    */
    public static final int RCM_TASK_ID_IDX = 2 ;

    /**
              * <p> Staus of the task 0 for open/5 for In Progress/10 for closed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>5</code></li>
              * <li><code>10</code></li>
              * </ul>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 3 ;

    /**
              * <p> Task created for Claim/Invoice/Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAP_TO= "MAP_TO" ;

    /*
    * The index position of the column MAP_TO in the table.
    */
    public static final int MAP_TO_IDX = 4 ;

    /**
              * <p> PK of Claim/Invoice/Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAP_ID= "MAP_ID" ;

    /*
    * The index position of the column MAP_ID in the table.
    */
    public static final int MAP_ID_IDX = 5 ;

}
