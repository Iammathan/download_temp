package com.adventnet.charm;

/** <p> Description of the table <code>ERAClaimAdditionalDetail</code>.
 *  Column Name and Table Name of  database table  <code>ERAClaimAdditionalDetail</code> is mapped
 * as constants in this util.</p> 
  contains some additional detail of the respective claim in the EClaimDetails table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_CLAIM_ADDITIONAL_DETAIL_ID}
  * </ul>
 */
 
public final class ERACLAIMADDITIONALDETAIL
{
    private ERACLAIMADDITIONALDETAIL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERAClaimAdditionalDetail" ;
    /**
              * <p> SAS Key - Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_CLAIM_ADDITIONAL_DETAIL_ID= "ERA_CLAIM_ADDITIONAL_DETAIL_ID" ;

    /*
    * The index position of the column ERA_CLAIM_ADDITIONAL_DETAIL_ID in the table.
    */
    public static final int ERA_CLAIM_ADDITIONAL_DETAIL_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERAClaimDetail table, where the respective claim detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_CLAIM_DETAIL_ID= "ERA_CLAIM_DETAIL_ID" ;

    /*
    * The index position of the column ERA_CLAIM_DETAIL_ID in the table.
    */
    public static final int ERA_CLAIM_DETAIL_ID_IDX = 2 ;

    /**
              * <p> 2100 : NM1 : PATIENT NAME : #137 - PK of ERAEntityDetail table, where claim patient detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_PATIENT_ID= "CLAIM_PATIENT_ID" ;

    /*
    * The index position of the column CLAIM_PATIENT_ID in the table.
    */
    public static final int CLAIM_PATIENT_ID_IDX = 3 ;

    /**
              * <p> 2100 : NM1 : INSURED NAME : #140 - PK of ERAEntityDetail table, where claim insured detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_INSURED_ID= "CLAIM_INSURED_ID" ;

    /*
    * The index position of the column CLAIM_INSURED_ID in the table.
    */
    public static final int CLAIM_INSURED_ID_IDX = 4 ;

    /**
              * <p> 2100 : NM1 : CORRECTED PATIENT/INSURED NAME : #143 - PK of ERAEntityDetail table, where the corrected patient or insured detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CORRECTED_PATIEN_OR_INSURED_ID= "CORRECTED_PATIEN_OR_INSURED_ID" ;

    /*
    * The index position of the column CORRECTED_PATIEN_OR_INSURED_ID in the table.
    */
    public static final int CORRECTED_PATIEN_OR_INSURED_ID_IDX = 5 ;

    /**
              * <p> 2100 : NM1 : SERVICE PROVIDER NAME : #146 - PK of ERAEntityDetail table, where claim service provider detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_PROVIDER_ID= "SERVICE_PROVIDER_ID" ;

    /*
    * The index position of the column SERVICE_PROVIDER_ID in the table.
    */
    public static final int SERVICE_PROVIDER_ID_IDX = 6 ;

    /**
              * <p> 2100 : NM1 : CROSSOVER CARRIER NAME : #150 - PK of ERAEntityDetail table, where crossover carrier detail is stored, if the claim is moved to another payer(i.e, when Claim Status CLP01 is any of 19,20,21,23)..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CROSSOVER_CARRIER_ID= "CROSSOVER_CARRIER_ID" ;

    /*
    * The index position of the column CROSSOVER_CARRIER_ID in the table.
    */
    public static final int CROSSOVER_CARRIER_ID_IDX = 7 ;

    /**
              * <p> 2100 : NM1 : CORRECTED PRIORITY PAYER NAME : #153 - PK of ERAEntityDetail table, where corrected priority payer detail is stored. When the destination payer identifies another payer has priority to make payment then and it is unable to forward the claim to that payer then this detail will be sent.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CORRECTED_PRIORITY_PAYER_ID= "CORRECTED_PRIORITY_PAYER_ID" ;

    /*
    * The index position of the column CORRECTED_PRIORITY_PAYER_ID in the table.
    */
    public static final int CORRECTED_PRIORITY_PAYER_ID_IDX = 8 ;

    /**
              * <p> 2100 : NM1 : OTHER SUBSCRIBER NAME : #156 - PK of ERAEntityDetail table, where the subscriber/insured detail of the corrected priority payer insurance is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OTHER_SUBSCRIBER_ID= "OTHER_SUBSCRIBER_ID" ;

    /*
    * The index position of the column OTHER_SUBSCRIBER_ID in the table.
    */
    public static final int OTHER_SUBSCRIBER_ID_IDX = 9 ;

    /**
              * <p> 2100 : DTM : STATEMENT FROM OR TO DATE : #173 - 'From Date' of the claim statement (DTM01 is 232).</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATEMENT_FROM_DATE= "STATEMENT_FROM_DATE" ;

    /*
    * The index position of the column STATEMENT_FROM_DATE in the table.
    */
    public static final int STATEMENT_FROM_DATE_IDX = 10 ;

    /**
              * <p> 2100 : DTM : STATEMENT FROM OR TO DATE : #173 - 'To Date' of the claim statement (DTM01 is 233).</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATEMENT_TO_DATE= "STATEMENT_TO_DATE" ;

    /*
    * The index position of the column STATEMENT_TO_DATE in the table.
    */
    public static final int STATEMENT_TO_DATE_IDX = 11 ;

    /**
              * <p> 2100 : DTM : COVERAGE EXPIRATION DATE : #175 - Expiry date of the coverage. Available when the claim is denied because of the expiration of the coverage.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COVERAGE_EXPIRATION_DATE= "COVERAGE_EXPIRATION_DATE" ;

    /*
    * The index position of the column COVERAGE_EXPIRATION_DATE in the table.
    */
    public static final int COVERAGE_EXPIRATION_DATE_IDX = 12 ;

    /**
              * <p> 2100 : DTM - CLAIM RECEIVED DATE : #177 - State or Federal regulations or the provider contract mandate interest payment or prompt payment discounts based upon the receipt date of the claim by the payee.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_RECEIVED_DATE= "CLAIM_RECEIVED_DATE" ;

    /*
    * The index position of the column CLAIM_RECEIVED_DATE in the table.
    */
    public static final int CLAIM_RECEIVED_DATE_IDX = 13 ;

    /**
              * <p> 2100 : PER - CLAIM CONTACT INFORMATION : #179 - PK of the ERAEntityContactDetails table, where the first contact details of the payers claim office is stored , if available.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FIRST_CLAIM_CONTACTDETAILS_ID= "FIRST_CLAIM_CONTACTDETAILS_ID" ;

    /*
    * The index position of the column FIRST_CLAIM_CONTACTDETAILS_ID in the table.
    */
    public static final int FIRST_CLAIM_CONTACTDETAILS_ID_IDX = 14 ;

    /**
              * <p> 2100 : PER - CLAIM CONTACT INFORMATION : #179 - PK of the ERAEntityContactDetails table, where the second contact details of the payers claim office is stored , if available.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SECOND_CLAIM_CONTACTDETAILS_ID= "SECOND_CLAIM_CONTACTDETAILS_ID" ;

    /*
    * The index position of the column SECOND_CLAIM_CONTACTDETAILS_ID in the table.
    */
    public static final int SECOND_CLAIM_CONTACTDETAILS_ID_IDX = 15 ;

}
