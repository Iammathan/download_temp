package com.adventnet.charm;

/** <p> Description of the table <code>ConsultationCPTMap</code>.
 *  Column Name and Table Name of  database table  <code>ConsultationCPTMap</code> is mapped
 * as constants in this util.</p> 
  Maintains Consultation Versus related CPT Procedure Code mapping. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CONSULTATION_CPT_MAP_ID}
  * </ul>
 */
 
public final class CONSULTATIONCPTMAP
{
    private CONSULTATIONCPTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ConsultationCPTMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSULTATION_CPT_MAP_ID= "CONSULTATION_CPT_MAP_ID" ;

    /*
    * The index position of the column CONSULTATION_CPT_MAP_ID in the table.
    */
    public static final int CONSULTATION_CPT_MAP_ID_IDX = 1 ;

    /**
              * <p> Consultation Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Procedure code number - Duplicated from ProcedureCode table as the generic details of the code can be changed or deleted in future .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>8</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CODE_NUMBER= "CODE_NUMBER" ;

    /*
    * The index position of the column CODE_NUMBER in the table.
    */
    public static final int CODE_NUMBER_IDX = 3 ;

    /**
              * <p> Service code description  - Duplicated from ProcedureCode table as the generic details of the code can be changed or deleted in future .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE_DESC= "CODE_DESC" ;

    /*
    * The index position of the column CODE_DESC in the table.
    */
    public static final int CODE_DESC_IDX = 4 ;

    /**
              * <p> Type of code  - Duplicated from ProcedureCode table as the generic details of the code can be changed or deleted in future .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE_TYPE= "CODE_TYPE" ;

    /*
    * The index position of the column CODE_TYPE in the table.
    */
    public static final int CODE_TYPE_IDX = 5 ;

    /**
              * <p> Charge for this code  - Duplicated from ProcedureCode table as the generic details of the code can be changed or deleted in future .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHARGE= "CHARGE" ;

    /*
    * The index position of the column CHARGE in the table.
    */
    public static final int CHARGE_IDX = 6 ;

    /**
              * <p> CPT Code Id of ProcedureCode table - This column is not used in joining purpose. Just stored as a reference .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CODE_ID= "CODE_ID" ;

    /*
    * The index position of the column CODE_ID in the table.
    */
    public static final int CODE_ID_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 8 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 9 ;

    /**
              * <p> Whether CPT has been used in invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_INVOICED= "IS_INVOICED" ;

    /*
    * The index position of the column IS_INVOICED in the table.
    */
    public static final int IS_INVOICED_IDX = 10 ;

}
