package com.adventnet.charm;

/** <p> Description of the table <code>QuickNotes</code>.
 *  Column Name and Table Name of  database table  <code>QuickNotes</code> is mapped
 * as constants in this util.</p> 
  used to store quick notes regarding a patient medical info. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #QUICK_NOTES_ID}
  * </ul>
 */
 
public final class QUICKNOTES
{
    private QUICKNOTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QuickNotes" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String QUICK_NOTES_ID= "QUICK_NOTES_ID" ;

    /*
    * The index position of the column QUICK_NOTES_ID in the table.
    */
    public static final int QUICK_NOTES_ID_IDX = 1 ;

    /**
              * <p> patient id in the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Member who have created the quick note.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 3 ;

    /**
              * <p> the quick note created time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 4 ;

    /**
              * <p> Quick notes content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 5 ;

    /**
              * <p> boolean to hold whether the sticky note is deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 6 ;

}
