package com.adventnet.charm;

/** <p> Description of the table <code>FlowsheetSpecialityMap</code>.
 *  Column Name and Table Name of  database table  <code>FlowsheetSpecialityMap</code> is mapped
 * as constants in this util.</p> 
  Table to be used only for Flowsheet Library. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FLOWSHEET_SPECIALITY_MAP_ID}
  * </ul>
 */
 
public final class FLOWSHEETSPECIALITYMAP
{
    private FLOWSHEETSPECIALITYMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FlowsheetSpecialityMap" ;
    /**
              * <p> Unique Identifier for a flowsheet mapped to a speciality.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FLOWSHEET_SPECIALITY_MAP_ID= "FLOWSHEET_SPECIALITY_MAP_ID" ;

    /*
    * The index position of the column FLOWSHEET_SPECIALITY_MAP_ID in the table.
    */
    public static final int FLOWSHEET_SPECIALITY_MAP_ID_IDX = 1 ;

    /**
              * <p> Unique Id from Flowsheets table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FLOW_SHEET_ID= "FLOW_SHEET_ID" ;

    /*
    * The index position of the column FLOW_SHEET_ID in the table.
    */
    public static final int FLOW_SHEET_ID_IDX = 2 ;

    /**
              * <p> Unique id from SpecialityList table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SPECIALITY_ID= "SPECIALITY_ID" ;

    /*
    * The index position of the column SPECIALITY_ID in the table.
    */
    public static final int SPECIALITY_ID_IDX = 3 ;

}
