package com.adventnet.charm;

/** <p> Description of the table <code>EOBsToRCM</code>.
 *  Column Name and Table Name of  database table  <code>EOBsToRCM</code> is mapped
 * as constants in this util.</p> 
  For sendings EOBs from Practice to RCM. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EOB_TO_RCM_ID}
  * </ul>
 */
 
public final class EOBSTORCM
{
    private EOBSTORCM()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EOBsToRCM" ;
    /**
              * <p> Surrogate key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EOB_TO_RCM_ID= "EOB_TO_RCM_ID" ;

    /*
    * The index position of the column EOB_TO_RCM_ID in the table.
    */
    public static final int EOB_TO_RCM_ID_IDX = 1 ;

    /**
              * <p> The pointer to the file stored in DFS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_POINTER= "FILE_POINTER" ;

    /*
    * The index position of the column FILE_POINTER in the table.
    */
    public static final int FILE_POINTER_IDX = 2 ;

    /**
              * <p> The name of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 3 ;

    /**
              * <p> The type of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_TYPE= "FILE_TYPE" ;

    /*
    * The index position of the column FILE_TYPE in the table.
    */
    public static final int FILE_TYPE_IDX = 4 ;

    /**
              * <p> The facility id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 5 ;

    /**
              * <p> The name of the payer(Insurance).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_NAME= "PAYER_NAME" ;

    /*
    * The index position of the column PAYER_NAME in the table.
    */
    public static final int PAYER_NAME_IDX = 6 ;

    /**
              * <p> The code of the payer.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_CODE= "PAYER_CODE" ;

    /*
    * The index position of the column PAYER_CODE in the table.
    */
    public static final int PAYER_CODE_IDX = 7 ;

    /**
              * <p> The comments from the practice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRACTICE_COMMENTS= "PRACTICE_COMMENTS" ;

    /*
    * The index position of the column PRACTICE_COMMENTS in the table.
    */
    public static final int PRACTICE_COMMENTS_IDX = 8 ;

    /**
              * <p> The id of the EHR member who uploaded the file.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String UPLOADED_MEM_ID= "UPLOADED_MEM_ID" ;

    /*
    * The index position of the column UPLOADED_MEM_ID in the table.
    */
    public static final int UPLOADED_MEM_ID_IDX = 9 ;

    /**
              * <p> The name of the EHR member who uploaded the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>103</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String UPLOADED_MEM_NAME= "UPLOADED_MEM_NAME" ;

    /*
    * The index position of the column UPLOADED_MEM_NAME in the table.
    */
    public static final int UPLOADED_MEM_NAME_IDX = 10 ;

    /**
              * <p> The time in UTC when uploaded.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String UPLOADED_ON_UTC= "UPLOADED_ON_UTC" ;

    /*
    * The index position of the column UPLOADED_ON_UTC in the table.
    */
    public static final int UPLOADED_ON_UTC_IDX = 11 ;

    /**
              * <p> 1 is deleted 0 is not deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 12 ;

    /**
              * <p> The id of the EHR member who deleted the file.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DELETED_MEM_ID= "DELETED_MEM_ID" ;

    /*
    * The index position of the column DELETED_MEM_ID in the table.
    */
    public static final int DELETED_MEM_ID_IDX = 13 ;

    /**
              * <p> The name of the EHR member who deleted the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>103</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DELETED_MEM_NAME= "DELETED_MEM_NAME" ;

    /*
    * The index position of the column DELETED_MEM_NAME in the table.
    */
    public static final int DELETED_MEM_NAME_IDX = 14 ;

    /**
              * <p> The time in UTC when deleted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DELETED_ON_UTC= "DELETED_ON_UTC" ;

    /*
    * The index position of the column DELETED_ON_UTC in the table.
    */
    public static final int DELETED_ON_UTC_IDX = 15 ;

    /**
              * <p> The comments in the RCM side.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTERNAL_RCM_COMMENTS= "INTERNAL_RCM_COMMENTS" ;

    /*
    * The index position of the column INTERNAL_RCM_COMMENTS in the table.
    */
    public static final int INTERNAL_RCM_COMMENTS_IDX = 16 ;

    /**
              * <p> The number of EOBs in the file.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NO_OF_EOBS_IN_FILE= "NO_OF_EOBS_IN_FILE" ;

    /*
    * The index position of the column NO_OF_EOBS_IN_FILE in the table.
    */
    public static final int NO_OF_EOBS_IN_FILE_IDX = 17 ;

    /**
              * <p> The id of the RCM member who last edited this file.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_MEM_ID_IN_RCM= "LAST_EDITED_MEM_ID_IN_RCM" ;

    /*
    * The index position of the column LAST_EDITED_MEM_ID_IN_RCM in the table.
    */
    public static final int LAST_EDITED_MEM_ID_IN_RCM_IDX = 18 ;

    /**
              * <p> The name of the RCM member who last edited this file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>103</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_MEM_NAME_IN_RCM= "LAST_EDITED_MEM_NAME_IN_RCM" ;

    /*
    * The index position of the column LAST_EDITED_MEM_NAME_IN_RCM in the table.
    */
    public static final int LAST_EDITED_MEM_NAME_IN_RCM_IDX = 19 ;

    /**
              * <p> The time in UTC when edited in RCM side.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_ON_UTC_IN_RCM= "LAST_EDITED_ON_UTC_IN_RCM" ;

    /*
    * The index position of the column LAST_EDITED_ON_UTC_IN_RCM in the table.
    */
    public static final int LAST_EDITED_ON_UTC_IN_RCM_IDX = 20 ;

    /**
              * <p> PracticeId of MBP to which the Files are shared.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 21 ;

}
