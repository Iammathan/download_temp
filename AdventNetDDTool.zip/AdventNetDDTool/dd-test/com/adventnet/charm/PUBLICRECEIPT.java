package com.adventnet.charm;

/** <p> Description of the table <code>PublicReceipt</code>.
 *  Column Name and Table Name of  database table  <code>PublicReceipt</code> is mapped
 * as constants in this util.</p> 
   Public receipt  . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PUBLIC_RECEIPT_ID}
  * </ul>
 */
 
public final class PUBLICRECEIPT
{
    private PUBLICRECEIPT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PublicReceipt" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PUBLIC_RECEIPT_ID= "PUBLIC_RECEIPT_ID" ;

    /*
    * The index position of the column PUBLIC_RECEIPT_ID in the table.
    */
    public static final int PUBLIC_RECEIPT_ID_IDX = 1 ;

    /**
              * <p>  Practice identification .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Identifier of Receipt.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 3 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
              * <p>  Amount .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String AMOUNT= "AMOUNT" ;

    /*
    * The index position of the column AMOUNT in the table.
    */
    public static final int AMOUNT_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 6 ;

    /**
              * <p> Email Id of patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 7 ;

    /**
              * <p> Mobile number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MOBILE= "MOBILE" ;

    /*
    * The index position of the column MOBILE in the table.
    */
    public static final int MOBILE_IDX = 8 ;

    /**
              * <p> DFS file path.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_PATH= "FILE_PATH" ;

    /*
    * The index position of the column FILE_PATH in the table.
    */
    public static final int FILE_PATH_IDX = 9 ;

}
