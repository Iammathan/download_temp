package com.adventnet.charm;

/** <p> Description of the table <code>AltCmn</code>.
 *  Column Name and Table Name of  database table  <code>AltCmn</code> is mapped
 * as constants in this util.</p> 
  Weekly downloaded list from surescripts for alternatives. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ALTERNATIVES_COMMON_ID}
  * </ul>
 */
 
public final class ALTCMN
{
    private ALTCMN()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AltCmn" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ALTERNATIVES_COMMON_ID= "ALTERNATIVES_COMMON_ID" ;

    /*
    * The index position of the column ALTERNATIVES_COMMON_ID in the table.
    */
    public static final int ALTERNATIVES_COMMON_ID_IDX = 1 ;

    /**
              * <p> PBM unique ID for surescripts.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PBM_PARTICIPANT_ID= "PBM_PARTICIPANT_ID" ;

    /*
    * The index position of the column PBM_PARTICIPANT_ID in the table.
    */
    public static final int PBM_PARTICIPANT_ID_IDX = 2 ;

    /**
              * <p> Formulary ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALTERNATIVE_ID= "ALTERNATIVE_ID" ;

    /*
    * The index position of the column ALTERNATIVE_ID in the table.
    */
    public static final int ALTERNATIVE_ID_IDX = 3 ;

    /**
              * <p> Date the list goes into effect.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EFFECTIVE_DATE= "EFFECTIVE_DATE" ;

    /*
    * The index position of the column EFFECTIVE_DATE in the table.
    */
    public static final int EFFECTIVE_DATE_IDX = 4 ;

    /**
              * <p> only Add is supported now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHANGE_IDENTIFIER= "CHANGE_IDENTIFIER" ;

    /*
    * The index position of the column CHANGE_IDENTIFIER in the table.
    */
    public static final int CHANGE_IDENTIFIER_IDX = 5 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_ID= "DRUG_ID" ;

    /*
    * The index position of the column DRUG_ID in the table.
    */
    public static final int DRUG_ID_IDX = 6 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_ID_QUALIFIER= "DRUG_ID_QUALIFIER" ;

    /*
    * The index position of the column DRUG_ID_QUALIFIER in the table.
    */
    public static final int DRUG_ID_QUALIFIER_IDX = 7 ;

    /**
              * <p> Identifier for the drug from proprietary code sources.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DRUG_REFERENCE_NUMBER= "DRUG_REFERENCE_NUMBER" ;

    /*
    * The index position of the column DRUG_REFERENCE_NUMBER in the table.
    */
    public static final int DRUG_REFERENCE_NUMBER_IDX = 8 ;

    /**
              * <p> Type of drug reference number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DRUG_REFERENCE_QUALIFIER= "DRUG_REFERENCE_QUALIFIER" ;

    /*
    * The index position of the column DRUG_REFERENCE_QUALIFIER in the table.
    */
    public static final int DRUG_REFERENCE_QUALIFIER_IDX = 9 ;

    /**
              * <p> Rxnorm code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_CODE= "RXNORM_CODE" ;

    /*
    * The index position of the column RXNORM_CODE in the table.
    */
    public static final int RXNORM_CODE_IDX = 10 ;

    /**
              * <p> Rxnorm qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_QUALIFIER= "RXNORM_QUALIFIER" ;

    /*
    * The index position of the column RXNORM_QUALIFIER in the table.
    */
    public static final int RXNORM_QUALIFIER_IDX = 11 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALTERNATIVE_DRUG_ID= "ALTERNATIVE_DRUG_ID" ;

    /*
    * The index position of the column ALTERNATIVE_DRUG_ID in the table.
    */
    public static final int ALTERNATIVE_DRUG_ID_IDX = 12 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALTERNATIVE_DRUG_ID_QUALIFIER= "ALTERNATIVE_DRUG_ID_QUALIFIER" ;

    /*
    * The index position of the column ALTERNATIVE_DRUG_ID_QUALIFIER in the table.
    */
    public static final int ALTERNATIVE_DRUG_ID_QUALIFIER_IDX = 13 ;

    /**
              * <p> Identifier for the drug from proprietary code sources.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALT_DRUG_REFERENCE_NUMBER= "ALT_DRUG_REFERENCE_NUMBER" ;

    /*
    * The index position of the column ALT_DRUG_REFERENCE_NUMBER in the table.
    */
    public static final int ALT_DRUG_REFERENCE_NUMBER_IDX = 14 ;

    /**
              * <p> Type of drug reference number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALT_DRUG_REFERENCE_QUALIFIER= "ALT_DRUG_REFERENCE_QUALIFIER" ;

    /*
    * The index position of the column ALT_DRUG_REFERENCE_QUALIFIER in the table.
    */
    public static final int ALT_DRUG_REFERENCE_QUALIFIER_IDX = 15 ;

    /**
              * <p> Rxnorm code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALTERNATIVE_RXNORM_CODE= "ALTERNATIVE_RXNORM_CODE" ;

    /*
    * The index position of the column ALTERNATIVE_RXNORM_CODE in the table.
    */
    public static final int ALTERNATIVE_RXNORM_CODE_IDX = 16 ;

    /**
              * <p> Rxnorm qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALTERNATIVE_RXNORM_QUALIFIER= "ALTERNATIVE_RXNORM_QUALIFIER" ;

    /*
    * The index position of the column ALTERNATIVE_RXNORM_QUALIFIER in the table.
    */
    public static final int ALTERNATIVE_RXNORM_QUALIFIER_IDX = 17 ;

    /**
              * <p> Preference level of the alternate drug.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PREFERENCE_LEVEL= "PREFERENCE_LEVEL" ;

    /*
    * The index position of the column PREFERENCE_LEVEL in the table.
    */
    public static final int PREFERENCE_LEVEL_IDX = 18 ;

}
