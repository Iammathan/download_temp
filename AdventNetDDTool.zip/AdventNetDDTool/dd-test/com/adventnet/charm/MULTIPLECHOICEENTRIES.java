package com.adventnet.charm;

/** <p> Description of the table <code>MultipleChoiceEntries</code>.
 *  Column Name and Table Name of  database table  <code>MultipleChoiceEntries</code> is mapped
 * as constants in this util.</p> 
  Questionnaire Entries in which the answer is with Multiple choice is stored. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MULTIPLE_ENTRY_ID}
  * </ul>
 */
 
public final class MULTIPLECHOICEENTRIES
{
    private MULTIPLECHOICEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MultipleChoiceEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MULTIPLE_ENTRY_ID= "MULTIPLE_ENTRY_ID" ;

    /*
    * The index position of the column MULTIPLE_ENTRY_ID in the table.
    */
    public static final int MULTIPLE_ENTRY_ID_IDX = 1 ;

    /**
              * <p> One of the Multiple Choice Answer for Intake questionnaire.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ANSWER= "ANSWER" ;

    /*
    * The index position of the column ANSWER in the table.
    */
    public static final int ANSWER_IDX = 2 ;

    /**
              * <p> Id of the Multiple Answers to a Question and an Appointment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QUESTIONNAIRE_ENTRY_ID= "QUESTIONNAIRE_ENTRY_ID" ;

    /*
    * The index position of the column QUESTIONNAIRE_ENTRY_ID in the table.
    */
    public static final int QUESTIONNAIRE_ENTRY_ID_IDX = 3 ;

}
