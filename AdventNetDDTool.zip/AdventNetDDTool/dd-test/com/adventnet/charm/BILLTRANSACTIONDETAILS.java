package com.adventnet.charm;

/** <p> Description of the table <code>BillTransactionDetails</code>.
 *  Column Name and Table Name of  database table  <code>BillTransactionDetails</code> is mapped
 * as constants in this util.</p> 
  Table to store mapping between bill and its respective transaction (transaction = Payment/write-off/adjustment/pt.responsibilty or all). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_TXN_ID}
  * </ul>
 */
 
public final class BILLTRANSACTIONDETAILS
{
    private BILLTRANSACTIONDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillTransactionDetails" ;
    /**
              * <p> Unique identifier for item payment.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_TXN_ID= "BILL_TXN_ID" ;

    /*
    * The index position of the column BILL_TXN_ID in the table.
    */
    public static final int BILL_TXN_ID_IDX = 1 ;

    /**
              * <p> Pk of BillDeails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 2 ;

    /**
              * <p> Bill Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSACTION_DATE= "TRANSACTION_DATE" ;

    /*
    * The index position of the column TRANSACTION_DATE in the table.
    */
    public static final int TRANSACTION_DATE_IDX = 3 ;

    /**
              * <p> Added time of invoice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSACTION_ADDED_DATE= "TRANSACTION_ADDED_DATE" ;

    /*
    * The index position of the column TRANSACTION_ADDED_DATE in the table.
    */
    public static final int TRANSACTION_ADDED_DATE_IDX = 4 ;

    /**
              * <p> Latest updated time of invoice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSACTION_UPDATED_TIME= "TRANSACTION_UPDATED_TIME" ;

    /*
    * The index position of the column TRANSACTION_UPDATED_TIME in the table.
    */
    public static final int TRANSACTION_UPDATED_TIME_IDX = 5 ;

    /**
              * <p> Column used while editing the receipt - to know write-off/adjustment/pr added along with this receipt.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 6 ;

    /**
              * <p> This column specifies whether the transaction is hard-closed or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>FALSE</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_HARD_CLOSED= "IS_HARD_CLOSED" ;

    /*
    * The index position of the column IS_HARD_CLOSED in the table.
    */
    public static final int IS_HARD_CLOSED_IDX = 7 ;

    /**
              * <p> Comments entered for each line item.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 8 ;

    /**
              * <p> External id of the Bill Transaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXTERNAL_ID= "EXTERNAL_ID" ;

    /*
    * The index position of the column EXTERNAL_ID in the table.
    */
    public static final int EXTERNAL_ID_IDX = 9 ;

}
