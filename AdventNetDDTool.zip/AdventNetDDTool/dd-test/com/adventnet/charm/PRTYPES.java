package com.adventnet.charm;

/** <p> Description of the table <code>PRTypes</code>.
 *  Column Name and Table Name of  database table  <code>PRTypes</code> is mapped
 * as constants in this util.</p> 
  Table to add user defined PR types. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PR_TYPE_ID}
  * </ul>
 */
 
public final class PRTYPES
{
    private PRTYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PRTypes" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PR_TYPE_ID= "PR_TYPE_ID" ;

    /*
    * The index position of the column PR_TYPE_ID in the table.
    */
    public static final int PR_TYPE_ID_IDX = 1 ;

    /**
              * <p> PR type name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PR_TYPE_NAME= "PR_TYPE_NAME" ;

    /*
    * The index position of the column PR_TYPE_NAME in the table.
    */
    public static final int PR_TYPE_NAME_IDX = 2 ;

    /**
              * <p> Whether pr type is system generated or user added one.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_SYSTEM_GENERATED= "IS_SYSTEM_GENERATED" ;

    /*
    * The index position of the column IS_SYSTEM_GENERATED in the table.
    */
    public static final int IS_SYSTEM_GENERATED_IDX = 3 ;

    /**
              * <p> Whether the pr type is set as default.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DEFAULT= "IS_DEFAULT" ;

    /*
    * The index position of the column IS_DEFAULT in the table.
    */
    public static final int IS_DEFAULT_IDX = 4 ;

}
