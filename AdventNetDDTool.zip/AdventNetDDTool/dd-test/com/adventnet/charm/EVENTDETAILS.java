package com.adventnet.charm;

/** <p> Description of the table <code>EventDetails</code>.
 *  Column Name and Table Name of  database table  <code>EventDetails</code> is mapped
 * as constants in this util.</p> 
  Details of every event is maintained in this patient space table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EVENT_TYPE_ID}
  * </ul>
 */
 
public final class EVENTDETAILS
{
    private EVENTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EventDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EVENT_TYPE_ID= "EVENT_TYPE_ID" ;

    /*
    * The index position of the column EVENT_TYPE_ID in the table.
    */
    public static final int EVENT_TYPE_ID_IDX = 1 ;

    /**
              * <p> Type of the Event.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EVENT_TYPE= "EVENT_TYPE" ;

    /*
    * The index position of the column EVENT_TYPE in the table.
    */
    public static final int EVENT_TYPE_IDX = 2 ;

    /**
              * <p> Color code for the events in Personal Calendar.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EVENT_COLOR_CODE= "EVENT_COLOR_CODE" ;

    /*
    * The index position of the column EVENT_COLOR_CODE in the table.
    */
    public static final int EVENT_COLOR_CODE_IDX = 3 ;

}
