package com.adventnet.charm;

/** <p> Description of the table <code>CommandLangPatterns</code>.
 *  Column Name and Table Name of  database table  <code>CommandLangPatterns</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CMMND_LANG_PAT_ID}
  * </ul>
 */
 
public final class COMMANDLANGPATTERNS
{
    private COMMANDLANGPATTERNS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CommandLangPatterns" ;
    /**
              * <p> Pk of CommandLangPatterns.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CMMND_LANG_PAT_ID= "CMMND_LANG_PAT_ID" ;

    /*
    * The index position of the column CMMND_LANG_PAT_ID in the table.
    */
    public static final int CMMND_LANG_PAT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMAND_PATTERN= "COMMAND_PATTERN" ;

    /*
    * The index position of the column COMMAND_PATTERN in the table.
    */
    public static final int COMMAND_PATTERN_IDX = 2 ;

}
