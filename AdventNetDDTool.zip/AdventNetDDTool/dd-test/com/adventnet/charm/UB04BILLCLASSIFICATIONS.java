package com.adventnet.charm;

/** <p> Description of the table <code>UB04BillClassifications</code>.
 *  Column Name and Table Name of  database table  <code>UB04BillClassifications</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_BILL_CLASS_ID}
  * </ul>
 */
 
public final class UB04BILLCLASSIFICATIONS
{
    private UB04BILLCLASSIFICATIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04BillClassifications" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_BILL_CLASS_ID= "UB04_BILL_CLASS_ID" ;

    /*
    * The index position of the column UB04_BILL_CLASS_ID in the table.
    */
    public static final int UB04_BILL_CLASS_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BILL_CLASS_CODE= "BILL_CLASS_CODE" ;

    /*
    * The index position of the column BILL_CLASS_CODE in the table.
    */
    public static final int BILL_CLASS_CODE_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BILL_CLASS_DESC= "BILL_CLASS_DESC" ;

    /*
    * The index position of the column BILL_CLASS_DESC in the table.
    */
    public static final int BILL_CLASS_DESC_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>18</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BILL_CLASS_TYPE= "BILL_CLASS_TYPE" ;

    /*
    * The index position of the column BILL_CLASS_TYPE in the table.
    */
    public static final int BILL_CLASS_TYPE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 7 ;

}
