package com.adventnet.charm;

/** <p> Description of the table <code>AppointmentRequest</code>.
 *  Column Name and Table Name of  database table  <code>AppointmentRequest</code> is mapped
 * as constants in this util.</p> 
  All new appointment request(s) made by patient(s) will managed in this table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REQUEST_ID}
  * </ul>
 */
 
public final class APPOINTMENTREQUEST
{
    private APPOINTMENTREQUEST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AppointmentRequest" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUEST_ID= "REQUEST_ID" ;

    /*
    * The index position of the column REQUEST_ID in the table.
    */
    public static final int REQUEST_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Idendifier of the physician.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PHYSICIAN_ID= "PHYSICIAN_ID" ;

    /*
    * The index position of the column PHYSICIAN_ID in the table.
    */
    public static final int PHYSICIAN_ID_IDX = 3 ;

    /**
              * <p>  Reason for this appointment - given by patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REASON= "REASON" ;

    /*
    * The index position of the column REASON in the table.
    */
    public static final int REASON_IDX = 4 ;

    /**
              * <p> Appointment Type selected by patient(ex : phone call / In person).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_TYPE= "APPOINTMENT_TYPE" ;

    /*
    * The index position of the column APPOINTMENT_TYPE in the table.
    */
    public static final int APPOINTMENT_TYPE_IDX = 5 ;

    /**
              * <p> Status of the appointment(Requested/Denied/Waitlisted/Deleted by Physician).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_STATUS= "APPOINTMENT_STATUS" ;

    /*
    * The index position of the column APPOINTMENT_STATUS in the table.
    */
    public static final int APPOINTMENT_STATUS_IDX = 6 ;

    /**
              * <p> Identifier of Timezone to which the patient belongs to.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>GMT</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>GMT</code>" , 
       * will be taken.<br>
                         */
    public static final String TIMEZONE= "TIMEZONE" ;

    /*
    * The index position of the column TIMEZONE in the table.
    */
    public static final int TIMEZONE_IDX = 7 ;

    /**
              * <p> Physician remarks for this appointment will be stored here.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHYSICIAN_REMARK= "PHYSICIAN_REMARK" ;

    /*
    * The index position of the column PHYSICIAN_REMARK in the table.
    */
    public static final int PHYSICIAN_REMARK_IDX = 8 ;

    /**
              * <p> reminder will be sent by a mail or popup.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REMINDER_TYPE= "REMINDER_TYPE" ;

    /*
    * The index position of the column REMINDER_TYPE in the table.
    */
    public static final int REMINDER_TYPE_IDX = 9 ;

    /**
              * <p> Date preference for appointment can be any of the following(any date / date range / specific date(s)).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                     * Default Value is <code>ANY_DATE</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>ANY_DATE</code>" , 
       * will be taken.<br>
                         */
    public static final String DATE_PREFERENCE= "DATE_PREFERENCE" ;

    /*
    * The index position of the column DATE_PREFERENCE in the table.
    */
    public static final int DATE_PREFERENCE_IDX = 10 ;

    /**
              * <p> appointment choice date selected by Patient .</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_CHOICE1= "DATE_CHOICE1" ;

    /*
    * The index position of the column DATE_CHOICE1 in the table.
    */
    public static final int DATE_CHOICE1_IDX = 11 ;

    /**
              * <p> appointment choice date selected by Patient.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_CHOICE2= "DATE_CHOICE2" ;

    /*
    * The index position of the column DATE_CHOICE2 in the table.
    */
    public static final int DATE_CHOICE2_IDX = 12 ;

    /**
              * <p> appointment choice date selected by Patient.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_CHOICE3= "DATE_CHOICE3" ;

    /*
    * The index position of the column DATE_CHOICE3 in the table.
    */
    public static final int DATE_CHOICE3_IDX = 13 ;

    /**
              * <p> Time preferred by the patient. It can be either Any Time (or) a time period.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                     * Default Value is <code>ANY_TIME</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>ANY_TIME</code>" , 
       * will be taken.<br>
                         */
    public static final String TIME_PREFERENCE= "TIME_PREFERENCE" ;

    /*
    * The index position of the column TIME_PREFERENCE in the table.
    */
    public static final int TIME_PREFERENCE_IDX = 14 ;

    /**
              * <p> time prefered by the patient - starting hour.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String START_HOUR= "START_HOUR" ;

    /*
    * The index position of the column START_HOUR in the table.
    */
    public static final int START_HOUR_IDX = 15 ;

    /**
              * <p> starting minutes.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String START_MINUTES= "START_MINUTES" ;

    /*
    * The index position of the column START_MINUTES in the table.
    */
    public static final int START_MINUTES_IDX = 16 ;

    /**
              * <p> Session AM or PM.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String START_SESSION= "START_SESSION" ;

    /*
    * The index position of the column START_SESSION in the table.
    */
    public static final int START_SESSION_IDX = 17 ;

    /**
              * <p> time prefered by the patient - ending hour.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String END_HOUR= "END_HOUR" ;

    /*
    * The index position of the column END_HOUR in the table.
    */
    public static final int END_HOUR_IDX = 18 ;

    /**
              * <p> ending minutes.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String END_MINUTES= "END_MINUTES" ;

    /*
    * The index position of the column END_MINUTES in the table.
    */
    public static final int END_MINUTES_IDX = 19 ;

    /**
              * <p> Session AM or PM.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String END_SESSION= "END_SESSION" ;

    /*
    * The index position of the column END_SESSION in the table.
    */
    public static final int END_SESSION_IDX = 20 ;

    /**
              * <p> start time of the request in UTC/GMT.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String START_TIME_UTC= "START_TIME_UTC" ;

    /*
    * The index position of the column START_TIME_UTC in the table.
    */
    public static final int START_TIME_UTC_IDX = 21 ;

    /**
              * <p> end time of the request in UTC/GMT.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String END_TIME_UTC= "END_TIME_UTC" ;

    /*
    * The index position of the column END_TIME_UTC in the table.
    */
    public static final int END_TIME_UTC_IDX = 22 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 23 ;

    /**
              * <p> To identify it is website request or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ONLINEAPP_REQUEST= "IS_ONLINEAPP_REQUEST" ;

    /*
    * The index position of the column IS_ONLINEAPP_REQUEST in the table.
    */
    public static final int IS_ONLINEAPP_REQUEST_IDX = 24 ;

    /**
              * <p> Identifier of visit type.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 25 ;

    /**
              * <p> Mapping from Departments table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DEPARTMENT_ID= "DEPARTMENT_ID" ;

    /*
    * The index position of the column DEPARTMENT_ID in the table.
    */
    public static final int DEPARTMENT_ID_IDX = 26 ;

    /**
              * <p> Unique Identifier of Receipt.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 27 ;

    /**
              * <p> To Display Receipt Number in UI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECEIPT_DISPLAY_ID= "RECEIPT_DISPLAY_ID" ;

    /*
    * The index position of the column RECEIPT_DISPLAY_ID in the table.
    */
    public static final int RECEIPT_DISPLAY_ID_IDX = 28 ;

    /**
              * <p> Amount Paid.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_AMOUNT= "RECEIPT_AMOUNT" ;

    /*
    * The index position of the column RECEIPT_AMOUNT in the table.
    */
    public static final int RECEIPT_AMOUNT_IDX = 29 ;

    /**
              * <p> When was the appointment reqested.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUESTED_TIME= "REQUESTED_TIME" ;

    /*
    * The index position of the column REQUESTED_TIME in the table.
    */
    public static final int REQUESTED_TIME_IDX = 30 ;

    /**
              * <p> When was the appointment request processed and changed to delete/confirmed/waitlisted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROCESSED_TIME= "PROCESSED_TIME" ;

    /*
    * The index position of the column PROCESSED_TIME in the table.
    */
    public static final int PROCESSED_TIME_IDX = 31 ;

    /**
              * <p> Who processed the appointment request to delete/confirmed/waitlisted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROCESSED_BY= "PROCESSED_BY" ;

    /*
    * The index position of the column PROCESSED_BY in the table.
    */
    public static final int PROCESSED_BY_IDX = 32 ;

    /**
              * <p> From where appointment is requested.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SOURCE= "SOURCE" ;

    /*
    * The index position of the column SOURCE in the table.
    */
    public static final int SOURCE_IDX = 33 ;

}
