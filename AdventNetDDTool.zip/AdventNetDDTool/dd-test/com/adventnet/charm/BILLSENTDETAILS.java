package com.adventnet.charm;

/** <p> Description of the table <code>BillSentDetails</code>.
 *  Column Name and Table Name of  database table  <code>BillSentDetails</code> is mapped
 * as constants in this util.</p> 
  Bill sent details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_SENT_DETAILS_ID}
  * </ul>
 */
 
public final class BILLSENTDETAILS
{
    private BILLSENTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillSentDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_SENT_DETAILS_ID= "BILL_SENT_DETAILS_ID" ;

    /*
    * The index position of the column BILL_SENT_DETAILS_ID in the table.
    */
    public static final int BILL_SENT_DETAILS_ID_IDX = 1 ;

    /**
              * <p> Bill id of BillDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 2 ;

    /**
              * <p> Bill sent Time.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_DATE_TIME= "ADDED_DATE_TIME" ;

    /*
    * The index position of the column ADDED_DATE_TIME in the table.
    */
    public static final int ADDED_DATE_TIME_IDX = 3 ;

    /**
              * <p> Member who sent the invoice to patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SENT_BY= "SENT_BY" ;

    /*
    * The index position of the column SENT_BY in the table.
    */
    public static final int SENT_BY_IDX = 4 ;

    /**
              * <p> Patient's Primary and Secondary Email Address.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SENT_TO= "SENT_TO" ;

    /*
    * The index position of the column SENT_TO in the table.
    */
    public static final int SENT_TO_IDX = 5 ;

    /**
              * <p> CC Email Addresses.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>210</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SENT_CC= "SENT_CC" ;

    /*
    * The index position of the column SENT_CC in the table.
    */
    public static final int SENT_CC_IDX = 6 ;

    /**
              * <p> maintains whether Invoice sent to PHR Account or to Paitent's Email.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SENT_TO_PHR_ACCOUNT= "IS_SENT_TO_PHR_ACCOUNT" ;

    /*
    * The index position of the column IS_SENT_TO_PHR_ACCOUNT in the table.
    */
    public static final int IS_SENT_TO_PHR_ACCOUNT_IDX = 7 ;

    /**
              * <p> Is Superbill PDF attached with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SUPERBILL_PDF= "IS_SUPERBILL_PDF" ;

    /*
    * The index position of the column IS_SUPERBILL_PDF in the table.
    */
    public static final int IS_SUPERBILL_PDF_IDX = 8 ;

    /**
              * <p> Is Invoice PDF attached with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_INVOICE_PDF= "IS_INVOICE_PDF" ;

    /*
    * The index position of the column IS_INVOICE_PDF in the table.
    */
    public static final int IS_INVOICE_PDF_IDX = 9 ;

    /**
              * <p> Is Invoice PDF 1 attached with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_INVOICE_PDF1= "IS_INVOICE_PDF1" ;

    /*
    * The index position of the column IS_INVOICE_PDF1 in the table.
    */
    public static final int IS_INVOICE_PDF1_IDX = 10 ;

    /**
              * <p> PDF file name attached to the mails.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PDF_FILE_NAME1= "PDF_FILE_NAME1" ;

    /*
    * The index position of the column PDF_FILE_NAME1 in the table.
    */
    public static final int PDF_FILE_NAME1_IDX = 11 ;

    /**
              * <p> PDF file name attached to the mails.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PDF_FILE_NAME2= "PDF_FILE_NAME2" ;

    /*
    * The index position of the column PDF_FILE_NAME2 in the table.
    */
    public static final int PDF_FILE_NAME2_IDX = 12 ;

    /**
              * <p> Is Ohter Attachments there with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_OTHER_ATTACHMENTS= "IS_OTHER_ATTACHMENTS" ;

    /*
    * The index position of the column IS_OTHER_ATTACHMENTS in the table.
    */
    public static final int IS_OTHER_ATTACHMENTS_IDX = 13 ;

    /**
              * <p> Shows whether the invoice is sent from RCM or via any other ways.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SENT_FROM= "SENT_FROM" ;

    /*
    * The index position of the column SENT_FROM in the table.
    */
    public static final int SENT_FROM_IDX = 14 ;

    /**
              * <p> Shows whether the invoice is sent Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>Email</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SENT_MODE= "SENT_MODE" ;

    /*
    * The index position of the column SENT_MODE in the table.
    */
    public static final int SENT_MODE_IDX = 15 ;

    /**
              * <p> Date on which this data is sent to patient.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SENT_DATE_TIME= "SENT_DATE_TIME" ;

    /*
    * The index position of the column SENT_DATE_TIME in the table.
    */
    public static final int SENT_DATE_TIME_IDX = 16 ;

    /**
              * <p> check is Deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 17 ;

    /**
              * <p> RCM invoice Date.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_INVOICE_DATE= "RCM_INVOICE_DATE" ;

    /*
    * The index position of the column RCM_INVOICE_DATE in the table.
    */
    public static final int RCM_INVOICE_DATE_IDX = 18 ;

    /**
              * <p> ID of Messages.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 19 ;

    /**
              * <p> Template type in which invoice is sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEMPLATE_TYPE= "TEMPLATE_TYPE" ;

    /*
    * The index position of the column TEMPLATE_TYPE in the table.
    */
    public static final int TEMPLATE_TYPE_IDX = 20 ;

    /**
              * <p> Template ID foreign key without foreign key relation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 21 ;

    /**
              * <p> Member ID foreign key without foreign key relation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 22 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATEMENT_ID= "STATEMENT_ID" ;

    /*
    * The index position of the column STATEMENT_ID in the table.
    */
    public static final int STATEMENT_ID_IDX = 23 ;

    /**
              * <p> Patient's and Guarantor's Mobile Number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MOBILE_NO= "MOBILE_NO" ;

    /*
    * The index position of the column MOBILE_NO in the table.
    */
    public static final int MOBILE_NO_IDX = 24 ;

}
