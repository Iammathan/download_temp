package com.adventnet.charm;

/** <p> Description of the table <code>LabOrderTestSpecLabelsVsGroups</code>.
 *  Column Name and Table Name of  database table  <code>LabOrderTestSpecLabelsVsGroups</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_ORD_SPEC_LAB_VS_GRP_ID}
  * </ul>
 */
 
public final class LABORDERTESTSPECLABELSVSGROUPS
{
    private LABORDERTESTSPECLABELSVSGROUPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabOrderTestSpecLabelsVsGroups" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_ORD_SPEC_LAB_VS_GRP_ID= "LAB_ORD_SPEC_LAB_VS_GRP_ID" ;

    /*
    * The index position of the column LAB_ORD_SPEC_LAB_VS_GRP_ID in the table.
    */
    public static final int LAB_ORD_SPEC_LAB_VS_GRP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ORDER_TEST_GROUP_ID= "ORDER_TEST_GROUP_ID" ;

    /*
    * The index position of the column ORDER_TEST_GROUP_ID in the table.
    */
    public static final int ORDER_TEST_GROUP_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SEQUENCE_NUMBER= "SEQUENCE_NUMBER" ;

    /*
    * The index position of the column SEQUENCE_NUMBER in the table.
    */
    public static final int SEQUENCE_NUMBER_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CONDITION_NAME= "CONDITION_NAME" ;

    /*
    * The index position of the column CONDITION_NAME in the table.
    */
    public static final int CONDITION_NAME_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String BARCODE_STRING= "BARCODE_STRING" ;

    /*
    * The index position of the column BARCODE_STRING in the table.
    */
    public static final int BARCODE_STRING_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DISPLAY_STRING= "DISPLAY_STRING" ;

    /*
    * The index position of the column DISPLAY_STRING in the table.
    */
    public static final int DISPLAY_STRING_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_PRINTED= "IS_PRINTED" ;

    /*
    * The index position of the column IS_PRINTED in the table.
    */
    public static final int IS_PRINTED_IDX = 8 ;

}
