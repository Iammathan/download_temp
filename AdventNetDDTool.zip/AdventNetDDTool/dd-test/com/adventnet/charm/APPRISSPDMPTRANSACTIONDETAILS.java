package com.adventnet.charm;

/** <p> Description of the table <code>ApprissPDMPTransactionDetails</code>.
 *  Column Name and Table Name of  database table  <code>ApprissPDMPTransactionDetails</code> is mapped
 * as constants in this util.</p> 
  Share To PHR Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TRANSACTION_PRIMARY_KEY}
  * </ul>
 */
 
public final class APPRISSPDMPTRANSACTIONDETAILS
{
    private APPRISSPDMPTRANSACTIONDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ApprissPDMPTransactionDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_PRIMARY_KEY= "TRANSACTION_PRIMARY_KEY" ;

    /*
    * The index position of the column TRANSACTION_PRIMARY_KEY in the table.
    */
    public static final int TRANSACTION_PRIMARY_KEY_IDX = 1 ;

    /**
              * <p> Added by.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_STATUS= "TRANSACTION_STATUS" ;

    /*
    * The index position of the column TRANSACTION_STATUS in the table.
    */
    public static final int TRANSACTION_STATUS_IDX = 2 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> disallowed or error.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_TYPE= "ERROR_TYPE" ;

    /*
    * The index position of the column ERROR_TYPE in the table.
    */
    public static final int ERROR_TYPE_IDX = 4 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUEST_ID= "REQUEST_ID" ;

    /*
    * The index position of the column REQUEST_ID in the table.
    */
    public static final int REQUEST_ID_IDX = 5 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_REQUEST_ID= "REPORT_REQUEST_ID" ;

    /*
    * The index position of the column REPORT_REQUEST_ID in the table.
    */
    public static final int REPORT_REQUEST_ID_IDX = 6 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LICENSEE_REQUEST_ID= "LICENSEE_REQUEST_ID" ;

    /*
    * The index position of the column LICENSEE_REQUEST_ID in the table.
    */
    public static final int LICENSEE_REQUEST_ID_IDX = 7 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 8 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 9 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REQUEST_DESTINATIONS= "REQUEST_DESTINATIONS" ;

    /*
    * The index position of the column REQUEST_DESTINATIONS in the table.
    */
    public static final int REQUEST_DESTINATIONS_IDX = 10 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_BEGIN_DATE= "REPORT_BEGIN_DATE" ;

    /*
    * The index position of the column REPORT_BEGIN_DATE in the table.
    */
    public static final int REPORT_BEGIN_DATE_IDX = 11 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_END_DATE= "REPORT_END_DATE" ;

    /*
    * The index position of the column REPORT_END_DATE in the table.
    */
    public static final int REPORT_END_DATE_IDX = 12 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REQUESTER_ROLE= "REQUESTER_ROLE" ;

    /*
    * The index position of the column REQUESTER_ROLE in the table.
    */
    public static final int REQUESTER_ROLE_IDX = 13 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_MESSAGE= "ERROR_MESSAGE" ;

    /*
    * The index position of the column ERROR_MESSAGE in the table.
    */
    public static final int ERROR_MESSAGE_IDX = 14 ;

    /**
              * <p> patient_id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_DETAILS= "ERROR_DETAILS" ;

    /*
    * The index position of the column ERROR_DETAILS in the table.
    */
    public static final int ERROR_DETAILS_IDX = 15 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_DATE= "TRANSACTION_DATE" ;

    /*
    * The index position of the column TRANSACTION_DATE in the table.
    */
    public static final int TRANSACTION_DATE_IDX = 16 ;

}
