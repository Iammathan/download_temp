package com.adventnet.charm;

/** <p> Description of the table <code>ClaimOtherPayerPaymentDetail</code>.
 *  Column Name and Table Name of  database table  <code>ClaimOtherPayerPaymentDetail</code> is mapped
 * as constants in this util.</p> 
  This table stores the payment made by other payers after adjudication for this (secondary) claim. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLM_OTHER_PAYER_PAYMENT_ID}
  * </ul>
 */
 
public final class CLAIMOTHERPAYERPAYMENTDETAIL
{
    private CLAIMOTHERPAYERPAYMENTDETAIL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ClaimOtherPayerPaymentDetail" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLM_OTHER_PAYER_PAYMENT_ID= "CLM_OTHER_PAYER_PAYMENT_ID" ;

    /*
    * The index position of the column CLM_OTHER_PAYER_PAYMENT_ID in the table.
    */
    public static final int CLM_OTHER_PAYER_PAYMENT_ID_IDX = 1 ;

    /**
              * <p> Claim ID of the secondary claim for which these adjudication details are going to be submitted(SAS Key of either ClaimCompleteDetails or RCMClaimCompleteDetails table).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> Claim ID of the actual processed/adjudicated claim which is the parent/primary claim of this secondary claim(SAS Key of either ClaimCompleteDetails or RCMClaimCompleteDetails table).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADJUDICATED_CLAIM_ID= "ADJUDICATED_CLAIM_ID" ;

    /*
    * The index position of the column ADJUDICATED_CLAIM_ID in the table.
    */
    public static final int ADJUDICATED_CLAIM_ID_IDX = 3 ;

    /**
              * <p> SAS Key of ClaimInsuranceDetails/RCMClaimInsuranceDetails where the respective insurance information is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTHER_INSURANCE_ID= "OTHER_INSURANCE_ID" ;

    /*
    * The index position of the column OTHER_INSURANCE_ID in the table.
    */
    public static final int OTHER_INSURANCE_ID_IDX = 4 ;

    /**
              * <p> Prior Authorization number provided by the respective insurance.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>29</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRIOR_AUTH_NUMBER= "PRIOR_AUTH_NUMBER" ;

    /*
    * The index position of the column PRIOR_AUTH_NUMBER in the table.
    */
    public static final int PRIOR_AUTH_NUMBER_IDX = 5 ;

    /**
              * <p> Referral number provided by this insurance if any.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERRAL_NUMBER= "REFERRAL_NUMBER" ;

    /*
    * The index position of the column REFERRAL_NUMBER in the table.
    */
    public static final int REFERRAL_NUMBER_IDX = 6 ;

    /**
              * <p> Claim Adjustment Indicator.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>Y</code></li>
              * </ul>
                         */
    public static final String CLAIM_ADJUSTMENT_INDICATOR= "CLAIM_ADJUSTMENT_INDICATOR" ;

    /*
    * The index position of the column CLAIM_ADJUSTMENT_INDICATOR in the table.
    */
    public static final int CLAIM_ADJUSTMENT_INDICATOR_IDX = 7 ;

    /**
              * <p> Payer Claim Control Number - a unique number in the payers adjudication system for this claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_CLAIM_CONTROL_NUMBER= "PAYER_CLAIM_CONTROL_NUMBER" ;

    /*
    * The index position of the column PAYER_CLAIM_CONTROL_NUMBER in the table.
    */
    public static final int PAYER_CLAIM_CONTROL_NUMBER_IDX = 8 ;

    /**
              * <p> Non-zero reimbursement rate for out-patient institutional claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REIMBURSEMENT_RATE= "REIMBURSEMENT_RATE" ;

    /*
    * The index position of the column REIMBURSEMENT_RATE in the table.
    */
    public static final int REIMBURSEMENT_RATE_IDX = 9 ;

    /**
              * <p> Non-zero HCPCS Payable Amount for out-patient institutional claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HCPCS_PAYABLE_AMOUNT= "HCPCS_PAYABLE_AMOUNT" ;

    /*
    * The index position of the column HCPCS_PAYABLE_AMOUNT in the table.
    */
    public static final int HCPCS_PAYABLE_AMOUNT_IDX = 10 ;

    /**
              * <p> Available when out-patient institutional claim ESRD Payment amount is non-zero for Medicare or Medicaid Claims.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESRD_PAYMENT_AMOUNT= "ESRD_PAYMENT_AMOUNT" ;

    /*
    * The index position of the column ESRD_PAYMENT_AMOUNT in the table.
    */
    public static final int ESRD_PAYMENT_AMOUNT_IDX = 11 ;

    /**
              * <p> Available when the outpatient institutional claim Nonpayable Professional Component Amount is not zero for a Medicare or Medicaid claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NON_PAYABLE_PROF_COMP_AMOUNT= "NON_PAYABLE_PROF_COMP_AMOUNT" ;

    /*
    * The index position of the column NON_PAYABLE_PROF_COMP_AMOUNT in the table.
    */
    public static final int NON_PAYABLE_PROF_COMP_AMOUNT_IDX = 12 ;

    /**
              * <p> Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_1= "REMARK_CODE_1" ;

    /*
    * The index position of the column REMARK_CODE_1 in the table.
    */
    public static final int REMARK_CODE_1_IDX = 13 ;

    /**
              * <p> Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_2= "REMARK_CODE_2" ;

    /*
    * The index position of the column REMARK_CODE_2 in the table.
    */
    public static final int REMARK_CODE_2_IDX = 14 ;

    /**
              * <p> Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_3= "REMARK_CODE_3" ;

    /*
    * The index position of the column REMARK_CODE_3 in the table.
    */
    public static final int REMARK_CODE_3_IDX = 15 ;

    /**
              * <p> Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_4= "REMARK_CODE_4" ;

    /*
    * The index position of the column REMARK_CODE_4 in the table.
    */
    public static final int REMARK_CODE_4_IDX = 16 ;

    /**
              * <p> Additional Claim Payment Remark Code applied to entire claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE_5= "REMARK_CODE_5" ;

    /*
    * The index position of the column REMARK_CODE_5 in the table.
    */
    public static final int REMARK_CODE_5_IDX = 17 ;

    /**
              * <p> Total amount paid by this insurance for this claim across all EOBs. Sum of all ClaimOtherPayerEOBDetail.PAYER_PAYMENT .</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYER_PAYMENT= "PAYER_PAYMENT" ;

    /*
    * The index position of the column PAYER_PAYMENT in the table.
    */
    public static final int PAYER_PAYMENT_IDX = 18 ;

    /**
              * <p> Total non-covered amount by this insurance for this claim across all EOBs. Sum of all ClaimOtherPayerEOBDetail.NON_COVERED_AMOUNT. this amount is equals to the submitted total charge of this claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NON_COVERED_AMOUNT= "NON_COVERED_AMOUNT" ;

    /*
    * The index position of the column NON_COVERED_AMOUNT in the table.
    */
    public static final int NON_COVERED_AMOUNT_IDX = 19 ;

    /**
              * <p> Amount for which patient is liable. Sum of all ClaimOtherPayerEOBDetail.PATIENT_LIABILITY.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_LIABILITY= "PATIENT_LIABILITY" ;

    /*
    * The index position of the column PATIENT_LIABILITY in the table.
    */
    public static final int PATIENT_LIABILITY_IDX = 20 ;

}
