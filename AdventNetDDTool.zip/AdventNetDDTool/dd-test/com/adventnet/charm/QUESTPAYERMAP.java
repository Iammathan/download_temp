package com.adventnet.charm;

/** <p> Description of the table <code>QuestPayerMap</code>.
 *  Column Name and Table Name of  database table  <code>QuestPayerMap</code> is mapped
 * as constants in this util.</p> 
  Map Patient Payer Name with Quest Payer Name. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #QUEST_PAYER_MAP_ID}
  * </ul>
 */
 
public final class QUESTPAYERMAP
{
    private QUESTPAYERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QuestPayerMap" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String QUEST_PAYER_MAP_ID= "QUEST_PAYER_MAP_ID" ;

    /*
    * The index position of the column QUEST_PAYER_MAP_ID in the table.
    */
    public static final int QUEST_PAYER_MAP_ID_IDX = 1 ;

    /**
              * <p> Patient Insurance Company Code in Patent Insurance List.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENERIC_PAYER_ID= "GENERIC_PAYER_ID" ;

    /*
    * The index position of the column GENERIC_PAYER_ID in the table.
    */
    public static final int GENERIC_PAYER_ID_IDX = 2 ;

    /**
              * <p> Patient Insurance Company Name in Patent Insurance List.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENERIC_PAYER_NAME= "GENERIC_PAYER_NAME" ;

    /*
    * The index position of the column GENERIC_PAYER_NAME in the table.
    */
    public static final int GENERIC_PAYER_NAME_IDX = 3 ;

    /**
              * <p> Quest Insurance Company Code in Quest Bill Details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUEST_PAYER_CODE= "QUEST_PAYER_CODE" ;

    /*
    * The index position of the column QUEST_PAYER_CODE in the table.
    */
    public static final int QUEST_PAYER_CODE_IDX = 4 ;

    /**
              * <p> Quest Insurance Company Name in Quest Bill Details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUEST_PAYER_NAME= "QUEST_PAYER_NAME" ;

    /*
    * The index position of the column QUEST_PAYER_NAME in the table.
    */
    public static final int QUEST_PAYER_NAME_IDX = 5 ;

}
