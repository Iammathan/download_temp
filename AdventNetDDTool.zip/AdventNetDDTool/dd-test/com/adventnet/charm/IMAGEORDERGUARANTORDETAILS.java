package com.adventnet.charm;

/** <p> Description of the table <code>ImageOrderGuarantorDetails</code>.
 *  Column Name and Table Name of  database table  <code>ImageOrderGuarantorDetails</code> is mapped
 * as constants in this util.</p> 
  Guarantor details on orders.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_ORDER_GUARANTOR_ID}
  * </ul>
 */
 
public final class IMAGEORDERGUARANTORDETAILS
{
    private IMAGEORDERGUARANTORDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageOrderGuarantorDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_ORDER_GUARANTOR_ID= "IMAGE_ORDER_GUARANTOR_ID" ;

    /*
    * The index position of the column IMAGE_ORDER_GUARANTOR_ID in the table.
    */
    public static final int IMAGE_ORDER_GUARANTOR_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_GUARANTOR_ID= "IMAGE_GUARANTOR_ID" ;

    /*
    * The index position of the column IMAGE_GUARANTOR_ID in the table.
    */
    public static final int IMAGE_GUARANTOR_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_E_ORDER_ID= "IMAGE_E_ORDER_ID" ;

    /*
    * The index position of the column IMAGE_E_ORDER_ID in the table.
    */
    public static final int IMAGE_E_ORDER_ID_IDX = 3 ;

}
