package com.adventnet.charm;

/** <p> Description of the table <code>ERANotes</code>.
 *  Column Name and Table Name of  database table  <code>ERANotes</code> is mapped
 * as constants in this util.</p> 
  Contains additional data related to ERADetail table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_NOTES_ID}
  * </ul>
 */
 
public final class ERANOTES
{
    private ERANOTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERANotes" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_NOTES_ID= "ERA_NOTES_ID" ;

    /*
    * The index position of the column ERA_NOTES_ID in the table.
    */
    public static final int ERA_NOTES_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERADetail table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_DETAIL_ID= "ERA_DETAIL_ID" ;

    /*
    * The index position of the column ERA_DETAIL_ID in the table.
    */
    public static final int ERA_DETAIL_ID_IDX = 2 ;

    /**
              * <p> Member's Name who has added the ERA note.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 3 ;

    /**
              * <p> ERA notes created time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 4 ;

    /**
              * <p> ERA Notes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 5 ;

}
