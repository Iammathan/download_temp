package com.adventnet.charm;

/** <p> Description of the table <code>LabTestDepartments</code>.
 *  Column Name and Table Name of  database table  <code>LabTestDepartments</code> is mapped
 * as constants in this util.</p> 
  LabTests. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_TEST_DEPARTMENT_ID}
  * </ul>
 */
 
public final class LABTESTDEPARTMENTS
{
    private LABTESTDEPARTMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabTestDepartments" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_TEST_DEPARTMENT_ID= "LAB_TEST_DEPARTMENT_ID" ;

    /*
    * The index position of the column LAB_TEST_DEPARTMENT_ID in the table.
    */
    public static final int LAB_TEST_DEPARTMENT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DEPARTMENT_NAME= "DEPARTMENT_NAME" ;

    /*
    * The index position of the column DEPARTMENT_NAME in the table.
    */
    public static final int DEPARTMENT_NAME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DEPARTMENT_DESC= "DEPARTMENT_DESC" ;

    /*
    * The index position of the column DEPARTMENT_DESC in the table.
    */
    public static final int DEPARTMENT_DESC_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 4 ;

    /**
              * <p> is deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

}
