package com.adventnet.charm;

/** <p> Description of the table <code>ExecutedCPTMap</code>.
 *  Column Name and Table Name of  database table  <code>ExecutedCPTMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXECUTED_CPT_MAP_ID}
  * </ul>
 */
 
public final class EXECUTEDCPTMAP
{
    private EXECUTEDCPTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ExecutedCPTMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXECUTED_CPT_MAP_ID= "EXECUTED_CPT_MAP_ID" ;

    /*
    * The index position of the column EXECUTED_CPT_MAP_ID in the table.
    */
    public static final int EXECUTED_CPT_MAP_ID_IDX = 1 ;

    /**
              * <p> Consultation cpt map id - PK of ConsultationCPTMap.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_CPT_MAP_ID= "CONSULTATION_CPT_MAP_ID" ;

    /*
    * The index position of the column CONSULTATION_CPT_MAP_ID in the table.
    */
    public static final int CONSULTATION_CPT_MAP_ID_IDX = 2 ;

    /**
              * <p> Identifier of product/item from BillItemDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRODUCT_ITEM_ID= "PRODUCT_ITEM_ID" ;

    /*
    * The index position of the column PRODUCT_ITEM_ID in the table.
    */
    public static final int PRODUCT_ITEM_ID_IDX = 3 ;

    /**
              * <p> Date from which procedure starts .</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 4 ;

    /**
              * <p> Date to which procedure ends.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 5 ;

    /**
              * <p> Units of the procedure.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                     * Default Value is <code>1</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String UNITS= "UNITS" ;

    /*
    * The index position of the column UNITS in the table.
    */
    public static final int UNITS_IDX = 6 ;

    /**
              * <p> Unique qualifiers are UN (Unit) , MJ(Minutes). This is to qualifier the value in the UNITS column.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                     * Default Value is <code>UN</code>. <br>
                            * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>UN</code></li>
              * <li><code>MJ</code></li>
              * </ul>
                         */
    public static final String UNIT_QUALIFIER= "UNIT_QUALIFIER" ;

    /*
    * The index position of the column UNIT_QUALIFIER in the table.
    */
    public static final int UNIT_QUALIFIER_IDX = 7 ;

    /**
              * <p> Place at which procedure is being executed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PLACE_OF_SERVICE= "PLACE_OF_SERVICE" ;

    /*
    * The index position of the column PLACE_OF_SERVICE in the table.
    */
    public static final int PLACE_OF_SERVICE_IDX = 8 ;

    /**
              * <p> 1st modifier of the procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER1= "MODIFIER1" ;

    /*
    * The index position of the column MODIFIER1 in the table.
    */
    public static final int MODIFIER1_IDX = 9 ;

    /**
              * <p> 2nd modifier of the procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER2= "MODIFIER2" ;

    /*
    * The index position of the column MODIFIER2 in the table.
    */
    public static final int MODIFIER2_IDX = 10 ;

    /**
              * <p> 3rd modifier of the procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER3= "MODIFIER3" ;

    /*
    * The index position of the column MODIFIER3 in the table.
    */
    public static final int MODIFIER3_IDX = 11 ;

    /**
              * <p> 4th modifier of the procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER4= "MODIFIER4" ;

    /*
    * The index position of the column MODIFIER4 in the table.
    */
    public static final int MODIFIER4_IDX = 12 ;

    /**
              * <p> whether the procedure is emergency or not or unknown.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMERGENCY= "EMERGENCY" ;

    /*
    * The index position of the column EMERGENCY in the table.
    */
    public static final int EMERGENCY_IDX = 13 ;

    /**
              * <p> Family plan number of the procedure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FAMILY_PLAN= "FAMILY_PLAN" ;

    /*
    * The index position of the column FAMILY_PLAN in the table.
    */
    public static final int FAMILY_PLAN_IDX = 14 ;

    /**
              * <p> Denotes whether this service involves EPSDT.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EPSDT_INDICATOR= "EPSDT_INDICATOR" ;

    /*
    * The index position of the column EPSDT_INDICATOR in the table.
    */
    public static final int EPSDT_INDICATOR_IDX = 15 ;

    /**
              * <p> If any 'Rendering Provider' is selected for this service line, it is stored in 'ClaimServiceLineProviders' table with TYPE as 'rendering'; corrosponding PK is stored here (LOOP 2420A -> #430).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RENDERING_PROVIDER_ID= "RENDERING_PROVIDER_ID" ;

    /*
    * The index position of the column RENDERING_PROVIDER_ID in the table.
    */
    public static final int RENDERING_PROVIDER_ID_IDX = 16 ;

    /**
              * <p> PK of the RCMClaimCPTDetails or ExecutedCPTMap table (i.e, sas key of the respective line item). Used in eclaim submission(837-2400:REF:6R) and/or eclaim status(267/277-2210E:REF:FJ) with each service line.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LINE_ITEM_CONTROL_NO= "LINE_ITEM_CONTROL_NO" ;

    /*
    * The index position of the column LINE_ITEM_CONTROL_NO in the table.
    */
    public static final int LINE_ITEM_CONTROL_NO_IDX = 17 ;

    /**
              * <p> External id of the Executed CPT.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXTERNAL_ID= "EXTERNAL_ID" ;

    /*
    * The index position of the column EXTERNAL_ID in the table.
    */
    public static final int EXTERNAL_ID_IDX = 18 ;

}
