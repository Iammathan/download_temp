package com.adventnet.charm;

/** <p> Description of the table <code>RCMDeniedCPTVsDxDetails</code>.
 *  Column Name and Table Name of  database table  <code>RCMDeniedCPTVsDxDetails</code> is mapped
 * as constants in this util.</p> 
  Diagnosis details of coressponding denied CPT. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_DENIED_CPT_DX_ID}
  * </ul>
 */
 
public final class RCMDENIEDCPTVSDXDETAILS
{
    private RCMDENIEDCPTVSDXDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMDeniedCPTVsDxDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_DENIED_CPT_DX_ID= "CLAIM_DENIED_CPT_DX_ID" ;

    /*
    * The index position of the column CLAIM_DENIED_CPT_DX_ID in the table.
    */
    public static final int CLAIM_DENIED_CPT_DX_ID_IDX = 1 ;

    /**
              * <p> CPT_DENIED_DETAIL_ID of RCMCPTVsDenialDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CPT_DENIED_DETAIL_ID= "CPT_DENIED_DETAIL_ID" ;

    /*
    * The index position of the column CPT_DENIED_DETAIL_ID in the table.
    */
    public static final int CPT_DENIED_DETAIL_ID_IDX = 2 ;

    /**
              * <p> Diagnosis Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DX_CODE= "DX_CODE" ;

    /*
    * The index position of the column DX_CODE in the table.
    */
    public static final int DX_CODE_IDX = 3 ;

    /**
              * <p> Diagnosis Pointer Values - A/B/....</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DX_POINTER_VAL= "DX_POINTER_VAL" ;

    /*
    * The index position of the column DX_POINTER_VAL in the table.
    */
    public static final int DX_POINTER_VAL_IDX = 4 ;

    /**
              * <p> Type of code whether is it ICD9 or 10.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DX_CODE_TYPE= "DX_CODE_TYPE" ;

    /*
    * The index position of the column DX_CODE_TYPE in the table.
    */
    public static final int DX_CODE_TYPE_IDX = 5 ;

}
