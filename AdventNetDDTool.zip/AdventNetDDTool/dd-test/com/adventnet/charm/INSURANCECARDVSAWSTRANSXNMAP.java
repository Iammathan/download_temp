package com.adventnet.charm;

/** <p> Description of the table <code>InsuranceCardVsAwsTransxnMap</code>.
 *  Column Name and Table Name of  database table  <code>InsuranceCardVsAwsTransxnMap</code> is mapped
 * as constants in this util.</p> 
   To map insurance card copy id with AWS Transaction History . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INSURANCE_CARD_VS_AWS_TRANSXN_MAP}
  * </ul>
 */
 
public final class INSURANCECARDVSAWSTRANSXNMAP
{
    private INSURANCECARDVSAWSTRANSXNMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InsuranceCardVsAwsTransxnMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INSURANCE_CARD_VS_AWS_TRANSXN_MAP= "INSURANCE_CARD_VS_AWS_TRANSXN_MAP" ;

    /*
    * The index position of the column INSURANCE_CARD_VS_AWS_TRANSXN_MAP in the table.
    */
    public static final int INSURANCE_CARD_VS_AWS_TRANSXN_MAP_IDX = 1 ;

    /**
              * <p> Insurance card copy Id to link with AWS Transaction ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INSURANCE_CARD_COPY_ID= "INSURANCE_CARD_COPY_ID" ;

    /*
    * The index position of the column INSURANCE_CARD_COPY_ID in the table.
    */
    public static final int INSURANCE_CARD_COPY_ID_IDX = 2 ;

    /**
              * <p> Latest transaction id of the front page, so that we can delink the old.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LATEST_AWS_FRONT_TRANSACTION_ID= "LATEST_AWS_FRONT_TRANSACTION_ID" ;

    /*
    * The index position of the column LATEST_AWS_FRONT_TRANSACTION_ID in the table.
    */
    public static final int LATEST_AWS_FRONT_TRANSACTION_ID_IDX = 3 ;

    /**
              * <p> Latest transaction id of the back page, so that we can delink the old.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LATEST_AWS_BACK_TRANSACTION_ID= "LATEST_AWS_BACK_TRANSACTION_ID" ;

    /*
    * The index position of the column LATEST_AWS_BACK_TRANSACTION_ID in the table.
    */
    public static final int LATEST_AWS_BACK_TRANSACTION_ID_IDX = 4 ;

}
