package com.adventnet.charm;

/** <p> Description of the table <code>LabResultTemplate</code>.
 *  Column Name and Table Name of  database table  <code>LabResultTemplate</code> is mapped
 * as constants in this util.</p> 
  Flowsheets filled by Patients. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_RESULT_TEMPLATE_ID}
  * </ul>
 */
 
public final class LABRESULTTEMPLATE
{
    private LABRESULTTEMPLATE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabResultTemplate" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RESULT_TEMPLATE_ID= "LAB_RESULT_TEMPLATE_ID" ;

    /*
    * The index position of the column LAB_RESULT_TEMPLATE_ID in the table.
    */
    public static final int LAB_RESULT_TEMPLATE_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 2 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CONTENT= "CONTENT" ;

    /*
    * The index position of the column CONTENT in the table.
    */
    public static final int CONTENT_IDX = 3 ;

    /**
              * <p> Time of Health vital Entry.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 4 ;

    /**
              * <p> Time of Health vital Entry.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UPDATED_TIME= "UPDATED_TIME" ;

    /*
    * The index position of the column UPDATED_TIME in the table.
    */
    public static final int UPDATED_TIME_IDX = 5 ;

}
