package com.adventnet.charm;

/** <p> Description of the table <code>PatientStatementDetails</code>.
 *  Column Name and Table Name of  database table  <code>PatientStatementDetails</code> is mapped
 * as constants in this util.</p> 
   Statement Details  . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_STATEMENT_ID}
  * </ul>
 */
 
public final class PATIENTSTATEMENTDETAILS
{
    private PATIENTSTATEMENTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientStatementDetails" ;
    /**
              * <p> Statement ID.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_STATEMENT_ID= "PATIENT_STATEMENT_ID" ;

    /*
    * The index position of the column PATIENT_STATEMENT_ID in the table.
    */
    public static final int PATIENT_STATEMENT_ID_IDX = 1 ;

    /**
              * <p> Patient to whom Statement is sent.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Current Time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAST_SENT_TIME= "LAST_SENT_TIME" ;

    /*
    * The index position of the column LAST_SENT_TIME in the table.
    */
    public static final int LAST_SENT_TIME_IDX = 3 ;

    /**
              * <p> Date on which this data is sent to patient.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_SENT_DATE_TIME= "LAST_SENT_DATE_TIME" ;

    /*
    * The index position of the column LAST_SENT_DATE_TIME in the table.
    */
    public static final int LAST_SENT_DATE_TIME_IDX = 4 ;

    /**
              * <p> member who sent the statement.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAST_SENT_MEMBER_ID= "LAST_SENT_MEMBER_ID" ;

    /*
    * The index position of the column LAST_SENT_MEMBER_ID in the table.
    */
    public static final int LAST_SENT_MEMBER_ID_IDX = 5 ;

    /**
              * <p> member name who sent the statement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAST_SENT_MEMBER_NAME= "LAST_SENT_MEMBER_NAME" ;

    /*
    * The index position of the column LAST_SENT_MEMBER_NAME in the table.
    */
    public static final int LAST_SENT_MEMBER_NAME_IDX = 6 ;

    /**
              * <p> pk value from StatementDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_SENT_STATEMENT_ID= "LAST_SENT_STATEMENT_ID" ;

    /*
    * The index position of the column LAST_SENT_STATEMENT_ID in the table.
    */
    public static final int LAST_SENT_STATEMENT_ID_IDX = 7 ;

}
