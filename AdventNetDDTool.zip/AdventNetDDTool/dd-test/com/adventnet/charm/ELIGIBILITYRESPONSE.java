package com.adventnet.charm;

/** <p> Description of the table <code>EligibilityResponse</code>.
 *  Column Name and Table Name of  database table  <code>EligibilityResponse</code> is mapped
 * as constants in this util.</p> 
  To store Formulary Id, Alternatives Id, etc. from eligibility 271 response. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ELIGIBILITY_RESPONSE_ID}
  * </ul>
 */
 
public final class ELIGIBILITYRESPONSE
{
    private ELIGIBILITYRESPONSE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EligibilityResponse" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELIGIBILITY_RESPONSE_ID= "ELIGIBILITY_RESPONSE_ID" ;

    /*
    * The index position of the column ELIGIBILITY_RESPONSE_ID in the table.
    */
    public static final int ELIGIBILITY_RESPONSE_ID_IDX = 1 ;

    /**
              * <p> Practice Patient ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Message Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 3 ;

    /**
              * <p> Appointment ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 4 ;

    /**
              * <p> Time of Eligibility response.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME_OF_RESPONSE= "TIME_OF_RESPONSE" ;

    /*
    * The index position of the column TIME_OF_RESPONSE in the table.
    */
    public static final int TIME_OF_RESPONSE_IDX = 5 ;

    /**
              * <p> Interchange control no. from elg. response. To be sent in med history request for claim data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>9</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTERCHANGE_CONTROL_NUMBER= "INTERCHANGE_CONTROL_NUMBER" ;

    /*
    * The index position of the column INTERCHANGE_CONTROL_NUMBER in the table.
    */
    public static final int INTERCHANGE_CONTROL_NUMBER_IDX = 6 ;

    /**
              * <p> Formulary Id from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FORMULARY_ID= "FORMULARY_ID" ;

    /*
    * The index position of the column FORMULARY_ID in the table.
    */
    public static final int FORMULARY_ID_IDX = 7 ;

    /**
              * <p> Alternatives Id from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALTERNATIVES_ID= "ALTERNATIVES_ID" ;

    /*
    * The index position of the column ALTERNATIVES_ID in the table.
    */
    public static final int ALTERNATIVES_ID_IDX = 8 ;

    /**
              * <p> Coverage Id from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COVERAGE_ID= "COVERAGE_ID" ;

    /*
    * The index position of the column COVERAGE_ID in the table.
    */
    public static final int COVERAGE_ID_IDX = 9 ;

    /**
              * <p> Copay Id from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COPAY_ID= "COPAY_ID" ;

    /*
    * The index position of the column COPAY_ID in the table.
    */
    public static final int COPAY_ID_IDX = 10 ;

    /**
              * <p> PBM Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PBM_NAME= "PBM_NAME" ;

    /*
    * The index position of the column PBM_NAME in the table.
    */
    public static final int PBM_NAME_IDX = 11 ;

    /**
              * <p> PBM Participant Id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PBM_PARTICIPANT_ID= "PBM_PARTICIPANT_ID" ;

    /*
    * The index position of the column PBM_PARTICIPANT_ID in the table.
    */
    public static final int PBM_PARTICIPANT_ID_IDX = 12 ;

    /**
              * <p> Patient First name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_FIRST_NAME= "PATIENT_FIRST_NAME" ;

    /*
    * The index position of the column PATIENT_FIRST_NAME in the table.
    */
    public static final int PATIENT_FIRST_NAME_IDX = 13 ;

    /**
              * <p> Patient middle name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_MIDDLE_NAME= "PATIENT_MIDDLE_NAME" ;

    /*
    * The index position of the column PATIENT_MIDDLE_NAME in the table.
    */
    public static final int PATIENT_MIDDLE_NAME_IDX = 14 ;

    /**
              * <p> Patient last name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_LAST_NAME= "PATIENT_LAST_NAME" ;

    /*
    * The index position of the column PATIENT_LAST_NAME in the table.
    */
    public static final int PATIENT_LAST_NAME_IDX = 15 ;

    /**
              * <p> Patient suffix.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_SUFFIX= "PATIENT_SUFFIX" ;

    /*
    * The index position of the column PATIENT_SUFFIX in the table.
    */
    public static final int PATIENT_SUFFIX_IDX = 16 ;

    /**
              * <p> Member Id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 17 ;

    /**
              * <p> Patient date of birth.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_BIRTH= "DATE_OF_BIRTH" ;

    /*
    * The index position of the column DATE_OF_BIRTH in the table.
    */
    public static final int DATE_OF_BIRTH_IDX = 18 ;

    /**
              * <p> Patient gender.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 19 ;

    /**
              * <p> Cardholder Id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CARDHOLDER_ID= "CARDHOLDER_ID" ;

    /*
    * The index position of the column CARDHOLDER_ID in the table.
    */
    public static final int CARDHOLDER_ID_IDX = 20 ;

    /**
              * <p> Health plan Id from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_PLAN_ID= "HEALTH_PLAN_ID" ;

    /*
    * The index position of the column HEALTH_PLAN_ID in the table.
    */
    public static final int HEALTH_PLAN_ID_IDX = 21 ;

    /**
              * <p> Health Plan Name from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_PLAN_NAME= "HEALTH_PLAN_NAME" ;

    /*
    * The index position of the column HEALTH_PLAN_NAME in the table.
    */
    public static final int HEALTH_PLAN_NAME_IDX = 22 ;

    /**
              * <p> Health Plan Group Id from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_PLAN_GROUP_NUMBER= "HEALTH_PLAN_GROUP_NUMBER" ;

    /*
    * The index position of the column HEALTH_PLAN_GROUP_NUMBER in the table.
    */
    public static final int HEALTH_PLAN_GROUP_NUMBER_IDX = 23 ;

    /**
              * <p> Health Plan Group Name from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HEALTH_PLAN_GROUP_NAME= "HEALTH_PLAN_GROUP_NAME" ;

    /*
    * The index position of the column HEALTH_PLAN_GROUP_NAME in the table.
    */
    public static final int HEALTH_PLAN_GROUP_NAME_IDX = 24 ;

    /**
              * <p> Address line 1.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>55</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDRESS_LINE1= "ADDRESS_LINE1" ;

    /*
    * The index position of the column ADDRESS_LINE1 in the table.
    */
    public static final int ADDRESS_LINE1_IDX = 25 ;

    /**
              * <p> Address line 2.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>55</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDRESS_LINE2= "ADDRESS_LINE2" ;

    /*
    * The index position of the column ADDRESS_LINE2 in the table.
    */
    public static final int ADDRESS_LINE2_IDX = 26 ;

    /**
              * <p> Patient city.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CITY= "CITY" ;

    /*
    * The index position of the column CITY in the table.
    */
    public static final int CITY_IDX = 27 ;

    /**
              * <p> State code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATE_CODE= "STATE_CODE" ;

    /*
    * The index position of the column STATE_CODE in the table.
    */
    public static final int STATE_CODE_IDX = 28 ;

    /**
              * <p> Zip code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZIP_CODE= "ZIP_CODE" ;

    /*
    * The index position of the column ZIP_CODE in the table.
    */
    public static final int ZIP_CODE_IDX = 29 ;

    /**
              * <p> Country code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COUNTRY_CODE= "COUNTRY_CODE" ;

    /*
    * The index position of the column COUNTRY_CODE in the table.
    */
    public static final int COUNTRY_CODE_IDX = 30 ;

    /**
              * <p> Mail order(M), Retail(R), Both(A).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHARMACY_TYPE= "PHARMACY_TYPE" ;

    /*
    * The index position of the column PHARMACY_TYPE in the table.
    */
    public static final int PHARMACY_TYPE_IDX = 31 ;

    /**
              * <p> Inactive coverage  - Mail order(M), Retail(R), Both(A).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_COVERAGE_PHARMACY= "NO_COVERAGE_PHARMACY" ;

    /*
    * The index position of the column NO_COVERAGE_PHARMACY in the table.
    */
    public static final int NO_COVERAGE_PHARMACY_IDX = 32 ;

    /**
              * <p> BIN number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BIN_NUMBER= "BIN_NUMBER" ;

    /*
    * The index position of the column BIN_NUMBER in the table.
    */
    public static final int BIN_NUMBER_IDX = 33 ;

    /**
              * <p> PCN number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PCN_NUMBER= "PCN_NUMBER" ;

    /*
    * The index position of the column PCN_NUMBER in the table.
    */
    public static final int PCN_NUMBER_IDX = 34 ;

    /**
              * <p> Service provider number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_PROVIDER_NO= "SERVICE_PROVIDER_NO" ;

    /*
    * The index position of the column SERVICE_PROVIDER_NO in the table.
    */
    public static final int SERVICE_PROVIDER_NO_IDX = 35 ;

    /**
              * <p> Mail order pharmacy name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAIL_ORDER_PHARMACY= "MAIL_ORDER_PHARMACY" ;

    /*
    * The index position of the column MAIL_ORDER_PHARMACY in the table.
    */
    public static final int MAIL_ORDER_PHARMACY_IDX = 36 ;

    /**
              * <p> Error message from surescripts.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR= "ERROR" ;

    /*
    * The index position of the column ERROR in the table.
    */
    public static final int ERROR_IDX = 37 ;

    /**
              * <p> Is coverage exists.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_COVERED= "IS_COVERED" ;

    /*
    * The index position of the column IS_COVERED in the table.
    */
    public static final int IS_COVERED_IDX = 38 ;

    /**
              * <p> Is there a change in patient demographics.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CHANGE_FLAG= "CHANGE_FLAG" ;

    /*
    * The index position of the column CHANGE_FLAG in the table.
    */
    public static final int CHANGE_FLAG_IDX = 39 ;

}
