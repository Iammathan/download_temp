package com.adventnet.charm;

/** <p> Description of the table <code>RelatedEntityContactInfo</code>.
 *  Column Name and Table Name of  database table  <code>RelatedEntityContactInfo</code> is mapped
 * as constants in this util.</p> 
  2120 PER Segment elements - Contact info of the benefit related entity. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #CONTACT_INFO_ID}
  * <li> {@link #RELATED_ENTITY_ID}
  * </ul>
 */
 
public final class RELATEDENTITYCONTACTINFO
{
    private RELATEDENTITYCONTACTINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RelatedEntityContactInfo" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACT_INFO_ID= "CONTACT_INFO_ID" ;

    /*
    * The index position of the column CONTACT_INFO_ID in the table.
    */
    public static final int CONTACT_INFO_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of the respective Eligibility Information Group.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RELATED_ENTITY_ID= "RELATED_ENTITY_ID" ;

    /*
    * The index position of the column RELATED_ENTITY_ID in the table.
    */
    public static final int RELATED_ENTITY_ID_IDX = 2 ;

    /**
              * <p> 2120 - PER01 - Contact Function Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONTACT_FUNC_CODE= "CONTACT_FUNC_CODE" ;

    /*
    * The index position of the column CONTACT_FUNC_CODE in the table.
    */
    public static final int CONTACT_FUNC_CODE_IDX = 3 ;

    /**
              * <p> 2120 - PER02 - Contact Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONTACT_NAME= "CONTACT_NAME" ;

    /*
    * The index position of the column CONTACT_NAME in the table.
    */
    public static final int CONTACT_NAME_IDX = 4 ;

    /**
              * <p> 2120 - PER03 - Communication Number Qualifier 1.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMM_NO_QUALIFIER_1= "COMM_NO_QUALIFIER_1" ;

    /*
    * The index position of the column COMM_NO_QUALIFIER_1 in the table.
    */
    public static final int COMM_NO_QUALIFIER_1_IDX = 5 ;

    /**
              * <p> 2120 - PER04 - Communication No 1.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMM_NO_1= "COMM_NO_1" ;

    /*
    * The index position of the column COMM_NO_1 in the table.
    */
    public static final int COMM_NO_1_IDX = 6 ;

    /**
              * <p> 2120 - PER05 - Communication Number Qualifier 2.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMM_NO_QUALIFIER_2= "COMM_NO_QUALIFIER_2" ;

    /*
    * The index position of the column COMM_NO_QUALIFIER_2 in the table.
    */
    public static final int COMM_NO_QUALIFIER_2_IDX = 7 ;

    /**
              * <p> 2120 - PER06 - Communication No 2.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMM_NO_2= "COMM_NO_2" ;

    /*
    * The index position of the column COMM_NO_2 in the table.
    */
    public static final int COMM_NO_2_IDX = 8 ;

    /**
              * <p> 2120 - PER07 - Communication Number Qualifier 3.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMM_NO_QUALIFIER_3= "COMM_NO_QUALIFIER_3" ;

    /*
    * The index position of the column COMM_NO_QUALIFIER_3 in the table.
    */
    public static final int COMM_NO_QUALIFIER_3_IDX = 9 ;

    /**
              * <p> 2120 - PER08 - Communication No 3.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMM_NO_3= "COMM_NO_3" ;

    /*
    * The index position of the column COMM_NO_3 in the table.
    */
    public static final int COMM_NO_3_IDX = 10 ;

}
