package com.adventnet.charm;

/** <p> Description of the table <code>UserSearchCMDDetils</code>.
 *  Column Name and Table Name of  database table  <code>UserSearchCMDDetils</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #USER_SEARCH_CMD_ID}
  * </ul>
 */
 
public final class USERSEARCHCMDDETILS
{
    private USERSEARCHCMDDETILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UserSearchCMDDetils" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String USER_SEARCH_CMD_ID= "USER_SEARCH_CMD_ID" ;

    /*
    * The index position of the column USER_SEARCH_CMD_ID in the table.
    */
    public static final int USER_SEARCH_CMD_ID_IDX = 1 ;

    /**
              * <p> User id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                            *    This field is an unique column.<br>
                  */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> facility id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                            *    This field is an unique column.<br>
                  */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SEARCH_COMMAND= "SEARCH_COMMAND" ;

    /*
    * The index position of the column SEARCH_COMMAND in the table.
    */
    public static final int SEARCH_COMMAND_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SEARCH_COMMAND_COMPLETE= "SEARCH_COMMAND_COMPLETE" ;

    /*
    * The index position of the column SEARCH_COMMAND_COMPLETE in the table.
    */
    public static final int SEARCH_COMMAND_COMPLETE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4096</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BOT_RESPONCE= "BOT_RESPONCE" ;

    /*
    * The index position of the column BOT_RESPONCE in the table.
    */
    public static final int BOT_RESPONCE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ACTIVE_COMMAND= "IS_ACTIVE_COMMAND" ;

    /*
    * The index position of the column IS_ACTIVE_COMMAND in the table.
    */
    public static final int IS_ACTIVE_COMMAND_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_VALID_COMMAND= "IS_VALID_COMMAND" ;

    /*
    * The index position of the column IS_VALID_COMMAND in the table.
    */
    public static final int IS_VALID_COMMAND_IDX = 8 ;

    /**
              * <p>  Time of creation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 9 ;

}
