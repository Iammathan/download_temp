package com.adventnet.charm;

/** <p> Description of the table <code>AsthmaTherapyMeasures</code>.
 *  Column Name and Table Name of  database table  <code>AsthmaTherapyMeasures</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ASTHMA_THERAPY_MEASURE_ID}
  * </ul>
 */
 
public final class ASTHMATHERAPYMEASURES
{
    private ASTHMATHERAPYMEASURES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AsthmaTherapyMeasures" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ASTHMA_THERAPY_MEASURE_ID= "ASTHMA_THERAPY_MEASURE_ID" ;

    /*
    * The index position of the column ASTHMA_THERAPY_MEASURE_ID in the table.
    */
    public static final int ASTHMA_THERAPY_MEASURE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_DATE= "CONSULTATION_DATE" ;

    /*
    * The index position of the column CONSULTATION_DATE in the table.
    */
    public static final int CONSULTATION_DATE_IDX = 5 ;

    /**
              * <p> Visit type of the appointment.Foreign key from PQRIEncounterTypes table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PQRI_ENCOUNTER_TYPE_ID= "PQRI_ENCOUNTER_TYPE_ID" ;

    /*
    * The index position of the column PQRI_ENCOUNTER_TYPE_ID in the table.
    */
    public static final int PQRI_ENCOUNTER_TYPE_ID_IDX = 6 ;

    /**
              * <p> Diagnosis active: asthma persistent.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SEVERITY_PERSISTENT= "IS_SEVERITY_PERSISTENT" ;

    /*
    * The index position of the column IS_SEVERITY_PERSISTENT in the table.
    */
    public static final int IS_SEVERITY_PERSISTENT_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_MET= "IS_PERFORMANCE_MET" ;

    /*
    * The index position of the column IS_PERFORMANCE_MET in the table.
    */
    public static final int IS_PERFORMANCE_MET_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PERFORMANCE_EXCLUDED= "IS_PERFORMANCE_EXCLUDED" ;

    /*
    * The index position of the column IS_PERFORMANCE_EXCLUDED in the table.
    */
    public static final int IS_PERFORMANCE_EXCLUDED_IDX = 9 ;

}
