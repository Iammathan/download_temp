package com.adventnet.charm;

/** <p> Description of the table <code>EHRPatientGroupMap</code>.
 *  Column Name and Table Name of  database table  <code>EHRPatientGroupMap</code> is mapped
 * as constants in this util.</p> 
  Patient grouping map table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_GROUP_MAP_ID}
  * </ul>
 */
 
public final class EHRPATIENTGROUPMAP
{
    private EHRPATIENTGROUPMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EHRPatientGroupMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_GROUP_MAP_ID= "PATIENT_GROUP_MAP_ID" ;

    /*
    * The index position of the column PATIENT_GROUP_MAP_ID in the table.
    */
    public static final int PATIENT_GROUP_MAP_ID_IDX = 1 ;

    /**
              * <p> Id of the patient group.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_GROUP_ID= "PATIENT_GROUP_ID" ;

    /*
    * The index position of the column PATIENT_GROUP_ID in the table.
    */
    public static final int PATIENT_GROUP_ID_IDX = 2 ;

    /**
              * <p> Id of the patients.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

}
