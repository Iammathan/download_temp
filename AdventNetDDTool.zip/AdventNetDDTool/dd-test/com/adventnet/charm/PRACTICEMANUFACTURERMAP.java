package com.adventnet.charm;

/** <p> Description of the table <code>PracticeManufacturerMap</code>.
 *  Column Name and Table Name of  database table  <code>PracticeManufacturerMap</code> is mapped
 * as constants in this util.</p> 
  Customised Practice Manufacturer List. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #MANUFACTURER_ID}
  * <li> {@link #PRACTICE_ID}
  * </ul>
 */
 
public final class PRACTICEMANUFACTURERMAP
{
    private PRACTICEMANUFACTURERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeManufacturerMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MANUFACTURER_ID= "MANUFACTURER_ID" ;

    /*
    * The index position of the column MANUFACTURER_ID in the table.
    */
    public static final int MANUFACTURER_ID_IDX = 1 ;

    /**
              * <p> Name of Supplement.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MANUFACTURER_NAME= "MANUFACTURER_NAME" ;

    /*
    * The index position of the column MANUFACTURER_NAME in the table.
    */
    public static final int MANUFACTURER_NAME_IDX = 2 ;

    /**
              * <p> Unique identifier.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

}
