package com.adventnet.charm;

/** <p> Description of the table <code>FacilitiesList</code>.
 *  Column Name and Table Name of  database table  <code>FacilitiesList</code> is mapped
 * as constants in this util.</p> 
  List of hospitals. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FACILITY_ID}
  * </ul>
 */
 
public final class FACILITIESLIST
{
    private FACILITIESLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FacilitiesList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 1 ;

    /**
              * <p> Name of the facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FACILITY_NAME= "FACILITY_NAME" ;

    /*
    * The index position of the column FACILITY_NAME in the table.
    */
    public static final int FACILITY_NAME_IDX = 2 ;

    /**
              * <p> Code of the facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_CODE= "FACILITY_CODE" ;

    /*
    * The index position of the column FACILITY_CODE in the table.
    */
    public static final int FACILITY_CODE_IDX = 3 ;

    /**
              * <p> National Provider Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 4 ;

    /**
              * <p> Id for Mapping PostalAddress and Practice information.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 5 ;

    /**
              * <p> Id for Mapping ContactDetails and Practice information.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 6 ;

    /**
              * <p> Qualifier Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String QUALIFIER_ID= "QUALIFIER_ID" ;

    /*
    * The index position of the column QUALIFIER_ID in the table.
    */
    public static final int QUALIFIER_ID_IDX = 7 ;

    /**
              * <p> Non National Provider Identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NON_NPI= "NON_NPI" ;

    /*
    * The index position of the column NON_NPI in the table.
    */
    public static final int NON_NPI_IDX = 8 ;

    /**
              * <p> Logo of the facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FACILITY_LOGO= "FACILITY_LOGO" ;

    /*
    * The index position of the column FACILITY_LOGO in the table.
    */
    public static final int FACILITY_LOGO_IDX = 9 ;

    /**
              * <p> Status of facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                     * Default Value is <code>Enabled</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>Enabled</code>" , 
       * will be taken.<br>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 10 ;

    /**
              * <p> Facility Tax id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_TAX_ID= "FACILITY_TAX_ID" ;

    /*
    * The index position of the column FACILITY_TAX_ID in the table.
    */
    public static final int FACILITY_TAX_ID_IDX = 11 ;

    /**
              * <p> Service Provider ID / Provider ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_PROVIDER_NUMBER= "SERVICE_PROVIDER_NUMBER" ;

    /*
    * The index position of the column SERVICE_PROVIDER_NUMBER in the table.
    */
    public static final int SERVICE_PROVIDER_NUMBER_IDX = 12 ;

    /**
              * <p> On adding a lab order, multiple lab-order entries will be created for each lab.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SPLIT_ORDERS_ON_LAB= "SPLIT_ORDERS_ON_LAB" ;

    /*
    * The index position of the column SPLIT_ORDERS_ON_LAB in the table.
    */
    public static final int SPLIT_ORDERS_ON_LAB_IDX = 13 ;

    /**
              * <p> Name of the Contact Person of this Facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONTACT_PERSON_NAME= "CONTACT_PERSON_NAME" ;

    /*
    * The index position of the column CONTACT_PERSON_NAME in the table.
    */
    public static final int CONTACT_PERSON_NAME_IDX = 14 ;

    /**
              * <p> Facilitie's Taxonomy Code - a unique ten character alphanumeric code that enables providers to identify their specialty. These codes are assigned at both the individual provider and organizational provider level..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TAXONOMY_CODE= "TAXONOMY_CODE" ;

    /*
    * The index position of the column TAXONOMY_CODE in the table.
    */
    public static final int TAXONOMY_CODE_IDX = 15 ;

    /**
              * <p> practice GSTIN number - only for non-us practices.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GSTIN_NUM= "GSTIN_NUM" ;

    /*
    * The index position of the column GSTIN_NUM in the table.
    */
    public static final int GSTIN_NUM_IDX = 16 ;

    /**
              * <p> place of supply - only for non-us practices.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PLACE_OF_SUPPLY= "PLACE_OF_SUPPLY" ;

    /*
    * The index position of the column PLACE_OF_SUPPLY in the table.
    */
    public static final int PLACE_OF_SUPPLY_IDX = 17 ;

    /**
              * <p> Direction of the Facility Address.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DIRECTION= "DIRECTION" ;

    /*
    * The index position of the column DIRECTION in the table.
    */
    public static final int DIRECTION_IDX = 18 ;

    /**
              * <p> Sending email address for automated email's to patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                     * Default Value is <code>noreply@charmtracker.com</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SENDER_EMAIL= "SENDER_EMAIL" ;

    /*
    * The index position of the column SENDER_EMAIL in the table.
    */
    public static final int SENDER_EMAIL_IDX = 19 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FACILITY_TYPE_CODE= "FACILITY_TYPE_CODE" ;

    /*
    * The index position of the column FACILITY_TYPE_CODE in the table.
    */
    public static final int FACILITY_TYPE_CODE_IDX = 20 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_UB04_ENABLE= "IS_UB04_ENABLE" ;

    /*
    * The index position of the column IS_UB04_ENABLE in the table.
    */
    public static final int IS_UB04_ENABLE_IDX = 21 ;

    /**
              * <p> Identifier of Timezone to which the facility belongs to.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>GMT</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TIMEZONE= "TIMEZONE" ;

    /*
    * The index position of the column TIMEZONE in the table.
    */
    public static final int TIMEZONE_IDX = 22 ;

    /**
              * <p> CLIA #.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CLIA_ID= "CLIA_ID" ;

    /*
    * The index position of the column CLIA_ID in the table.
    */
    public static final int CLIA_ID_IDX = 23 ;

    /**
              * <p> Latitude of the facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LATITUDE= "LATITUDE" ;

    /*
    * The index position of the column LATITUDE in the table.
    */
    public static final int LATITUDE_IDX = 24 ;

    /**
              * <p> Latitude of the facility.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LONGITUDE= "LONGITUDE" ;

    /*
    * The index position of the column LONGITUDE in the table.
    */
    public static final int LONGITUDE_IDX = 25 ;

}
