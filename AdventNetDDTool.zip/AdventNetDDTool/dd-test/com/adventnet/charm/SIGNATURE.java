package com.adventnet.charm;

/** <p> Description of the table <code>Signature</code>.
 *  Column Name and Table Name of  database table  <code>Signature</code> is mapped
 * as constants in this util.</p> 
  Signature Image (PNG,JPEG) of Facility member. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SIGNATURE_ID}
  * </ul>
 */
 
public final class SIGNATURE
{
    private SIGNATURE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Signature" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SIGNATURE_ID= "SIGNATURE_ID" ;

    /*
    * The index position of the column SIGNATURE_ID in the table.
    */
    public static final int SIGNATURE_ID_IDX = 1 ;

    /**
              * <p> ChARM ID for the physician.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Signature file location in the DFS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SIGNATURE= "SIGNATURE" ;

    /*
    * The index position of the column SIGNATURE in the table.
    */
    public static final int SIGNATURE_IDX = 3 ;

    /**
              * <p> eRx.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String ERX= "ERX" ;

    /*
    * The index position of the column ERX in the table.
    */
    public static final int ERX_IDX = 4 ;

    /**
              * <p> Patient Summary.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PATIENT_SUMMARY= "PATIENT_SUMMARY" ;

    /*
    * The index position of the column PATIENT_SUMMARY in the table.
    */
    public static final int PATIENT_SUMMARY_IDX = 5 ;

    /**
              * <p> Lab Order.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String LAB_ORDER= "LAB_ORDER" ;

    /*
    * The index position of the column LAB_ORDER in the table.
    */
    public static final int LAB_ORDER_IDX = 6 ;

    /**
              * <p> Image Order.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IMAGE_ORDER= "IMAGE_ORDER" ;

    /*
    * The index position of the column IMAGE_ORDER in the table.
    */
    public static final int IMAGE_ORDER_IDX = 7 ;

    /**
              * <p> Chart Note.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CHART_NOTE= "CHART_NOTE" ;

    /*
    * The index position of the column CHART_NOTE in the table.
    */
    public static final int CHART_NOTE_IDX = 8 ;

    /**
              * <p> Invoice Summary.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String INVOICE_PDF= "INVOICE_PDF" ;

    /*
    * The index position of the column INVOICE_PDF in the table.
    */
    public static final int INVOICE_PDF_IDX = 9 ;

    /**
              * <p> Invoice Super bill pdf.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String INVOICE_SUPERBILL_PDF= "INVOICE_SUPERBILL_PDF" ;

    /*
    * The index position of the column INVOICE_SUPERBILL_PDF in the table.
    */
    public static final int INVOICE_SUPERBILL_PDF_IDX = 10 ;

    /**
              * <p> Receipt pdf.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String RECEIPT_PDF= "RECEIPT_PDF" ;

    /*
    * The index position of the column RECEIPT_PDF in the table.
    */
    public static final int RECEIPT_PDF_IDX = 11 ;

}
