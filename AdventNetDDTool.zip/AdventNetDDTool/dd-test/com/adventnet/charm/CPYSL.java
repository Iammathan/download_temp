package com.adventnet.charm;

/** <p> Description of the table <code>CpySL</code>.
 *  Column Name and Table Name of  database table  <code>CpySL</code> is mapped
 * as constants in this util.</p> 
  Weekly downloaded list from surescripts for summary level copay. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #COP_SL_DOWNLOAD_ID}
  * </ul>
 */
 
public final class CPYSL
{
    private CPYSL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CpySL" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COP_SL_DOWNLOAD_ID= "COP_SL_DOWNLOAD_ID" ;

    /*
    * The index position of the column COP_SL_DOWNLOAD_ID in the table.
    */
    public static final int COP_SL_DOWNLOAD_ID_IDX = 1 ;

    /**
              * <p> PBM unique ID for surescripts.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PBM_PARTICIPANT_ID= "PBM_PARTICIPANT_ID" ;

    /*
    * The index position of the column PBM_PARTICIPANT_ID in the table.
    */
    public static final int PBM_PARTICIPANT_ID_IDX = 2 ;

    /**
              * <p> Copay list ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COPAY_LIST_ID= "COPAY_LIST_ID" ;

    /*
    * The index position of the column COPAY_LIST_ID in the table.
    */
    public static final int COPAY_LIST_ID_IDX = 3 ;

    /**
              * <p> Copay list type (SL).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COPAY_LIST_TYPE= "COPAY_LIST_TYPE" ;

    /*
    * The index position of the column COPAY_LIST_TYPE in the table.
    */
    public static final int COPAY_LIST_TYPE_IDX = 4 ;

    /**
              * <p> Date the list goes into effect.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EFFECTIVE_DATE= "EFFECTIVE_DATE" ;

    /*
    * The index position of the column EFFECTIVE_DATE in the table.
    */
    public static final int EFFECTIVE_DATE_IDX = 5 ;

    /**
              * <p> only Add is supported now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHANGE_IDENTIFIER= "CHANGE_IDENTIFIER" ;

    /*
    * The index position of the column CHANGE_IDENTIFIER in the table.
    */
    public static final int CHANGE_IDENTIFIER_IDX = 6 ;

    /**
              * <p> Copay ID from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COPAY_ID= "COPAY_ID" ;

    /*
    * The index position of the column COPAY_ID in the table.
    */
    public static final int COPAY_ID_IDX = 7 ;

    /**
              * <p> formulary status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FORMULARY_STATUS= "FORMULARY_STATUS" ;

    /*
    * The index position of the column FORMULARY_STATUS in the table.
    */
    public static final int FORMULARY_STATUS_IDX = 8 ;

    /**
              * <p> Type of drug brand, generic, etc. numbers 0-7 or A.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRODUCT_TYPE= "PRODUCT_TYPE" ;

    /*
    * The index position of the column PRODUCT_TYPE in the table.
    */
    public static final int PRODUCT_TYPE_IDX = 9 ;

    /**
              * <p> pharmacy type (R, M, S, L or A).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHARMACY_TYPE= "PHARMACY_TYPE" ;

    /*
    * The index position of the column PHARMACY_TYPE in the table.
    */
    public static final int PHARMACY_TYPE_IDX = 10 ;

    /**
              * <p> Lower range value of out of pocket.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OUT_OF_POCKET_RANGE_START= "OUT_OF_POCKET_RANGE_START" ;

    /*
    * The index position of the column OUT_OF_POCKET_RANGE_START in the table.
    */
    public static final int OUT_OF_POCKET_RANGE_START_IDX = 11 ;

    /**
              * <p> Upper range value of out of pocket.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OUT_OF_POCKET_RANGE_END= "OUT_OF_POCKET_RANGE_END" ;

    /*
    * The index position of the column OUT_OF_POCKET_RANGE_END in the table.
    */
    public static final int OUT_OF_POCKET_RANGE_END_IDX = 12 ;

    /**
              * <p> Flat copay amount.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FLAT_COPAY_AMOUNT= "FLAT_COPAY_AMOUNT" ;

    /*
    * The index position of the column FLAT_COPAY_AMOUNT in the table.
    */
    public static final int FLAT_COPAY_AMOUNT_IDX = 13 ;

    /**
              * <p> Percent copay amount.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PERCENT_COPAY_AMOUNT= "PERCENT_COPAY_AMOUNT" ;

    /*
    * The index position of the column PERCENT_COPAY_AMOUNT in the table.
    */
    public static final int PERCENT_COPAY_AMOUNT_IDX = 14 ;

    /**
              * <p> First copay term F or P.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIRST_COPAY_TERM= "FIRST_COPAY_TERM" ;

    /*
    * The index position of the column FIRST_COPAY_TERM in the table.
    */
    public static final int FIRST_COPAY_TERM_IDX = 15 ;

    /**
              * <p> Minimum copay if % populated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MINIMUM_COPAY= "MINIMUM_COPAY" ;

    /*
    * The index position of the column MINIMUM_COPAY in the table.
    */
    public static final int MINIMUM_COPAY_IDX = 16 ;

    /**
              * <p> Maximum copay if % populated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAXIMUM_COPAY= "MAXIMUM_COPAY" ;

    /*
    * The index position of the column MAXIMUM_COPAY in the table.
    */
    public static final int MAXIMUM_COPAY_IDX = 17 ;

    /**
              * <p> Days supply per copay.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DAYS_SUPPLY_PER_COPAY= "DAYS_SUPPLY_PER_COPAY" ;

    /*
    * The index position of the column DAYS_SUPPLY_PER_COPAY in the table.
    */
    public static final int DAYS_SUPPLY_PER_COPAY_IDX = 18 ;

    /**
              * <p> Copay tier.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COPAY_TIER= "COPAY_TIER" ;

    /*
    * The index position of the column COPAY_TIER in the table.
    */
    public static final int COPAY_TIER_IDX = 19 ;

    /**
              * <p> Maximum copay tier.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAXIMUM_COPAY_TIER= "MAXIMUM_COPAY_TIER" ;

    /*
    * The index position of the column MAXIMUM_COPAY_TIER in the table.
    */
    public static final int MAXIMUM_COPAY_TIER_IDX = 20 ;

}
