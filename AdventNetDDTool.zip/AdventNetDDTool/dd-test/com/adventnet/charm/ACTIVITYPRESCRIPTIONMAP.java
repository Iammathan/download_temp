package com.adventnet.charm;

/** <p> Description of the table <code>ActivityPrescriptionMap</code>.
 *  Column Name and Table Name of  database table  <code>ActivityPrescriptionMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Activity and Prescription. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACTIVITY_LOG_ID}
  * </ul>
 */
 
public final class ACTIVITYPRESCRIPTIONMAP
{
    private ACTIVITYPRESCRIPTIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ActivityPrescriptionMap" ;
    /**
              * <p> Activity Log id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACTIVITY_LOG_ID= "ACTIVITY_LOG_ID" ;

    /*
    * The index position of the column ACTIVITY_LOG_ID in the table.
    */
    public static final int ACTIVITY_LOG_ID_IDX = 1 ;

    /**
              * <p> Medication Id .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_MEDICATION_ID= "PATIENT_MEDICATION_ID" ;

    /*
    * The index position of the column PATIENT_MEDICATION_ID in the table.
    */
    public static final int PATIENT_MEDICATION_ID_IDX = 2 ;

}
