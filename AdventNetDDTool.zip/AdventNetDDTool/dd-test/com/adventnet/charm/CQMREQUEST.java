package com.adventnet.charm;

/** <p> Description of the table <code>CQMRequest</code>.
 *  Column Name and Table Name of  database table  <code>CQMRequest</code> is mapped
 * as constants in this util.</p> 
  To store each rquest of a report generation for the scheduler. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CQM_REQUEST_ID}
  * </ul>
 */
 
public final class CQMREQUEST
{
    private CQMREQUEST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMRequest" ;
    /**
              * <p> Unique id for CQMRequest table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CQM_REQUEST_ID= "CQM_REQUEST_ID" ;

    /*
    * The index position of the column CQM_REQUEST_ID in the table.
    */
    public static final int CQM_REQUEST_ID_IDX = 1 ;

    /**
              * <p> Physician Id for whom report is generated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Time of at which request was sumitted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_REQUEST= "TIME_OF_REQUEST" ;

    /*
    * The index position of the column TIME_OF_REQUEST in the table.
    */
    public static final int TIME_OF_REQUEST_IDX = 3 ;

    /**
              * <p> Staring date of the reporting period.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 4 ;

    /**
              * <p> Ending date of the reporting period.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 5 ;

    /**
              * <p> CQM Measure Ids.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MEASURE_IDS= "MEASURE_IDS" ;

    /*
    * The index position of the column MEASURE_IDS in the table.
    */
    public static final int MEASURE_IDS_IDX = 6 ;

    /**
              * <p> Status of report generation Pending / Completed.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 7 ;

    /**
              * <p> Time of at which report was generated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String GENERATED_TIME= "GENERATED_TIME" ;

    /*
    * The index position of the column GENERATED_TIME in the table.
    */
    public static final int GENERATED_TIME_IDX = 8 ;

}
