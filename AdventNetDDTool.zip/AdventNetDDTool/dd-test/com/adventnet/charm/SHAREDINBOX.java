package com.adventnet.charm;

/** <p> Description of the table <code>SharedInbox</code>.
 *  Column Name and Table Name of  database table  <code>SharedInbox</code> is mapped
 * as constants in this util.</p> 
  Shared Inbox. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SHARED_INBOX_ID}
  * </ul>
 */
 
public final class SHAREDINBOX
{
    private SHAREDINBOX()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SharedInbox" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SHARED_INBOX_ID= "SHARED_INBOX_ID" ;

    /*
    * The index position of the column SHARED_INBOX_ID in the table.
    */
    public static final int SHARED_INBOX_ID_IDX = 1 ;

    /**
              * <p> member Id who is sharing the inbox.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_ID= "FROM_ID" ;

    /*
    * The index position of the column FROM_ID in the table.
    */
    public static final int FROM_ID_IDX = 2 ;

    /**
              * <p> share to members.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_ID= "TO_ID" ;

    /*
    * The index position of the column TO_ID in the table.
    */
    public static final int TO_ID_IDX = 3 ;

}
