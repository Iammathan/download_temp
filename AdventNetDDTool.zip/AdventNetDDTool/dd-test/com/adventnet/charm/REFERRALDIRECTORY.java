package com.adventnet.charm;

/** <p> Description of the table <code>ReferralDirectory</code>.
 *  Column Name and Table Name of  database table  <code>ReferralDirectory</code> is mapped
 * as constants in this util.</p> 
  Details about Referral providers. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REFERRAL_ID}
  * </ul>
 */
 
public final class REFERRALDIRECTORY
{
    private REFERRALDIRECTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ReferralDirectory" ;
    /**
              * <p> Unique identifier for Referral.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFERRAL_ID= "REFERRAL_ID" ;

    /*
    * The index position of the column REFERRAL_ID in the table.
    */
    public static final int REFERRAL_ID_IDX = 1 ;

    /**
              * <p> First Name of Referral.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 2 ;

    /**
              * <p> Last Name of Referral.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 3 ;

    /**
              * <p> Middle Name of Referral.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIDDLE_NAME= "MIDDLE_NAME" ;

    /*
    * The index position of the column MIDDLE_NAME in the table.
    */
    public static final int MIDDLE_NAME_IDX = 4 ;

    /**
              * <p> Email Id of practice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMAILID= "EMAILID" ;

    /*
    * The index position of the column EMAILID in the table.
    */
    public static final int EMAILID_IDX = 5 ;

    /**
              * <p> Landline number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHONE= "PHONE" ;

    /*
    * The index position of the column PHONE in the table.
    */
    public static final int PHONE_IDX = 6 ;

    /**
              * <p> Provider LandLine number(Phone Number in UI).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHONE_EXTENSION_NO= "PHONE_EXTENSION_NO" ;

    /*
    * The index position of the column PHONE_EXTENSION_NO in the table.
    */
    public static final int PHONE_EXTENSION_NO_IDX = 7 ;

    /**
              * <p> Fax number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FAX= "FAX" ;

    /*
    * The index position of the column FAX in the table.
    */
    public static final int FAX_IDX = 8 ;

    /**
              * <p> Provider website.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String WEBSITE= "WEBSITE" ;

    /*
    * The index position of the column WEBSITE in the table.
    */
    public static final int WEBSITE_IDX = 9 ;

    /**
              * <p> Direct address for referring providers in other practice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DIRECT_ADDRESS= "DIRECT_ADDRESS" ;

    /*
    * The index position of the column DIRECT_ADDRESS in the table.
    */
    public static final int DIRECT_ADDRESS_IDX = 10 ;

    /**
              * <p> Speciality of Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIALITY= "SPECIALITY" ;

    /*
    * The index position of the column SPECIALITY in the table.
    */
    public static final int SPECIALITY_IDX = 11 ;

    /**
              * <p> Speciality of Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRACTICE_NAME= "PRACTICE_NAME" ;

    /*
    * The index position of the column PRACTICE_NAME in the table.
    */
    public static final int PRACTICE_NAME_IDX = 12 ;

    /**
              * <p> Door number and street details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDRESS_LINE_1= "ADDRESS_LINE_1" ;

    /*
    * The index position of the column ADDRESS_LINE_1 in the table.
    */
    public static final int ADDRESS_LINE_1_IDX = 13 ;

    /**
              * <p> Line 2 of the Address.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDRESS_LINE_2= "ADDRESS_LINE_2" ;

    /*
    * The index position of the column ADDRESS_LINE_2 in the table.
    */
    public static final int ADDRESS_LINE_2_IDX = 14 ;

    /**
              * <p> Name of city.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CITY= "CITY" ;

    /*
    * The index position of the column CITY in the table.
    */
    public static final int CITY_IDX = 15 ;

    /**
              * <p> Name of the state.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATE= "STATE" ;

    /*
    * The index position of the column STATE in the table.
    */
    public static final int STATE_IDX = 16 ;

    /**
              * <p> Name of the country.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY= "COUNTRY" ;

    /*
    * The index position of the column COUNTRY in the table.
    */
    public static final int COUNTRY_IDX = 17 ;

    /**
              * <p> Postal code / PIN code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String POSTALCODE= "POSTALCODE" ;

    /*
    * The index position of the column POSTALCODE in the table.
    */
    public static final int POSTALCODE_IDX = 18 ;

    /**
              * <p> NPI number of Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 19 ;

    /**
              * <p> Id Qualifier of Referring Provider.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 20 ;

    /**
              * <p> Referring Provider Id know as NonNPI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 21 ;

    /**
              * <p> Notes about Providers.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 22 ;

    /**
              * <p> referral is active or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 23 ;

    /**
              * <p> Prefix of the Referral Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PREFIX= "PREFIX" ;

    /*
    * The index position of the column PREFIX in the table.
    */
    public static final int PREFIX_IDX = 24 ;

}
