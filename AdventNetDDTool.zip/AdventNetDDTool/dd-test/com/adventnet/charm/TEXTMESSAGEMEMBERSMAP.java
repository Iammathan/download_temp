package com.adventnet.charm;

/** <p> Description of the table <code>TextMessageMembersMap</code>.
 *  Column Name and Table Name of  database table  <code>TextMessageMembersMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Text Message and members. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TEXT_MESSAGE_MAP_ID}
  * </ul>
 */
 
public final class TEXTMESSAGEMEMBERSMAP
{
    private TEXTMESSAGEMEMBERSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TextMessageMembersMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TEXT_MESSAGE_MAP_ID= "TEXT_MESSAGE_MAP_ID" ;

    /*
    * The index position of the column TEXT_MESSAGE_MAP_ID in the table.
    */
    public static final int TEXT_MESSAGE_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of the Text Message.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEXT_MESSAGE_ID= "TEXT_MESSAGE_ID" ;

    /*
    * The index position of the column TEXT_MESSAGE_ID in the table.
    */
    public static final int TEXT_MESSAGE_ID_IDX = 2 ;

    /**
              * <p> Identifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

}
