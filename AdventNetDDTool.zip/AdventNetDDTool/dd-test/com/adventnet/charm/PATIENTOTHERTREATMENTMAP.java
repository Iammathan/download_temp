package com.adventnet.charm;

/** <p> Description of the table <code>PatientOtherTreatmentMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientOtherTreatmentMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and OtherTreatment. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #OTHER_TREATMENT_MAP_ID}
  * </ul>
 */
 
public final class PATIENTOTHERTREATMENTMAP
{
    private PATIENTOTHERTREATMENTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientOtherTreatmentMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OTHER_TREATMENT_MAP_ID= "OTHER_TREATMENT_MAP_ID" ;

    /*
    * The index position of the column OTHER_TREATMENT_MAP_ID in the table.
    */
    public static final int OTHER_TREATMENT_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Name of the Treatment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TREATMENT_NAME= "TREATMENT_NAME" ;

    /*
    * The index position of the column TREATMENT_NAME in the table.
    */
    public static final int TREATMENT_NAME_IDX = 3 ;

    /**
              * <p> Start time of the scaling.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_SCALING= "FROM_SCALING" ;

    /*
    * The index position of the column FROM_SCALING in the table.
    */
    public static final int FROM_SCALING_IDX = 4 ;

    /**
              * <p> End time of the scaling.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_SCALING= "TO_SCALING" ;

    /*
    * The index position of the column TO_SCALING in the table.
    */
    public static final int TO_SCALING_IDX = 5 ;

    /**
              * <p> Type of the Scale.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SCALE_TYPE= "SCALE_TYPE" ;

    /*
    * The index position of the column SCALE_TYPE in the table.
    */
    public static final int SCALE_TYPE_IDX = 6 ;

    /**
              * <p> Details of the Custom program".</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TREATMENT_DETAILS= "TREATMENT_DETAILS" ;

    /*
    * The index position of the column TREATMENT_DETAILS in the table.
    */
    public static final int TREATMENT_DETAILS_IDX = 7 ;

    /**
              * <p> To check whether the custom program is de activated or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 8 ;

}
