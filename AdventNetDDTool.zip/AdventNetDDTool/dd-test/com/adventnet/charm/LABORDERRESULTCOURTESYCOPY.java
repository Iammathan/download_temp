package com.adventnet.charm;

/** <p> Description of the table <code>LabOrderResultCourtesyCopy</code>.
 *  Column Name and Table Name of  database table  <code>LabOrderResultCourtesyCopy</code> is mapped
 * as constants in this util.</p> 
  Specific to LabCorp Orders. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ORDER_COURTESY_COPY_ID}
  * </ul>
 */
 
public final class LABORDERRESULTCOURTESYCOPY
{
    private LABORDERRESULTCOURTESYCOPY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabOrderResultCourtesyCopy" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORDER_COURTESY_COPY_ID= "ORDER_COURTESY_COPY_ID" ;

    /*
    * The index position of the column ORDER_COURTESY_COPY_ID in the table.
    */
    public static final int ORDER_COURTESY_COPY_ID_IDX = 1 ;

    /**
              * <p> Lab Order Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ORDER_ID= "LAB_ORDER_ID" ;

    /*
    * The index position of the column LAB_ORDER_ID in the table.
    */
    public static final int LAB_ORDER_ID_IDX = 2 ;

    /**
              * <p> Specimen Type Details code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COURTESY_COPY_DESTINATION= "COURTESY_COPY_DESTINATION" ;

    /*
    * The index position of the column COURTESY_COPY_DESTINATION in the table.
    */
    public static final int COURTESY_COPY_DESTINATION_IDX = 3 ;

    /**
              * <p> Specimen Type Details desc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COURTESY_COPY_VALUE= "COURTESY_COPY_VALUE" ;

    /*
    * The index position of the column COURTESY_COPY_VALUE in the table.
    */
    public static final int COURTESY_COPY_VALUE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>70</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FAX_RECIPIENT_NAME= "FAX_RECIPIENT_NAME" ;

    /*
    * The index position of the column FAX_RECIPIENT_NAME in the table.
    */
    public static final int FAX_RECIPIENT_NAME_IDX = 5 ;

}
