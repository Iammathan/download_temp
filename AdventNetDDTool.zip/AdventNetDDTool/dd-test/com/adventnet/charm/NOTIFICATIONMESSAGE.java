package com.adventnet.charm;

/** <p> Description of the table <code>NotificationMessage</code>.
 *  Column Name and Table Name of  database table  <code>NotificationMessage</code> is mapped
 * as constants in this util.</p> 
  Pincode details for Indian Practices. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #NOTIFICATION_MESSAGE_ID}
  * </ul>
 */
 
public final class NOTIFICATIONMESSAGE
{
    private NOTIFICATIONMESSAGE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "NotificationMessage" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NOTIFICATION_MESSAGE_ID= "NOTIFICATION_MESSAGE_ID" ;

    /*
    * The index position of the column NOTIFICATION_MESSAGE_ID in the table.
    */
    public static final int NOTIFICATION_MESSAGE_ID_IDX = 1 ;

    /**
              * <p> Notification for module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_TYPE= "NOTIFICATION_TYPE" ;

    /*
    * The index position of the column NOTIFICATION_TYPE in the table.
    */
    public static final int NOTIFICATION_TYPE_IDX = 2 ;

    /**
              * <p> Notification for module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MODULE= "MODULE" ;

    /*
    * The index position of the column MODULE in the table.
    */
    public static final int MODULE_IDX = 3 ;

    /**
              * <p> Message to be displayed to the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MESSAGE= "MESSAGE" ;

    /*
    * The index position of the column MESSAGE in the table.
    */
    public static final int MESSAGE_IDX = 4 ;

    /**
              * <p> Notification created by member... If its null, then system generated message.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 5 ;

    /**
              * <p> Date when the notification was created.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CREATED_DATE= "CREATED_DATE" ;

    /*
    * The index position of the column CREATED_DATE in the table.
    */
    public static final int CREATED_DATE_IDX = 6 ;

    /**
              * <p> url to be opened.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NAV_URL= "NAV_URL" ;

    /*
    * The index position of the column NAV_URL in the table.
    */
    public static final int NAV_URL_IDX = 7 ;

    /**
              * <p> js method to be called.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String JS_METHOD= "JS_METHOD" ;

    /*
    * The index position of the column JS_METHOD in the table.
    */
    public static final int JS_METHOD_IDX = 8 ;

}
