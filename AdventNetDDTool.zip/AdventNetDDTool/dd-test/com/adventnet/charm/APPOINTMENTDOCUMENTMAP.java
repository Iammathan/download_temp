package com.adventnet.charm;

/** <p> Description of the table <code>AppointmentDocumentMap</code>.
 *  Column Name and Table Name of  database table  <code>AppointmentDocumentMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Appointment and uploaded files. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #APPOINTMENT_ID}
  * <li> {@link #FILE_PATH}
  * </ul>
 */
 
public final class APPOINTMENTDOCUMENTMAP
{
    private APPOINTMENTDOCUMENTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AppointmentDocumentMap" ;
    /**
              * <p>  Identifier  of Appointment.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 1 ;

    /**
              * <p> Identifier of file.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_PATH= "FILE_PATH" ;

    /*
    * The index position of the column FILE_PATH in the table.
    */
    public static final int FILE_PATH_IDX = 2 ;

    /**
              * <p> Identifier of file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESOURCE_NAME= "RESOURCE_NAME" ;

    /*
    * The index position of the column RESOURCE_NAME in the table.
    */
    public static final int RESOURCE_NAME_IDX = 3 ;

    /**
              * <p> Identifier of file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESOURCE_TYPE= "RESOURCE_TYPE" ;

    /*
    * The index position of the column RESOURCE_TYPE in the table.
    */
    public static final int RESOURCE_TYPE_IDX = 4 ;

}
