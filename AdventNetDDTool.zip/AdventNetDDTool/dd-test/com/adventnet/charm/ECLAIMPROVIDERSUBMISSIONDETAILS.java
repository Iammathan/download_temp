package com.adventnet.charm;

/** <p> Description of the table <code>EClaimProviderSubmissionDetails</code>.
 *  Column Name and Table Name of  database table  <code>EClaimProviderSubmissionDetails</code> is mapped
 * as constants in this util.</p> 
  
            This table is to keep provider details such rendering provider(31), billing provider(33) and line item provider(24J) when the claimis submitted. This helps in fetching claim submission usage by provider. Values from ClaimCompleteDetails and this table need not match. Values stored here are the values sent while submitting claims.
        . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ECLAIM_PROVIDER_SUBMISSION_ID}
  * </ul>
 */
 
public final class ECLAIMPROVIDERSUBMISSIONDETAILS
{
    private ECLAIMPROVIDERSUBMISSIONDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EClaimProviderSubmissionDetails" ;
    /**
              * <p> Unique ID(SAS KEY - PK) assigned by Mickey.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_PROVIDER_SUBMISSION_ID= "ECLAIM_PROVIDER_SUBMISSION_ID" ;

    /*
    * The index position of the column ECLAIM_PROVIDER_SUBMISSION_ID in the table.
    */
    public static final int ECLAIM_PROVIDER_SUBMISSION_ID_IDX = 1 ;

    /**
              * <p> ClaimCompleteDetails.CLAIM_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> EClaimTransactionVsClaimMap.ECLAIM_TXN_CLAIM_MAP_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ECLAIM_TXN_CLAIM_MAP_ID= "ECLAIM_TXN_CLAIM_MAP_ID" ;

    /*
    * The index position of the column ECLAIM_TXN_CLAIM_MAP_ID in the table.
    */
    public static final int ECLAIM_TXN_CLAIM_MAP_ID_IDX = 3 ;

    /**
              * <p> EClaimTransactions.ECLAIM_TRANSACTION_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ECLAIM_TRANSACTION_ID= "ECLAIM_TRANSACTION_ID" ;

    /*
    * The index position of the column ECLAIM_TRANSACTION_ID in the table.
    */
    public static final int ECLAIM_TRANSACTION_ID_IDX = 4 ;

    /**
              * <p> Claim Submission Time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_SUBMISSION_TIME= "CLAIM_SUBMISSION_TIME" ;

    /*
    * The index position of the column CLAIM_SUBMISSION_TIME in the table.
    */
    public static final int CLAIM_SUBMISSION_TIME_IDX = 5 ;

    /**
              * <p> PracticeMembersList.MEMBER_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_RENDERING_PROVIDER_ID= "CLAIM_RENDERING_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_RENDERING_PROVIDER_ID in the table.
    */
    public static final int CLAIM_RENDERING_PROVIDER_ID_IDX = 6 ;

    /**
              * <p> Rendering Provider Name - Box #31.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_RENDERING_PROVIDER_NAME= "CLAIM_RENDERING_PROVIDER_NAME" ;

    /*
    * The index position of the column CLAIM_RENDERING_PROVIDER_NAME in the table.
    */
    public static final int CLAIM_RENDERING_PROVIDER_NAME_IDX = 7 ;

    /**
              * <p> Rendering Provider NPI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_RENDERING_PROVIDER_NPI= "CLAIM_RENDERING_PROVIDER_NPI" ;

    /*
    * The index position of the column CLAIM_RENDERING_PROVIDER_NPI in the table.
    */
    public static final int CLAIM_RENDERING_PROVIDER_NPI_IDX = 8 ;

    /**
              * <p> PracticeMembersList.MEMBER_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_BILLING_PROVIDER_ID= "CLAIM_BILLING_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_BILLING_PROVIDER_ID in the table.
    */
    public static final int CLAIM_BILLING_PROVIDER_ID_IDX = 9 ;

    /**
              * <p> Billing Provider Name - Box #33.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_BILLING_PROVIDER_NAME= "CLAIM_BILLING_PROVIDER_NAME" ;

    /*
    * The index position of the column CLAIM_BILLING_PROVIDER_NAME in the table.
    */
    public static final int CLAIM_BILLING_PROVIDER_NAME_IDX = 10 ;

    /**
              * <p> Billing Provider NPI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_BILLING_PROVIDER_NPI= "CLAIM_BILLING_PROVIDER_NPI" ;

    /*
    * The index position of the column CLAIM_BILLING_PROVIDER_NPI in the table.
    */
    public static final int CLAIM_BILLING_PROVIDER_NPI_IDX = 11 ;

    /**
              * <p> PracticeMembersList.MEMBER_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_LINE_ITEM_PROVIDER_ID= "CLAIM_LINE_ITEM_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_LINE_ITEM_PROVIDER_ID in the table.
    */
    public static final int CLAIM_LINE_ITEM_PROVIDER_ID_IDX = 12 ;

    /**
              * <p> Line Item Provider Name - Box #24J.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_LINE_ITEM_PROVIDER_NAME= "CLAIM_LINE_ITEM_PROVIDER_NAME" ;

    /*
    * The index position of the column CLAIM_LINE_ITEM_PROVIDER_NAME in the table.
    */
    public static final int CLAIM_LINE_ITEM_PROVIDER_NAME_IDX = 13 ;

    /**
              * <p> Line Item Provider NPI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_LINE_ITEM_PROVIDER_NPI= "CLAIM_LINE_ITEM_PROVIDER_NPI" ;

    /*
    * The index position of the column CLAIM_LINE_ITEM_PROVIDER_NPI in the table.
    */
    public static final int CLAIM_LINE_ITEM_PROVIDER_NPI_IDX = 14 ;

}
