package com.adventnet.charm;

/** <p> Description of the table <code>EHRAuditAdditionalProps</code>.
 *  Column Name and Table Name of  database table  <code>EHRAuditAdditionalProps</code> is mapped
 * as constants in this util.</p> 
  Additional Message for Audits will be saved here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROP_ID}
  * </ul>
 */
 
public final class EHRAUDITADDITIONALPROPS
{
    private EHRAUDITADDITIONALPROPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EHRAuditAdditionalProps" ;
    /**
              * <p> Unique identifier for Audit Additional Props.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROP_ID= "PROP_ID" ;

    /*
    * The index position of the column PROP_ID in the table.
    */
    public static final int PROP_ID_IDX = 1 ;

    /**
              * <p> Additional property name for Audit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROP_NAME= "PROP_NAME" ;

    /*
    * The index position of the column PROP_NAME in the table.
    */
    public static final int PROP_NAME_IDX = 2 ;

    /**
              * <p> Additional property value for Audit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROP_VALUE= "PROP_VALUE" ;

    /*
    * The index position of the column PROP_VALUE in the table.
    */
    public static final int PROP_VALUE_IDX = 3 ;

    /**
              * <p> Audit Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AUDIT_ID= "AUDIT_ID" ;

    /*
    * The index position of the column AUDIT_ID in the table.
    */
    public static final int AUDIT_ID_IDX = 4 ;

}
