package com.adventnet.charm;

/** <p> Description of the table <code>PatientProgramData</code>.
 *  Column Name and Table Name of  database table  <code>PatientProgramData</code> is mapped
 * as constants in this util.</p> 
  Patient's data for Target. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PROGRAM_ID}
  * <li> {@link #PATIENT_ID}
  * </ul>
 */
 
public final class PATIENTPROGRAMDATA
{
    private PATIENTPROGRAMDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientProgramData" ;
    /**
              * <p> Identifier of a Target.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROGRAM_ID= "PROGRAM_ID" ;

    /*
    * The index position of the column PROGRAM_ID in the table.
    */
    public static final int PROGRAM_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Introduction Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INTRO_DATE= "INTRO_DATE" ;

    /*
    * The index position of the column INTRO_DATE in the table.
    */
    public static final int INTRO_DATE_IDX = 3 ;

    /**
              * <p> Mastered Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MASTERED_DATE= "MASTERED_DATE" ;

    /*
    * The index position of the column MASTERED_DATE in the table.
    */
    public static final int MASTERED_DATE_IDX = 4 ;

}
