package com.adventnet.charm;

/** <p> Description of the table <code>Mail_Server</code>.
 *  Column Name and Table Name of  database table  <code>Mail_Server</code> is mapped
 * as constants in this util.</p> 
  Mail Server . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SERVER_ID}
  * </ul>
 */
 
public final class MAIL_SERVER
{
    private MAIL_SERVER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Mail_Server" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVER_ID= "SERVER_ID" ;

    /*
    * The index position of the column SERVER_ID in the table.
    */
    public static final int SERVER_ID_IDX = 1 ;

    /**
              * <p> Default Server.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 2 ;

    /**
              * <p> Name of the server.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SERVER_NAME= "SERVER_NAME" ;

    /*
    * The index position of the column SERVER_NAME in the table.
    */
    public static final int SERVER_NAME_IDX = 3 ;

    /**
              * <p> Mail Server Port.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PORT= "PORT" ;

    /*
    * The index position of the column PORT in the table.
    */
    public static final int PORT_IDX = 4 ;

    /**
              * <p> Username.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USER_NAME= "USER_NAME" ;

    /*
    * The index position of the column USER_NAME in the table.
    */
    public static final int USER_NAME_IDX = 5 ;

    /**
              * <p> Password.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PASSWORD= "PASSWORD" ;

    /*
    * The index position of the column PASSWORD in the table.
    */
    public static final int PASSWORD_IDX = 6 ;

}
