package com.adventnet.charm;

/** <p> Description of the table <code>LabRecordValueDetails</code>.
 *  Column Name and Table Name of  database table  <code>LabRecordValueDetails</code> is mapped
 * as constants in this util.</p> 
  Stores the additional information of parameter results in name-value pair. Especially handling LabCorp system generated result messages.. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #LAB_RECORD_VALUE_ID}
  * <li> {@link #NAME}
  * </ul>
 */
 
public final class LABRECORDVALUEDETAILS
{
    private LABRECORDVALUEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabRecordValueDetails" ;
    /**
              * <p> medical record value id.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_RECORD_VALUE_ID= "LAB_RECORD_VALUE_ID" ;

    /*
    * The index position of the column LAB_RECORD_VALUE_ID in the table.
    */
    public static final int LAB_RECORD_VALUE_ID_IDX = 1 ;

    /**
              * <p> name.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 2 ;

    /**
              * <p> value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VALUE= "VALUE" ;

    /*
    * The index position of the column VALUE in the table.
    */
    public static final int VALUE_IDX = 3 ;

}
