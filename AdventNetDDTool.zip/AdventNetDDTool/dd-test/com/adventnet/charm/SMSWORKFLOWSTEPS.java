package com.adventnet.charm;

/** <p> Description of the table <code>SMSWorkflowSteps</code>.
 *  Column Name and Table Name of  database table  <code>SMSWorkflowSteps</code> is mapped
 * as constants in this util.</p> 
  Steps in the workflow (publicspace). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SMS_WORKFLOW_STEP_ID}
  * </ul>
 */
 
public final class SMSWORKFLOWSTEPS
{
    private SMSWORKFLOWSTEPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SMSWorkflowSteps" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SMS_WORKFLOW_STEP_ID= "SMS_WORKFLOW_STEP_ID" ;

    /*
    * The index position of the column SMS_WORKFLOW_STEP_ID in the table.
    */
    public static final int SMS_WORKFLOW_STEP_ID_IDX = 1 ;

    /**
              * <p> Key in SMS.properties.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STEP_NAME= "STEP_NAME" ;

    /*
    * The index position of the column STEP_NAME in the table.
    */
    public static final int STEP_NAME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PREV_STEP_RESPONSE= "PREV_STEP_RESPONSE" ;

    /*
    * The index position of the column PREV_STEP_RESPONSE in the table.
    */
    public static final int PREV_STEP_RESPONSE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PREV_STEP_ID= "PREV_STEP_ID" ;

    /*
    * The index position of the column PREV_STEP_ID in the table.
    */
    public static final int PREV_STEP_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SMS_WORKFLOW_ID= "SMS_WORKFLOW_ID" ;

    /*
    * The index position of the column SMS_WORKFLOW_ID in the table.
    */
    public static final int SMS_WORKFLOW_ID_IDX = 5 ;

}
