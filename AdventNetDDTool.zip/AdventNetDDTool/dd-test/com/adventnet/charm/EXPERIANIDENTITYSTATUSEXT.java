package com.adventnet.charm;

/** <p> Description of the table <code>ExperianIdentityStatusExt</code>.
 *  Column Name and Table Name of  database table  <code>ExperianIdentityStatusExt</code> is mapped
 * as constants in this util.</p> 
   experian identity status . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXPERIANEXT_ID}
  * </ul>
 */
 
public final class EXPERIANIDENTITYSTATUSEXT
{
    private EXPERIANIDENTITYSTATUSEXT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ExperianIdentityStatusExt" ;
    /**
              * <p> Experian identity.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXPERIANEXT_ID= "EXPERIANEXT_ID" ;

    /*
    * The index position of the column EXPERIANEXT_ID in the table.
    */
    public static final int EXPERIANEXT_ID_IDX = 1 ;

    /**
              * <p> Experian identity.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXPERIAN_ID= "EXPERIAN_ID" ;

    /*
    * The index position of the column EXPERIAN_ID in the table.
    */
    public static final int EXPERIAN_ID_IDX = 2 ;

    /**
              * <p>  Session identity .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>90</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SESSION_ID= "SESSION_ID" ;

    /*
    * The index position of the column SESSION_ID in the table.
    */
    public static final int SESSION_ID_IDX = 3 ;

    /**
              * <p>  Session identity .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 4 ;

    /**
              * <p>  Session identity .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CODE= "CODE" ;

    /*
    * The index position of the column CODE in the table.
    */
    public static final int CODE_IDX = 5 ;

    /**
              * <p>  Session identity .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 6 ;

    /**
              * <p>  entry for time of response gettiing from experian .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 7 ;

}
