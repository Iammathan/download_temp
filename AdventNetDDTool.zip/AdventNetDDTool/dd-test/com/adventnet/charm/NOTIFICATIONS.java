package com.adventnet.charm;

/** <p> Description of the table <code>Notifications</code>.
 *  Column Name and Table Name of  database table  <code>Notifications</code> is mapped
 * as constants in this util.</p> 
  Notifications for Patient from EHR. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #NOTIFICATION_ID}
  * </ul>
 */
 
public final class NOTIFICATIONS
{
    private NOTIFICATIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Notifications" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NOTIFICATION_ID= "NOTIFICATION_ID" ;

    /*
    * The index position of the column NOTIFICATION_ID in the table.
    */
    public static final int NOTIFICATION_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_MAPPING_ID= "NOTIFICATION_MAPPING_ID" ;

    /*
    * The index position of the column NOTIFICATION_MAPPING_ID in the table.
    */
    public static final int NOTIFICATION_MAPPING_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Identifier of Practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 4 ;

    /**
              * <p> Details of the notification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_MESSAGE= "NOTIFICATION_MESSAGE" ;

    /*
    * The index position of the column NOTIFICATION_MESSAGE in the table.
    */
    public static final int NOTIFICATION_MESSAGE_IDX = 5 ;

    /**
              * <p> Type of the notification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_TYPE= "NOTIFICATION_TYPE" ;

    /*
    * The index position of the column NOTIFICATION_TYPE in the table.
    */
    public static final int NOTIFICATION_TYPE_IDX = 6 ;

    /**
              * <p> Time at which notification is shared.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_TIME= "NOTIFICATION_TIME" ;

    /*
    * The index position of the column NOTIFICATION_TIME in the table.
    */
    public static final int NOTIFICATION_TIME_IDX = 7 ;

    /**
              * <p> Status of the notification.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_READ= "IS_READ" ;

    /*
    * The index position of the column IS_READ in the table.
    */
    public static final int IS_READ_IDX = 8 ;

}
