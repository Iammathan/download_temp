package com.adventnet.charm;

/** <p> Description of the table <code>ShareURL</code>.
 *  Column Name and Table Name of  database table  <code>ShareURL</code> is mapped
 * as constants in this util.</p> 
  Patient_space for contacts. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #URL_ID}
  * </ul>
 */
 
public final class SHAREURL
{
    private SHAREURL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ShareURL" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String URL_ID= "URL_ID" ;

    /*
    * The index position of the column URL_ID in the table.
    */
    public static final int URL_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONTACT_ID= "CONTACT_ID" ;

    /*
    * The index position of the column CONTACT_ID in the table.
    */
    public static final int CONTACT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_ON= "CREATED_ON" ;

    /*
    * The index position of the column CREATED_ON in the table.
    */
    public static final int CREATED_ON_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXPIRE_ON= "EXPIRE_ON" ;

    /*
    * The index position of the column EXPIRE_ON in the table.
    */
    public static final int EXPIRE_ON_IDX = 4 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACCESS_LIMIT= "ACCESS_LIMIT" ;

    /*
    * The index position of the column ACCESS_LIMIT in the table.
    */
    public static final int ACCESS_LIMIT_IDX = 5 ;

    /**
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_EXPIRED= "IS_EXPIRED" ;

    /*
    * The index position of the column IS_EXPIRED in the table.
    */
    public static final int IS_EXPIRED_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXPIRY_REASON= "EXPIRY_REASON" ;

    /*
    * The index position of the column EXPIRY_REASON in the table.
    */
    public static final int EXPIRY_REASON_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 8 ;

    /**
              * <p> Patient's Account ZUID in accounts.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROXY_ZUID= "PROXY_ZUID" ;

    /*
    * The index position of the column PROXY_ZUID in the table.
    */
    public static final int PROXY_ZUID_IDX = 9 ;

}
