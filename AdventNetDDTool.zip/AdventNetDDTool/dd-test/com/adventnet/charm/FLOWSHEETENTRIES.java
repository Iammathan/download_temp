package com.adventnet.charm;

/** <p> Description of the table <code>FlowsheetEntries</code>.
 *  Column Name and Table Name of  database table  <code>FlowsheetEntries</code> is mapped
 * as constants in this util.</p> 
  Table for flowsheet's list of entries. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FLOW_SHEET_ENTRY_ID}
  * </ul>
 */
 
public final class FLOWSHEETENTRIES
{
    private FLOWSHEETENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FlowsheetEntries" ;
    /**
              * <p> Unique Id for each param of a flowsheet.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FLOW_SHEET_ENTRY_ID= "FLOW_SHEET_ENTRY_ID" ;

    /*
    * The index position of the column FLOW_SHEET_ENTRY_ID in the table.
    */
    public static final int FLOW_SHEET_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Unique Id from Flowsheets table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FLOW_SHEET_ID= "FLOW_SHEET_ID" ;

    /*
    * The index position of the column FLOW_SHEET_ID in the table.
    */
    public static final int FLOW_SHEET_ID_IDX = 2 ;

    /**
              * <p> Name of the param in the flowsheet.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 3 ;

    /**
              * <p> Type of the param i.e VITAL/LAB/CUSTOM/HEADER.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 4 ;

    /**
              * <p> Position of the param in the flowsheet. Used for Ordering.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 5 ;

}
