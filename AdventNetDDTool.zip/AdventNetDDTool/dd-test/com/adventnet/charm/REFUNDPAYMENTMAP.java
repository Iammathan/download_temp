package com.adventnet.charm;

/** <p> Description of the table <code>RefundPaymentMap</code>.
 *  Column Name and Table Name of  database table  <code>RefundPaymentMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REFUND_PAYMENT_MAP_ID}
  * </ul>
 */
 
public final class REFUNDPAYMENTMAP
{
    private REFUNDPAYMENTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RefundPaymentMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFUND_PAYMENT_MAP_ID= "REFUND_PAYMENT_MAP_ID" ;

    /*
    * The index position of the column REFUND_PAYMENT_MAP_ID in the table.
    */
    public static final int REFUND_PAYMENT_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REFUND_ID= "REFUND_ID" ;

    /*
    * The index position of the column REFUND_ID in the table.
    */
    public static final int REFUND_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 3 ;

}
