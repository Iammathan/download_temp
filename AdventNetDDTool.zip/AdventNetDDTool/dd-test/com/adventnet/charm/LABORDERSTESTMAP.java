package com.adventnet.charm;

/** <p> Description of the table <code>LabOrdersTestMap</code>.
 *  Column Name and Table Name of  database table  <code>LabOrdersTestMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Orders and Tests. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ORDER_TEST_MAP_ID}
  * </ul>
 */
 
public final class LABORDERSTESTMAP
{
    private LABORDERSTESTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabOrdersTestMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORDER_TEST_MAP_ID= "ORDER_TEST_MAP_ID" ;

    /*
    * The index position of the column ORDER_TEST_MAP_ID in the table.
    */
    public static final int ORDER_TEST_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ORDER_ID= "LAB_ORDER_ID" ;

    /*
    * The index position of the column LAB_ORDER_ID in the table.
    */
    public static final int LAB_ORDER_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ID= "MEDICAL_RECORD_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ID in the table.
    */
    public static final int MEDICAL_RECORD_ID_IDX = 3 ;

    /**
              * <p> Lab Id .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 4 ;

    /**
              * <p> Status of the Test Result - 1 -> Completed / 0 -> Pending.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_CONDITION_TEMPERATURE= "SPECIMEN_CONDITION_TEMPERATURE" ;

    /*
    * The index position of the column SPECIMEN_CONDITION_TEMPERATURE in the table.
    */
    public static final int SPECIMEN_CONDITION_TEMPERATURE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_TYPE= "TEST_TYPE" ;

    /*
    * The index position of the column TEST_TYPE in the table.
    */
    public static final int TEST_TYPE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 8 ;

    /**
              * <p> Lab Record Id  from LabRecordMap table of public space. This will be used in identifying the corresponding lab record.May not be available for the older data entries..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_RECORD_ID= "LAB_RECORD_ID" ;

    /*
    * The index position of the column LAB_RECORD_ID in the table.
    */
    public static final int LAB_RECORD_ID_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PROFILE_INDICATOR= "PROFILE_INDICATOR" ;

    /*
    * The index position of the column PROFILE_INDICATOR in the table.
    */
    public static final int PROFILE_INDICATOR_IDX = 10 ;

    /**
              * <p> Z-segment map to AOE.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String Z_SEGMENT_AOE_MAP= "Z_SEGMENT_AOE_MAP" ;

    /*
    * The index position of the column Z_SEGMENT_AOE_MAP in the table.
    */
    public static final int Z_SEGMENT_AOE_MAP_IDX = 11 ;

    /**
              * <p> specimen type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_TYPE= "SPECIMEN_TYPE" ;

    /*
    * The index position of the column SPECIMEN_TYPE in the table.
    */
    public static final int SPECIMEN_TYPE_IDX = 12 ;

    /**
              * <p> Name of LAB.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_NAME= "LAB_NAME" ;

    /*
    * The index position of the column LAB_NAME in the table.
    */
    public static final int LAB_NAME_IDX = 13 ;

    /**
              * <p> Name of MedicalRecord.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEDICAL_RECORD_NAME= "MEDICAL_RECORD_NAME" ;

    /*
    * The index position of the column MEDICAL_RECORD_NAME in the table.
    */
    public static final int MEDICAL_RECORD_NAME_IDX = 14 ;

    /**
              * <p> Test code specific to the associated lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_CODE= "LAB_RECORD_CODE" ;

    /*
    * The index position of the column LAB_RECORD_CODE in the table.
    */
    public static final int LAB_RECORD_CODE_IDX = 15 ;

    /**
              * <p> Name of Depatment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DEPARTMENT_NAME= "DEPARTMENT_NAME" ;

    /*
    * The index position of the column DEPARTMENT_NAME in the table.
    */
    public static final int DEPARTMENT_NAME_IDX = 16 ;

    /**
              * <p> test description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_DESCRIPTION= "TEST_DESCRIPTION" ;

    /*
    * The index position of the column TEST_DESCRIPTION in the table.
    */
    public static final int TEST_DESCRIPTION_IDX = 17 ;

}
