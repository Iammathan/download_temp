package com.adventnet.charm;

/** <p> Description of the table <code>ImageResultPatientDetails</code>.
 *  Column Name and Table Name of  database table  <code>ImageResultPatientDetails</code> is mapped
 * as constants in this util.</p> 
  ImageResultPatientDetails table is used to store image test results . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_RESULT_PATIENT_ID}
  * </ul>
 */
 
public final class IMAGERESULTPATIENTDETAILS
{
    private IMAGERESULTPATIENTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageResultPatientDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_RESULT_PATIENT_ID= "IMAGE_RESULT_PATIENT_ID" ;

    /*
    * The index position of the column IMAGE_RESULT_PATIENT_ID in the table.
    */
    public static final int IMAGE_RESULT_PATIENT_ID_IDX = 1 ;

    /**
              * <p> IMAGE TEST RESULT PATIENT ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_RESULT_MAP_PATIENT_ID= "IMAGE_RESULT_MAP_PATIENT_ID" ;

    /*
    * The index position of the column IMAGE_RESULT_MAP_PATIENT_ID in the table.
    */
    public static final int IMAGE_RESULT_MAP_PATIENT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 4 ;

    /**
              * <p> Date of Birth of Patient.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_BIRTH= "DATE_OF_BIRTH" ;

    /*
    * The index position of the column DATE_OF_BIRTH in the table.
    */
    public static final int DATE_OF_BIRTH_IDX = 5 ;

    /**
              * <p> Gender of Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 6 ;

    /**
              * <p> Race.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>45</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RACE= "RACE" ;

    /*
    * The index position of the column RACE in the table.
    */
    public static final int RACE_IDX = 7 ;

    /**
              * <p> Ethnicity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ETHNICITY= "ETHNICITY" ;

    /*
    * The index position of the column ETHNICITY in the table.
    */
    public static final int ETHNICITY_IDX = 8 ;

    /**
              * <p> Door number and street details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_1= "LINE_1" ;

    /*
    * The index position of the column LINE_1 in the table.
    */
    public static final int LINE_1_IDX = 9 ;

    /**
              * <p> Line 2 of the Address.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_2= "LINE_2" ;

    /*
    * The index position of the column LINE_2 in the table.
    */
    public static final int LINE_2_IDX = 10 ;

    /**
              * <p> Name of city.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CITY= "CITY" ;

    /*
    * The index position of the column CITY in the table.
    */
    public static final int CITY_IDX = 11 ;

    /**
              * <p> Name of the state.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATE= "STATE" ;

    /*
    * The index position of the column STATE in the table.
    */
    public static final int STATE_IDX = 12 ;

    /**
              * <p> Name of the country.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY= "COUNTRY" ;

    /*
    * The index position of the column COUNTRY in the table.
    */
    public static final int COUNTRY_IDX = 13 ;

    /**
              * <p> Postal code / PIN code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String POSTALCODE= "POSTALCODE" ;

    /*
    * The index position of the column POSTALCODE in the table.
    */
    public static final int POSTALCODE_IDX = 14 ;

    /**
              * <p> Home phone number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HOME_PHONE_NUMBER= "HOME_PHONE_NUMBER" ;

    /*
    * The index position of the column HOME_PHONE_NUMBER in the table.
    */
    public static final int HOME_PHONE_NUMBER_IDX = 15 ;

    /**
              * <p> Social security number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SSN= "SSN" ;

    /*
    * The index position of the column SSN in the table.
    */
    public static final int SSN_IDX = 16 ;

    /**
              * <p> ABN Flag.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ABN_FLAG= "ABN_FLAG" ;

    /*
    * The index position of the column ABN_FLAG in the table.
    */
    public static final int ABN_FLAG_IDX = 17 ;

    /**
              * <p> Says who has added this record entry : Patient / LabCorp / etc....</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 18 ;

    /**
              * <p> To hold message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_DETAILS= "ADDITIONAL_DETAILS" ;

    /*
    * The index position of the column ADDITIONAL_DETAILS in the table.
    */
    public static final int ADDITIONAL_DETAILS_IDX = 19 ;

}
