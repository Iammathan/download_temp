package com.adventnet.charm;

/** <p> Description of the table <code>UB04ClaimDetails</code>.
 *  Column Name and Table Name of  database table  <code>UB04ClaimDetails</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_CLAIM_ID}
  * </ul>
 */
 
public final class UB04CLAIMDETAILS
{
    private UB04CLAIMDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04ClaimDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_CLAIM_ID= "UB04_CLAIM_ID" ;

    /*
    * The index position of the column UB04_CLAIM_ID in the table.
    */
    public static final int UB04_CLAIM_ID_IDX = 1 ;

    /**
              * <p> Record id used to display in CMS1450 form as medical record id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_RECORD_ID= "CLAIM_RECORD_ID" ;

    /*
    * The index position of the column CLAIM_RECORD_ID in the table.
    */
    public static final int CLAIM_RECORD_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_DATE= "LAST_EDITED_DATE" ;

    /*
    * The index position of the column LAST_EDITED_DATE in the table.
    */
    public static final int LAST_EDITED_DATE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_EDITED_BY= "LAST_EDITED_BY" ;

    /*
    * The index position of the column LAST_EDITED_BY in the table.
    */
    public static final int LAST_EDITED_BY_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PAY_TO_ADDRESS_EXIST= "IS_PAY_TO_ADDRESS_EXIST" ;

    /*
    * The index position of the column IS_PAY_TO_ADDRESS_EXIST in the table.
    */
    public static final int IS_PAY_TO_ADDRESS_EXIST_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BILL_TYPE= "BILL_TYPE" ;

    /*
    * The index position of the column BILL_TYPE in the table.
    */
    public static final int BILL_TYPE_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>6</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATEMENT_FROM= "STATEMENT_FROM" ;

    /*
    * The index position of the column STATEMENT_FROM in the table.
    */
    public static final int STATEMENT_FROM_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>6</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATEMENT_TO= "STATEMENT_TO" ;

    /*
    * The index position of the column STATEMENT_TO in the table.
    */
    public static final int STATEMENT_TO_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMISSION_TYPE_CODE= "ADMISSION_TYPE_CODE" ;

    /*
    * The index position of the column ADMISSION_TYPE_CODE in the table.
    */
    public static final int ADMISSION_TYPE_CODE_IDX = 11 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMISSION_TYPE_DESC= "ADMISSION_TYPE_DESC" ;

    /*
    * The index position of the column ADMISSION_TYPE_DESC in the table.
    */
    public static final int ADMISSION_TYPE_DESC_IDX = 12 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMISSION_SOURCE_CODE= "ADMISSION_SOURCE_CODE" ;

    /*
    * The index position of the column ADMISSION_SOURCE_CODE in the table.
    */
    public static final int ADMISSION_SOURCE_CODE_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMISSION_SOURCE_DESC= "ADMISSION_SOURCE_DESC" ;

    /*
    * The index position of the column ADMISSION_SOURCE_DESC in the table.
    */
    public static final int ADMISSION_SOURCE_DESC_IDX = 14 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>8</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADMISSION_DATE= "ADMISSION_DATE" ;

    /*
    * The index position of the column ADMISSION_DATE in the table.
    */
    public static final int ADMISSION_DATE_IDX = 15 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>6</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CREATION_DATE= "CREATION_DATE" ;

    /*
    * The index position of the column CREATION_DATE in the table.
    */
    public static final int CREATION_DATE_IDX = 16 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISCHARGE_STATUS_CODE= "DISCHARGE_STATUS_CODE" ;

    /*
    * The index position of the column DISCHARGE_STATUS_CODE in the table.
    */
    public static final int DISCHARGE_STATUS_CODE_IDX = 17 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISCHARGE_STATUS_DESC= "DISCHARGE_STATUS_DESC" ;

    /*
    * The index position of the column DISCHARGE_STATUS_DESC in the table.
    */
    public static final int DISCHARGE_STATUS_DESC_IDX = 18 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 19 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 20 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 21 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TOTAL_COVERED_CHARGES= "TOTAL_COVERED_CHARGES" ;

    /*
    * The index position of the column TOTAL_COVERED_CHARGES in the table.
    */
    public static final int TOTAL_COVERED_CHARGES_IDX = 22 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOTAL_NON_COVERED_CHARGES= "TOTAL_NON_COVERED_CHARGES" ;

    /*
    * The index position of the column TOTAL_NON_COVERED_CHARGES in the table.
    */
    public static final int TOTAL_NON_COVERED_CHARGES_IDX = 23 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSULTATION_DATE= "CONSULTATION_DATE" ;

    /*
    * The index position of the column CONSULTATION_DATE in the table.
    */
    public static final int CONSULTATION_DATE_IDX = 24 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 25 ;

    /**
              * <p> Refers ICD version of diagnoses added in the claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                     * Default Value is <code>9</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>9</code>" , 
       * will be taken.<br>
                         */
    public static final String ICD_VERSION= "ICD_VERSION" ;

    /*
    * The index position of the column ICD_VERSION in the table.
    */
    public static final int ICD_VERSION_IDX = 26 ;

    /**
              * <p> Stores the Encounter with whom and when.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>86</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ENCOUNTER_WITH_AND_DATE= "ENCOUNTER_WITH_AND_DATE" ;

    /*
    * The index position of the column ENCOUNTER_WITH_AND_DATE in the table.
    */
    public static final int ENCOUNTER_WITH_AND_DATE_IDX = 27 ;

    /**
              * <p> Identifier of the Bill.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 28 ;

}
