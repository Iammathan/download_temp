package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimPaymentCorrections</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimPaymentCorrections</code> is mapped
 * as constants in this util.</p> 
  Contains details of the corrections made between invoicing cycles. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_CLM_PAYMENT_CORRECTION_ID}
  * </ul>
 */
 
public final class RCMCLAIMPAYMENTCORRECTIONS
{
    private RCMCLAIMPAYMENTCORRECTIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimPaymentCorrections" ;
    /**
              * <p> PK of this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_CLM_PAYMENT_CORRECTION_ID= "RCM_CLM_PAYMENT_CORRECTION_ID" ;

    /*
    * The index position of the column RCM_CLM_PAYMENT_CORRECTION_ID in the table.
    */
    public static final int RCM_CLM_PAYMENT_CORRECTION_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_CP_ID= "RCM_CP_ID" ;

    /*
    * The index position of the column RCM_CP_ID in the table.
    */
    public static final int RCM_CP_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_POSTED_DATE= "PAYMENT_POSTED_DATE" ;

    /*
    * The index position of the column PAYMENT_POSTED_DATE in the table.
    */
    public static final int PAYMENT_POSTED_DATE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 4 ;

    /**
              * <p> Date on which the payment was invoiced first.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVOICED_DATE= "INVOICED_DATE" ;

    /*
    * The index position of the column INVOICED_DATE in the table.
    */
    public static final int INVOICED_DATE_IDX = 5 ;

    /**
              * <p> Percentage of commission collected.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVOICED_PERCENTAGE= "INVOICED_PERCENTAGE" ;

    /*
    * The index position of the column INVOICED_PERCENTAGE in the table.
    */
    public static final int INVOICED_PERCENTAGE_IDX = 6 ;

    /**
              * <p>  Amount Split Up Details while each row is added in this table.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INITIAL_PAYMENT_DETAILS= "INITIAL_PAYMENT_DETAILS" ;

    /*
    * The index position of the column INITIAL_PAYMENT_DETAILS in the table.
    */
    public static final int INITIAL_PAYMENT_DETAILS_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>6</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>EDIT</code></li>
              * <li><code>DELETE</code></li>
              * </ul>
                         */
    public static final String OPERATION_TYPE= "OPERATION_TYPE" ;

    /*
    * The index position of the column OPERATION_TYPE in the table.
    */
    public static final int OPERATION_TYPE_IDX = 8 ;

    /**
              * <p> Operation last updated date.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_LAST_UPDATED_ON= "PAYMENT_LAST_UPDATED_ON" ;

    /*
    * The index position of the column PAYMENT_LAST_UPDATED_ON in the table.
    */
    public static final int PAYMENT_LAST_UPDATED_ON_IDX = 9 ;

    /**
              * <p> Difference in Amount Paid.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_AMT_DIFF= "PAYMENT_AMT_DIFF" ;

    /*
    * The index position of the column PAYMENT_AMT_DIFF in the table.
    */
    public static final int PAYMENT_AMT_DIFF_IDX = 10 ;

    /**
              * <p> Difference in Patient Responsibility.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAT_RESP_DIFF= "PAT_RESP_DIFF" ;

    /*
    * The index position of the column PAT_RESP_DIFF in the table.
    */
    public static final int PAT_RESP_DIFF_IDX = 11 ;

    /**
              * <p> Contains the details of PR components that were changed.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PR_DIFF_DETAILS_JSON= "PR_DIFF_DETAILS_JSON" ;

    /*
    * The index position of the column PR_DIFF_DETAILS_JSON in the table.
    */
    public static final int PR_DIFF_DETAILS_JSON_IDX = 12 ;

    /**
              * <p> Contains the sum of PAYMENT_AMT_DIFF and PAT_RESP_DIFF.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOTAL_DIFF_AMOUNT= "TOTAL_DIFF_AMOUNT" ;

    /*
    * The index position of the column TOTAL_DIFF_AMOUNT in the table.
    */
    public static final int TOTAL_DIFF_AMOUNT_IDX = 13 ;

    /**
              * <p> Contains History of Edits made on the payment - values at each edit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EDIT_HISTORY_JSON= "EDIT_HISTORY_JSON" ;

    /*
    * The index position of the column EDIT_HISTORY_JSON in the table.
    */
    public static final int EDIT_HISTORY_JSON_IDX = 14 ;

    /**
              * <p> Date and time on which invoice report with corrections are adjusted and 'MARK_AS_INVOICED'.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVOICE_ADJUSTED_DATE= "INVOICE_ADJUSTED_DATE" ;

    /*
    * The index position of the column INVOICE_ADJUSTED_DATE in the table.
    */
    public static final int INVOICE_ADJUSTED_DATE_IDX = 15 ;

    /**
              * <p> PracticeId of MBP for RCM Service Invoice Report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 16 ;

}
