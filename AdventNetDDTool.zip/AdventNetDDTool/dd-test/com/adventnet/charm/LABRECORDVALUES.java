package com.adventnet.charm;

/** <p> Description of the table <code>LabRecordValues</code>.
 *  Column Name and Table Name of  database table  <code>LabRecordValues</code> is mapped
 * as constants in this util.</p> 
  Parameter values entered by user for a particular record. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_RECORD_VALUE_ID}
  * </ul>
 */
 
public final class LABRECORDVALUES
{
    private LABRECORDVALUES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabRecordValues" ;
    /**
              * <p> Unique identifier of Medical Record Value.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_VALUE_ID= "LAB_RECORD_VALUE_ID" ;

    /*
    * The index position of the column LAB_RECORD_VALUE_ID in the table.
    */
    public static final int LAB_RECORD_VALUE_ID_IDX = 1 ;

    /**
              * <p> Unique identifier of Medical Record ENTRY.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ENTRY_ID= "MEDICAL_RECORD_ENTRY_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ENTRY_ID in the table.
    */
    public static final int MEDICAL_RECORD_ENTRY_ID_IDX = 2 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_PARAM_ID= "MEDICAL_RECORD_PARAM_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_PARAM_ID in the table.
    */
    public static final int MEDICAL_RECORD_PARAM_ID_IDX = 3 ;

    /**
              * <p> Recorded value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORDVALUE= "RECORDVALUE" ;

    /*
    * The index position of the column RECORDVALUE in the table.
    */
    public static final int RECORDVALUE_IDX = 4 ;

    /**
              * <p> Maximum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MAX= "REFERENCE_MAX" ;

    /*
    * The index position of the column REFERENCE_MAX in the table.
    */
    public static final int REFERENCE_MAX_IDX = 5 ;

    /**
              * <p> Mininum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MIN= "REFERENCE_MIN" ;

    /*
    * The index position of the column REFERENCE_MIN in the table.
    */
    public static final int REFERENCE_MIN_IDX = 6 ;

    /**
              * <p> Interpretation of the medical record param.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INTERPRETATION= "INTERPRETATION" ;

    /*
    * The index position of the column INTERPRETATION in the table.
    */
    public static final int INTERPRETATION_IDX = 7 ;

    /**
              * <p> Unit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORDUNIT= "RECORDUNIT" ;

    /*
    * The index position of the column RECORDUNIT in the table.
    */
    public static final int RECORDUNIT_IDX = 8 ;

    /**
              * <p> Associated lab facility Id. If lab facility is common for all the associated parameters, corresponding facility id has to be set here. If not common, facility id has to be set at the parameter level but not here..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 9 ;

    /**
              * <p>  comments .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 10 ;

    /**
              * <p> To maintain status of the result sent by Labcorp.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OBSERVATION_STATUS= "OBSERVATION_STATUS" ;

    /*
    * The index position of the column OBSERVATION_STATUS in the table.
    */
    public static final int OBSERVATION_STATUS_IDX = 11 ;

    /**
              * <p> Reference range for String type of references.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE_RANGE= "REFERENCE_RANGE" ;

    /*
    * The index position of the column REFERENCE_RANGE in the table.
    */
    public static final int REFERENCE_RANGE_IDX = 12 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_PARAM_ID= "LAB_RECORD_PARAM_ID" ;

    /*
    * The index position of the column LAB_RECORD_PARAM_ID in the table.
    */
    public static final int LAB_RECORD_PARAM_ID_IDX = 13 ;

    /**
              * <p> Name of Medical Record Parameter.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PARAMETER_NAME= "PARAMETER_NAME" ;

    /*
    * The index position of the column PARAMETER_NAME in the table.
    */
    public static final int PARAMETER_NAME_IDX = 14 ;

    /**
              * <p> LOINC CODE associated with this parameter. Used in maintaining the uniqueness among the parameters.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LOINC_CODE= "LOINC_CODE" ;

    /*
    * The index position of the column LOINC_CODE in the table.
    */
    public static final int LOINC_CODE_IDX = 15 ;

    /**
              * <p> Code for this parameter as specified by the Lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_PARAM_CODE= "LAB_PARAM_CODE" ;

    /*
    * The index position of the column LAB_PARAM_CODE in the table.
    */
    public static final int LAB_PARAM_CODE_IDX = 16 ;

    /**
              * <p> user defined order of parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 17 ;

    /**
              * <p> param description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PARAM_DESCRIPTION= "PARAM_DESCRIPTION" ;

    /*
    * The index position of the column PARAM_DESCRIPTION in the table.
    */
    public static final int PARAM_DESCRIPTION_IDX = 18 ;

}
