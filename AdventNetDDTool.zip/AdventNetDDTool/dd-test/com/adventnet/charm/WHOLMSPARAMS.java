package com.adventnet.charm;

/** <p> Description of the table <code>WHOLMSParams</code>.
 *  Column Name and Table Name of  database table  <code>WHOLMSParams</code> is mapped
 * as constants in this util.</p> 
  LMS Params of who charts[0-2 yrs]. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #WHO_LMS_PARAMS_ID}
  * </ul>
 */
 
public final class WHOLMSPARAMS
{
    private WHOLMSPARAMS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "WHOLMSParams" ;
    /**
              * <p> Unique ID for WHOLMSParams.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WHO_LMS_PARAMS_ID= "WHO_LMS_PARAMS_ID" ;

    /*
    * The index position of the column WHO_LMS_PARAMS_ID in the table.
    */
    public static final int WHO_LMS_PARAMS_ID_IDX = 1 ;

    /**
              * <p> Age for find lms.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AGE= "AGE" ;

    /*
    * The index position of the column AGE in the table.
    */
    public static final int AGE_IDX = 2 ;

    /**
              * <p> 1>male, 2>female.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 3 ;

    /**
              * <p> L param of HC.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String HC_L= "HC_L" ;

    /*
    * The index position of the column HC_L in the table.
    */
    public static final int HC_L_IDX = 4 ;

    /**
              * <p> M param of HC.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String HC_M= "HC_M" ;

    /*
    * The index position of the column HC_M in the table.
    */
    public static final int HC_M_IDX = 5 ;

    /**
              * <p> S param of HC.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String HC_S= "HC_S" ;

    /*
    * The index position of the column HC_S in the table.
    */
    public static final int HC_S_IDX = 6 ;

    /**
              * <p> L param of Weight.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String WT_L= "WT_L" ;

    /*
    * The index position of the column WT_L in the table.
    */
    public static final int WT_L_IDX = 7 ;

    /**
              * <p> M param of Weight.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String WT_M= "WT_M" ;

    /*
    * The index position of the column WT_M in the table.
    */
    public static final int WT_M_IDX = 8 ;

    /**
              * <p> S param of Weight.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String WT_S= "WT_S" ;

    /*
    * The index position of the column WT_S in the table.
    */
    public static final int WT_S_IDX = 9 ;

    /**
              * <p> L param of Height.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LEN_L= "LEN_L" ;

    /*
    * The index position of the column LEN_L in the table.
    */
    public static final int LEN_L_IDX = 10 ;

    /**
              * <p> M param of Height.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LEN_M= "LEN_M" ;

    /*
    * The index position of the column LEN_M in the table.
    */
    public static final int LEN_M_IDX = 11 ;

    /**
              * <p> S param of Height.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LEN_S= "LEN_S" ;

    /*
    * The index position of the column LEN_S in the table.
    */
    public static final int LEN_S_IDX = 12 ;

}
