package com.adventnet.charm;

/** <p> Description of the table <code>ATECSharedDetails</code>.
 *  Column Name and Table Name of  database table  <code>ATECSharedDetails</code> is mapped
 * as constants in this util.</p> 
  Shared details of ATEC data between patient and practice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ATEC_SHARED_ID}
  * </ul>
 */
 
public final class ATECSHAREDDETAILS
{
    private ATECSHAREDDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ATECSharedDetails" ;
    /**
              * <p> Unique identifier for ATECSharedDetails.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ATEC_SHARED_ID= "ATEC_SHARED_ID" ;

    /*
    * The index position of the column ATEC_SHARED_ID in the table.
    */
    public static final int ATEC_SHARED_ID_IDX = 1 ;

    /**
              * <p> Unique identifier for Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Unique identifier for Practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

    /**
              * <p> Evaluation date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EVAL_DATE= "EVAL_DATE" ;

    /*
    * The index position of the column EVAL_DATE in the table.
    */
    public static final int EVAL_DATE_IDX = 4 ;

}
