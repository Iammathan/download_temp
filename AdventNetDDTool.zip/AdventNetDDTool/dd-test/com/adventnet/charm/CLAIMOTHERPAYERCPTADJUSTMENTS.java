package com.adventnet.charm;

/** <p> Description of the table <code>ClaimOtherPayerCPTAdjustments</code>.
 *  Column Name and Table Name of  database table  <code>ClaimOtherPayerCPTAdjustments</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLM_CPT_ADJUSTMENT_ID}
  * </ul>
 */
 
public final class CLAIMOTHERPAYERCPTADJUSTMENTS
{
    private CLAIMOTHERPAYERCPTADJUSTMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ClaimOtherPayerCPTAdjustments" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLM_CPT_ADJUSTMENT_ID= "CLM_CPT_ADJUSTMENT_ID" ;

    /*
    * The index position of the column CLM_CPT_ADJUSTMENT_ID in the table.
    */
    public static final int CLM_CPT_ADJUSTMENT_ID_IDX = 1 ;

    /**
              * <p> SAS Key of the ClaimOtherPayerEOBCPTDtl table where the EOB line items detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLM_OTHER_PAYER_EOB_CPT_ID= "CLM_OTHER_PAYER_EOB_CPT_ID" ;

    /*
    * The index position of the column CLM_OTHER_PAYER_EOB_CPT_ID in the table.
    */
    public static final int CLM_OTHER_PAYER_EOB_CPT_ID_IDX = 2 ;

    /**
              * <p> 2100 : CAS01 : #130 - Claim Adjustment Group Code. Code description is present in ClaimAdjustmentGroupCodes.properties.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_GROUP_CODE= "ADJUSTMENT_GROUP_CODE" ;

    /*
    * The index position of the column ADJUSTMENT_GROUP_CODE in the table.
    */
    public static final int ADJUSTMENT_GROUP_CODE_IDX = 3 ;

    /**
              * <p> 2100 : CAS02 : #131 / CAS05 : #132 / CAS08 : #133 / CAS11 : #134 / CAS14 : #135 / CAS17 : #135 - Claim Adjustment Reason Codes - description is in ClaimAdjustmentReasonCodes.properties file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_REASON_CODE= "ADJUSTMENT_REASON_CODE" ;

    /*
    * The index position of the column ADJUSTMENT_REASON_CODE in the table.
    */
    public static final int ADJUSTMENT_REASON_CODE_IDX = 4 ;

    /**
              * <p> 2100 : CAS03 : #132 / CAS06 : #133 / CAS09 : #133 / CAS12 : #134 / CAS15 : #135 / CAS18 : #136 - Amount which has been adjusted; either positive or negative, which either decreases or increases the payment respectively.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_AMOUNT= "ADJUSTMENT_AMOUNT" ;

    /*
    * The index position of the column ADJUSTMENT_AMOUNT in the table.
    */
    public static final int ADJUSTMENT_AMOUNT_IDX = 5 ;

    /**
              * <p> 2100 : CAS04 : #132 / CAS07 : #133 / CAS10 : #134 / CAS13 : #134 / CAS16 : #135 / CAS19 : #136; Adjusted quantity.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_QUANTITY= "ADJUSTMENT_QUANTITY" ;

    /*
    * The index position of the column ADJUSTMENT_QUANTITY in the table.
    */
    public static final int ADJUSTMENT_QUANTITY_IDX = 6 ;

}
