package com.adventnet.charm;

/** <p> Description of the table <code>PracticeVitalsProp</code>.
 *  Column Name and Table Name of  database table  <code>PracticeVitalsProp</code> is mapped
 * as constants in this util.</p> 
  To store Practice Property. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VITAL_ENTRY_ID}
  * </ul>
 */
 
public final class PRACTICEVITALSPROP
{
    private PRACTICEVITALSPROP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeVitalsProp" ;
    /**
              * <p> Unique identifier for Practice Vitals Property.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VITAL_ENTRY_ID= "VITAL_ENTRY_ID" ;

    /*
    * The index position of the column VITAL_ENTRY_ID in the table.
    */
    public static final int VITAL_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Vital Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VITAL_NAME= "VITAL_NAME" ;

    /*
    * The index position of the column VITAL_NAME in the table.
    */
    public static final int VITAL_NAME_IDX = 2 ;

    /**
              * <p> Vital status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VITAL_STATUS= "VITAL_STATUS" ;

    /*
    * The index position of the column VITAL_STATUS in the table.
    */
    public static final int VITAL_STATUS_IDX = 3 ;

}
