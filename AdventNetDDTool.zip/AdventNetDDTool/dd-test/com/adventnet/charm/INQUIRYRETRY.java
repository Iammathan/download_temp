package com.adventnet.charm;

/** <p> Description of the table <code>InquiryRetry</code>.
 *  Column Name and Table Name of  database table  <code>InquiryRetry</code> is mapped
 * as constants in this util.</p> 
  table contains the retry details of a recent-payperiod's recurring profile . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ID}
  * </ul>
 */
 
public final class INQUIRYRETRY
{
    private INQUIRYRETRY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InquiryRetry" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROFILEID= "PROFILEID" ;

    /*
    * The index position of the column PROFILEID in the table.
    */
    public static final int PROFILEID_IDX = 2 ;

    /**
              * <p> Date on which Charm had collected the PaymentInquiry report from PayPal.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RETRYDATE= "RETRYDATE" ;

    /*
    * The index position of the column RETRYDATE in the table.
    */
    public static final int RETRYDATE_IDX = 3 ;

    /**
              * <p> Retry count specific to the Charm. Payment-Inquiry is fetched for a profile on 3 times on different dates ( payment_date +1 / +3 / +6 ).Based on this, retry_no ranges from 1 to 3..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RETRY_NO= "RETRY_NO" ;

    /*
    * The index position of the column RETRY_NO in the table.
    */
    public static final int RETRY_NO_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYPAL_RECENT_RESULT= "PAYPAL_RECENT_RESULT" ;

    /*
    * The index position of the column PAYPAL_RECENT_RESULT in the table.
    */
    public static final int PAYPAL_RECENT_RESULT_IDX = 5 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYPAL_RECENT_RETRY_DATE= "PAYPAL_RECENT_RETRY_DATE" ;

    /*
    * The index position of the column PAYPAL_RECENT_RETRY_DATE in the table.
    */
    public static final int PAYPAL_RECENT_RETRY_DATE_IDX = 6 ;

}
