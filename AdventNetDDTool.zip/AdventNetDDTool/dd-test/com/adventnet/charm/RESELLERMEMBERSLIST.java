package com.adventnet.charm;

/** <p> Description of the table <code>ResellerMembersList</code>.
 *  Column Name and Table Name of  database table  <code>ResellerMembersList</code> is mapped
 * as constants in this util.</p> 
  Information about Reseller org Members. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RESELLER_MEMBER_ID}
  * </ul>
 */
 
public final class RESELLERMEMBERSLIST
{
    private RESELLERMEMBERSLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ResellerMembersList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RESELLER_MEMBER_ID= "RESELLER_MEMBER_ID" ;

    /*
    * The index position of the column RESELLER_MEMBER_ID in the table.
    */
    public static final int RESELLER_MEMBER_ID_IDX = 1 ;

    /**
              * <p> First name of the member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 2 ;

    /**
              * <p> Last name of the member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 3 ;

    /**
              * <p> Full name of the member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FULL_NAME= "FULL_NAME" ;

    /*
    * The index position of the column FULL_NAME in the table.
    */
    public static final int FULL_NAME_IDX = 4 ;

    /**
              * <p>  Mail Id of the member .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 5 ;

    /**
              * <p> Zoho User Id of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZUID= "ZUID" ;

    /*
    * The index position of the column ZUID in the table.
    */
    public static final int ZUID_IDX = 6 ;

    /**
              * <p> Gender of member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>M</code></li>
              * <li><code>F</code></li>
              * <li><code>O</code></li>
              * </ul>
                         */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 7 ;

    /**
              * <p> Currently selected practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CUR_SEL_PRACTICE= "CUR_SEL_PRACTICE" ;

    /*
    * The index position of the column CUR_SEL_PRACTICE in the table.
    */
    public static final int CUR_SEL_PRACTICE_IDX = 8 ;

    /**
              * <p> Landline number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LANDLINE= "LANDLINE" ;

    /*
    * The index position of the column LANDLINE in the table.
    */
    public static final int LANDLINE_IDX = 9 ;

    /**
              * <p> Mobile number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MOBILE= "MOBILE" ;

    /*
    * The index position of the column MOBILE in the table.
    */
    public static final int MOBILE_IDX = 10 ;

    /**
              * <p> Status whether member is invited or confirmed.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_CONFIRMED= "IS_CONFIRMED" ;

    /*
    * The index position of the column IS_CONFIRMED in the table.
    */
    public static final int IS_CONFIRMED_IDX = 11 ;

    /**
              * <p> Status whether member is ADMIN.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ADMIN= "IS_ADMIN" ;

    /*
    * The index position of the column IS_ADMIN in the table.
    */
    public static final int IS_ADMIN_IDX = 12 ;

    /**
              * <p> Status whether member is deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 13 ;

    /**
              * <p> Time of creation of member account/time of invite.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_TIME= "CREATED_TIME" ;

    /*
    * The index position of the column CREATED_TIME in the table.
    */
    public static final int CREATED_TIME_IDX = 14 ;

    /**
              * <p> Time when member is deleted.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DELETED_TIME= "DELETED_TIME" ;

    /*
    * The index position of the column DELETED_TIME in the table.
    */
    public static final int DELETED_TIME_IDX = 15 ;

    /**
              * <p> Id for Mapping PostalAddress and member profile.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 16 ;

}
