package com.adventnet.charm;

/** <p> Description of the table <code>MessageMembersMap</code>.
 *  Column Name and Table Name of  database table  <code>MessageMembersMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAP_ID}
  * </ul>
 */
 
public final class MESSAGEMEMBERSMAP
{
    private MESSAGEMEMBERSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MessageMembersMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAP_ID= "MAP_ID" ;

    /*
    * The index position of the column MAP_ID in the table.
    */
    public static final int MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of message.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 2 ;

    /**
              * <p> Member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDITIONAL_MEMBER_ID= "ADDITIONAL_MEMBER_ID" ;

    /*
    * The index position of the column ADDITIONAL_MEMBER_ID in the table.
    */
    public static final int ADDITIONAL_MEMBER_ID_IDX = 3 ;

}
