package com.adventnet.charm;

/** <p> Description of the table <code>EClaimTransactionVsClaimMap</code>.
 *  Column Name and Table Name of  database table  <code>EClaimTransactionVsClaimMap</code> is mapped
 * as constants in this util.</p> 
  It maintains the mapping of claimId's that are sent in each transaction (ECLAIM_TRANSACTION_ID) alongwith the claim submission response, which will be stored in ClaimNotes table and PK will be stored here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ECLAIM_TXN_CLAIM_MAP_ID}
  * </ul>
 */
 
public final class ECLAIMTRANSACTIONVSCLAIMMAP
{
    private ECLAIMTRANSACTIONVSCLAIMMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EClaimTransactionVsClaimMap" ;
    /**
              * <p> Unique ID(SAS KEY - PK) assigned by Mickey.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_TXN_CLAIM_MAP_ID= "ECLAIM_TXN_CLAIM_MAP_ID" ;

    /*
    * The index position of the column ECLAIM_TXN_CLAIM_MAP_ID in the table.
    */
    public static final int ECLAIM_TXN_CLAIM_MAP_ID_IDX = 1 ;

    /**
              * <p> PK of the EClaimTransactions table where the transaction detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ECLAIM_TRANSACTION_ID= "ECLAIM_TRANSACTION_ID" ;

    /*
    * The index position of the column ECLAIM_TRANSACTION_ID in the table.
    */
    public static final int ECLAIM_TRANSACTION_ID_IDX = 2 ;

    /**
              * <p> Claim ID - PK of the ClaimCompleteDetails(or, RCMClaimCompleteDetails) table which has the claim related detail.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 3 ;

    /**
              * <p> Status of the claim before submitting to the scheduler.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_STATUS_BEFORE_SUBMISSION= "CLAIM_STATUS_BEFORE_SUBMISSION" ;

    /*
    * The index position of the column CLAIM_STATUS_BEFORE_SUBMISSION in the table.
    */
    public static final int CLAIM_STATUS_BEFORE_SUBMISSION_IDX = 4 ;

    /**
              * <p> STC01-1 Or STC10-1 Or STC11-1 - Claim Status (WQ|U|ONLY_ERRORS|ONLY_WARNINGS|BOTH_ERRORS_WARNINGS) .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_STATUS= "CLAIM_STATUS" ;

    /*
    * The index position of the column CLAIM_STATUS in the table.
    */
    public static final int CLAIM_STATUS_IDX = 5 ;

    /**
              * <p> 0-In Queue, 1-NETWORK_ERROR,9-Submitted/Processed.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CLAIM_QUEUE_STATUS= "CLAIM_QUEUE_STATUS" ;

    /*
    * The index position of the column CLAIM_QUEUE_STATUS in the table.
    */
    public static final int CLAIM_QUEUE_STATUS_IDX = 6 ;

}
