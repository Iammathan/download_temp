package com.adventnet.charm;

/** <p> Description of the table <code>HealthPassportOtpMap</code>.
 *  Column Name and Table Name of  database table  <code>HealthPassportOtpMap</code> is mapped
 * as constants in this util.</p> 
  Map for Health Passport and PHR Otp Requests . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HEALTH_PASSPORT_OTP_MAP_ID}
  * </ul>
 */
 
public final class HEALTHPASSPORTOTPMAP
{
    private HEALTHPASSPORTOTPMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HealthPassportOtpMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_PASSPORT_OTP_MAP_ID= "HEALTH_PASSPORT_OTP_MAP_ID" ;

    /*
    * The index position of the column HEALTH_PASSPORT_OTP_MAP_ID in the table.
    */
    public static final int HEALTH_PASSPORT_OTP_MAP_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String HEALTH_PASSPORT_ID= "HEALTH_PASSPORT_ID" ;

    /*
    * The index position of the column HEALTH_PASSPORT_ID in the table.
    */
    public static final int HEALTH_PASSPORT_ID_IDX = 2 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PHR_OTP_REQUEST_ID= "PHR_OTP_REQUEST_ID" ;

    /*
    * The index position of the column PHR_OTP_REQUEST_ID in the table.
    */
    public static final int PHR_OTP_REQUEST_ID_IDX = 3 ;

}
