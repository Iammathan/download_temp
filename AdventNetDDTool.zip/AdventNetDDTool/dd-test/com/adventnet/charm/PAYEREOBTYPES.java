package com.adventnet.charm;

/** <p> Description of the table <code>PayerEOBTypes</code>.
 *  Column Name and Table Name of  database table  <code>PayerEOBTypes</code> is mapped
 * as constants in this util.</p> 
  EOB details of Payers. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAYER_EOB_TYPE_ID}
  * </ul>
 */
 
public final class PAYEREOBTYPES
{
    private PAYEREOBTYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PayerEOBTypes" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYER_EOB_TYPE_ID= "PAYER_EOB_TYPE_ID" ;

    /*
    * The index position of the column PAYER_EOB_TYPE_ID in the table.
    */
    public static final int PAYER_EOB_TYPE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_TYPE= "PAYER_TYPE" ;

    /*
    * The index position of the column PAYER_TYPE in the table.
    */
    public static final int PAYER_TYPE_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISPLAY_BG_COLOR= "DISPLAY_BG_COLOR" ;

    /*
    * The index position of the column DISPLAY_BG_COLOR in the table.
    */
    public static final int DISPLAY_BG_COLOR_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISPLAY_FONT_COLOR= "DISPLAY_FONT_COLOR" ;

    /*
    * The index position of the column DISPLAY_FONT_COLOR in the table.
    */
    public static final int DISPLAY_FONT_COLOR_IDX = 4 ;

}
