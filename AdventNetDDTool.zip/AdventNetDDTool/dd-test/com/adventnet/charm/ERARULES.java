package com.adventnet.charm;

/** <p> Description of the table <code>ERARules</code>.
 *  Column Name and Table Name of  database table  <code>ERARules</code> is mapped
 * as constants in this util.</p> 
  ERA Settings which defines how payment behaviour has to be. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RULE_ID}
  * </ul>
 */
 
public final class ERARULES
{
    private ERARULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERARules" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RULE_ID= "RULE_ID" ;

    /*
    * The index position of the column RULE_ID in the table.
    */
    public static final int RULE_ID_IDX = 1 ;

    /**
              * <p> Key for the rule.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RULE_NAME= "RULE_NAME" ;

    /*
    * The index position of the column RULE_NAME in the table.
    */
    public static final int RULE_NAME_IDX = 2 ;

    /**
              * <p> Value of the rule.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RULE_VALUE= "RULE_VALUE" ;

    /*
    * The index position of the column RULE_VALUE in the table.
    */
    public static final int RULE_VALUE_IDX = 3 ;

    /**
              * <p> Whether the setting is updated from EHR or RCM.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 4 ;

}
