package com.adventnet.charm;

/** <p> Description of the table <code>DraftReceipients</code>.
 *  Column Name and Table Name of  database table  <code>DraftReceipients</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DRAFT_RECIPIENT_ID}
  * </ul>
 */
 
public final class DRAFTRECEIPIENTS
{
    private DRAFTRECEIPIENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DraftReceipients" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DRAFT_RECIPIENT_ID= "DRAFT_RECIPIENT_ID" ;

    /*
    * The index position of the column DRAFT_RECIPIENT_ID in the table.
    */
    public static final int DRAFT_RECIPIENT_ID_IDX = 1 ;

    /**
              * <p> Identifier of message.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DRAFT_ID= "DRAFT_ID" ;

    /*
    * The index position of the column DRAFT_ID in the table.
    */
    public static final int DRAFT_ID_IDX = 2 ;

    /**
              * <p> Member id or patient id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_ID= "TO_ID" ;

    /*
    * The index position of the column TO_ID in the table.
    */
    public static final int TO_ID_IDX = 3 ;

    /**
              * <p> Practice Id or patient space.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_SPACE= "TO_SPACE" ;

    /*
    * The index position of the column TO_SPACE in the table.
    */
    public static final int TO_SPACE_IDX = 4 ;

    /**
              * <p> Patient name or member name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TO_NAME= "TO_NAME" ;

    /*
    * The index position of the column TO_NAME in the table.
    */
    public static final int TO_NAME_IDX = 5 ;

}
