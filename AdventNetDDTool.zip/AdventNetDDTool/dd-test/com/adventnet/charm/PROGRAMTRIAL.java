package com.adventnet.charm;

/** <p> Description of the table <code>ProgramTrial</code>.
 *  Column Name and Table Name of  database table  <code>ProgramTrial</code> is mapped
 * as constants in this util.</p> 
  Program's Trial. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROG_TRIAL_ID}
  * </ul>
 */
 
public final class PROGRAMTRIAL
{
    private PROGRAMTRIAL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ProgramTrial" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROG_TRIAL_ID= "PROG_TRIAL_ID" ;

    /*
    * The index position of the column PROG_TRIAL_ID in the table.
    */
    public static final int PROG_TRIAL_ID_IDX = 1 ;

    /**
              * <p> Program Trial Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROG_TRIAL_NAME= "PROG_TRIAL_NAME" ;

    /*
    * The index position of the column PROG_TRIAL_NAME in the table.
    */
    public static final int PROG_TRIAL_NAME_IDX = 2 ;

    /**
              * <p> Program identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROGRAM_ID= "PROGRAM_ID" ;

    /*
    * The index position of the column PROGRAM_ID in the table.
    */
    public static final int PROGRAM_ID_IDX = 3 ;

    /**
              * <p> Session identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SESSION_ID= "SESSION_ID" ;

    /*
    * The index position of the column SESSION_ID in the table.
    */
    public static final int SESSION_ID_IDX = 4 ;

    /**
              * <p> Program Facilitator.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITATOR_ID= "FACILITATOR_ID" ;

    /*
    * The index position of the column FACILITATOR_ID in the table.
    */
    public static final int FACILITATOR_ID_IDX = 5 ;

    /**
              * <p> Whether targets done sequentially or not. 1/0 for Task execution, NULL otherwise.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_SEQ_TARGETS_EXEC= "IS_SEQ_TARGETS_EXEC" ;

    /*
    * The index position of the column IS_SEQ_TARGETS_EXEC in the table.
    */
    public static final int IS_SEQ_TARGETS_EXEC_IDX = 6 ;

    /**
              * <p> Updated time in long.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String UPDATED_TIME= "UPDATED_TIME" ;

    /*
    * The index position of the column UPDATED_TIME in the table.
    */
    public static final int UPDATED_TIME_IDX = 7 ;

    /**
              * <p> Comments on Program Trial.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 8 ;

}
