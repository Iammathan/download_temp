package com.adventnet.charm;

/** <p> Description of the table <code>RxQueueToMDScripts</code>.
 *  Column Name and Table Name of  database table  <code>RxQueueToMDScripts</code> is mapped
 * as constants in this util.</p> 
  Rx data Queued to MDScripts. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RX_QUEUE_MDSCRIPTS_ID}
  * </ul>
 */
 
public final class RXQUEUETOMDSCRIPTS
{
    private RXQUEUETOMDSCRIPTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RxQueueToMDScripts" ;
    /**
              * <p> Surrogate key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RX_QUEUE_MDSCRIPTS_ID= "RX_QUEUE_MDSCRIPTS_ID" ;

    /*
    * The index position of the column RX_QUEUE_MDSCRIPTS_ID in the table.
    */
    public static final int RX_QUEUE_MDSCRIPTS_ID_IDX = 1 ;

    /**
              * <p> Practice id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Patient ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Facility Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 4 ;

    /**
              * <p> Medication Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_MEDICATION_ID= "PATIENT_MEDICATION_ID" ;

    /*
    * The index position of the column PATIENT_MEDICATION_ID in the table.
    */
    public static final int PATIENT_MEDICATION_ID_IDX = 5 ;

    /**
              * <p> Specifies the status of the RX.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 6 ;

    /**
              * <p> Specifies the time at which it is queued.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_ON= "ADDED_ON" ;

    /*
    * The index position of the column ADDED_ON in the table.
    */
    public static final int ADDED_ON_IDX = 7 ;

    /**
              * <p> Specifies the Member Id of the person queueing it.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 8 ;

    /**
              * <p> Specifies the Memerb Name of the person queueing it.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY_NAME= "ADDED_BY_NAME" ;

    /*
    * The index position of the column ADDED_BY_NAME in the table.
    */
    public static final int ADDED_BY_NAME_IDX = 9 ;

}
