package com.adventnet.charm;

/** <p> Description of the table <code>SecureURL</code>.
 *  Column Name and Table Name of  database table  <code>SecureURL</code> is mapped
 * as constants in this util.</p> 
  Secure share for files to patient by sms. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SECURE_URL_ID}
  * </ul>
 */
 
public final class SECUREURL
{
    private SECUREURL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SecureURL" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SECURE_URL_ID= "SECURE_URL_ID" ;

    /*
    * The index position of the column SECURE_URL_ID in the table.
    */
    public static final int SECURE_URL_ID_IDX = 1 ;

    /**
              * <p> Random key to be stored for secure share.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RANDOM_KEY= "RANDOM_KEY" ;

    /*
    * The index position of the column RANDOM_KEY in the table.
    */
    public static final int RANDOM_KEY_IDX = 2 ;

    /**
              * <p> FK Reference column to PracticePatientsList table PRACTICE_PATIENT_ID Column.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Created Time of secure url.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_ON= "CREATED_ON" ;

    /*
    * The index position of the column CREATED_ON in the table.
    */
    public static final int CREATED_ON_IDX = 4 ;

    /**
              * <p> OTP count.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTP= "OTP" ;

    /*
    * The index position of the column OTP in the table.
    */
    public static final int OTP_IDX = 5 ;

    /**
              * <p> Time of creating the OTP.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTP_SENT_ON= "OTP_SENT_ON" ;

    /*
    * The index position of the column OTP_SENT_ON in the table.
    */
    public static final int OTP_SENT_ON_IDX = 6 ;

    /**
              * <p> Status of otp for debugging whether it is send or in queue or  failed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_STATUS= "OTP_STATUS" ;

    /*
    * The index position of the column OTP_STATUS in the table.
    */
    public static final int OTP_STATUS_IDX = 7 ;

    /**
              * <p> OTP failed attempt count.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_FAILED_ATTEMPTS= "OTP_FAILED_ATTEMPTS" ;

    /*
    * The index position of the column OTP_FAILED_ATTEMPTS in the table.
    */
    public static final int OTP_FAILED_ATTEMPTS_IDX = 8 ;

    /**
              * <p> Number of otp per day maximum 5 count.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_SENT_PER_DAY= "OTP_SENT_PER_DAY" ;

    /*
    * The index position of the column OTP_SENT_PER_DAY in the table.
    */
    public static final int OTP_SENT_PER_DAY_IDX = 9 ;

    /**
              * <p> Validity date of the url.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VALID_UNTIL= "VALID_UNTIL" ;

    /*
    * The index position of the column VALID_UNTIL in the table.
    */
    public static final int VALID_UNTIL_IDX = 10 ;

    /**
              * <p> FK Reference column to AppointmentHistory table APPOINTMENT_ID Column.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 11 ;

    /**
              * <p> 0 - Shared to patient , 1 - shared from patient, 2 - Fill questionnaire.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String URL_TYPE= "URL_TYPE" ;

    /*
    * The index position of the column URL_TYPE in the table.
    */
    public static final int URL_TYPE_IDX = 12 ;

    /**
              * <p> FK Reference column to Facilities list FACILITY_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 13 ;

    /**
              * <p> MemberIDs of members(seperated by comma) to be notified about documents shared by patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SEND_NOTIFICATION_TO= "SEND_NOTIFICATION_TO" ;

    /*
    * The index position of the column SEND_NOTIFICATION_TO in the table.
    */
    public static final int SEND_NOTIFICATION_TO_IDX = 14 ;

    /**
              * <p> DOB failed attempt count.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DOB_FAILED_ATTEMPTS= "DOB_FAILED_ATTEMPTS" ;

    /*
    * The index position of the column DOB_FAILED_ATTEMPTS in the table.
    */
    public static final int DOB_FAILED_ATTEMPTS_IDX = 15 ;

    /**
              * <p> Will set false for lab result QR code scanning purpose.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MOBILE_OTP= "IS_MOBILE_OTP" ;

    /*
    * The index position of the column IS_MOBILE_OTP in the table.
    */
    public static final int IS_MOBILE_OTP_IDX = 16 ;

    /**
              * <p> Last accessed time in milliseconds for secure text msg send sms.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_ACCESSED_TIME= "LAST_ACCESSED_TIME" ;

    /*
    * The index position of the column LAST_ACCESSED_TIME in the table.
    */
    public static final int LAST_ACCESSED_TIME_IDX = 17 ;

}
