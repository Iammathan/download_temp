package com.adventnet.charm;

/** <p> Description of the table <code>PracticeTimings</code>.
 *  Column Name and Table Name of  database table  <code>PracticeTimings</code> is mapped
 * as constants in this util.</p> 
  Contains details related to the Practice working hours. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_TIMINGS_ID}
  * </ul>
 */
 
public final class PRACTICETIMINGS
{
    private PRACTICETIMINGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeTimings" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_TIMINGS_ID= "PRACTICE_TIMINGS_ID" ;

    /*
    * The index position of the column PRACTICE_TIMINGS_ID in the table.
    */
    public static final int PRACTICE_TIMINGS_ID_IDX = 1 ;

    /**
              * <p> Day of the week Sunday as 0 and Monday as 1 etc.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DAY= "DAY" ;

    /*
    * The index position of the column DAY in the table.
    */
    public static final int DAY_IDX = 2 ;

    /**
              * <p> String denoting start time like 1:00.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String START_TIME= "START_TIME" ;

    /*
    * The index position of the column START_TIME in the table.
    */
    public static final int START_TIME_IDX = 3 ;

    /**
              * <p> String denoting start session like am/pm.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>am</code></li>
              * <li><code>pm</code></li>
              * </ul>
                         */
    public static final String START_SESSION= "START_SESSION" ;

    /*
    * The index position of the column START_SESSION in the table.
    */
    public static final int START_SESSION_IDX = 4 ;

    /**
              * <p> String denoting end time like 1:00.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String END_TIME= "END_TIME" ;

    /*
    * The index position of the column END_TIME in the table.
    */
    public static final int END_TIME_IDX = 5 ;

    /**
              * <p> String denoting end session like am/pm.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>am</code></li>
              * <li><code>pm</code></li>
              * </ul>
                         */
    public static final String END_SESSION= "END_SESSION" ;

    /*
    * The index position of the column END_SESSION in the table.
    */
    public static final int END_SESSION_IDX = 6 ;

    /**
              * <p> For indicating the day as holiday.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_HOLIDAY= "IS_HOLIDAY" ;

    /*
    * The index position of the column IS_HOLIDAY in the table.
    */
    public static final int IS_HOLIDAY_IDX = 7 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 8 ;

}
