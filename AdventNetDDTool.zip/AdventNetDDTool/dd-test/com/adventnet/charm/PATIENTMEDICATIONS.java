package com.adventnet.charm;

/** <p> Description of the table <code>PatientMedications</code>.
 *  Column Name and Table Name of  database table  <code>PatientMedications</code> is mapped
 * as constants in this util.</p> 
  Medications used by patients (For Practice Purpose). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_MEDICATION_ID}
  * </ul>
 */
 
public final class PATIENTMEDICATIONS
{
    private PATIENTMEDICATIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientMedications" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_MEDICATION_ID= "PATIENT_MEDICATION_ID" ;

    /*
    * The index position of the column PATIENT_MEDICATION_ID in the table.
    */
    public static final int PATIENT_MEDICATION_ID_IDX = 1 ;

    /**
              * <p> Date and Time on which this data is entered.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE_OF_ENTRY= "DATE_OF_ENTRY" ;

    /*
    * The index position of the column DATE_OF_ENTRY in the table.
    */
    public static final int DATE_OF_ENTRY_IDX = 2 ;

    /**
              * <p> Identifier of Drug Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DRUGDETAILS_ID= "DRUGDETAILS_ID" ;

    /*
    * The index position of the column DRUGDETAILS_ID in the table.
    */
    public static final int DRUGDETAILS_ID_IDX = 3 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
              * <p> Date from which the prescription is taken.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String START_DATE= "START_DATE" ;

    /*
    * The index position of the column START_DATE in the table.
    */
    public static final int START_DATE_IDX = 5 ;

    /**
              * <p> Date till which the prescription is taken.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STOP_DATE= "STOP_DATE" ;

    /*
    * The index position of the column STOP_DATE in the table.
    */
    public static final int STOP_DATE_IDX = 6 ;

    /**
              * <p> Dosage Unit.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DOSAGE_UNIT_ID= "DOSAGE_UNIT_ID" ;

    /*
    * The index position of the column DOSAGE_UNIT_ID in the table.
    */
    public static final int DOSAGE_UNIT_ID_IDX = 7 ;

    /**
              * <p> Intake Route.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String INTAKE_ROUTE= "INTAKE_ROUTE" ;

    /*
    * The index position of the column INTAKE_ROUTE in the table.
    */
    public static final int INTAKE_ROUTE_IDX = 8 ;

    /**
              * <p>  Whether the Medication is currently active or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 9 ;

    /**
              * <p> Medication Comment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 10 ;

    /**
              * <p> Physician Id who has added this medication.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 11 ;

    /**
              * <p> whether it is Rx or not.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_AS= "ADDED_AS" ;

    /*
    * The index position of the column ADDED_AS in the table.
    */
    public static final int ADDED_AS_IDX = 12 ;

    /**
              * <p> Time of entry in milliseconds.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 13 ;

    /**
              * <p> Status of Fax.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FAX_STATUS= "FAX_STATUS" ;

    /*
    * The index position of the column FAX_STATUS in the table.
    */
    public static final int FAX_STATUS_IDX = 14 ;

    /**
              * <p> The medication is signed with Positive Id or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_POSITIVE_ID_SIGNED= "IS_POSITIVE_ID_SIGNED" ;

    /*
    * The index position of the column IS_POSITIVE_ID_SIGNED in the table.
    */
    public static final int IS_POSITIVE_ID_SIGNED_IDX = 15 ;

    /**
              * <p> Sign Status for Rx.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String SIGN_STATUS= "SIGN_STATUS" ;

    /*
    * The index position of the column SIGN_STATUS in the table.
    */
    public static final int SIGN_STATUS_IDX = 16 ;

    /**
              * <p> Physician Id who has signed this Prescription.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SIGNED_BY= "SIGNED_BY" ;

    /*
    * The index position of the column SIGNED_BY in the table.
    */
    public static final int SIGNED_BY_IDX = 17 ;

    /**
              * <p> Specifies the time at which it is signed.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SIGNED_ON= "SIGNED_ON" ;

    /*
    * The index position of the column SIGNED_ON in the table.
    */
    public static final int SIGNED_ON_IDX = 18 ;

    /**
              * <p> The transmission status of the medication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRANSMIT_STATUS= "TRANSMIT_STATUS" ;

    /*
    * The index position of the column TRANSMIT_STATUS in the table.
    */
    public static final int TRANSMIT_STATUS_IDX = 19 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 20 ;

    /**
              * <p> Date from which the prescription is signed.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String WRITTEN_DATE= "WRITTEN_DATE" ;

    /*
    * The index position of the column WRITTEN_DATE in the table.
    */
    public static final int WRITTEN_DATE_IDX = 21 ;

    /**
              * <p> Time when the prescription is added/signed.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String WRITTEN_TIME= "WRITTEN_TIME" ;

    /*
    * The index position of the column WRITTEN_TIME in the table.
    */
    public static final int WRITTEN_TIME_IDX = 22 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 23 ;

    /**
              * <p> manual trasmission by provider/automatic by system - EPA.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRANSMITTED_BY= "TRANSMITTED_BY" ;

    /*
    * The index position of the column TRANSMITTED_BY in the table.
    */
    public static final int TRANSMITTED_BY_IDX = 24 ;

    /**
              * <p> Refill request cannot be accepted for this Rx.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String ACCEPT_REFILL= "ACCEPT_REFILL" ;

    /*
    * The index position of the column ACCEPT_REFILL in the table.
    */
    public static final int ACCEPT_REFILL_IDX = 25 ;

    /**
              * <p> Rx fill Indicator.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILL_STATUS= "FILL_STATUS" ;

    /*
    * The index position of the column FILL_STATUS in the table.
    */
    public static final int FILL_STATUS_IDX = 26 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SIGNED_DEA_NUMBER= "SIGNED_DEA_NUMBER" ;

    /*
    * The index position of the column SIGNED_DEA_NUMBER in the table.
    */
    public static final int SIGNED_DEA_NUMBER_IDX = 27 ;

}
