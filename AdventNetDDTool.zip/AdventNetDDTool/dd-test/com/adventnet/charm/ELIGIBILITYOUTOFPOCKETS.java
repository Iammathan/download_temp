package com.adventnet.charm;

/** <p> Description of the table <code>EligibilityOutOfPockets</code>.
 *  Column Name and Table Name of  database table  <code>EligibilityOutOfPockets</code> is mapped
 * as constants in this util.</p> 
  Stores the eligibility out of pockets. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ELIG_OUTOFPOCKET_ID}
  * </ul>
 */
 
public final class ELIGIBILITYOUTOFPOCKETS
{
    private ELIGIBILITYOUTOFPOCKETS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EligibilityOutOfPockets" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELIG_OUTOFPOCKET_ID= "ELIG_OUTOFPOCKET_ID" ;

    /*
    * The index position of the column ELIG_OUTOFPOCKET_ID in the table.
    */
    public static final int ELIG_OUTOFPOCKET_ID_IDX = 1 ;

    /**
              * <p> Primary key of EligibilityBenefitDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ELIG_BENEFIT_DETAILS_ID= "ELIG_BENEFIT_DETAILS_ID" ;

    /*
    * The index position of the column ELIG_BENEFIT_DETAILS_ID in the table.
    */
    public static final int ELIG_BENEFIT_DETAILS_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COVERAGE_LEVEL= "COVERAGE_LEVEL" ;

    /*
    * The index position of the column COVERAGE_LEVEL in the table.
    */
    public static final int COVERAGE_LEVEL_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AUTH_REQUIRED= "AUTH_REQUIRED" ;

    /*
    * The index position of the column AUTH_REQUIRED in the table.
    */
    public static final int AUTH_REQUIRED_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LIMIT_AMOUNT= "LIMIT_AMOUNT" ;

    /*
    * The index position of the column LIMIT_AMOUNT in the table.
    */
    public static final int LIMIT_AMOUNT_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LIMIT_CURRENCY= "LIMIT_CURRENCY" ;

    /*
    * The index position of the column LIMIT_CURRENCY in the table.
    */
    public static final int LIMIT_CURRENCY_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USED_AMOUNT= "USED_AMOUNT" ;

    /*
    * The index position of the column USED_AMOUNT in the table.
    */
    public static final int USED_AMOUNT_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USED_CURRENCY= "USED_CURRENCY" ;

    /*
    * The index position of the column USED_CURRENCY in the table.
    */
    public static final int USED_CURRENCY_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REM_AMOUNT= "REM_AMOUNT" ;

    /*
    * The index position of the column REM_AMOUNT in the table.
    */
    public static final int REM_AMOUNT_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REM_CURRENCY= "REM_CURRENCY" ;

    /*
    * The index position of the column REM_CURRENCY in the table.
    */
    public static final int REM_CURRENCY_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MESSAGES= "MESSAGES" ;

    /*
    * The index position of the column MESSAGES in the table.
    */
    public static final int MESSAGES_IDX = 11 ;

}
