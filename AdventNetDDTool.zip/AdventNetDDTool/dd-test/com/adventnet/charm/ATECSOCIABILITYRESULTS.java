package com.adventnet.charm;

/** <p> Description of the table <code>ATECSociabilityResults</code>.
 *  Column Name and Table Name of  database table  <code>ATECSociabilityResults</code> is mapped
 * as constants in this util.</p> 
  ATEC Results for Sociability. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #QUESTION_ID}
  * <li> {@link #PATIENT_ID}
  * <li> {@link #EVAL_DATE}
  * </ul>
 */
 
public final class ATECSOCIABILITYRESULTS
{
    private ATECSOCIABILITYRESULTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ATECSociabilityResults" ;
    /**
              * <p> Unique identifier for Question.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QUESTION_ID= "QUESTION_ID" ;

    /*
    * The index position of the column QUESTION_ID in the table.
    */
    public static final int QUESTION_ID_IDX = 1 ;

    /**
              * <p> Unique identifier for Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Evaluation date.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EVAL_DATE= "EVAL_DATE" ;

    /*
    * The index position of the column EVAL_DATE in the table.
    */
    public static final int EVAL_DATE_IDX = 3 ;

    /**
              * <p> Evaluation Result.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String EVAL_RESULT= "EVAL_RESULT" ;

    /*
    * The index position of the column EVAL_RESULT in the table.
    */
    public static final int EVAL_RESULT_IDX = 4 ;

}
