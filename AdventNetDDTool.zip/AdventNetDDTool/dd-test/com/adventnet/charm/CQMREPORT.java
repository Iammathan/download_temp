package com.adventnet.charm;

/** <p> Description of the table <code>CQMReport</code>.
 *  Column Name and Table Name of  database table  <code>CQMReport</code> is mapped
 * as constants in this util.</p> 
  CQM report stored. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CQM_REPORT_ID}
  * </ul>
 */
 
public final class CQMREPORT
{
    private CQMREPORT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMReport" ;
    /**
              * <p> Unique id for CQM Report table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CQM_REPORT_ID= "CQM_REPORT_ID" ;

    /*
    * The index position of the column CQM_REPORT_ID in the table.
    */
    public static final int CQM_REPORT_ID_IDX = 1 ;

    /**
              * <p> Request Id from CQMRequest.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CQM_REQUEST_ID= "CQM_REQUEST_ID" ;

    /*
    * The index position of the column CQM_REQUEST_ID in the table.
    */
    public static final int CQM_REQUEST_ID_IDX = 2 ;

    /**
              * <p> Unique id of the CQM measure.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEASURE_ID= "MEASURE_ID" ;

    /*
    * The index position of the column MEASURE_ID in the table.
    */
    public static final int MEASURE_ID_IDX = 3 ;

    /**
              * <p> Sub meaure id for CQM measure.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SUB_MEASURE_ID= "SUB_MEASURE_ID" ;

    /*
    * The index position of the column SUB_MEASURE_ID in the table.
    */
    public static final int SUB_MEASURE_ID_IDX = 4 ;

    /**
              * <p> IPP ids for cqm measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IPP_PATIENT_IDS= "IPP_PATIENT_IDS" ;

    /*
    * The index position of the column IPP_PATIENT_IDS in the table.
    */
    public static final int IPP_PATIENT_IDS_IDX = 5 ;

    /**
              * <p> Demoninator ids for cqm measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DENOMINATOR_PATIENT_IDS= "DENOMINATOR_PATIENT_IDS" ;

    /*
    * The index position of the column DENOMINATOR_PATIENT_IDS in the table.
    */
    public static final int DENOMINATOR_PATIENT_IDS_IDX = 6 ;

    /**
              * <p> Demoninator ids for cqm measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NUMERATOR_PATIENT_IDS= "NUMERATOR_PATIENT_IDS" ;

    /*
    * The index position of the column NUMERATOR_PATIENT_IDS in the table.
    */
    public static final int NUMERATOR_PATIENT_IDS_IDX = 7 ;

    /**
              * <p> Demoninator ids for cqm measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXCLUSION_PATIENT_IDS= "EXCLUSION_PATIENT_IDS" ;

    /*
    * The index position of the column EXCLUSION_PATIENT_IDS in the table.
    */
    public static final int EXCLUSION_PATIENT_IDS_IDX = 8 ;

    /**
              * <p> Demoninator ids for cqm measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXCEPTION_PATIENT_IDS= "EXCEPTION_PATIENT_IDS" ;

    /*
    * The index position of the column EXCEPTION_PATIENT_IDS in the table.
    */
    public static final int EXCEPTION_PATIENT_IDS_IDX = 9 ;

}
