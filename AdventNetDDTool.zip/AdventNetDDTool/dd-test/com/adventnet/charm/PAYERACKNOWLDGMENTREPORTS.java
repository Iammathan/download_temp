package com.adventnet.charm;

/** <p> Description of the table <code>PayerAcknowldgmentReports</code>.
 *  Column Name and Table Name of  database table  <code>PayerAcknowldgmentReports</code> is mapped
 * as constants in this util.</p> 
  Payer Acknowledgement(Claim) Reports (Level-2) downloaded from Optum but could not mapped to any claim are stored here. User is expected to either map this report with a proper cliam or ignore this report. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAYER_ACK_REPORT_ID}
  * </ul>
 */
 
public final class PAYERACKNOWLDGMENTREPORTS
{
    private PAYERACKNOWLDGMENTREPORTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PayerAcknowldgmentReports" ;
    /**
              * <p> Unique identifier for each Payer Acknowledgment Report.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYER_ACK_REPORT_ID= "PAYER_ACK_REPORT_ID" ;

    /*
    * The index position of the column PAYER_ACK_REPORT_ID in the table.
    */
    public static final int PAYER_ACK_REPORT_ID_IDX = 1 ;

    /**
              * <p> This is the Load ID to which this report belongs to.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LOAD_ID= "LOAD_ID" ;

    /*
    * The index position of the column LOAD_ID in the table.
    */
    public static final int LOAD_ID_IDX = 2 ;

    /**
              * <p> Last name of the Patient if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_LAST_NAME= "PATIENT_LAST_NAME" ;

    /*
    * The index position of the column PATIENT_LAST_NAME in the table.
    */
    public static final int PATIENT_LAST_NAME_IDX = 3 ;

    /**
              * <p> First name of the Patient if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_FIRST_NAME= "PATIENT_FIRST_NAME" ;

    /*
    * The index position of the column PATIENT_FIRST_NAME in the table.
    */
    public static final int PATIENT_FIRST_NAME_IDX = 4 ;

    /**
              * <p> Patient Account # (a.k.a, Record Id) if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_ACCOUNT_NO= "PATIENT_ACCOUNT_NO" ;

    /*
    * The index position of the column PATIENT_ACCOUNT_NO in the table.
    */
    public static final int PATIENT_ACCOUNT_NO_IDX = 5 ;

    /**
              * <p> Last name of the Insured Person if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURED_LAST_NAME= "INSURED_LAST_NAME" ;

    /*
    * The index position of the column INSURED_LAST_NAME in the table.
    */
    public static final int INSURED_LAST_NAME_IDX = 6 ;

    /**
              * <p> First name of the Insured Person if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURED_FIRST_NAME= "INSURED_FIRST_NAME" ;

    /*
    * The index position of the column INSURED_FIRST_NAME in the table.
    */
    public static final int INSURED_FIRST_NAME_IDX = 7 ;

    /**
              * <p> Member ID of the Insured Person if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INSURED_ID= "INSURED_ID" ;

    /*
    * The index position of the column INSURED_ID in the table.
    */
    public static final int INSURED_ID_IDX = 8 ;

    /**
              * <p> Payer name if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_NAME= "PAYER_NAME" ;

    /*
    * The index position of the column PAYER_NAME in the table.
    */
    public static final int PAYER_NAME_IDX = 9 ;

    /**
              * <p> Payer Id if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_ID= "PAYER_ID" ;

    /*
    * The index position of the column PAYER_ID in the table.
    */
    public static final int PAYER_ID_IDX = 10 ;

    /**
              * <p> Last name of the Billing Provider if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_LAST_NAME= "PROVIDER_LAST_NAME" ;

    /*
    * The index position of the column PROVIDER_LAST_NAME in the table.
    */
    public static final int PROVIDER_LAST_NAME_IDX = 11 ;

    /**
              * <p> First name of the Billing Provider if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_FIRST_NAME= "PROVIDER_FIRST_NAME" ;

    /*
    * The index position of the column PROVIDER_FIRST_NAME in the table.
    */
    public static final int PROVIDER_FIRST_NAME_IDX = 12 ;

    /**
              * <p> NPI of the Billing Provider if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_NPI= "PROVIDER_NPI" ;

    /*
    * The index position of the column PROVIDER_NPI in the table.
    */
    public static final int PROVIDER_NPI_IDX = 13 ;

    /**
              * <p> Tax ID of the Billing Provider if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_TAX_ID= "PROVIDER_TAX_ID" ;

    /*
    * The index position of the column PROVIDER_TAX_ID in the table.
    */
    public static final int PROVIDER_TAX_ID_IDX = 14 ;

    /**
              * <p> Sub-ID (OptumInsight defined field) of the Billing Provider if available in the report, else NULL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_SUB_ID= "PROVIDER_SUB_ID" ;

    /*
    * The index position of the column PROVIDER_SUB_ID in the table.
    */
    public static final int PROVIDER_SUB_ID_IDX = 15 ;

    /**
              * <p> Claim charge.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_CHARGE= "CLAIM_CHARGE" ;

    /*
    * The index position of the column CLAIM_CHARGE in the table.
    */
    public static final int CLAIM_CHARGE_IDX = 16 ;

    /**
              * <p> Service Start Date of the Claim.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_SERVICE= "DATE_OF_SERVICE" ;

    /*
    * The index position of the column DATE_OF_SERVICE in the table.
    */
    public static final int DATE_OF_SERVICE_IDX = 17 ;

    /**
              * <p> Service End Date of the Claim.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_END_DATE= "SERVICE_END_DATE" ;

    /*
    * The index position of the column SERVICE_END_DATE in the table.
    */
    public static final int SERVICE_END_DATE_IDX = 18 ;

    /**
              * <p> File name of each report.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 19 ;

    /**
              * <p> Contains the OptumInsight claim tracking number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ECT_NUMBER= "ECT_NUMBER" ;

    /*
    * The index position of the column ECT_NUMBER in the table.
    */
    public static final int ECT_NUMBER_IDX = 20 ;

    /**
              * <p> Contains the OptumInsight Trace number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRACE_NUMBER= "TRACE_NUMBER" ;

    /*
    * The index position of the column TRACE_NUMBER in the table.
    */
    public static final int TRACE_NUMBER_IDX = 21 ;

    /**
              * <p> Contains the date/time OptumInsight received the report.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_RECEIVED_DATE= "REPORT_RECEIVED_DATE" ;

    /*
    * The index position of the column REPORT_RECEIVED_DATE in the table.
    */
    public static final int REPORT_RECEIVED_DATE_IDX = 22 ;

    /**
              * <p> Contains the date/time OptumInsight processed the report.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_PROCESSED_DATE= "REPORT_PROCESSED_DATE" ;

    /*
    * The index position of the column REPORT_PROCESSED_DATE in the table.
    */
    public static final int REPORT_PROCESSED_DATE_IDX = 23 ;

    /**
              * <p> Contains the date/time OptumInsight received the report.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_GENERATED_DATE= "REPORT_GENERATED_DATE" ;

    /*
    * The index position of the column REPORT_GENERATED_DATE in the table.
    */
    public static final int REPORT_GENERATED_DATE_IDX = 24 ;

    /**
              * <p> Contains the date/time OptumInsight processed the report.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_LOAD_TIMESTAMP= "REPORT_LOAD_TIMESTAMP" ;

    /*
    * The index position of the column REPORT_LOAD_TIMESTAMP in the table.
    */
    public static final int REPORT_LOAD_TIMESTAMP_IDX = 25 ;

    /**
              * <p> Claim Status derived from the report detail.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 26 ;

    /**
              * <p> Status description in detail.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_REMARKS= "STATUS_REMARKS" ;

    /*
    * The index position of the column STATUS_REMARKS in the table.
    */
    public static final int STATUS_REMARKS_IDX = 27 ;

    /**
              * <p> Status code for this claim concluded from the report status detail.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_CODE= "STATUS_CODE" ;

    /*
    * The index position of the column STATUS_CODE in the table.
    */
    public static final int STATUS_CODE_IDX = 28 ;

    /**
              * <p> This dentoes whether the report is mapped with claim(1), ignored-by-user(2) or un-mapped(0-default).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String MAPPING_STATUS= "MAPPING_STATUS" ;

    /*
    * The index position of the column MAPPING_STATUS in the table.
    */
    public static final int MAPPING_STATUS_IDX = 29 ;

    /**
              * <p> Unique ID of claim i.e, (RCM)ClaimCompleteDetails.CLAIM_ID to which this status detail is mapped.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 30 ;

    /**
              * <p> Unique Id of the member who has either mapped or ignored this report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 31 ;

    /**
              * <p> Name of the member who has either mapped or ignored this report.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>105</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEMBER_NAME= "MEMBER_NAME" ;

    /*
    * The index position of the column MEMBER_NAME in the table.
    */
    public static final int MEMBER_NAME_IDX = 32 ;

    /**
              * <p> Time at which user has either mapped or ignored this report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTIVITY_TIME= "ACTIVITY_TIME" ;

    /*
    * The index position of the column ACTIVITY_TIME in the table.
    */
    public static final int ACTIVITY_TIME_IDX = 33 ;

    /**
              * <p> Remarks entered by the member while ignoring the report.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEMBER_REMARKS= "MEMBER_REMARKS" ;

    /*
    * The index position of the column MEMBER_REMARKS in the table.
    */
    public static final int MEMBER_REMARKS_IDX = 34 ;

    /**
              * <p> PK of PayerAckReportDownloadHx in which download transaction for this report is being stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PAYER_ACK_REPORT_DWNLD_HX_ID= "PAYER_ACK_REPORT_DWNLD_HX_ID" ;

    /*
    * The index position of the column PAYER_ACK_REPORT_DWNLD_HX_ID in the table.
    */
    public static final int PAYER_ACK_REPORT_DWNLD_HX_ID_IDX = 35 ;

    /**
              * <p> PK of PayerAckReportLoads - to which load-id these reports were downloaded.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYER_ACK_REPORT_LOAD_ID= "PAYER_ACK_REPORT_LOAD_ID" ;

    /*
    * The index position of the column PAYER_ACK_REPORT_LOAD_ID in the table.
    */
    public static final int PAYER_ACK_REPORT_LOAD_ID_IDX = 36 ;

    /**
              * <p> Denotes whether user this report is being downloaded from EHR / RCM(MBP).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>TRUE</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 37 ;

    /**
              * <p> "header1" received as part of the report-load-response for this load.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HEADER_1= "HEADER_1" ;

    /*
    * The index position of the column HEADER_1 in the table.
    */
    public static final int HEADER_1_IDX = 38 ;

    /**
              * <p> "header2" received as part of the report-load-response for this load.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HEADER_2= "HEADER_2" ;

    /*
    * The index position of the column HEADER_2 in the table.
    */
    public static final int HEADER_2_IDX = 39 ;

    /**
              * <p> "header3" received as part of the report-load-response for this load.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HEADER_3= "HEADER_3" ;

    /*
    * The index position of the column HEADER_3 in the table.
    */
    public static final int HEADER_3_IDX = 40 ;

    /**
              * <p> 'Organization ID' received as part of the report-load-response for this load.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ORGANIZATION_ID= "ORGANIZATION_ID" ;

    /*
    * The index position of the column ORGANIZATION_ID in the table.
    */
    public static final int ORGANIZATION_ID_IDX = 41 ;

    /**
              * <p> 'claim-id' received as part of the report-load-response for this load.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID_IN_REPORT= "CLAIM_ID_IN_REPORT" ;

    /*
    * The index position of the column CLAIM_ID_IN_REPORT in the table.
    */
    public static final int CLAIM_ID_IN_REPORT_IDX = 42 ;

    /**
              * <p> 'claim-obj-id' received as part of the report-load-response for this load.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_OBJ_ID= "CLAIM_OBJ_ID" ;

    /*
    * The index position of the column CLAIM_OBJ_ID in the table.
    */
    public static final int CLAIM_OBJ_ID_IDX = 43 ;

}
