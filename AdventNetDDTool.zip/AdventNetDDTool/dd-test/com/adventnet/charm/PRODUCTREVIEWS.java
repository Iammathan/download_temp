package com.adventnet.charm;

/** <p> Description of the table <code>ProductReviews</code>.
 *  Column Name and Table Name of  database table  <code>ProductReviews</code> is mapped
 * as constants in this util.</p> 
  All patients rating data will be maintained in this table. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PRODUCT_ID}
  * <li> {@link #PATIENT_ID}
  * </ul>
 */
 
public final class PRODUCTREVIEWS
{
    private PRODUCTREVIEWS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ProductReviews" ;
    /**
              * <p> Time at which the review was done.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 1 ;

    /**
              * <p> Unique id for all products.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRODUCT_ID= "PRODUCT_ID" ;

    /*
    * The index position of the column PRODUCT_ID in the table.
    */
    public static final int PRODUCT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Idendifier of the physician.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String USER_RATING= "USER_RATING" ;

    /*
    * The index position of the column USER_RATING in the table.
    */
    public static final int USER_RATING_IDX = 4 ;

    /**
              * <p> Idendifier of the physician.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SYSTEM_RATING= "SYSTEM_RATING" ;

    /*
    * The index position of the column SYSTEM_RATING in the table.
    */
    public static final int SYSTEM_RATING_IDX = 5 ;

    /**
              * <p> Idendifier of the physician.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_SYSTEM_GENERATED= "IS_SYSTEM_GENERATED" ;

    /*
    * The index position of the column IS_SYSTEM_GENERATED in the table.
    */
    public static final int IS_SYSTEM_GENERATED_IDX = 6 ;

    /**
              * <p> Title of the review comments.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVIEW_TITLE= "REVIEW_TITLE" ;

    /*
    * The index position of the column REVIEW_TITLE in the table.
    */
    public static final int REVIEW_TITLE_IDX = 7 ;

    /**
              * <p>  Review Comments of this product - given by patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVIEW= "REVIEW" ;

    /*
    * The index position of the column REVIEW in the table.
    */
    public static final int REVIEW_IDX = 8 ;

    /**
              * <p>  Review Comments of this product - given by patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROS= "PROS" ;

    /*
    * The index position of the column PROS in the table.
    */
    public static final int PROS_IDX = 9 ;

    /**
              * <p>  Review Comments of this product - given by patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONS= "CONS" ;

    /*
    * The index position of the column CONS in the table.
    */
    public static final int CONS_IDX = 10 ;

    /**
              * <p> Name of the reviewer.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REVIEWER_NAME= "REVIEWER_NAME" ;

    /*
    * The index position of the column REVIEWER_NAME in the table.
    */
    public static final int REVIEWER_NAME_IDX = 11 ;

    /**
              * <p> To check whether the product reviewed by patient  can be recommended or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_RECOMMENDED= "IS_RECOMMENDED" ;

    /*
    * The index position of the column IS_RECOMMENDED in the table.
    */
    public static final int IS_RECOMMENDED_IDX = 12 ;

    /**
              * <p> How long the patient used this product.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DURATION= "DURATION" ;

    /*
    * The index position of the column DURATION in the table.
    */
    public static final int DURATION_IDX = 13 ;

    /**
              * <p> Unit of duration.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>MONTH</code></li>
              * <li><code>YEAR</code></li>
              * <li><code>DAYS</code></li>
              * </ul>
                         */
    public static final String DURATION_UNIT= "DURATION_UNIT" ;

    /*
    * The index position of the column DURATION_UNIT in the table.
    */
    public static final int DURATION_UNIT_IDX = 14 ;

    /**
              * <p> Duration in days.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COMPUTED_DURATION= "COMPUTED_DURATION" ;

    /*
    * The index position of the column COMPUTED_DURATION in the table.
    */
    public static final int COMPUTED_DURATION_IDX = 15 ;

}
