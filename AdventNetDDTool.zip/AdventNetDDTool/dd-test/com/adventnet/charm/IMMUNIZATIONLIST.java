package com.adventnet.charm;

/** <p> Description of the table <code>ImmunizationList</code>.
 *  Column Name and Table Name of  database table  <code>ImmunizationList</code> is mapped
 * as constants in this util.</p> 
  Master Immunization list. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMMUNIZATION_ID}
  * </ul>
 */
 
public final class IMMUNIZATIONLIST
{
    private IMMUNIZATIONLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImmunizationList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMMUNIZATION_ID= "IMMUNIZATION_ID" ;

    /*
    * The index position of the column IMMUNIZATION_ID in the table.
    */
    public static final int IMMUNIZATION_ID_IDX = 1 ;

    /**
              * <p> Name of Immunization.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String IMMUNIZATION_NAME= "IMMUNIZATION_NAME" ;

    /*
    * The index position of the column IMMUNIZATION_NAME in the table.
    */
    public static final int IMMUNIZATION_NAME_IDX = 2 ;

    /**
              * <p> Type of Immunization.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String IMMUNIZATION_TYPE= "IMMUNIZATION_TYPE" ;

    /*
    * The index position of the column IMMUNIZATION_TYPE in the table.
    */
    public static final int IMMUNIZATION_TYPE_IDX = 3 ;

    /**
              * <p> Number of patients Using this Prescription.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PATIENT_COUNT= "PATIENT_COUNT" ;

    /*
    * The index position of the column PATIENT_COUNT in the table.
    */
    public static final int PATIENT_COUNT_IDX = 4 ;

    /**
              * <p> To chek whether the Immunization is approved or not.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APPROVAL_STATUS= "APPROVAL_STATUS" ;

    /*
    * The index position of the column APPROVAL_STATUS in the table.
    */
    public static final int APPROVAL_STATUS_IDX = 5 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

}
