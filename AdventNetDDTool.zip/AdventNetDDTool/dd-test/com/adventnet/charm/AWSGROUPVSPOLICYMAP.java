package com.adventnet.charm;

/** <p> Description of the table <code>AWSGroupVsPolicyMap</code>.
 *  Column Name and Table Name of  database table  <code>AWSGroupVsPolicyMap</code> is mapped
 * as constants in this util.</p> 
   To map group with what all policies attached to it . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AWS_GROUP_VS_POLICY_MAP_ID}
  * </ul>
 */
 
public final class AWSGROUPVSPOLICYMAP
{
    private AWSGROUPVSPOLICYMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AWSGroupVsPolicyMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_GROUP_VS_POLICY_MAP_ID= "AWS_GROUP_VS_POLICY_MAP_ID" ;

    /*
    * The index position of the column AWS_GROUP_VS_POLICY_MAP_ID in the table.
    */
    public static final int AWS_GROUP_VS_POLICY_MAP_ID_IDX = 1 ;

    /**
              * <p> Primary key of the AWS group details.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_GROUP_DETAILS_ID= "AWS_GROUP_DETAILS_ID" ;

    /*
    * The index position of the column AWS_GROUP_DETAILS_ID in the table.
    */
    public static final int AWS_GROUP_DETAILS_ID_IDX = 2 ;

    /**
              * <p> Primary key of the AWS policy details.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_POLICY_DETAILS_ID= "AWS_POLICY_DETAILS_ID" ;

    /*
    * The index position of the column AWS_POLICY_DETAILS_ID in the table.
    */
    public static final int AWS_POLICY_DETAILS_ID_IDX = 3 ;

}
