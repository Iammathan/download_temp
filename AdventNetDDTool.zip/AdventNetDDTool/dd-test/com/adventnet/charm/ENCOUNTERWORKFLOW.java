package com.adventnet.charm;

/** <p> Description of the table <code>EncounterWorkFlow</code>.
 *  Column Name and Table Name of  database table  <code>EncounterWorkFlow</code> is mapped
 * as constants in this util.</p> 
  Contains different stages(Status) of Appointment. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #WORKFLOW_ID}
  * </ul>
 */
 
public final class ENCOUNTERWORKFLOW
{
    private ENCOUNTERWORKFLOW()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EncounterWorkFlow" ;
    /**
              * <p> Identifier of Workflow.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WORKFLOW_ID= "WORKFLOW_ID" ;

    /*
    * The index position of the column WORKFLOW_ID in the table.
    */
    public static final int WORKFLOW_ID_IDX = 1 ;

    /**
              * <p> Different stages of Appointment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 2 ;

    /**
              * <p> Color code for status like green:white.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>blue:white</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS_COLOR= "STATUS_COLOR" ;

    /*
    * The index position of the column STATUS_COLOR in the table.
    */
    public static final int STATUS_COLOR_IDX = 3 ;

    /**
              * <p> Differentiate between user generated, default Status.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SYSTEM_GENERATED= "IS_SYSTEM_GENERATED" ;

    /*
    * The index position of the column IS_SYSTEM_GENERATED in the table.
    */
    public static final int IS_SYSTEM_GENERATED_IDX = 4 ;

    /**
              * <p> To indicate whether this status has been deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

    /**
              * <p> Entry order of Status.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 6 ;

    /**
              * <p> Whether this status is default status or not while appointment creation.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DEFAULT_STATUS= "IS_DEFAULT_STATUS" ;

    /*
    * The index position of the column IS_DEFAULT_STATUS in the table.
    */
    public static final int IS_DEFAULT_STATUS_IDX = 7 ;

}
