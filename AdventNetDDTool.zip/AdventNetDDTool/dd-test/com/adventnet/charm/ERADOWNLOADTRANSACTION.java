package com.adventnet.charm;

/** <p> Description of the table <code>ERADownloadTransaction</code>.
 *  Column Name and Table Name of  database table  <code>ERADownloadTransaction</code> is mapped
 * as constants in this util.</p> 
  This table maintains an entry for each download attempt made by the ERA Downloader/Scheduler. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_DWNLD_TXN_ID}
  * </ul>
 */
 
public final class ERADOWNLOADTRANSACTION
{
    private ERADOWNLOADTRANSACTION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERADownloadTransaction" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_DWNLD_TXN_ID= "ERA_DWNLD_TXN_ID" ;

    /*
    * The index position of the column ERA_DWNLD_TXN_ID in the table.
    */
    public static final int ERA_DWNLD_TXN_ID_IDX = 1 ;

    /**
              * <p> Available reports from this date are tried to download.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_FROM_DATE= "REPORT_FROM_DATE" ;

    /*
    * The index position of the column REPORT_FROM_DATE in the table.
    */
    public static final int REPORT_FROM_DATE_IDX = 2 ;

    /**
              * <p> Available reports till this date are tried to download.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_TILL_DATE= "REPORT_TILL_DATE" ;

    /*
    * The index position of the column REPORT_TILL_DATE in the table.
    */
    public static final int REPORT_TILL_DATE_IDX = 3 ;

    /**
              * <p> Date on which ChARM has made this download attempt - not an ERA data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_DOWNLOADED_DATE= "ERA_DOWNLOADED_DATE" ;

    /*
    * The index position of the column ERA_DOWNLOADED_DATE in the table.
    */
    public static final int ERA_DOWNLOADED_DATE_IDX = 4 ;

    /**
              * <p> No. of reports downloaded during this attempt.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_REPORTS= "NO_OF_REPORTS" ;

    /*
    * The index position of the column NO_OF_REPORTS in the table.
    */
    public static final int NO_OF_REPORTS_IDX = 5 ;

    /**
              * <p> No. of reports found duplicate in the total NO_OF_REPORTS downloaded; should be sum of NO_OF_ERA_ALREADY_DOWNLOADED and NO_OF_DUPLICATE_ERA.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOTAL_DUPLICATE_REPORTS= "TOTAL_DUPLICATE_REPORTS" ;

    /*
    * The index position of the column TOTAL_DUPLICATE_REPORTS in the table.
    */
    public static final int TOTAL_DUPLICATE_REPORTS_IDX = 6 ;

    /**
              * <p> No. of reports that does not belongs to this practice.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_OTHER_PRACTICE_ERA= "NO_OF_OTHER_PRACTICE_ERA" ;

    /*
    * The index position of the column NO_OF_OTHER_PRACTICE_ERA in the table.
    */
    public static final int NO_OF_OTHER_PRACTICE_ERA_IDX = 7 ;

    /**
              * <p> No. of ERA reports already downloaded but got as part of this downloaded reports.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_ERA_ALREADY_DOWNLOADED= "NO_OF_ERA_ALREADY_DOWNLOADED" ;

    /*
    * The index position of the column NO_OF_ERA_ALREADY_DOWNLOADED in the table.
    */
    public static final int NO_OF_ERA_ALREADY_DOWNLOADED_IDX = 8 ;

    /**
              * <p> No. of duplicte ERA reports present in the downloaded reports i.e same reports occurs more than once).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_DUPLICATE_ERA= "NO_OF_DUPLICATE_ERA" ;

    /*
    * The index position of the column NO_OF_DUPLICATE_ERA in the table.
    */
    public static final int NO_OF_DUPLICATE_ERA_IDX = 9 ;

    /**
              * <p> No. of new ERAs  present in the downloaded reports i.e, difference between NO_OF_REPORTS and TOTAL_DUPLICATE_REPORTS.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_NEW_ERA= "NO_OF_NEW_ERA" ;

    /*
    * The index position of the column NO_OF_NEW_ERA in the table.
    */
    public static final int NO_OF_NEW_ERA_IDX = 10 ;

    /**
              * <p> No. of EOBs present in the downlaoded new ERA reports.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_EOBS_PRESENT= "NO_OF_EOBS_PRESENT" ;

    /*
    * The index position of the column NO_OF_EOBS_PRESENT in the table.
    */
    public static final int NO_OF_EOBS_PRESENT_IDX = 11 ;

    /**
              * <p> No. of EOBs for which system couldn't find a properly matching claim.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_UNMATCHED_EOB= "NO_OF_UNMATCHED_EOB" ;

    /*
    * The index position of the column NO_OF_UNMATCHED_EOB in the table.
    */
    public static final int NO_OF_UNMATCHED_EOB_IDX = 12 ;

    /**
              * <p> No. of EOBs for which a properly matching claim found.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_MATCHED_EOB= "NO_OF_MATCHED_EOB" ;

    /*
    * The index position of the column NO_OF_MATCHED_EOB in the table.
    */
    public static final int NO_OF_MATCHED_EOB_IDX = 13 ;

    /**
              * <p> Count denotes no. of payments of EOBs failed while appling to the matching claim found.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_PAYMENT_FAILURES= "NO_OF_PAYMENT_FAILURES" ;

    /*
    * The index position of the column NO_OF_PAYMENT_FAILURES in the table.
    */
    public static final int NO_OF_PAYMENT_FAILURES_IDX = 14 ;

    /**
              * <p> Count denotes no. of payments of EOBs successfully applied to the matching claim found.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NO_OF_SUCCESSFUL_PAYMENTS= "NO_OF_SUCCESSFUL_PAYMENTS" ;

    /*
    * The index position of the column NO_OF_SUCCESSFUL_PAYMENTS in the table.
    */
    public static final int NO_OF_SUCCESSFUL_PAYMENTS_IDX = 15 ;

    /**
              * <p> Value in the status code node received in the response received from Optum for the ERA Download request.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_CODE= "STATUS_CODE" ;

    /*
    * The index position of the column STATUS_CODE in the table.
    */
    public static final int STATUS_CODE_IDX = 16 ;

    /**
              * <p> Status message received in the response received from Optum for the ERA Download request.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_MESSAGE= "STATUS_MESSAGE" ;

    /*
    * The index position of the column STATUS_MESSAGE in the table.
    */
    public static final int STATUS_MESSAGE_IDX = 17 ;

    /**
              * <p> Denotes whether this download is scheduled or initiated manually. Default is FALSE to indicate manual download.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SCHEDULED_DOWNLOAD= "IS_SCHEDULED_DOWNLOAD" ;

    /*
    * The index position of the column IS_SCHEDULED_DOWNLOAD in the table.
    */
    public static final int IS_SCHEDULED_DOWNLOAD_IDX = 18 ;

    /**
              * <p> User who has invoked the ERA download action. For automatic download the value is "ERA Scheduler".</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USER_NAME= "USER_NAME" ;

    /*
    * The index position of the column USER_NAME in the table.
    */
    public static final int USER_NAME_IDX = 19 ;

    /**
              * <p> Indicates the type of error, If any error occured during the Download ERA process.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_TYPE= "ERROR_TYPE" ;

    /*
    * The index position of the column ERROR_TYPE in the table.
    */
    public static final int ERROR_TYPE_IDX = 20 ;

    /**
              * <p> Contains the error message, If any error occured during the Download ERA process.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_MESSAGE= "ERROR_MESSAGE" ;

    /*
    * The index position of the column ERROR_MESSAGE in the table.
    */
    public static final int ERROR_MESSAGE_IDX = 21 ;

    /**
              * <p> Is it from RCM or Billing.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 22 ;

    /**
              * <p> Unique ID of the facility using whose optum account this era transaction was done.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DOWNLOADED_FACILITY_ID= "DOWNLOADED_FACILITY_ID" ;

    /*
    * The index position of the column DOWNLOADED_FACILITY_ID in the table.
    */
    public static final int DOWNLOADED_FACILITY_ID_IDX = 23 ;

    /**
              * <p> Uploaded via file in UI.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FILE_UPLOAD= "IS_FILE_UPLOAD" ;

    /*
    * The index position of the column IS_FILE_UPLOAD in the table.
    */
    public static final int IS_FILE_UPLOAD_IDX = 24 ;

    /**
              * <p> When this transaction is a retry transaction, this column will have ERA_DWNLD_TXN_ID of the previously failed transaction.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PREV_FAILED_TXN_ID= "PREV_FAILED_TXN_ID" ;

    /*
    * The index position of the column PREV_FAILED_TXN_ID in the table.
    */
    public static final int PREV_FAILED_TXN_ID_IDX = 25 ;

    /**
              * <p> Stores the retry count of this transaction.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RETRY_COUNT= "RETRY_COUNT" ;

    /*
    * The index position of the column RETRY_COUNT in the table.
    */
    public static final int RETRY_COUNT_IDX = 26 ;

}
