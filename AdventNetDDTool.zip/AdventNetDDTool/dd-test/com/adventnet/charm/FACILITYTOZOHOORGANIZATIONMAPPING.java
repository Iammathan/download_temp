package com.adventnet.charm;

/** <p> Description of the table <code>FacilityToZohoOrganizationMapping</code>.
 *  Column Name and Table Name of  database table  <code>FacilityToZohoOrganizationMapping</code> is mapped
 * as constants in this util.</p> 
  Facility to Zoho Books Organizations details mapping. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAPPING_ID}
  * </ul>
 */
 
public final class FACILITYTOZOHOORGANIZATIONMAPPING
{
    private FACILITYTOZOHOORGANIZATIONMAPPING()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FacilityToZohoOrganizationMapping" ;
    /**
              * <p> PK for FacilityToZohoOrganizationMapping table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MAPPING_ID= "MAPPING_ID" ;

    /*
    * The index position of the column MAPPING_ID in the table.
    */
    public static final int MAPPING_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 2 ;

    /**
              * <p> ZohoOrganizationDetails.ZOHO_ORG_DETAILS_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_ORG_DETAILS_ID= "ZOHO_ORG_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_ORG_DETAILS_ID in the table.
    */
    public static final int ZOHO_ORG_DETAILS_ID_IDX = 3 ;

}
