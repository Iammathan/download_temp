package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimPatientDemographics</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimPatientDemographics</code> is mapped
 * as constants in this util.</p> 
  RCM Claim patient Demographics. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_PATIENT_ID}
  * </ul>
 */
 
public final class RCMCLAIMPATIENTDEMOGRAPHICS
{
    private RCMCLAIMPATIENTDEMOGRAPHICS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimPatientDemographics" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_PATIENT_ID= "CLAIM_PATIENT_ID" ;

    /*
    * The index position of the column CLAIM_PATIENT_ID in the table.
    */
    public static final int CLAIM_PATIENT_ID_IDX = 1 ;

    /**
              * <p> Id for the patient in this practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Record id for the patient in the practice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_RECORD_ID= "PATIENT_RECORD_ID" ;

    /*
    * The index position of the column PATIENT_RECORD_ID in the table.
    */
    public static final int PATIENT_RECORD_ID_IDX = 3 ;

    /**
              * <p> Full name of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_FULL_NAME= "PATIENT_FULL_NAME" ;

    /*
    * The index position of the column PATIENT_FULL_NAME in the table.
    */
    public static final int PATIENT_FULL_NAME_IDX = 4 ;

    /**
              * <p> First name of the Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PATIENT_FIRST_NAME= "PATIENT_FIRST_NAME" ;

    /*
    * The index position of the column PATIENT_FIRST_NAME in the table.
    */
    public static final int PATIENT_FIRST_NAME_IDX = 5 ;

    /**
              * <p> Last name of the Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_MIDDLE_NAME= "PATIENT_MIDDLE_NAME" ;

    /*
    * The index position of the column PATIENT_MIDDLE_NAME in the table.
    */
    public static final int PATIENT_MIDDLE_NAME_IDX = 6 ;

    /**
              * <p> Last name of the Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PATIENT_LAST_NAME= "PATIENT_LAST_NAME" ;

    /*
    * The index position of the column PATIENT_LAST_NAME in the table.
    */
    public static final int PATIENT_LAST_NAME_IDX = 7 ;

    /**
              * <p> Gender of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 8 ;

    /**
              * <p> Date of birth of patient.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_BIRTH= "DATE_OF_BIRTH" ;

    /*
    * The index position of the column DATE_OF_BIRTH in the table.
    */
    public static final int DATE_OF_BIRTH_IDX = 9 ;

    /**
              * <p> marital status of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MARITAL_STATUS= "MARITAL_STATUS" ;

    /*
    * The index position of the column MARITAL_STATUS in the table.
    */
    public static final int MARITAL_STATUS_IDX = 10 ;

    /**
              * <p> Employment status of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMPLOYMENT_STATUS= "EMPLOYMENT_STATUS" ;

    /*
    * The index position of the column EMPLOYMENT_STATUS in the table.
    */
    public static final int EMPLOYMENT_STATUS_IDX = 11 ;

    /**
              * <p> Mobile number of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHONE_NUMBER= "PHONE_NUMBER" ;

    /*
    * The index position of the column PHONE_NUMBER in the table.
    */
    public static final int PHONE_NUMBER_IDX = 12 ;

    /**
              * <p> Postal address id - PK of PostalAddress.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 13 ;

    /**
              * <p> Social security number.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SSN= "SSN" ;

    /*
    * The index position of the column SSN in the table.
    */
    public static final int SSN_IDX = 14 ;

    /**
              * <p> Id for Mapping ContactDetails and patient Profile.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 15 ;

    /**
              * <p> Employer name of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMPLOYER_NAME= "EMPLOYER_NAME" ;

    /*
    * The index position of the column EMPLOYER_NAME in the table.
    */
    public static final int EMPLOYER_NAME_IDX = 16 ;

    /**
              * <p> Employer Postal address id - PK of PostalAddress.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EMPLOYER_ADDRESS_ID= "EMPLOYER_ADDRESS_ID" ;

    /*
    * The index position of the column EMPLOYER_ADDRESS_ID in the table.
    */
    public static final int EMPLOYER_ADDRESS_ID_IDX = 17 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>29</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NAME_IN_UB04_FORM= "NAME_IN_UB04_FORM" ;

    /*
    * The index position of the column NAME_IN_UB04_FORM in the table.
    */
    public static final int NAME_IN_UB04_FORM_IDX = 18 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>24</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECORD_ID_IN_UB04= "RECORD_ID_IN_UB04" ;

    /*
    * The index position of the column RECORD_ID_IN_UB04 in the table.
    */
    public static final int RECORD_ID_IN_UB04_IDX = 19 ;

}
