package com.adventnet.charm;

/** <p> Description of the table <code>ActivityImageOrderMap</code>.
 *  Column Name and Table Name of  database table  <code>ActivityImageOrderMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Activity and Image order. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACTIVITY_LOG_ID}
  * </ul>
 */
 
public final class ACTIVITYIMAGEORDERMAP
{
    private ACTIVITYIMAGEORDERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ActivityImageOrderMap" ;
    /**
              * <p> Activity Log id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACTIVITY_LOG_ID= "ACTIVITY_LOG_ID" ;

    /*
    * The index position of the column ACTIVITY_LOG_ID in the table.
    */
    public static final int ACTIVITY_LOG_ID_IDX = 1 ;

    /**
              * <p> Image order Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_ORDER_ID= "IMAGE_ORDER_ID" ;

    /*
    * The index position of the column IMAGE_ORDER_ID in the table.
    */
    public static final int IMAGE_ORDER_ID_IDX = 2 ;

}
