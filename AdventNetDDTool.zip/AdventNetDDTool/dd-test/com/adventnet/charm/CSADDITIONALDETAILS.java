package com.adventnet.charm;

/** <p> Description of the table <code>CSAdditionalDetails</code>.
 *  Column Name and Table Name of  database table  <code>CSAdditionalDetails</code> is mapped
 * as constants in this util.</p> 
  Added for CSAPP report; It contains additional information about the CS products; Entries will be added when you dispense control substance;. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CSA_DETAILS_ID}
  * </ul>
 */
 
public final class CSADDITIONALDETAILS
{
    private CSADDITIONALDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CSAdditionalDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CSA_DETAILS_ID= "CSA_DETAILS_ID" ;

    /*
    * The index position of the column CSA_DETAILS_ID in the table.
    */
    public static final int CSA_DETAILS_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_ITEM_ID= "BILL_ITEM_ID" ;

    /*
    * The index position of the column BILL_ITEM_ID in the table.
    */
    public static final int BILL_ITEM_ID_IDX = 2 ;

    /**
              * <p> (DSP 03).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WRITTEN_OR_AUTHORIZED_DATE= "WRITTEN_OR_AUTHORIZED_DATE" ;

    /*
    * The index position of the column WRITTEN_OR_AUTHORIZED_DATE in the table.
    */
    public static final int WRITTEN_OR_AUTHORIZED_DATE_IDX = 3 ;

    /**
              * <p> 0 to 99 (DSP 04).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFILLS_AUTHORIZED= "REFILLS_AUTHORIZED" ;

    /*
    * The index position of the column REFILLS_AUTHORIZED in the table.
    */
    public static final int REFILLS_AUTHORIZED_IDX = 4 ;

    /**
              * <p> 0 to 99 (DSP 06).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFILL_NUMBER= "REFILL_NUMBER" ;

    /*
    * The index position of the column REFILL_NUMBER in the table.
    */
    public static final int REFILL_NUMBER_IDX = 5 ;

    /**
              * <p> (DSP 05).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRESCRIPTION_FILLED_DATE= "PRESCRIPTION_FILLED_DATE" ;

    /*
    * The index position of the column PRESCRIPTION_FILLED_DATE in the table.
    */
    public static final int PRESCRIPTION_FILLED_DATE_IDX = 6 ;

    /**
              * <p> (DSP 09).</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String QUANTITY_DISPENSED= "QUANTITY_DISPENSED" ;

    /*
    * The index position of the column QUANTITY_DISPENSED in the table.
    */
    public static final int QUANTITY_DISPENSED_IDX = 7 ;

    /**
              * <p> 0 to 999(DSP 10).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DAYS_SUPPLY= "DAYS_SUPPLY" ;

    /*
    * The index position of the column DAYS_SUPPLY in the table.
    */
    public static final int DAYS_SUPPLY_IDX = 8 ;

    /**
              * <p> 0 to 99(DSP 13).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PARTIAL_FILL_INDICATOR= "PARTIAL_FILL_INDICATOR" ;

    /*
    * The index position of the column PARTIAL_FILL_INDICATOR in the table.
    */
    public static final int PARTIAL_FILL_INDICATOR_IDX = 9 ;

    /**
              * <p> 0 to 7 or 99(DSP 16).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_TYPE= "PAYMENT_TYPE" ;

    /*
    * The index position of the column PAYMENT_TYPE in the table.
    */
    public static final int PAYMENT_TYPE_IDX = 10 ;

    /**
              * <p> 0 to 5 or 99(DSP 12).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRESCRIPTION_MODE= "PRESCRIPTION_MODE" ;

    /*
    * The index position of the column PRESCRIPTION_MODE in the table.
    */
    public static final int PRESCRIPTION_MODE_IDX = 11 ;

    /**
              * <p> (DSP 09).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTUAL_PICKUP_DATE= "ACTUAL_PICKUP_DATE" ;

    /*
    * The index position of the column ACTUAL_PICKUP_DATE in the table.
    */
    public static final int ACTUAL_PICKUP_DATE_IDX = 12 ;

    /**
              * <p> 0 to 4 or 99(AIR 06).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PERSON_PICKINGUP_RX= "PERSON_PICKINGUP_RX" ;

    /*
    * The index position of the column PERSON_PICKINGUP_RX in the table.
    */
    public static final int PERSON_PICKINGUP_RX_IDX = 13 ;

    /**
              * <p> (AIR 07).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PERSON_PICKINGUP_LASTNAME= "PERSON_PICKINGUP_LASTNAME" ;

    /*
    * The index position of the column PERSON_PICKINGUP_LASTNAME in the table.
    */
    public static final int PERSON_PICKINGUP_LASTNAME_IDX = 14 ;

    /**
              * <p> (AIR 08).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PERSON_PICKINGUP_FIRSTNAME= "PERSON_PICKINGUP_FIRSTNAME" ;

    /*
    * The index position of the column PERSON_PICKINGUP_FIRSTNAME in the table.
    */
    public static final int PERSON_PICKINGUP_FIRSTNAME_IDX = 15 ;

    /**
              * <p> 1 to 2 or 98(AIR 11).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DROPPING_OFF_ID_QUALIFIER= "DROPPING_OFF_ID_QUALIFIER" ;

    /*
    * The index position of the column DROPPING_OFF_ID_QUALIFIER in the table.
    */
    public static final int DROPPING_OFF_ID_QUALIFIER_IDX = 16 ;

    /**
              * <p> (AIR 03).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PERSON_PICKING_ID_JURISDICTION= "PERSON_PICKING_ID_JURISDICTION" ;

    /*
    * The index position of the column PERSON_PICKING_ID_JURISDICTION in the table.
    */
    public static final int PERSON_PICKING_ID_JURISDICTION_IDX = 17 ;

    /**
              * <p> 1 to 8 or 99(AIR 04).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PERSON_PICKING_ID_QUALIFIER= "PERSON_PICKING_ID_QUALIFIER" ;

    /*
    * The index position of the column PERSON_PICKING_ID_QUALIFIER in the table.
    */
    public static final int PERSON_PICKING_ID_QUALIFIER_IDX = 18 ;

    /**
              * <p> (AIR 05).</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PERSON_PICKING_ID= "PERSON_PICKING_ID" ;

    /*
    * The index position of the column PERSON_PICKING_ID in the table.
    */
    public static final int PERSON_PICKING_ID_IDX = 19 ;

    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRESCRIBER_ID= "PRESCRIBER_ID" ;

    /*
    * The index position of the column PRESCRIBER_ID in the table.
    */
    public static final int PRESCRIBER_ID_IDX = 20 ;

    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DISPENSER_ID= "DISPENSER_ID" ;

    /*
    * The index position of the column DISPENSER_ID in the table.
    */
    public static final int DISPENSER_ID_IDX = 21 ;

    /**
              * <p> Unique Number of Product (DSP 02).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRESCRIPTION_NUMBER= "PRESCRIPTION_NUMBER" ;

    /*
    * The index position of the column PRESCRIPTION_NUMBER in the table.
    */
    public static final int PRESCRIPTION_NUMBER_IDX = 22 ;

    /**
              * <p> If it is submitted to the board of pharmacy,it will be set to true when you click "Generate Report and Mark Status as Submitted". By default,It will be set to false..</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_REPORT_GENERATED= "IS_REPORT_GENERATED" ;

    /*
    * The index position of the column IS_REPORT_GENERATED in the table.
    */
    public static final int IS_REPORT_GENERATED_IDX = 23 ;

}
