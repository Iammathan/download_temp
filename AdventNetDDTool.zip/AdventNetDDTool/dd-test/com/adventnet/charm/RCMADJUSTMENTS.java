package com.adventnet.charm;

/** <p> Description of the table <code>RCMAdjustments</code>.
 *  Column Name and Table Name of  database table  <code>RCMAdjustments</code> is mapped
 * as constants in this util.</p> 
  Adjustment table. Data is dumped in RCM SPACE. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ADJUSTMENT_ID}
  * </ul>
 */
 
public final class RCMADJUSTMENTS
{
    private RCMADJUSTMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMAdjustments" ;
    /**
              * <p> Primary Key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_ID= "ADJUSTMENT_ID" ;

    /*
    * The index position of the column ADJUSTMENT_ID in the table.
    */
    public static final int ADJUSTMENT_ID_IDX = 1 ;

    /**
              * <p> Name of Adjustment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_TYPE= "ADJUSTMENT_TYPE" ;

    /*
    * The index position of the column ADJUSTMENT_TYPE in the table.
    */
    public static final int ADJUSTMENT_TYPE_IDX = 2 ;

    /**
              * <p> Description of the Adjustment Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_DESC= "ADJUSTMENT_DESC" ;

    /*
    * The index position of the column ADJUSTMENT_DESC in the table.
    */
    public static final int ADJUSTMENT_DESC_IDX = 3 ;

    /**
              * <p> Adjustment deletable or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String CANNOT_BE_DELETED= "CANNOT_BE_DELETED" ;

    /*
    * The index position of the column CANNOT_BE_DELETED in the table.
    */
    public static final int CANNOT_BE_DELETED_IDX = 4 ;

    /**
              * <p> Reason for cannot deleting the Adustment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NO_DELETE_REASON= "NO_DELETE_REASON" ;

    /*
    * The index position of the column NO_DELETE_REASON in the table.
    */
    public static final int NO_DELETE_REASON_IDX = 5 ;

}
