package com.adventnet.charm;

/** <p> Description of the table <code>AnnouncementsAuditDetails</code>.
 *  Column Name and Table Name of  database table  <code>AnnouncementsAuditDetails</code> is mapped
 * as constants in this util.</p> 
  details of announcement. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ANNOUNCEMENT_AUDIT_ID}
  * </ul>
 */
 
public final class ANNOUNCEMENTSAUDITDETAILS
{
    private ANNOUNCEMENTSAUDITDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AnnouncementsAuditDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ANNOUNCEMENT_AUDIT_ID= "ANNOUNCEMENT_AUDIT_ID" ;

    /*
    * The index position of the column ANNOUNCEMENT_AUDIT_ID in the table.
    */
    public static final int ANNOUNCEMENT_AUDIT_ID_IDX = 1 ;

    /**
              * <p> member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ANNOUNCEMENT_ID= "ANNOUNCEMENT_ID" ;

    /*
    * The index position of the column ANNOUNCEMENT_ID in the table.
    */
    public static final int ANNOUNCEMENT_ID_IDX = 2 ;

    /**
              * <p> member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> practice id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 4 ;

    /**
              * <p> Number of clicks.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NO_OF_VIEWS= "NO_OF_VIEWS" ;

    /*
    * The index position of the column NO_OF_VIEWS in the table.
    */
    public static final int NO_OF_VIEWS_IDX = 5 ;

    /**
              * <p> Added time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 6 ;

    /**
              * <p> Latest updated time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String UPDATED_TIME= "UPDATED_TIME" ;

    /*
    * The index position of the column UPDATED_TIME in the table.
    */
    public static final int UPDATED_TIME_IDX = 7 ;

}
