package com.adventnet.charm;

/** <p> Description of the table <code>FaxNotes</code>.
 *  Column Name and Table Name of  database table  <code>FaxNotes</code> is mapped
 * as constants in this util.</p> 
   add notes to fax . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FAX_NOTES_ID}
  * </ul>
 */
 
public final class FAXNOTES
{
    private FAXNOTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FaxNotes" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FAX_NOTES_ID= "FAX_NOTES_ID" ;

    /*
    * The index position of the column FAX_NOTES_ID in the table.
    */
    public static final int FAX_NOTES_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_FAX_MAP_ID= "RCM_FAX_MAP_ID" ;

    /*
    * The index position of the column RCM_FAX_MAP_ID in the table.
    */
    public static final int RCM_FAX_MAP_ID_IDX = 2 ;

    /**
              * <p> INBOUND or OUTBOUND.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 3 ;

    /**
              * <p> Notes about the corresponding fax.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 4 ;

    /**
              * <p> date of adding Notes.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 5 ;

    /**
              * <p> The fax user who is added.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 6 ;

}
