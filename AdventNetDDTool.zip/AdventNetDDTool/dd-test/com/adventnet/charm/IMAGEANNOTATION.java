package com.adventnet.charm;

/** <p> Description of the table <code>ImageAnnotation</code>.
 *  Column Name and Table Name of  database table  <code>ImageAnnotation</code> is mapped
 * as constants in this util.</p> 
  This table stores the Image Annotations in SVG and JSON format. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ANNOTATION_ID}
  * </ul>
 */
 
public final class IMAGEANNOTATION
{
    private IMAGEANNOTATION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageAnnotation" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ANNOTATION_ID= "ANNOTATION_ID" ;

    /*
    * The index position of the column ANNOTATION_ID in the table.
    */
    public static final int ANNOTATION_ID_IDX = 1 ;

    /**
              * <p> Name of this Annotation.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ANNOTATION_NAME= "ANNOTATION_NAME" ;

    /*
    * The index position of the column ANNOTATION_NAME in the table.
    */
    public static final int ANNOTATION_NAME_IDX = 2 ;

    /**
              * <p> Base Image for this Annotation. Refers ImageAnnotationLibrary.IMAGE_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BASE_IMAGE_ID= "BASE_IMAGE_ID" ;

    /*
    * The index position of the column BASE_IMAGE_ID in the table.
    */
    public static final int BASE_IMAGE_ID_IDX = 3 ;

    /**
              * <p> SVG Content in JSON format..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ANNOTATION_JSON= "ANNOTATION_JSON" ;

    /*
    * The index position of the column ANNOTATION_JSON in the table.
    */
    public static final int ANNOTATION_JSON_IDX = 4 ;

    /**
              * <p> Annotation SVG Content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ANNOTATION_SVG= "ANNOTATION_SVG" ;

    /*
    * The index position of the column ANNOTATION_SVG in the table.
    */
    public static final int ANNOTATION_SVG_IDX = 5 ;

    /**
              * <p> Comment for this annotation.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 6 ;

    /**
              * <p> To check whether the Annotation is deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 7 ;

    /**
              * <p> Base file ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BASE_FILE_ID= "BASE_FILE_ID" ;

    /*
    * The index position of the column BASE_FILE_ID in the table.
    */
    public static final int BASE_FILE_ID_IDX = 8 ;

    /**
              * <p> Width of the file.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_WIDTH= "FILE_WIDTH" ;

    /*
    * The index position of the column FILE_WIDTH in the table.
    */
    public static final int FILE_WIDTH_IDX = 9 ;

    /**
              * <p> Height of the file.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_HEIGHT= "FILE_HEIGHT" ;

    /*
    * The index position of the column FILE_HEIGHT in the table.
    */
    public static final int FILE_HEIGHT_IDX = 10 ;

}
