package com.adventnet.charm;

/** <p> Description of the table <code>ReferralHistory</code>.
 *  Column Name and Table Name of  database table  <code>ReferralHistory</code> is mapped
 * as constants in this util.</p> 
  List of referral mails sent by practice members.Data is stored in profilespace.. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REF_HISTORY_ID}
  * </ul>
 */
 
public final class REFERRALHISTORY
{
    private REFERRALHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ReferralHistory" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_HISTORY_ID= "REF_HISTORY_ID" ;

    /*
    * The index position of the column REF_HISTORY_ID in the table.
    */
    public static final int REF_HISTORY_ID_IDX = 1 ;

    /**
              * <p> ID of the practice of the respective member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> ID of the facility of the respective member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> ID of the member who is referring.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 4 ;

    /**
              * <p> Name of the member who is referring.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEMBER_NAME= "MEMBER_NAME" ;

    /*
    * The index position of the column MEMBER_NAME in the table.
    */
    public static final int MEMBER_NAME_IDX = 5 ;

    /**
              * <p> From email id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FROM= "FROM" ;

    /*
    * The index position of the column FROM in the table.
    */
    public static final int FROM_IDX = 6 ;

    /**
              * <p> To email ids.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TO= "TO" ;

    /*
    * The index position of the column TO in the table.
    */
    public static final int TO_IDX = 7 ;

    /**
              * <p> Carbon Copy email ids.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CC= "CC" ;

    /*
    * The index position of the column CC in the table.
    */
    public static final int CC_IDX = 8 ;

    /**
              * <p> Date and time of referring.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_DATE= "REF_DATE" ;

    /*
    * The index position of the column REF_DATE in the table.
    */
    public static final int REF_DATE_IDX = 9 ;

    /**
              * <p> Place of referring either from RCM or EHR.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REF_FROM= "REF_FROM" ;

    /*
    * The index position of the column REF_FROM in the table.
    */
    public static final int REF_FROM_IDX = 10 ;

    /**
              * <p> subject of the email.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBJECT= "SUBJECT" ;

    /*
    * The index position of the column SUBJECT in the table.
    */
    public static final int SUBJECT_IDX = 11 ;

    /**
              * <p> DFS path of the content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONTENT_PATH= "CONTENT_PATH" ;

    /*
    * The index position of the column CONTENT_PATH in the table.
    */
    public static final int CONTENT_PATH_IDX = 12 ;

    /**
              * <p> Comments.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 13 ;

}
