package com.adventnet.charm;

/** <p> Description of the table <code>LabUserCredentials</code>.
 *  Column Name and Table Name of  database table  <code>LabUserCredentials</code> is mapped
 * as constants in this util.</p> 
  Store user credentials for Quest Lab- Practice specific. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_USER_CREDENTIAL_ID}
  * </ul>
 */
 
public final class LABUSERCREDENTIALS
{
    private LABUSERCREDENTIALS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabUserCredentials" ;
    /**
              * <p> Unique identifier for LabUserCredentials.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_USER_CREDENTIAL_ID= "LAB_USER_CREDENTIAL_ID" ;

    /*
    * The index position of the column LAB_USER_CREDENTIAL_ID in the table.
    */
    public static final int LAB_USER_CREDENTIAL_ID_IDX = 1 ;

    /**
              * <p> User name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String USER_NAME= "USER_NAME" ;

    /*
    * The index position of the column USER_NAME in the table.
    */
    public static final int USER_NAME_IDX = 2 ;

    /**
              * <p> Password.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PASSWORD= "PASSWORD" ;

    /*
    * The index position of the column PASSWORD in the table.
    */
    public static final int PASSWORD_IDX = 3 ;

    /**
              * <p> Password.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AUTH_CODE= "AUTH_CODE" ;

    /*
    * The index position of the column AUTH_CODE in the table.
    */
    public static final int AUTH_CODE_IDX = 4 ;

}
