package com.adventnet.charm;

/** <p> Description of the table <code>AppointmentVisitMap</code>.
 *  Column Name and Table Name of  database table  <code>AppointmentVisitMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between AppointmentHistory and VisitTypes . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #APPOINTMENT_ID}
  * </ul>
 */
 
public final class APPOINTMENTVISITMAP
{
    private APPOINTMENTVISITMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AppointmentVisitMap" ;
    /**
              * <p> Identifier of AppointmentHistory.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 1 ;

    /**
              * <p> Identifier of VisitTypes.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 2 ;

}
