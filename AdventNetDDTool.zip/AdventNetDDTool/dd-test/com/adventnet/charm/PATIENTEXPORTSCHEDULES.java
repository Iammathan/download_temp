package com.adventnet.charm;

/** <p> Description of the table <code>PatientExportSchedules</code>.
 *  Column Name and Table Name of  database table  <code>PatientExportSchedules</code> is mapped
 * as constants in this util.</p> 
  Stores scheduler data for CCDA Patient Export. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAT_EXP_SCH_ID}
  * </ul>
 */
 
public final class PATIENTEXPORTSCHEDULES
{
    private PATIENTEXPORTSCHEDULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientExportSchedules" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAT_EXP_SCH_ID= "PAT_EXP_SCH_ID" ;

    /*
    * The index position of the column PAT_EXP_SCH_ID in the table.
    */
    public static final int PAT_EXP_SCH_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SCHEDULED_JOBS_ID= "SCHEDULED_JOBS_ID" ;

    /*
    * The index position of the column SCHEDULED_JOBS_ID in the table.
    */
    public static final int SCHEDULED_JOBS_ID_IDX = 2 ;

    /**
              * <p> data type is not boolean;0-ALL, 1-SUBSET.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * </ul>
                         */
    public static final String PAT_EXP_PAT_LIST= "PAT_EXP_PAT_LIST" ;

    /*
    * The index position of the column PAT_EXP_PAT_LIST in the table.
    */
    public static final int PAT_EXP_PAT_LIST_IDX = 3 ;

    /**
              * <p> data type is not boolean;0-BETWEEN, 1-ON, 2-IN_PAST_N_MONTHS;value mandatory if PAT_EXP_PAT_LIST is 1.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String DATE_FILTER_TYPE= "DATE_FILTER_TYPE" ;

    /*
    * The index position of the column DATE_FILTER_TYPE in the table.
    */
    public static final int DATE_FILTER_TYPE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ON_DATE= "ON_DATE" ;

    /*
    * The index position of the column ON_DATE in the table.
    */
    public static final int ON_DATE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * <li><code>6</code></li>
              * <li><code>7</code></li>
              * <li><code>8</code></li>
              * <li><code>9</code></li>
              * <li><code>10</code></li>
              * <li><code>11</code></li>
              * <li><code>12</code></li>
              * </ul>
                         */
    public static final String IN_PAST_N_MONTHS= "IN_PAST_N_MONTHS" ;

    /*
    * The index position of the column IN_PAST_N_MONTHS in the table.
    */
    public static final int IN_PAST_N_MONTHS_IDX = 8 ;

    /**
              * <p> data type is not boolean;0-Export Now, 1-Export later once, 2- Repeat Periodically.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                     * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String EXPORT_OPTION= "EXPORT_OPTION" ;

    /*
    * The index position of the column EXPORT_OPTION in the table.
    */
    public static final int EXPORT_OPTION_IDX = 9 ;

    /**
                            * Data Type of this field is <code>TIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SCHEDULED_TIME_OF_DAY= "SCHEDULED_TIME_OF_DAY" ;

    /*
    * The index position of the column SCHEDULED_TIME_OF_DAY in the table.
    */
    public static final int SCHEDULED_TIME_OF_DAY_IDX = 10 ;

    /**
              * <p> value is mandatory if EXPORT_OPTION is 0 or 1 (If 0, we hide it in view).</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SCHEDULED_DATE= "SCHEDULED_DATE" ;

    /*
    * The index position of the column SCHEDULED_DATE in the table.
    */
    public static final int SCHEDULED_DATE_IDX = 11 ;

    /**
              * <p> data type is not boolean;0-Monthly, 1-Yearly;value mandatory if EXPORT_OPTION is 2;.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * </ul>
                         */
    public static final String REPEAT_SCHEDULE= "REPEAT_SCHEDULE" ;

    /*
    * The index position of the column REPEAT_SCHEDULE in the table.
    */
    public static final int REPEAT_SCHEDULE_IDX = 12 ;

    /**
              * <p> value mandatory if EXPORT_OPTION is 2.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * <li><code>6</code></li>
              * <li><code>7</code></li>
              * <li><code>8</code></li>
              * <li><code>9</code></li>
              * <li><code>10</code></li>
              * <li><code>11</code></li>
              * <li><code>12</code></li>
              * <li><code>13</code></li>
              * <li><code>14</code></li>
              * <li><code>15</code></li>
              * <li><code>16</code></li>
              * <li><code>17</code></li>
              * <li><code>18</code></li>
              * <li><code>19</code></li>
              * <li><code>20</code></li>
              * <li><code>21</code></li>
              * <li><code>22</code></li>
              * <li><code>23</code></li>
              * <li><code>24</code></li>
              * <li><code>25</code></li>
              * <li><code>26</code></li>
              * <li><code>27</code></li>
              * <li><code>28</code></li>
              * <li><code>29</code></li>
              * <li><code>30</code></li>
              * <li><code>31</code></li>
              * </ul>
                         */
    public static final String REPEAT_DAY= "REPEAT_DAY" ;

    /*
    * The index position of the column REPEAT_DAY in the table.
    */
    public static final int REPEAT_DAY_IDX = 13 ;

    /**
              * <p> value mandatory if EXPORT_OPTION is 2 and REPEAT_SCHEDULE is monthly. 0-11 index and not 1-12.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * <li><code>3</code></li>
              * <li><code>4</code></li>
              * <li><code>5</code></li>
              * <li><code>6</code></li>
              * <li><code>7</code></li>
              * <li><code>8</code></li>
              * <li><code>9</code></li>
              * <li><code>10</code></li>
              * <li><code>11</code></li>
              * </ul>
                         */
    public static final String REPEAT_MONTH= "REPEAT_MONTH" ;

    /*
    * The index position of the column REPEAT_MONTH in the table.
    */
    public static final int REPEAT_MONTH_IDX = 14 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 15 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 16 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 17 ;

    /**
              * <p> Used only for timezone calculation. Not displayed and not used for filtering.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 18 ;

}
