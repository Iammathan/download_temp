package com.adventnet.charm;

/** <p> Description of the table <code>HealthVitalFlagEntry</code>.
 *  Column Name and Table Name of  database table  <code>HealthVitalFlagEntry</code> is mapped
 * as constants in this util.</p> 
  Table to flag default health vital entries. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HEALTH_VITAL_FLAG_ENTRY_ID}
  * </ul>
 */
 
public final class HEALTHVITALFLAGENTRY
{
    private HEALTHVITALFLAGENTRY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HealthVitalFlagEntry" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_VITAL_FLAG_ENTRY_ID= "HEALTH_VITAL_FLAG_ENTRY_ID" ;

    /*
    * The index position of the column HEALTH_VITAL_FLAG_ENTRY_ID in the table.
    */
    public static final int HEALTH_VITAL_FLAG_ENTRY_ID_IDX = 1 ;

    /**
              * <p> FK column from HealthVitalEntries.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String HEALTH_VITAL_ENTRY_ID= "HEALTH_VITAL_ENTRY_ID" ;

    /*
    * The index position of the column HEALTH_VITAL_ENTRY_ID in the table.
    */
    public static final int HEALTH_VITAL_ENTRY_ID_IDX = 2 ;

    /**
              * <p> Name of the column in HealthVitalEntries table.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 3 ;

    /**
              * <p> Staus of custom vital entries. 0 - Normal, 1 - Abnormal.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String VITAL_FLAG= "VITAL_FLAG" ;

    /*
    * The index position of the column VITAL_FLAG in the table.
    */
    public static final int VITAL_FLAG_IDX = 4 ;

}
