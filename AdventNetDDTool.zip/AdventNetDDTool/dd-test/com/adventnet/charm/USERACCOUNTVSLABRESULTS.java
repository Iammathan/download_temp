package com.adventnet.charm;

/** <p> Description of the table <code>UserAccountVsLabResults</code>.
 *  Column Name and Table Name of  database table  <code>UserAccountVsLabResults</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #USER_ACCOUNT_LAB_RESULT_ID}
  * </ul>
 */
 
public final class USERACCOUNTVSLABRESULTS
{
    private USERACCOUNTVSLABRESULTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UserAccountVsLabResults" ;
    /**
              * <p> Unique ID for UserAccountsVsLabResults.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String USER_ACCOUNT_LAB_RESULT_ID= "USER_ACCOUNT_LAB_RESULT_ID" ;

    /*
    * The index position of the column USER_ACCOUNT_LAB_RESULT_ID in the table.
    */
    public static final int USER_ACCOUNT_LAB_RESULT_ID_IDX = 1 ;

    /**
              * <p> Member id of PracticeMembersList table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> Lab Id of LabList in public space.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 3 ;

}
