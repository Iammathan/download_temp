package com.adventnet.charm;

/** <p> Description of the table <code>BillingCustomReportCategories</code>.
 *  Column Name and Table Name of  database table  <code>BillingCustomReportCategories</code> is mapped
 * as constants in this util.</p> 
  Holds the category names of billing custom report. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CUSTOM_REPORT_CATEGORY_ID}
  * </ul>
 */
 
public final class BILLINGCUSTOMREPORTCATEGORIES
{
    private BILLINGCUSTOMREPORTCATEGORIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillingCustomReportCategories" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CUSTOM_REPORT_CATEGORY_ID= "CUSTOM_REPORT_CATEGORY_ID" ;

    /*
    * The index position of the column CUSTOM_REPORT_CATEGORY_ID in the table.
    */
    public static final int CUSTOM_REPORT_CATEGORY_ID_IDX = 1 ;

    /**
              * <p> Name of the category.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CATEGORY_NAME= "CATEGORY_NAME" ;

    /*
    * The index position of the column CATEGORY_NAME in the table.
    */
    public static final int CATEGORY_NAME_IDX = 2 ;

    /**
              * <p> Total no of reports in a category.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REPORT_COUNT= "REPORT_COUNT" ;

    /*
    * The index position of the column REPORT_COUNT in the table.
    */
    public static final int REPORT_COUNT_IDX = 3 ;

}
