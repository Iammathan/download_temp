package com.adventnet.charm;

/** <p> Description of the table <code>IntakeQuesValues</code>.
 *  Column Name and Table Name of  database table  <code>IntakeQuesValues</code> is mapped
 * as constants in this util.</p> 
  Intake Questionnaire values. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * <li> {@link #CONSULTATION_ID}
  * </ul>
 */
 
public final class INTAKEQUESVALUES
{
    private INTAKEQUESVALUES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "IntakeQuesValues" ;
    /**
              * <p> Questionnaire entry id.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from ConsultationHistory table.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Intake questionnaire answer.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ANSWER= "ANSWER" ;

    /*
    * The index position of the column ANSWER in the table.
    */
    public static final int ANSWER_IDX = 3 ;

    /**
              * <p> Intake Question.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUESTION= "QUESTION" ;

    /*
    * The index position of the column QUESTION in the table.
    */
    public static final int QUESTION_IDX = 4 ;

}
