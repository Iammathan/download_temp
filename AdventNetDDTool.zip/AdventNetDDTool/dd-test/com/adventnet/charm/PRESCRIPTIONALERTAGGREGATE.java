package com.adventnet.charm;

/** <p> Description of the table <code>PrescriptionAlertAggregate</code>.
 *  Column Name and Table Name of  database table  <code>PrescriptionAlertAggregate</code> is mapped
 * as constants in this util.</p> 
  Patient Progress Entries table. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PRESCRIPTION_ID}
  * <li> {@link #OBSERVATION_ID}
  * <li> {@link #PATIENT_ID}
  * <li> {@link #ALERT_TYPE}
  * </ul>
 */
 
public final class PRESCRIPTIONALERTAGGREGATE
{
    private PRESCRIPTIONALERTAGGREGATE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PrescriptionAlertAggregate" ;
    /**
              * <p> Identifier of Prescription.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRESCRIPTION_ID= "PRESCRIPTION_ID" ;

    /*
    * The index position of the column PRESCRIPTION_ID in the table.
    */
    public static final int PRESCRIPTION_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OBSERVATION_ID= "OBSERVATION_ID" ;

    /*
    * The index position of the column OBSERVATION_ID in the table.
    */
    public static final int OBSERVATION_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Alert Type where 1 is Positive or 0 is Negative.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ALERT_TYPE= "ALERT_TYPE" ;

    /*
    * The index position of the column ALERT_TYPE in the table.
    */
    public static final int ALERT_TYPE_IDX = 4 ;

    /**
              * <p> Number of alerts that occurred for this PK .</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ALERT_COUNT= "ALERT_COUNT" ;

    /*
    * The index position of the column ALERT_COUNT in the table.
    */
    public static final int ALERT_COUNT_IDX = 5 ;

}
