package com.adventnet.charm;

/** <p> Description of the table <code>ImageOrders</code>.
 *  Column Name and Table Name of  database table  <code>ImageOrders</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_ORDER_ID}
  * </ul>
 */
 
public final class IMAGEORDERS
{
    private IMAGEORDERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageOrders" ;
    /**
              * <p> Unique value for the Image Order.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_ORDER_ID= "IMAGE_ORDER_ID" ;

    /*
    * The index position of the column IMAGE_ORDER_ID in the table.
    */
    public static final int IMAGE_ORDER_ID_IDX = 1 ;

    /**
              * <p> Patient id to whom Image is Ordered.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Ordered by Member id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Date on which Image is Ordered.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 4 ;

    /**
              * <p> Status of the Image Order - 0 -> Pending / 1 -> Partial/ 2 -> Completed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 5 ;

    /**
              * <p> Image Ordered during Consultation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 6 ;

    /**
              * <p> Facility id .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 7 ;

    /**
              * <p> Notes to patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String IMAGE_NOTES= "IMAGE_NOTES" ;

    /*
    * The index position of the column IMAGE_NOTES in the table.
    */
    public static final int IMAGE_NOTES_IDX = 8 ;

    /**
              * <p> Intra office notes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String INTRA_OFFICE_NOTES= "INTRA_OFFICE_NOTES" ;

    /*
    * The index position of the column INTRA_OFFICE_NOTES in the table.
    */
    public static final int INTRA_OFFICE_NOTES_IDX = 9 ;

    /**
              * <p> Image Reference Number. This value will be printed in the pdf image orders..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IMAGE_REFERENCE_NUMBER= "IMAGE_REFERENCE_NUMBER" ;

    /*
    * The index position of the column IMAGE_REFERENCE_NUMBER in the table.
    */
    public static final int IMAGE_REFERENCE_NUMBER_IDX = 10 ;

    /**
              * <p> Facility id .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 11 ;

    /**
              * <p> Facility id .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 12 ;

    /**
              * <p> Whether the Dx is mapped from encounter tab.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MAPPED_WITH_ENC_DX= "IS_MAPPED_WITH_ENC_DX" ;

    /*
    * The index position of the column IS_MAPPED_WITH_ENC_DX in the table.
    */
    public static final int IS_MAPPED_WITH_ENC_DX_IDX = 13 ;

}
