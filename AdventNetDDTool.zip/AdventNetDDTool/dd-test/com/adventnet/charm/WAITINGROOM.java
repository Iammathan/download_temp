package com.adventnet.charm;

/** <p> Description of the table <code>WaitingRoom</code>.
 *  Column Name and Table Name of  database table  <code>WaitingRoom</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #WAITING_ROOM_ID}
  * </ul>
 */
 
public final class WAITINGROOM
{
    private WAITINGROOM()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "WaitingRoom" ;
    /**
              * <p> PK of WaitingRoom.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WAITING_ROOM_ID= "WAITING_ROOM_ID" ;

    /*
    * The index position of the column WAITING_ROOM_ID in the table.
    */
    public static final int WAITING_ROOM_ID_IDX = 1 ;

    /**
              * <p> Stores Patient ID of related patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Requested member for the consultaion.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SPECIALITY_ID= "SPECIALITY_ID" ;

    /*
    * The index position of the column SPECIALITY_ID in the table.
    */
    public static final int SPECIALITY_ID_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 7 ;

    /**
              * <p> Reason for this appointment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REASON= "REASON" ;

    /*
    * The index position of the column REASON in the table.
    */
    public static final int REASON_IDX = 8 ;

    /**
              * <p>  0. Waiting, 1. Provider Assigned, 2. Payment Collected (optional), 3. Forms Filled (optional), 4. Ready to Consult, 5. Patient Joined, 6. Consulted, -1. Cancelled .</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 9 ;

    /**
              * <p> Long time when was the entry added.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_BY= "LAST_MODIFIED_BY" ;

    /*
    * The index position of the column LAST_MODIFIED_BY in the table.
    */
    public static final int LAST_MODIFIED_BY_IDX = 11 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 12 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MOBILE= "MOBILE" ;

    /*
    * The index position of the column MOBILE in the table.
    */
    public static final int MOBILE_IDX = 13 ;

    /**
              * <p> Last time when patient is online.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_AVAILABLE_TIME= "LAST_AVAILABLE_TIME" ;

    /*
    * The index position of the column LAST_AVAILABLE_TIME in the table.
    */
    public static final int LAST_AVAILABLE_TIME_IDX = 14 ;

    /**
              * <p> Anonymous zuid created for sending wms notifications.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ANONYMOUS_ZUID= "ANONYMOUS_ZUID" ;

    /*
    * The index position of the column ANONYMOUS_ZUID in the table.
    */
    public static final int ANONYMOUS_ZUID_IDX = 15 ;

    /**
              * <p> Location passed along with consult_now url.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LOCATION= "LOCATION" ;

    /*
    * The index position of the column LOCATION in the table.
    */
    public static final int LOCATION_IDX = 16 ;

}
