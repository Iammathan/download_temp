package com.adventnet.charm;

/** <p> Description of the table <code>SMSToWorkflowStepMap</code>.
 *  Column Name and Table Name of  database table  <code>SMSToWorkflowStepMap</code> is mapped
 * as constants in this util.</p> 
  2 way SMS conversation thread (practice space). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SMS_WFSTEP_MAP_ID}
  * </ul>
 */
 
public final class SMSTOWORKFLOWSTEPMAP
{
    private SMSTOWORKFLOWSTEPMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SMSToWorkflowStepMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SMS_WFSTEP_MAP_ID= "SMS_WFSTEP_MAP_ID" ;

    /*
    * The index position of the column SMS_WFSTEP_MAP_ID in the table.
    */
    public static final int SMS_WFSTEP_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SMS_TRANSACTION_ID= "SMS_TRANSACTION_ID" ;

    /*
    * The index position of the column SMS_TRANSACTION_ID in the table.
    */
    public static final int SMS_TRANSACTION_ID_IDX = 2 ;

    /**
              * <p> SMS Workflow step ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SMS_WORKFLOW_STEP_ID= "SMS_WORKFLOW_STEP_ID" ;

    /*
    * The index position of the column SMS_WORKFLOW_STEP_ID in the table.
    */
    public static final int SMS_WORKFLOW_STEP_ID_IDX = 3 ;

    /**
              * <p> References MobileNotifcations.PRACTICE_NOTIFICATION_ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 4 ;

    /**
              * <p> References IncomingSMS.INCOMING_SMS_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESPONSE_MESSAGE_ID= "RESPONSE_MESSAGE_ID" ;

    /*
    * The index position of the column RESPONSE_MESSAGE_ID in the table.
    */
    public static final int RESPONSE_MESSAGE_ID_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STEP_RESPONSE= "STEP_RESPONSE" ;

    /*
    * The index position of the column STEP_RESPONSE in the table.
    */
    public static final int STEP_RESPONSE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RESPONSE_PARSED_DATA= "RESPONSE_PARSED_DATA" ;

    /*
    * The index position of the column RESPONSE_PARSED_DATA in the table.
    */
    public static final int RESPONSE_PARSED_DATA_IDX = 7 ;

    /**
              * <p> References TextMessages.TEXT_MESSAGE_ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEXT_MESSAGE_ID= "TEXT_MESSAGE_ID" ;

    /*
    * The index position of the column TEXT_MESSAGE_ID in the table.
    */
    public static final int TEXT_MESSAGE_ID_IDX = 8 ;

}
