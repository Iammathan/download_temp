package com.adventnet.charm;

/** <p> Description of the table <code>SavedCSReport</code>.
 *  Column Name and Table Name of  database table  <code>SavedCSReport</code> is mapped
 * as constants in this util.</p> 
  Table for stored reports search criteria. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SAVED_CS_REPORT_ID}
  * </ul>
 */
 
public final class SAVEDCSREPORT
{
    private SAVEDCSREPORT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SavedCSReport" ;
    /**
              * <p> Unique id for each report.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SAVED_CS_REPORT_ID= "SAVED_CS_REPORT_ID" ;

    /*
    * The index position of the column SAVED_CS_REPORT_ID in the table.
    */
    public static final int SAVED_CS_REPORT_ID_IDX = 1 ;

    /**
              * <p> Name of the report.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REPORT_NAME= "REPORT_NAME" ;

    /*
    * The index position of the column REPORT_NAME in the table.
    */
    public static final int REPORT_NAME_IDX = 2 ;

    /**
              * <p> Id of the member on the report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CRITERIA_MEMBER_ID= "CRITERIA_MEMBER_ID" ;

    /*
    * The index position of the column CRITERIA_MEMBER_ID in the table.
    */
    public static final int CRITERIA_MEMBER_ID_IDX = 3 ;

    /**
              * <p> Name of the member on the report.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CRITERIA_MEMBER_NAME= "CRITERIA_MEMBER_NAME" ;

    /*
    * The index position of the column CRITERIA_MEMBER_NAME in the table.
    */
    public static final int CRITERIA_MEMBER_NAME_IDX = 4 ;

    /**
              * <p> Start date of the report.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CRITERIA_FROM_DATE= "CRITERIA_FROM_DATE" ;

    /*
    * The index position of the column CRITERIA_FROM_DATE in the table.
    */
    public static final int CRITERIA_FROM_DATE_IDX = 5 ;

    /**
              * <p> End date of the report.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CRITERIA_TO_DATE= "CRITERIA_TO_DATE" ;

    /*
    * The index position of the column CRITERIA_TO_DATE in the table.
    */
    public static final int CRITERIA_TO_DATE_IDX = 6 ;

    /**
              * <p> Date when the criteria was saved.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_ADDED_ON= "REPORT_ADDED_ON" ;

    /*
    * The index position of the column REPORT_ADDED_ON in the table.
    */
    public static final int REPORT_ADDED_ON_IDX = 7 ;

    /**
              * <p> Name of member who created the report.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_ADDED_BY= "REPORT_ADDED_BY" ;

    /*
    * The index position of the column REPORT_ADDED_BY in the table.
    */
    public static final int REPORT_ADDED_BY_IDX = 8 ;

    /**
              * <p> Date when the criteria was saved.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPORT_UPDATED_ON= "REPORT_UPDATED_ON" ;

    /*
    * The index position of the column REPORT_UPDATED_ON in the table.
    */
    public static final int REPORT_UPDATED_ON_IDX = 9 ;

    /**
              * <p> Drug type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_TYPE= "DRUG_TYPE" ;

    /*
    * The index position of the column DRUG_TYPE in the table.
    */
    public static final int DRUG_TYPE_IDX = 10 ;

    /**
              * <p> sign status of the drug.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SIGN_STATUS= "SIGN_STATUS" ;

    /*
    * The index position of the column SIGN_STATUS in the table.
    */
    public static final int SIGN_STATUS_IDX = 11 ;

}
