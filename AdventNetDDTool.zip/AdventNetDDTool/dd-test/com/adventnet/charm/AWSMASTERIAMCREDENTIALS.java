package com.adventnet.charm;

/** <p> Description of the table <code>AWSMasterIAMCredentials</code>.
 *  Column Name and Table Name of  database table  <code>AWSMasterIAMCredentials</code> is mapped
 * as constants in this util.</p> 
   Contains the master IAM credentials which is used to perform amazon admin console use cases . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AWS_MASTER_IAM_CREDENTIALS_ID}
  * </ul>
 */
 
public final class AWSMASTERIAMCREDENTIALS
{
    private AWSMASTERIAMCREDENTIALS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AWSMasterIAMCredentials" ;
    /**
              * <p> Primary Key for AWS IAM Credentials table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_MASTER_IAM_CREDENTIALS_ID= "AWS_MASTER_IAM_CREDENTIALS_ID" ;

    /*
    * The index position of the column AWS_MASTER_IAM_CREDENTIALS_ID in the table.
    */
    public static final int AWS_MASTER_IAM_CREDENTIALS_ID_IDX = 1 ;

    /**
              * <p> Name of the IAM user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>128</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MASTER_USER_NAME= "MASTER_USER_NAME" ;

    /*
    * The index position of the column MASTER_USER_NAME in the table.
    */
    public static final int MASTER_USER_NAME_IDX = 2 ;

    /**
              * <p> Access key of the IAM user.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MASTER_ACCESS_KEY= "MASTER_ACCESS_KEY" ;

    /*
    * The index position of the column MASTER_ACCESS_KEY in the table.
    */
    public static final int MASTER_ACCESS_KEY_IDX = 3 ;

    /**
              * <p> Secret access key of the IAM user.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MASTER_SECRET_ACCESS_KEY= "MASTER_SECRET_ACCESS_KEY" ;

    /*
    * The index position of the column MASTER_SECRET_ACCESS_KEY in the table.
    */
    public static final int MASTER_SECRET_ACCESS_KEY_IDX = 4 ;

    /**
              * <p> Contains the date when it is updated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MASTER_UPDATED_DATE= "MASTER_UPDATED_DATE" ;

    /*
    * The index position of the column MASTER_UPDATED_DATE in the table.
    */
    public static final int MASTER_UPDATED_DATE_IDX = 5 ;

    /**
              * <p> Contains the region name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MASTER_REGION_NAME= "MASTER_REGION_NAME" ;

    /*
    * The index position of the column MASTER_REGION_NAME in the table.
    */
    public static final int MASTER_REGION_NAME_IDX = 6 ;

}
