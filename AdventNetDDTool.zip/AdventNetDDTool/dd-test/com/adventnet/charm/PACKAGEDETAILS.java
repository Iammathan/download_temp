package com.adventnet.charm;

/** <p> Description of the table <code>PackageDetails</code>.
 *  Column Name and Table Name of  database table  <code>PackageDetails</code> is mapped
 * as constants in this util.</p> 
  Holds the custom packages added by the practive. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PACKAGE_ID}
  * </ul>
 */
 
public final class PACKAGEDETAILS
{
    private PACKAGEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PackageDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PACKAGE_ID= "PACKAGE_ID" ;

    /*
    * The index position of the column PACKAGE_ID in the table.
    */
    public static final int PACKAGE_ID_IDX = 1 ;

    /**
              * <p> Name of the package.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PACKAGE_NAME= "PACKAGE_NAME" ;

    /*
    * The index position of the column PACKAGE_NAME in the table.
    */
    public static final int PACKAGE_NAME_IDX = 2 ;

    /**
              * <p> Code for the package.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PACKAGE_CODE= "PACKAGE_CODE" ;

    /*
    * The index position of the column PACKAGE_CODE in the table.
    */
    public static final int PACKAGE_CODE_IDX = 3 ;

    /**
              * <p> Comments/descriptions for the package.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PACKAGE_DETAILS= "PACKAGE_DETAILS" ;

    /*
    * The index position of the column PACKAGE_DETAILS in the table.
    */
    public static final int PACKAGE_DETAILS_IDX = 4 ;

    /**
              * <p> Unique identifier of package code number.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PACKAGE_CPT_CODE_ID= "PACKAGE_CPT_CODE_ID" ;

    /*
    * The index position of the column PACKAGE_CPT_CODE_ID in the table.
    */
    public static final int PACKAGE_CPT_CODE_ID_IDX = 5 ;

    /**
              * <p> Period of the package.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PACKAGE_PERIOD= "PACKAGE_PERIOD" ;

    /*
    * The index position of the column PACKAGE_PERIOD in the table.
    */
    public static final int PACKAGE_PERIOD_IDX = 6 ;

    /**
              * <p> Measurement of package period, Months or weeks or days.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                     * Default Value is <code>months</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PACKAGE_PERIOD_METRICS= "PACKAGE_PERIOD_METRICS" ;

    /*
    * The index position of the column PACKAGE_PERIOD_METRICS in the table.
    */
    public static final int PACKAGE_PERIOD_METRICS_IDX = 7 ;

    /**
              * <p> whether to allow package to be shared among family or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_FAMILY_SHARING= "ALLOW_FAMILY_SHARING" ;

    /*
    * The index position of the column ALLOW_FAMILY_SHARING in the table.
    */
    public static final int ALLOW_FAMILY_SHARING_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String CHARGE_PATIENTS_DURING_VISIT= "CHARGE_PATIENTS_DURING_VISIT" ;

    /*
    * The index position of the column CHARGE_PATIENTS_DURING_VISIT in the table.
    */
    public static final int CHARGE_PATIENTS_DURING_VISIT_IDX = 9 ;

    /**
              * <p> Whether package is active or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 10 ;

}
