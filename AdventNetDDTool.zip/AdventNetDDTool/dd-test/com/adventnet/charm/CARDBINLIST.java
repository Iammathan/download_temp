package com.adventnet.charm;

/** <p> Description of the table <code>CardBinList</code>.
 *  Column Name and Table Name of  database table  <code>CardBinList</code> is mapped
 * as constants in this util.</p> 
  Table for dumping BINDB list from binbase.com. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BIN_ID}
  * </ul>
 */
 
public final class CARDBINLIST
{
    private CARDBINLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CardBinList" ;
    /**
              * <p> First 5 or 6 digits of bin.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BIN_ID= "BIN_ID" ;

    /*
    * The index position of the column BIN_ID in the table.
    */
    public static final int BIN_ID_IDX = 1 ;

    /**
              * <p> Visa, Master etc.,.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CARD_NAME= "CARD_NAME" ;

    /*
    * The index position of the column CARD_NAME in the table.
    */
    public static final int CARD_NAME_IDX = 2 ;

    /**
              * <p> For holding bank name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BANK_NAME= "BANK_NAME" ;

    /*
    * The index position of the column BANK_NAME in the table.
    */
    public static final int BANK_NAME_IDX = 3 ;

    /**
              * <p> For holding various status of verification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CARD_TYPE= "CARD_TYPE" ;

    /*
    * The index position of the column CARD_TYPE in the table.
    */
    public static final int CARD_TYPE_IDX = 4 ;

    /**
              * <p> For holding various status of verification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CARD_SUBTYPE= "CARD_SUBTYPE" ;

    /*
    * The index position of the column CARD_SUBTYPE in the table.
    */
    public static final int CARD_SUBTYPE_IDX = 5 ;

    /**
              * <p> For holding various status of verification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY= "COUNTRY" ;

    /*
    * The index position of the column COUNTRY in the table.
    */
    public static final int COUNTRY_IDX = 6 ;

    /**
              * <p> For holding various status of verification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY_SHORT= "COUNTRY_SHORT" ;

    /*
    * The index position of the column COUNTRY_SHORT in the table.
    */
    public static final int COUNTRY_SHORT_IDX = 7 ;

    /**
              * <p> For holding various status of verification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY_SHORT_1= "COUNTRY_SHORT_1" ;

    /*
    * The index position of the column COUNTRY_SHORT_1 in the table.
    */
    public static final int COUNTRY_SHORT_1_IDX = 8 ;

    /**
              * <p> For holding various status of verification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE= "CODE" ;

    /*
    * The index position of the column CODE in the table.
    */
    public static final int CODE_IDX = 9 ;

    /**
              * <p> Bank URL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String URL= "URL" ;

    /*
    * The index position of the column URL in the table.
    */
    public static final int URL_IDX = 10 ;

    /**
              * <p> Bank Phone numbers.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHONE= "PHONE" ;

    /*
    * The index position of the column PHONE in the table.
    */
    public static final int PHONE_IDX = 11 ;

}
