package com.adventnet.charm;

/** <p> Description of the table <code>PayPalQueryTransaction</code>.
 *  Column Name and Table Name of  database table  <code>PayPalQueryTransaction</code> is mapped
 * as constants in this util.</p> 
  Table contains all the response received from the PayPal on each transaction. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PAYPAL_QUERY_ID}
  * </ul>
 */
 
public final class PAYPALQUERYTRANSACTION
{
    private PAYPALQUERYTRANSACTION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PayPalQueryTransaction" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PAYPAL_QUERY_ID= "PAYPAL_QUERY_ID" ;

    /*
    * The index position of the column PAYPAL_QUERY_ID in the table.
    */
    public static final int PAYPAL_QUERY_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QUERY_DATE_TIME= "QUERY_DATE_TIME" ;

    /*
    * The index position of the column QUERY_DATE_TIME in the table.
    */
    public static final int QUERY_DATE_TIME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String QUERY_TYPE= "QUERY_TYPE" ;

    /*
    * The index position of the column QUERY_TYPE in the table.
    */
    public static final int QUERY_TYPE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROFILEID= "PROFILEID" ;

    /*
    * The index position of the column PROFILEID in the table.
    */
    public static final int PROFILEID_IDX = 4 ;

    /**
              * <p>  PLAN_CUSTOMER_ID available in the ServiceCustomerPlan .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PLAN_CUSTOMER_ID= "PLAN_CUSTOMER_ID" ;

    /*
    * The index position of the column PLAN_CUSTOMER_ID in the table.
    */
    public static final int PLAN_CUSTOMER_ID_IDX = 5 ;

    /**
              * <p>  This request should not contain the Card details and PayPal Account details .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REQEUEST_IN_JSON= "REQEUEST_IN_JSON" ;

    /*
    * The index position of the column REQEUEST_IN_JSON in the table.
    */
    public static final int REQEUEST_IN_JSON_IDX = 6 ;

    /**
              * <p> Response received from the paypal.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESPONSE_IN_JSON= "RESPONSE_IN_JSON" ;

    /*
    * The index position of the column RESPONSE_IN_JSON in the table.
    */
    public static final int RESPONSE_IN_JSON_IDX = 7 ;

    /**
              * <p> ID of the sesion.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRANSACTION_ID= "TRANSACTION_ID" ;

    /*
    * The index position of the column TRANSACTION_ID in the table.
    */
    public static final int TRANSACTION_ID_IDX = 8 ;

}
