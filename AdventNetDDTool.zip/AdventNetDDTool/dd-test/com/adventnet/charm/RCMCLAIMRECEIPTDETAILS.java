package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimReceiptDetails</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimReceiptDetails</code> is mapped
 * as constants in this util.</p> 
  RCM Claim Receipt Details : consist of receipt ID's. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_CLAIM_RECEIPT_ID}
  * </ul>
 */
 
public final class RCMCLAIMRECEIPTDETAILS
{
    private RCMCLAIMRECEIPTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimReceiptDetails" ;
    /**
              * <p> RCMClaimReceipt Id of RCMClaimReceiptDetails.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_CLAIM_RECEIPT_ID= "RCM_CLAIM_RECEIPT_ID" ;

    /*
    * The index position of the column RCM_CLAIM_RECEIPT_ID in the table.
    */
    public static final int RCM_CLAIM_RECEIPT_ID_IDX = 1 ;

    /**
              * <p> Claim Id of RCMClaimCompleteDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 2 ;

    /**
              * <p> Payment Id of RCMClaimPayments table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RCM_CP_ID= "RCM_CP_ID" ;

    /*
    * The index position of the column RCM_CP_ID in the table.
    */
    public static final int RCM_CP_ID_IDX = 3 ;

    /**
              * <p> Receipt Types Adjustment WriteOff Payment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECEIPT_TYPE= "RECEIPT_TYPE" ;

    /*
    * The index position of the column RECEIPT_TYPE in the table.
    */
    public static final int RECEIPT_TYPE_IDX = 4 ;

    /**
              * <p> Receipt Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 5 ;

    /**
              * <p> refer to BillTransactionDetails BILL_TXN_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_TXN_ID= "BILL_TXN_ID" ;

    /*
    * The index position of the column BILL_TXN_ID in the table.
    */
    public static final int BILL_TXN_ID_IDX = 6 ;

}
