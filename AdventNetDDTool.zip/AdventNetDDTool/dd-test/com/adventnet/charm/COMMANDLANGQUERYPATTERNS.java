package com.adventnet.charm;

/** <p> Description of the table <code>CommandLangQueryPatterns</code>.
 *  Column Name and Table Name of  database table  <code>CommandLangQueryPatterns</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CMMND_LANG_QUERY_PAT_ID}
  * </ul>
 */
 
public final class COMMANDLANGQUERYPATTERNS
{
    private COMMANDLANGQUERYPATTERNS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CommandLangQueryPatterns" ;
    /**
              * <p> Pk of CommandLangQueryPatterns.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CMMND_LANG_QUERY_PAT_ID= "CMMND_LANG_QUERY_PAT_ID" ;

    /*
    * The index position of the column CMMND_LANG_QUERY_PAT_ID in the table.
    */
    public static final int CMMND_LANG_QUERY_PAT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CMMND_LANG_QUERY_ID= "CMMND_LANG_QUERY_ID" ;

    /*
    * The index position of the column CMMND_LANG_QUERY_ID in the table.
    */
    public static final int CMMND_LANG_QUERY_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CMMND_LANG_PAT_ID= "CMMND_LANG_PAT_ID" ;

    /*
    * The index position of the column CMMND_LANG_PAT_ID in the table.
    */
    public static final int CMMND_LANG_PAT_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_MANDATE= "IS_MANDATE" ;

    /*
    * The index position of the column IS_MANDATE in the table.
    */
    public static final int IS_MANDATE_IDX = 4 ;

}
