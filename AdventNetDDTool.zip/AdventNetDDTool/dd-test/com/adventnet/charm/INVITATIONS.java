package com.adventnet.charm;

/** <p> Description of the table <code>Invitations</code>.
 *  Column Name and Table Name of  database table  <code>Invitations</code> is mapped
 * as constants in this util.</p> 
  Invitations history. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INVITATION_ID}
  * </ul>
 */
 
public final class INVITATIONS
{
    private INVITATIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "Invitations" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVITATION_ID= "INVITATION_ID" ;

    /*
    * The index position of the column INVITATION_ID in the table.
    */
    public static final int INVITATION_ID_IDX = 1 ;

    /**
              * <p> The time at which the invitation was sent.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 2 ;

    /**
              * <p> Identifier the person of who sent intivation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_ID= "FROM_ID" ;

    /*
    * The index position of the column FROM_ID in the table.
    */
    public static final int FROM_ID_IDX = 3 ;

    /**
              * <p> Identifier of the person received invitation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_ID= "TO_ID" ;

    /*
    * The index position of the column TO_ID in the table.
    */
    public static final int TO_ID_IDX = 4 ;

    /**
              * <p> Name of the person who sends invitation.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FROM_NAME= "FROM_NAME" ;

    /*
    * The index position of the column FROM_NAME in the table.
    */
    public static final int FROM_NAME_IDX = 5 ;

    /**
              * <p> Name of the person who was invited.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TO_NAME= "TO_NAME" ;

    /*
    * The index position of the column TO_NAME in the table.
    */
    public static final int TO_NAME_IDX = 6 ;

    /**
              * <p> User space of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_USER_SPACE= "PATIENT_USER_SPACE" ;

    /*
    * The index position of the column PATIENT_USER_SPACE in the table.
    */
    public static final int PATIENT_USER_SPACE_IDX = 7 ;

    /**
              * <p> Message given by the requester .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MESSAGE= "MESSAGE" ;

    /*
    * The index position of the column MESSAGE in the table.
    */
    public static final int MESSAGE_IDX = 8 ;

    /**
              * <p> Status of the invitation .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 9 ;

}
