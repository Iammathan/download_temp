package com.adventnet.charm;

/** <p> Description of the table <code>TeleHealthParticipantDetails</code>.
 *  Column Name and Table Name of  database table  <code>TeleHealthParticipantDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ID}
  * </ul>
 */
 
public final class TELEHEALTHPARTICIPANTDETAILS
{
    private TELEHEALTHPARTICIPANTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TeleHealthParticipantDetails" ;
    /**
              * <p> id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 1 ;

    /**
              * <p> Invitation id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVITATION_ID= "INVITATION_ID" ;

    /*
    * The index position of the column INVITATION_ID in the table.
    */
    public static final int INVITATION_ID_IDX = 2 ;

    /**
              * <p> Appointment id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 3 ;

    /**
              * <p> User name of participant.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String USER_NAME= "USER_NAME" ;

    /*
    * The index position of the column USER_NAME in the table.
    */
    public static final int USER_NAME_IDX = 4 ;

    /**
              * <p> Email id of participant.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 5 ;

    /**
              * <p> State of US participant.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHECKIN_STATE= "CHECKIN_STATE" ;

    /*
    * The index position of the column CHECKIN_STATE in the table.
    */
    public static final int CHECKIN_STATE_IDX = 6 ;

    /**
              * <p> Accept provider TOS.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROVIDER_TOS_ID= "PROVIDER_TOS_ID" ;

    /*
    * The index position of the column PROVIDER_TOS_ID in the table.
    */
    public static final int PROVIDER_TOS_ID_IDX = 7 ;

    /**
              * <p> Checkin time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHECKIN_TIME= "CHECKIN_TIME" ;

    /*
    * The index position of the column CHECKIN_TIME in the table.
    */
    public static final int CHECKIN_TIME_IDX = 8 ;

    /**
              * <p> Ip address of participant.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IP_ADDRESS= "IP_ADDRESS" ;

    /*
    * The index position of the column IP_ADDRESS in the table.
    */
    public static final int IP_ADDRESS_IDX = 9 ;

    /**
              * <p> Participate from phr,link,direct link.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                            * Default Value is <code>PHR</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PARTICIPATE_FROM= "PARTICIPATE_FROM" ;

    /*
    * The index position of the column PARTICIPATE_FROM in the table.
    */
    public static final int PARTICIPATE_FROM_IDX = 10 ;

}
