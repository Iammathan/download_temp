package com.adventnet.charm;

/** <p> Description of the table <code>DocumentCategoryList</code>.
 *  Column Name and Table Name of  database table  <code>DocumentCategoryList</code> is mapped
 * as constants in this util.</p> 
  List of categories. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CATEGORY_ID}
  * </ul>
 */
 
public final class DOCUMENTCATEGORYLIST
{
    private DOCUMENTCATEGORYLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DocumentCategoryList" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CATEGORY_ID= "CATEGORY_ID" ;

    /*
    * The index position of the column CATEGORY_ID in the table.
    */
    public static final int CATEGORY_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CATEGORY_NAME= "CATEGORY_NAME" ;

    /*
    * The index position of the column CATEGORY_NAME in the table.
    */
    public static final int CATEGORY_NAME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_ON= "CREATED_ON" ;

    /*
    * The index position of the column CREATED_ON in the table.
    */
    public static final int CREATED_ON_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MODIFIED_ON= "MODIFIED_ON" ;

    /*
    * The index position of the column MODIFIED_ON in the table.
    */
    public static final int MODIFIED_ON_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 6 ;

}
