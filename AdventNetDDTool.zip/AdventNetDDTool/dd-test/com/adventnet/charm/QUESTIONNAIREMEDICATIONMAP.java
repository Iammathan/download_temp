package com.adventnet.charm;

/** <p> Description of the table <code>QuestionnaireMedicationMap</code>.
 *  Column Name and Table Name of  database table  <code>QuestionnaireMedicationMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEDICATION_WIDGET_ENTRIES_ID}
  * </ul>
 */
 
public final class QUESTIONNAIREMEDICATIONMAP
{
    private QUESTIONNAIREMEDICATIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QuestionnaireMedicationMap" ;
    /**
              * <p> PK of MedicationWidgetEntries.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICATION_WIDGET_ENTRIES_ID= "MEDICATION_WIDGET_ENTRIES_ID" ;

    /*
    * The index position of the column MEDICATION_WIDGET_ENTRIES_ID in the table.
    */
    public static final int MEDICATION_WIDGET_ENTRIES_ID_IDX = 1 ;

    /**
              * <p> FK to PatientQuesMap.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_QUES_MAP_ID= "PATIENT_QUES_MAP_ID" ;

    /*
    * The index position of the column PATIENT_QUES_MAP_ID in the table.
    */
    public static final int PATIENT_QUES_MAP_ID_IDX = 2 ;

}
