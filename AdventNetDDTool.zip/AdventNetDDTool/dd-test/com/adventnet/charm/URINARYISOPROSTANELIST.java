package com.adventnet.charm;

/** <p> Description of the table <code>UrinaryIsoprostaneList</code>.
 *  Column Name and Table Name of  database table  <code>UrinaryIsoprostaneList</code> is mapped
 * as constants in this util.</p> 
  Urinary Isoprostane List. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #URINARY_ISOPROSTANE_ID}
  * </ul>
 */
 
public final class URINARYISOPROSTANELIST
{
    private URINARYISOPROSTANELIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UrinaryIsoprostaneList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String URINARY_ISOPROSTANE_ID= "URINARY_ISOPROSTANE_ID" ;

    /*
    * The index position of the column URINARY_ISOPROSTANE_ID in the table.
    */
    public static final int URINARY_ISOPROSTANE_ID_IDX = 1 ;

    /**
              * <p> Name of Urinary Isoprostane elements.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String URINARY_ISOPROSTANE_NAME= "URINARY_ISOPROSTANE_NAME" ;

    /*
    * The index position of the column URINARY_ISOPROSTANE_NAME in the table.
    */
    public static final int URINARY_ISOPROSTANE_NAME_IDX = 2 ;

    /**
              * <p> Maximum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MAX= "REFERENCE_MAX" ;

    /*
    * The index position of the column REFERENCE_MAX in the table.
    */
    public static final int REFERENCE_MAX_IDX = 3 ;

    /**
              * <p> Mininum reference value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERENCE_MIN= "REFERENCE_MIN" ;

    /*
    * The index position of the column REFERENCE_MIN in the table.
    */
    public static final int REFERENCE_MIN_IDX = 4 ;

}
