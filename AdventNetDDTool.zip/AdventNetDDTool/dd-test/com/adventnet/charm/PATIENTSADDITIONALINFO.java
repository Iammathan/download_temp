package com.adventnet.charm;

/** <p> Description of the table <code>PatientsAdditionalInfo</code>.
 *  Column Name and Table Name of  database table  <code>PatientsAdditionalInfo</code> is mapped
 * as constants in this util.</p> 
  Patient's additional information other that information in PracticePatientsList. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_PATIENT_MAP_ID}
  * </ul>
 */
 
public final class PATIENTSADDITIONALINFO
{
    private PATIENTSADDITIONALINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientsAdditionalInfo" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_MAP_ID= "PRACTICE_PATIENT_MAP_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_MAP_ID in the table.
    */
    public static final int PRACTICE_PATIENT_MAP_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> To check whether patient information can be shared to other CAIR members.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PROTECTION_INDICATOR= "PROTECTION_INDICATOR" ;

    /*
    * The index position of the column PROTECTION_INDICATOR in the table.
    */
    public static final int PROTECTION_INDICATOR_IDX = 3 ;

    /**
              * <p> Date on which protection indicator was enabled/disabled.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROTECTION_INDICATOR_DATE= "PROTECTION_INDICATOR_DATE" ;

    /*
    * The index position of the column PROTECTION_INDICATOR_DATE in the table.
    */
    public static final int PROTECTION_INDICATOR_DATE_IDX = 4 ;

    /**
              * <p> First name of the Patient's Mother's maiden.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MOTHER_MAIDEN_FIRST_NAME= "MOTHER_MAIDEN_FIRST_NAME" ;

    /*
    * The index position of the column MOTHER_MAIDEN_FIRST_NAME in the table.
    */
    public static final int MOTHER_MAIDEN_FIRST_NAME_IDX = 5 ;

    /**
              * <p> Last name of the Patient's Mother's maiden.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MOTHER_MAIDEN_LAST_NAME= "MOTHER_MAIDEN_LAST_NAME" ;

    /*
    * The index position of the column MOTHER_MAIDEN_LAST_NAME in the table.
    */
    public static final int MOTHER_MAIDEN_LAST_NAME_IDX = 6 ;

    /**
              * <p> To check whether patient was born in a multiple birth.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MULTIPLE_BIRTH= "IS_MULTIPLE_BIRTH" ;

    /*
    * The index position of the column IS_MULTIPLE_BIRTH in the table.
    */
    public static final int IS_MULTIPLE_BIRTH_IDX = 7 ;

    /**
              * <p> Order number in which the patient was born.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BIRTH_ORDER= "BIRTH_ORDER" ;

    /*
    * The index position of the column BIRTH_ORDER in the table.
    */
    public static final int BIRTH_ORDER_IDX = 8 ;

    /**
              * <p> Code of the reminders/recalls for patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PUBLICITY_CODE= "PUBLICITY_CODE" ;

    /*
    * The index position of the column PUBLICITY_CODE in the table.
    */
    public static final int PUBLICITY_CODE_IDX = 9 ;

    /**
              * <p> Date on which publicity code was entered.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PUBLICITY_CODE_DATE= "PUBLICITY_CODE_DATE" ;

    /*
    * The index position of the column PUBLICITY_CODE_DATE in the table.
    */
    public static final int PUBLICITY_CODE_DATE_IDX = 10 ;

    /**
              * <p> VFC eligibility for the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_VFC_ELIGIBILITY= "PATIENT_VFC_ELIGIBILITY" ;

    /*
    * The index position of the column PATIENT_VFC_ELIGIBILITY in the table.
    */
    public static final int PATIENT_VFC_ELIGIBILITY_IDX = 11 ;

    /**
              * <p> Check to send data to immunization registry.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SEND_IMMUNIZATION_DATA_TO_IR= "SEND_IMMUNIZATION_DATA_TO_IR" ;

    /*
    * The index position of the column SEND_IMMUNIZATION_DATA_TO_IR in the table.
    */
    public static final int SEND_IMMUNIZATION_DATA_TO_IR_IDX = 12 ;

    /**
              * <p> Vaccine Funding Source of the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_VACCINE_FUNDING_SOURCE= "PATIENT_VACCINE_FUNDING_SOURCE" ;

    /*
    * The index position of the column PATIENT_VACCINE_FUNDING_SOURCE in the table.
    */
    public static final int PATIENT_VACCINE_FUNDING_SOURCE_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYMENT_SOURCE= "PAYMENT_SOURCE" ;

    /*
    * The index position of the column PAYMENT_SOURCE in the table.
    */
    public static final int PAYMENT_SOURCE_IDX = 14 ;

    /**
              * <p> Payment source start date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_START_DATE= "PAYMENT_START_DATE" ;

    /*
    * The index position of the column PAYMENT_START_DATE in the table.
    */
    public static final int PAYMENT_START_DATE_IDX = 15 ;

    /**
              * <p> Payment source end date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_END_DATE= "PAYMENT_END_DATE" ;

    /*
    * The index position of the column PAYMENT_END_DATE in the table.
    */
    public static final int PAYMENT_END_DATE_IDX = 16 ;

    /**
              * <p> Primary care physician of the patient. Stores Referral Id from Referral Directory..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRIMARY_CARE_PHYSICIAN= "PRIMARY_CARE_PHYSICIAN" ;

    /*
    * The index position of the column PRIMARY_CARE_PHYSICIAN in the table.
    */
    public static final int PRIMARY_CARE_PHYSICIAN_IDX = 17 ;

    /**
              * <p> Decides if email notification should be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String EMAIL_NOTIFICATION= "EMAIL_NOTIFICATION" ;

    /*
    * The index position of the column EMAIL_NOTIFICATION in the table.
    */
    public static final int EMAIL_NOTIFICATION_IDX = 18 ;

    /**
              * <p> Decides if text notification should be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TEXT_NOTIFICATION= "TEXT_NOTIFICATION" ;

    /*
    * The index position of the column TEXT_NOTIFICATION in the table.
    */
    public static final int TEXT_NOTIFICATION_IDX = 19 ;

    /**
              * <p> Decides if voice notification should be sent to the patient.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String VOICE_NOTIFICATION= "VOICE_NOTIFICATION" ;

    /*
    * The index position of the column VOICE_NOTIFICATION in the table.
    */
    public static final int VOICE_NOTIFICATION_IDX = 20 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CUSTOM_FIELD_1= "CUSTOM_FIELD_1" ;

    /*
    * The index position of the column CUSTOM_FIELD_1 in the table.
    */
    public static final int CUSTOM_FIELD_1_IDX = 21 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CUSTOM_FIELD_2= "CUSTOM_FIELD_2" ;

    /*
    * The index position of the column CUSTOM_FIELD_2 in the table.
    */
    public static final int CUSTOM_FIELD_2_IDX = 22 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CUSTOM_FIELD_3= "CUSTOM_FIELD_3" ;

    /*
    * The index position of the column CUSTOM_FIELD_3 in the table.
    */
    public static final int CUSTOM_FIELD_3_IDX = 23 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CUSTOM_FIELD_4= "CUSTOM_FIELD_4" ;

    /*
    * The index position of the column CUSTOM_FIELD_4 in the table.
    */
    public static final int CUSTOM_FIELD_4_IDX = 24 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CUSTOM_FIELD_5= "CUSTOM_FIELD_5" ;

    /*
    * The index position of the column CUSTOM_FIELD_5 in the table.
    */
    public static final int CUSTOM_FIELD_5_IDX = 25 ;

    /**
              * <p> Decides if the patient is edited in newui.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_EDITED_IN_NEWUI= "IS_EDITED_IN_NEWUI" ;

    /*
    * The index position of the column IS_EDITED_IN_NEWUI in the table.
    */
    public static final int IS_EDITED_IN_NEWUI_IDX = 26 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MED_HISTORY_START_TIME= "MED_HISTORY_START_TIME" ;

    /*
    * The index position of the column MED_HISTORY_START_TIME in the table.
    */
    public static final int MED_HISTORY_START_TIME_IDX = 27 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MED_HISTORY_END_TIME= "MED_HISTORY_END_TIME" ;

    /*
    * The index position of the column MED_HISTORY_END_TIME in the table.
    */
    public static final int MED_HISTORY_END_TIME_IDX = 28 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MED_HISTORY_RESPONSE_STATUS= "MED_HISTORY_RESPONSE_STATUS" ;

    /*
    * The index position of the column MED_HISTORY_RESPONSE_STATUS in the table.
    */
    public static final int MED_HISTORY_RESPONSE_STATUS_IDX = 29 ;

    /**
              * <p> previous name of the Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PREVIOUS_NAME= "PREVIOUS_NAME" ;

    /*
    * The index position of the column PREVIOUS_NAME in the table.
    */
    public static final int PREVIOUS_NAME_IDX = 30 ;

    /**
              * <p> till when previous name of the Patient was in use.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PREVIOUS_NAME_END_DATE= "PREVIOUS_NAME_END_DATE" ;

    /*
    * The index position of the column PREVIOUS_NAME_END_DATE in the table.
    */
    public static final int PREVIOUS_NAME_END_DATE_IDX = 31 ;

}
