package com.adventnet.charm;

/** <p> Description of the table <code>BillItemPaymentMap</code>.
 *  Column Name and Table Name of  database table  <code>BillItemPaymentMap</code> is mapped
 * as constants in this util.</p> 
  Table to store mapping between each line item and payments (Payment/write-off/Adjustment). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_ITEM_PAY_ID}
  * </ul>
 */
 
public final class BILLITEMPAYMENTMAP
{
    private BILLITEMPAYMENTMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillItemPaymentMap" ;
    /**
              * <p> Unique identifier for item payment.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_ITEM_PAY_ID= "BILL_ITEM_PAY_ID" ;

    /*
    * The index position of the column BILL_ITEM_PAY_ID in the table.
    */
    public static final int BILL_ITEM_PAY_ID_IDX = 1 ;

    /**
              * <p> Pk of Bill Item Details table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ITEM_ID= "BILL_ITEM_ID" ;

    /*
    * The index position of the column BILL_ITEM_ID in the table.
    */
    public static final int BILL_ITEM_ID_IDX = 2 ;

    /**
              * <p> PK of BillReceiptMapDetails table of type 'Receipt'.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_ID= "PAYMENT_ID" ;

    /*
    * The index position of the column PAYMENT_ID in the table.
    */
    public static final int PAYMENT_ID_IDX = 3 ;

    /**
              * <p> Payment Amount of 'Receipt'.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYMENT_AMOUNT= "PAYMENT_AMOUNT" ;

    /*
    * The index position of the column PAYMENT_AMOUNT in the table.
    */
    public static final int PAYMENT_AMOUNT_IDX = 4 ;

    /**
              * <p> PK of BillReceiptMapDetails table of type 'Write-off'.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WRITEOFF_ID= "WRITEOFF_ID" ;

    /*
    * The index position of the column WRITEOFF_ID in the table.
    */
    public static final int WRITEOFF_ID_IDX = 5 ;

    /**
              * <p> type of write off i.e contractual/bad debt/small balance..etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String WRITEOFF_TYPE= "WRITEOFF_TYPE" ;

    /*
    * The index position of the column WRITEOFF_TYPE in the table.
    */
    public static final int WRITEOFF_TYPE_IDX = 6 ;

    /**
              * <p> Write-off amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WRITEOFF_AMOUNT= "WRITEOFF_AMOUNT" ;

    /*
    * The index position of the column WRITEOFF_AMOUNT in the table.
    */
    public static final int WRITEOFF_AMOUNT_IDX = 7 ;

    /**
              * <p> PK of BillReceiptMapDetails table of type 'Adjustment'.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_ID= "ADJUSTMENT_ID" ;

    /*
    * The index position of the column ADJUSTMENT_ID in the table.
    */
    public static final int ADJUSTMENT_ID_IDX = 8 ;

    /**
              * <p> type of adjustment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_TYPE= "ADJUSTMENT_TYPE" ;

    /*
    * The index position of the column ADJUSTMENT_TYPE in the table.
    */
    public static final int ADJUSTMENT_TYPE_IDX = 9 ;

    /**
              * <p> Adjustment amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_AMOUNT= "ADJUSTMENT_AMOUNT" ;

    /*
    * The index position of the column ADJUSTMENT_AMOUNT in the table.
    */
    public static final int ADJUSTMENT_AMOUNT_IDX = 10 ;

    /**
              * <p> PK of BillPtRespMapDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PT_RESP_ID= "PT_RESP_ID" ;

    /*
    * The index position of the column PT_RESP_ID in the table.
    */
    public static final int PT_RESP_ID_IDX = 11 ;

    /**
              * <p> Patient responsible type - copay, supplement amount, not covered, etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PT_RESP_TYPE1= "PT_RESP_TYPE1" ;

    /*
    * The index position of the column PT_RESP_TYPE1 in the table.
    */
    public static final int PT_RESP_TYPE1_IDX = 12 ;

    /**
              * <p> Patient responsible amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PT_RESP_AMOUNT1= "PT_RESP_AMOUNT1" ;

    /*
    * The index position of the column PT_RESP_AMOUNT1 in the table.
    */
    public static final int PT_RESP_AMOUNT1_IDX = 13 ;

    /**
              * <p> Patient responsible type - copay, supplement amount, not covered, etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PT_RESP_TYPE2= "PT_RESP_TYPE2" ;

    /*
    * The index position of the column PT_RESP_TYPE2 in the table.
    */
    public static final int PT_RESP_TYPE2_IDX = 14 ;

    /**
              * <p> Patient responsible amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PT_RESP_AMOUNT2= "PT_RESP_AMOUNT2" ;

    /*
    * The index position of the column PT_RESP_AMOUNT2 in the table.
    */
    public static final int PT_RESP_AMOUNT2_IDX = 15 ;

    /**
              * <p> Comments entered for each line item.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 16 ;

}
