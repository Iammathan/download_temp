package com.adventnet.charm;

/** <p> Description of the table <code>TodoReminderOptions</code>.
 *  Column Name and Table Name of  database table  <code>TodoReminderOptions</code> is mapped
 * as constants in this util.</p> 
  Types of Reminder available. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REMINDEROPTION_ID}
  * </ul>
 */
 
public final class TODOREMINDEROPTIONS
{
    private TODOREMINDEROPTIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TodoReminderOptions" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REMINDEROPTION_ID= "REMINDEROPTION_ID" ;

    /*
    * The index position of the column REMINDEROPTION_ID in the table.
    */
    public static final int REMINDEROPTION_ID_IDX = 1 ;

    /**
              * <p> Option's like 1 Day Before, 2 Day Before etc. .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REMINDER_OPTION= "REMINDER_OPTION" ;

    /*
    * The index position of the column REMINDER_OPTION in the table.
    */
    public static final int REMINDER_OPTION_IDX = 2 ;

    /**
              * <p> Time frame for a particular reminder option Eg.24 * 60 * 60 * 1000 for 1 Day before.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TIMEFRAME= "TIMEFRAME" ;

    /*
    * The index position of the column TIMEFRAME in the table.
    */
    public static final int TIMEFRAME_IDX = 3 ;

}
