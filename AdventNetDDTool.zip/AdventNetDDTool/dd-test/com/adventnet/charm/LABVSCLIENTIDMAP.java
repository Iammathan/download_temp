package com.adventnet.charm;

/** <p> Description of the table <code>LabVsClientIDMap</code>.
 *  Column Name and Table Name of  database table  <code>LabVsClientIDMap</code> is mapped
 * as constants in this util.</p> 
  Lab account information of practices and facilities. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_CLIENT_MAP_ID}
  * </ul>
 */
 
public final class LABVSCLIENTIDMAP
{
    private LABVSCLIENTIDMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabVsClientIDMap" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_CLIENT_MAP_ID= "LAB_CLIENT_MAP_ID" ;

    /*
    * The index position of the column LAB_CLIENT_MAP_ID in the table.
    */
    public static final int LAB_CLIENT_MAP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAB_ACCOUNT_ID= "LAB_ACCOUNT_ID" ;

    /*
    * The index position of the column LAB_ACCOUNT_ID in the table.
    */
    public static final int LAB_ACCOUNT_ID_IDX = 3 ;

    /**
              * <p> e-Lab associating Practice and Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 4 ;

}
