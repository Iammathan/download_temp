package com.adventnet.charm;

/** <p> Description of the table <code>HIEEndPointData</code>.
 *  Column Name and Table Name of  database table  <code>HIEEndPointData</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HIE_ENDPOINT_ID}
  * </ul>
 */
 
public final class HIEENDPOINTDATA
{
    private HIEENDPOINTDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HIEEndPointData" ;
    /**
              * <p> Unique value for HIE Endpoint ID .</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HIE_ENDPOINT_ID= "HIE_ENDPOINT_ID" ;

    /*
    * The index position of the column HIE_ENDPOINT_ID in the table.
    */
    public static final int HIE_ENDPOINT_ID_IDX = 1 ;

    /**
              * <p> Name of the HIE Endpoint .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENDPOINT_NAME= "ENDPOINT_NAME" ;

    /*
    * The index position of the column ENDPOINT_NAME in the table.
    */
    public static final int ENDPOINT_NAME_IDX = 2 ;

    /**
              * <p> URL of the respective Endpoint.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENDPOINT_URL= "ENDPOINT_URL" ;

    /*
    * The index position of the column ENDPOINT_URL in the table.
    */
    public static final int ENDPOINT_URL_IDX = 3 ;

    /**
              * <p> The application used to send the HL7 Message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SENDING_APPLICATION= "SENDING_APPLICATION" ;

    /*
    * The index position of the column SENDING_APPLICATION in the table.
    */
    public static final int SENDING_APPLICATION_IDX = 4 ;

    /**
              * <p> The facility that is sending the Message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SENDING_FACILITY= "SENDING_FACILITY" ;

    /*
    * The index position of the column SENDING_FACILITY in the table.
    */
    public static final int SENDING_FACILITY_IDX = 5 ;

    /**
              * <p> Facility that will be receiving the Message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RECEIVING_FACILITY= "RECEIVING_FACILITY" ;

    /*
    * The index position of the column RECEIVING_FACILITY in the table.
    */
    public static final int RECEIVING_FACILITY_IDX = 6 ;

    /**
              * <p> Authentication used by the Endpoint.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String AUTH_TYPE= "AUTH_TYPE" ;

    /*
    * The index position of the column AUTH_TYPE in the table.
    */
    public static final int AUTH_TYPE_IDX = 7 ;

    /**
              * <p> Authentication Data stored in the JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AUTH_DATA_IN_JSON= "AUTH_DATA_IN_JSON" ;

    /*
    * The index position of the column AUTH_DATA_IN_JSON in the table.
    */
    public static final int AUTH_DATA_IN_JSON_IDX = 8 ;

    /**
              * <p> This is the Practice ID for the ENDPoint.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 9 ;

    /**
              * <p> This is the Facility ID for the Endpoint.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 10 ;

    /**
              * <p> Whether the Endpoint is active or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 11 ;

    /**
              * <p> The Date when the Endpoint is Added.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 12 ;

    /**
              * <p> The person who added the Endpoint.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 13 ;

    /**
              * <p> The Last date and time the HIE HL7 Message was transmitted to this endpoint.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_TRANSMITTED_DATE= "LAST_TRANSMITTED_DATE" ;

    /*
    * The index position of the column LAST_TRANSMITTED_DATE in the table.
    */
    public static final int LAST_TRANSMITTED_DATE_IDX = 14 ;

    /**
              * <p> This section may contain comments and list of URLs if the Endpoint has seperate urls.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 15 ;

    /**
              * <p> This is the Random Job ID for the ENDPoint.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>1</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>1</code>" , 
       * will be taken.<br>
                         */
    public static final String HIE_RANDOM_ID= "HIE_RANDOM_ID" ;

    /*
    * The index position of the column HIE_RANDOM_ID in the table.
    */
    public static final int HIE_RANDOM_ID_IDX = 16 ;

}
