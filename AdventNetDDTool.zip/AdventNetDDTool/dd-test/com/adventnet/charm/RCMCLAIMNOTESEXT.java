package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimNotesExt</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimNotesExt</code> is mapped
 * as constants in this util.</p> 
  Claim notes - intended for notes from AR callers. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_NOTES_EXT_ID}
  * </ul>
 */
 
public final class RCMCLAIMNOTESEXT
{
    private RCMCLAIMNOTESEXT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimNotesExt" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_NOTES_EXT_ID= "CLAIM_NOTES_EXT_ID" ;

    /*
    * The index position of the column CLAIM_NOTES_EXT_ID in the table.
    */
    public static final int CLAIM_NOTES_EXT_ID_IDX = 1 ;

    /**
              * <p> PK of RCMClaimNotes table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_NOTES_ID= "CLAIM_NOTES_ID" ;

    /*
    * The index position of the column CLAIM_NOTES_ID in the table.
    */
    public static final int CLAIM_NOTES_ID_IDX = 2 ;

    /**
              * <p> Payer Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_NAME= "PAYER_NAME" ;

    /*
    * The index position of the column PAYER_NAME in the table.
    */
    public static final int PAYER_NAME_IDX = 3 ;

    /**
              * <p> contact number of the Payer.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_CONTACT_NUMBER= "PAYER_CONTACT_NUMBER" ;

    /*
    * The index position of the column PAYER_CONTACT_NUMBER in the table.
    */
    public static final int PAYER_CONTACT_NUMBER_IDX = 4 ;

    /**
              * <p> Claim Number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_NUMBER= "CLAIM_NUMBER" ;

    /*
    * The index position of the column CLAIM_NUMBER in the table.
    */
    public static final int CLAIM_NUMBER_IDX = 5 ;

    /**
              * <p> Reference number for the AR call.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CALL_REFERENCE_NUMBER= "CALL_REFERENCE_NUMBER" ;

    /*
    * The index position of the column CALL_REFERENCE_NUMBER in the table.
    */
    public static final int CALL_REFERENCE_NUMBER_IDX = 6 ;

    /**
              * <p> Timely filing limit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TFL= "TFL" ;

    /*
    * The index position of the column TFL in the table.
    */
    public static final int TFL_IDX = 7 ;

    /**
              * <p> TFL for Resubmission.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TFL_FOR_RESUBMISSION= "TFL_FOR_RESUBMISSION" ;

    /*
    * The index position of the column TFL_FOR_RESUBMISSION in the table.
    */
    public static final int TFL_FOR_RESUBMISSION_IDX = 8 ;

    /**
              * <p> Other TFL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OTHER_TFL= "OTHER_TFL" ;

    /*
    * The index position of the column OTHER_TFL in the table.
    */
    public static final int OTHER_TFL_IDX = 9 ;

    /**
              * <p> Call recipient name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CSR_NAME= "CSR_NAME" ;

    /*
    * The index position of the column CSR_NAME in the table.
    */
    public static final int CSR_NAME_IDX = 10 ;

    /**
              * <p> Check number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CHECK_NUMBER= "CHECK_NUMBER" ;

    /*
    * The index position of the column CHECK_NUMBER in the table.
    */
    public static final int CHECK_NUMBER_IDX = 11 ;

    /**
              * <p> date of check.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CHECK_DATE= "CHECK_DATE" ;

    /*
    * The index position of the column CHECK_DATE in the table.
    */
    public static final int CHECK_DATE_IDX = 12 ;

    /**
              * <p> Patient's plan effective from date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PLAN_EFFECTIVE_FROM= "PLAN_EFFECTIVE_FROM" ;

    /*
    * The index position of the column PLAN_EFFECTIVE_FROM in the table.
    */
    public static final int PLAN_EFFECTIVE_FROM_IDX = 13 ;

    /**
              * <p> Patient's plan effective to date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PLAN_EFFECTIVE_TO= "PLAN_EFFECTIVE_TO" ;

    /*
    * The index position of the column PLAN_EFFECTIVE_TO in the table.
    */
    public static final int PLAN_EFFECTIVE_TO_IDX = 14 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String APPEAL_FAX_NUMBER= "APPEAL_FAX_NUMBER" ;

    /*
    * The index position of the column APPEAL_FAX_NUMBER in the table.
    */
    public static final int APPEAL_FAX_NUMBER_IDX = 15 ;

}
