package com.adventnet.charm;

/** <p> Description of the table <code>VoiceNotifications</code>.
 *  Column Name and Table Name of  database table  <code>VoiceNotifications</code> is mapped
 * as constants in this util.</p> 
  details of voice messages . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VOICE_NOTIFICATION_ID}
  * </ul>
 */
 
public final class VOICENOTIFICATIONS
{
    private VOICENOTIFICATIONS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VoiceNotifications" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_NOTIFICATION_ID= "VOICE_NOTIFICATION_ID" ;

    /*
    * The index position of the column VOICE_NOTIFICATION_ID in the table.
    */
    public static final int VOICE_NOTIFICATION_ID_IDX = 1 ;

    /**
              * <p> voice message initiated time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INITIATED_TIME= "INITIATED_TIME" ;

    /*
    * The index position of the column INITIATED_TIME in the table.
    */
    public static final int INITIATED_TIME_IDX = 2 ;

    /**
              * <p> voice message sent time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SENT_TIME= "SENT_TIME" ;

    /*
    * The index position of the column SENT_TIME in the table.
    */
    public static final int SENT_TIME_IDX = 3 ;

    /**
              * <p> To whome the voice message sent.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
              * <p> To which number the voice message sent.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MOBILE_NUMBER= "MOBILE_NUMBER" ;

    /*
    * The index position of the column MOBILE_NUMBER in the table.
    */
    public static final int MOBILE_NUMBER_IDX = 5 ;

    /**
              * <p> Unique id of voice message sent (id from twilio).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_MESSAGE_ID= "VOICE_MESSAGE_ID" ;

    /*
    * The index position of the column VOICE_MESSAGE_ID in the table.
    */
    public static final int VOICE_MESSAGE_ID_IDX = 6 ;

    /**
              * <p> Type of voice message - Appoinment/Lab res/Document shared .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VOICE_MESSAGE_TYPE= "VOICE_MESSAGE_TYPE" ;

    /*
    * The index position of the column VOICE_MESSAGE_TYPE in the table.
    */
    public static final int VOICE_MESSAGE_TYPE_IDX = 7 ;

    /**
              * <p> Voice message content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1600</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VOICE_CONTENT= "VOICE_CONTENT" ;

    /*
    * The index position of the column VOICE_CONTENT in the table.
    */
    public static final int VOICE_CONTENT_IDX = 8 ;

    /**
              * <p> Status of voice message - Queued/Initiated/Ringing/Completed.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CALL_STATUS= "CALL_STATUS" ;

    /*
    * The index position of the column CALL_STATUS in the table.
    */
    public static final int CALL_STATUS_IDX = 9 ;

    /**
              * <p> duration of the specific voice message.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DURATION= "DURATION" ;

    /*
    * The index position of the column DURATION in the table.
    */
    public static final int DURATION_IDX = 10 ;

    /**
              * <p> No of calls for the specific voice message.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NO_OF_CALLS= "NO_OF_CALLS" ;

    /*
    * The index position of the column NO_OF_CALLS in the table.
    */
    public static final int NO_OF_CALLS_IDX = 11 ;

    /**
              * <p> Description of updated voice message status(Failed Message description etc) .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_DESCRIPTION= "STATUS_DESCRIPTION" ;

    /*
    * The index position of the column STATUS_DESCRIPTION in the table.
    */
    public static final int STATUS_DESCRIPTION_IDX = 12 ;

    /**
              * <p> status of the appointment when the patient confirms the appointment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONFIRMATION_STATUS_ID= "CONFIRMATION_STATUS_ID" ;

    /*
    * The index position of the column CONFIRMATION_STATUS_ID in the table.
    */
    public static final int CONFIRMATION_STATUS_ID_IDX = 13 ;

    /**
              * <p> appointment id for update the status of appointment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 14 ;

    /**
              * <p> Input given by the patient.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String USER_INPUT= "USER_INPUT" ;

    /*
    * The index position of the column USER_INPUT in the table.
    */
    public static final int USER_INPUT_IDX = 15 ;

    /**
              * <p> Final status of the voice message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONFIRMATION_STATUS= "CONFIRMATION_STATUS" ;

    /*
    * The index position of the column CONFIRMATION_STATUS in the table.
    */
    public static final int CONFIRMATION_STATUS_IDX = 16 ;

    /**
              * <p> From Mobile number of practice for sending 2 WAY SMS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FROM_MOBILE_NUMBER= "FROM_MOBILE_NUMBER" ;

    /*
    * The index position of the column FROM_MOBILE_NUMBER in the table.
    */
    public static final int FROM_MOBILE_NUMBER_IDX = 17 ;

}
