package com.adventnet.charm;

/** <p> Description of the table <code>VisitTypes</code>.
 *  Column Name and Table Name of  database table  <code>VisitTypes</code> is mapped
 * as constants in this util.</p> 
  Type of Appointment Visit. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VISITTYPE_ID}
  * </ul>
 */
 
public final class VISITTYPES
{
    private VISITTYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "VisitTypes" ;
    /**
              * <p> Identifier of visit type.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 1 ;

    /**
              * <p> Different typea of appointment visit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VISIT_TYPE= "VISIT_TYPE" ;

    /*
    * The index position of the column VISIT_TYPE in the table.
    */
    public static final int VISIT_TYPE_IDX = 2 ;

    /**
              * <p> Duration of visit type.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DURATION= "DURATION" ;

    /*
    * The index position of the column DURATION in the table.
    */
    public static final int DURATION_IDX = 3 ;

    /**
              * <p> Color code for visit type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>#0000ff:#ffffff</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>#0000ff:#ffffff</code>" , 
       * will be taken.<br>
                         */
    public static final String VISITTYPE_COLOR= "VISITTYPE_COLOR" ;

    /*
    * The index position of the column VISITTYPE_COLOR in the table.
    */
    public static final int VISITTYPE_COLOR_IDX = 4 ;

    /**
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String CHARGE= "CHARGE" ;

    /*
    * The index position of the column CHARGE in the table.
    */
    public static final int CHARGE_IDX = 5 ;

    /**
              * <p> mode of visit type[1>in person 2>Phone call 3>Video Consult].</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                     * Default Value is <code>In Person</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>In Person</code>" , 
       * will be taken.<br>
                         */
    public static final String APPOINTMENT_MODE= "APPOINTMENT_MODE" ;

    /*
    * The index position of the column APPOINTMENT_MODE in the table.
    */
    public static final int APPOINTMENT_MODE_IDX = 6 ;

    /**
              * <p> Type of patients allowed for this visittype [0 > All; 1 > New; 2 > Existing].</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String PATIENT_TYPE= "PATIENT_TYPE" ;

    /*
    * The index position of the column PATIENT_TYPE in the table.
    */
    public static final int PATIENT_TYPE_IDX = 7 ;

    /**
              * <p> To indicate whether this visit type has been deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String AUTO_GENERATE_INVOICE= "AUTO_GENERATE_INVOICE" ;

    /*
    * The index position of the column AUTO_GENERATE_INVOICE in the table.
    */
    public static final int AUTO_GENERATE_INVOICE_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AUTO_GENERATE_INVOICE_CPT_ID= "AUTO_GENERATE_INVOICE_CPT_ID" ;

    /*
    * The index position of the column AUTO_GENERATE_INVOICE_CPT_ID in the table.
    */
    public static final int AUTO_GENERATE_INVOICE_CPT_ID_IDX = 10 ;

    /**
              * <p> CPT ids are stored as coma seperaed values.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String AUTO_GENERATE_INVOICE_CPT_IDS= "AUTO_GENERATE_INVOICE_CPT_IDS" ;

    /*
    * The index position of the column AUTO_GENERATE_INVOICE_CPT_IDS in the table.
    */
    public static final int AUTO_GENERATE_INVOICE_CPT_IDS_IDX = 11 ;

    /**
              * <p> telemode for where patient connect from phr or kiosk.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TELE_MODE= "TELE_MODE" ;

    /*
    * The index position of the column TELE_MODE in the table.
    */
    public static final int TELE_MODE_IDX = 12 ;

    /**
              * <p> Decides which charge should be applied for procedure..</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CPT_CHARGE= "CPT_CHARGE" ;

    /*
    * The index position of the column CPT_CHARGE in the table.
    */
    public static final int CPT_CHARGE_IDX = 13 ;

}
