package com.adventnet.charm;

/** <p> Description of the table <code>AsthmaData</code>.
 *  Column Name and Table Name of  database table  <code>AsthmaData</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ASTHMADATA_ID}
  * </ul>
 */
 
public final class ASTHMADATA
{
    private ASTHMADATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AsthmaData" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ASTHMADATA_ID= "ASTHMADATA_ID" ;

    /*
    * The index position of the column ASTHMADATA_ID in the table.
    */
    public static final int ASTHMADATA_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Symptom assessed: asthma daytime Symptoms quantified.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DAYTIME_QUANTIFIED= "IS_DAYTIME_QUANTIFIED" ;

    /*
    * The index position of the column IS_DAYTIME_QUANTIFIED in the table.
    */
    public static final int IS_DAYTIME_QUANTIFIED_IDX = 3 ;

    /**
              * <p> Symptom assessed: asthma nighttime Symptoms quantified.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_NIGHTTIME_QUANTIFIED= "IS_NIGHTTIME_QUANTIFIED" ;

    /*
    * The index position of the column IS_NIGHTTIME_QUANTIFIED in the table.
    */
    public static final int IS_NIGHTTIME_QUANTIFIED_IDX = 4 ;

    /**
              * <p> Symptom active: asthma daytime Symptoms.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE_IN_DAYTIME= "IS_ACTIVE_IN_DAYTIME" ;

    /*
    * The index position of the column IS_ACTIVE_IN_DAYTIME in the table.
    */
    public static final int IS_ACTIVE_IN_DAYTIME_IDX = 5 ;

    /**
              * <p> Symptom active: asthma nighttime Symptoms.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE_IN_NIGHTTIME= "IS_ACTIVE_IN_NIGHTTIME" ;

    /*
    * The index position of the column IS_ACTIVE_IN_NIGHTTIME in the table.
    */
    public static final int IS_ACTIVE_IN_NIGHTTIME_IDX = 6 ;

    /**
              * <p> Risk category / assessment: asthma symptom assessment tool.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_IN_RISK_CATEGORY= "IS_IN_RISK_CATEGORY" ;

    /*
    * The index position of the column IS_IN_RISK_CATEGORY in the table.
    */
    public static final int IS_IN_RISK_CATEGORY_IDX = 7 ;

    /**
              * <p> Diagnosis active: asthma persistent.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SEVERITY_PERSISTENT= "IS_SEVERITY_PERSISTENT" ;

    /*
    * The index position of the column IS_SEVERITY_PERSISTENT in the table.
    */
    public static final int IS_SEVERITY_PERSISTENT_IDX = 8 ;

    /**
              * <p> Medication order: corticosteroid, inhaled or alternative asthma medication.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MEDICATION_ORDERED= "IS_MEDICATION_ORDERED" ;

    /*
    * The index position of the column IS_MEDICATION_ORDERED in the table.
    */
    public static final int IS_MEDICATION_ORDERED_IDX = 9 ;

    /**
              * <p> Medication active: corticosteroid, inhaled or alternative asthma medication.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MEDICATION_ACTIVE= "IS_MEDICATION_ACTIVE" ;

    /*
    * The index position of the column IS_MEDICATION_ACTIVE in the table.
    */
    public static final int IS_MEDICATION_ACTIVE_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_EXCLUDED= "IS_EXCLUDED" ;

    /*
    * The index position of the column IS_EXCLUDED in the table.
    */
    public static final int IS_EXCLUDED_IDX = 11 ;

    /**
              * <p> Complete description of the excluded reason, such it should be mapped with corresponding radio-button in the UI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXCLUDED_REASON= "EXCLUDED_REASON" ;

    /*
    * The index position of the column EXCLUDED_REASON in the table.
    */
    public static final int EXCLUDED_REASON_IDX = 12 ;

}
