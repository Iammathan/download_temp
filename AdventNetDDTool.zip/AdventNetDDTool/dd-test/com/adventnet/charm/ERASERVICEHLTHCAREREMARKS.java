package com.adventnet.charm;

/** <p> Description of the table <code>ERAServiceHlthCareRemarks</code>.
 *  Column Name and Table Name of  database table  <code>ERAServiceHlthCareRemarks</code> is mapped
 * as constants in this util.</p> 
  stores service specific health care remark codes(only information remarks only) 2110 : LQ - HEALTH CARE REMARK CODES : #215. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_SERVICE_HC_REMARK_CODE_ID}
  * </ul>
 */
 
public final class ERASERVICEHLTHCAREREMARKS
{
    private ERASERVICEHLTHCAREREMARKS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERAServiceHlthCareRemarks" ;
    /**
              * <p> SAS Key - Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_SERVICE_HC_REMARK_CODE_ID= "ERA_SERVICE_HC_REMARK_CODE_ID" ;

    /*
    * The index position of the column ERA_SERVICE_HC_REMARK_CODE_ID in the table.
    */
    public static final int ERA_SERVICE_HC_REMARK_CODE_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERAServiceDetail table, where the respective line item detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_SERVICE_DETAIL_ID= "ERA_SERVICE_DETAIL_ID" ;

    /*
    * The index position of the column ERA_SERVICE_DETAIL_ID in the table.
    */
    public static final int ERA_SERVICE_DETAIL_ID_IDX = 2 ;

    /**
              * <p> 2110 : LQ01 : #215.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String INDUSTRY_TYPE_IDENTIFIER_CODE= "INDUSTRY_TYPE_IDENTIFIER_CODE" ;

    /*
    * The index position of the column INDUSTRY_TYPE_IDENTIFIER_CODE in the table.
    */
    public static final int INDUSTRY_TYPE_IDENTIFIER_CODE_IDX = 3 ;

    /**
              * <p> 2110 : LQ02 : #216.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REMARK_CODE= "REMARK_CODE" ;

    /*
    * The index position of the column REMARK_CODE in the table.
    */
    public static final int REMARK_CODE_IDX = 4 ;

}
