package com.adventnet.charm;

/** <p> Description of the table <code>TobaccoCessationData</code>.
 *  Column Name and Table Name of  database table  <code>TobaccoCessationData</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TOBACCO_CESSATION_DATA_ID}
  * </ul>
 */
 
public final class TOBACCOCESSATIONDATA
{
    private TOBACCOCESSATIONDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TobaccoCessationData" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TOBACCO_CESSATION_DATA_ID= "TOBACCO_CESSATION_DATA_ID" ;

    /*
    * The index position of the column TOBACCO_CESSATION_DATA_ID in the table.
    */
    public static final int TOBACCO_CESSATION_DATA_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_COUNSELING_PERFORMED= "IS_COUNSELING_PERFORMED" ;

    /*
    * The index position of the column IS_COUNSELING_PERFORMED in the table.
    */
    public static final int IS_COUNSELING_PERFORMED_IDX = 3 ;

    /**
              * <p> This needs to be filled based on the smoking cessation agent status.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MEDICATION_AGENT_ACTIVE= "IS_MEDICATION_AGENT_ACTIVE" ;

    /*
    * The index position of the column IS_MEDICATION_AGENT_ACTIVE in the table.
    */
    public static final int IS_MEDICATION_AGENT_ACTIVE_IDX = 4 ;

}
