package com.adventnet.charm;

/** <p> Description of the table <code>AuditTrials</code>.
 *  Column Name and Table Name of  database table  <code>AuditTrials</code> is mapped
 * as constants in this util.</p> 
  Audits will be saved here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AUDIT_ID}
  * </ul>
 */
 
public final class AUDITTRIALS
{
    private AUDITTRIALS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AuditTrials" ;
    /**
              * <p> Unique identifier of AUDIT message.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String AUDIT_ID= "AUDIT_ID" ;

    /*
    * The index position of the column AUDIT_ID in the table.
    */
    public static final int AUDIT_ID_IDX = 1 ;

    /**
              * <p> Time of generating the Audit.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 2 ;

    /**
              * <p> Member ID who did the operation.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Patient Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 4 ;

    /**
              * <p> Action Carried Out.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ACTION= "ACTION" ;

    /*
    * The index position of the column ACTION in the table.
    */
    public static final int ACTION_IDX = 5 ;

    /**
              * <p> 0-READ/1-WRITE/2-MODIFY/3-DELETE/4-PRINT/5-IMPORT/6-EXPORT.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTION_TYPE= "ACTION_TYPE" ;

    /*
    * The index position of the column ACTION_TYPE in the table.
    */
    public static final int ACTION_TYPE_IDX = 6 ;

    /**
              * <p> 0-FAILED/1-SUCCESS/2-DENIED.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTION_STATUS= "ACTION_STATUS" ;

    /*
    * The index position of the column ACTION_STATUS in the table.
    */
    public static final int ACTION_STATUS_IDX = 7 ;

    /**
              * <p> 0-READ/1-WRITE/2-MODIFY/3-DELETE/4-PRINT/5-IMPORT/6-EXPORT.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACTION_TYPE_STRING= "ACTION_TYPE_STRING" ;

    /*
    * The index position of the column ACTION_TYPE_STRING in the table.
    */
    public static final int ACTION_TYPE_STRING_IDX = 8 ;

    /**
              * <p> Audit Module Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AUDIT_MODULE_ID= "AUDIT_MODULE_ID" ;

    /*
    * The index position of the column AUDIT_MODULE_ID in the table.
    */
    public static final int AUDIT_MODULE_ID_IDX = 9 ;

    /**
              * <p> Any additional comment or remark about the action.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 10 ;

    /**
              * <p> API Method; Whether the method is GET, POST, PUT, DELETE..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String API_METHOD= "API_METHOD" ;

    /*
    * The index position of the column API_METHOD in the table.
    */
    public static final int API_METHOD_IDX = 11 ;

    /**
              * <p> URL called from API call.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String API_URL= "API_URL" ;

    /*
    * The index position of the column API_URL in the table.
    */
    public static final int API_URL_IDX = 12 ;

    /**
              * <p> IP used access the resource..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String IP_ADDRESS= "IP_ADDRESS" ;

    /*
    * The index position of the column IP_ADDRESS in the table.
    */
    public static final int IP_ADDRESS_IDX = 13 ;

}
