package com.adventnet.charm;

/** <p> Description of the table <code>NotificationModuleDetails</code>.
 *  Column Name and Table Name of  database table  <code>NotificationModuleDetails</code> is mapped
 * as constants in this util.</p> 
  Pincode details for Indian Practices. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #NOTIFICATION_MODULE_ID}
  * </ul>
 */
 
public final class NOTIFICATIONMODULEDETAILS
{
    private NOTIFICATIONMODULEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "NotificationModuleDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NOTIFICATION_MODULE_ID= "NOTIFICATION_MODULE_ID" ;

    /*
    * The index position of the column NOTIFICATION_MODULE_ID in the table.
    */
    public static final int NOTIFICATION_MODULE_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_MOD_ID= "NOTIFICATION_MOD_ID" ;

    /*
    * The index position of the column NOTIFICATION_MOD_ID in the table.
    */
    public static final int NOTIFICATION_MOD_ID_IDX = 2 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String KEY= "KEY" ;

    /*
    * The index position of the column KEY in the table.
    */
    public static final int KEY_IDX = 3 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DISPLAY_CRITERIA= "DISPLAY_CRITERIA" ;

    /*
    * The index position of the column DISPLAY_CRITERIA in the table.
    */
    public static final int DISPLAY_CRITERIA_IDX = 4 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String HEADING= "HEADING" ;

    /*
    * The index position of the column HEADING in the table.
    */
    public static final int HEADING_IDX = 5 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 6 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_EDITABLE= "IS_EDITABLE" ;

    /*
    * The index position of the column IS_EDITABLE in the table.
    */
    public static final int IS_EDITABLE_IDX = 7 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DEFAULT_NOTIFY_TO= "DEFAULT_NOTIFY_TO" ;

    /*
    * The index position of the column DEFAULT_NOTIFY_TO in the table.
    */
    public static final int DEFAULT_NOTIFY_TO_IDX = 8 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MESSAGE= "MESSAGE" ;

    /*
    * The index position of the column MESSAGE in the table.
    */
    public static final int MESSAGE_IDX = 9 ;

    /**
              * <p> url to be opened.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NAV_URL= "NAV_URL" ;

    /*
    * The index position of the column NAV_URL in the table.
    */
    public static final int NAV_URL_IDX = 10 ;

    /**
              * <p> js method to be called.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String JS_METHOD= "JS_METHOD" ;

    /*
    * The index position of the column JS_METHOD in the table.
    */
    public static final int JS_METHOD_IDX = 11 ;

    /**
              * <p> Notification for module.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTIFICATION_TYPE= "NOTIFICATION_TYPE" ;

    /*
    * The index position of the column NOTIFICATION_TYPE in the table.
    */
    public static final int NOTIFICATION_TYPE_IDX = 12 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CRITERIA_PATTERN= "CRITERIA_PATTERN" ;

    /*
    * The index position of the column CRITERIA_PATTERN in the table.
    */
    public static final int CRITERIA_PATTERN_IDX = 13 ;

    /**
              * <p> Module Name.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ENABLED= "IS_ENABLED" ;

    /*
    * The index position of the column IS_ENABLED in the table.
    */
    public static final int IS_ENABLED_IDX = 14 ;

    /**
              * <p> Date when the notification was created.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 15 ;

    /**
              * <p> Date when the notification was created.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIED_DATE= "MODIFIED_DATE" ;

    /*
    * The index position of the column MODIFIED_DATE in the table.
    */
    public static final int MODIFIED_DATE_IDX = 16 ;

}
