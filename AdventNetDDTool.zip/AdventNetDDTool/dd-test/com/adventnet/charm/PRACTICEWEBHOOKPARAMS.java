package com.adventnet.charm;

/** <p> Description of the table <code>PracticeWebhookParams</code>.
 *  Column Name and Table Name of  database table  <code>PracticeWebhookParams</code> is mapped
 * as constants in this util.</p> 
  Table for storing params configured for webhook. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #WEBHOOK_PARAM_ID}
  * </ul>
 */
 
public final class PRACTICEWEBHOOKPARAMS
{
    private PRACTICEWEBHOOKPARAMS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeWebhookParams" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WEBHOOK_PARAM_ID= "WEBHOOK_PARAM_ID" ;

    /*
    * The index position of the column WEBHOOK_PARAM_ID in the table.
    */
    public static final int WEBHOOK_PARAM_ID_IDX = 1 ;

    /**
              * <p> Unique identifier of Webhook entry.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String WEBHOOK_ID= "WEBHOOK_ID" ;

    /*
    * The index position of the column WEBHOOK_ID in the table.
    */
    public static final int WEBHOOK_ID_IDX = 2 ;

    /**
              * <p> Unique identifier of default param.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DEFAULT_PARAM_ID= "DEFAULT_PARAM_ID" ;

    /*
    * The index position of the column DEFAULT_PARAM_ID in the table.
    */
    public static final int DEFAULT_PARAM_ID_IDX = 3 ;

    /**
              * <p> Param Name added by User.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PARAM_NAME= "PARAM_NAME" ;

    /*
    * The index position of the column PARAM_NAME in the table.
    */
    public static final int PARAM_NAME_IDX = 4 ;

    /**
              * <p> Param value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PARAM_VALUE= "PARAM_VALUE" ;

    /*
    * The index position of the column PARAM_VALUE in the table.
    */
    public static final int PARAM_VALUE_IDX = 5 ;

    /**
              * <p> For Extra params added by User.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_CUSTOM_PARAM= "IS_CUSTOM_PARAM" ;

    /*
    * The index position of the column IS_CUSTOM_PARAM in the table.
    */
    public static final int IS_CUSTOM_PARAM_IDX = 6 ;

}
