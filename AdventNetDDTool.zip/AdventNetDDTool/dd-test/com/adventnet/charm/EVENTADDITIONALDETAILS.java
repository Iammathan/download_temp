package com.adventnet.charm;

/** <p> Description of the table <code>EventAdditionalDetails</code>.
 *  Column Name and Table Name of  database table  <code>EventAdditionalDetails</code> is mapped
 * as constants in this util.</p> 
   Additional Details about event are maintained in this patient space table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class EVENTADDITIONALDETAILS
{
    private EVENTADDITIONALDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EventAdditionalDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Identifier of specific Event.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EVENT_ID= "EVENT_ID" ;

    /*
    * The index position of the column EVENT_ID in the table.
    */
    public static final int EVENT_ID_IDX = 2 ;

    /**
              * <p> Name of the Key.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROPERTY_KEY= "PROPERTY_KEY" ;

    /*
    * The index position of the column PROPERTY_KEY in the table.
    */
    public static final int PROPERTY_KEY_IDX = 3 ;

    /**
              * <p> Value of the Key.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROPERTY_VALUE= "PROPERTY_VALUE" ;

    /*
    * The index position of the column PROPERTY_VALUE in the table.
    */
    public static final int PROPERTY_VALUE_IDX = 4 ;

}
