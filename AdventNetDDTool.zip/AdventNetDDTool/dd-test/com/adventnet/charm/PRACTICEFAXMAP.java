package com.adventnet.charm;

/** <p> Description of the table <code>PracticeFaxMap</code>.
 *  Column Name and Table Name of  database table  <code>PracticeFaxMap</code> is mapped
 * as constants in this util.</p> 
  Fax Details mapping API key and Practice ID. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_FAX_MAP_ID}
  * </ul>
 */
 
public final class PRACTICEFAXMAP
{
    private PRACTICEFAXMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeFaxMap" ;
    /**
              * <p> Unique Id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_FAX_MAP_ID= "PRACTICE_FAX_MAP_ID" ;

    /*
    * The index position of the column PRACTICE_FAX_MAP_ID in the table.
    */
    public static final int PRACTICE_FAX_MAP_ID_IDX = 1 ;

    /**
              * <p> API Key.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String API_KEY= "API_KEY" ;

    /*
    * The index position of the column API_KEY in the table.
    */
    public static final int API_KEY_IDX = 2 ;

    /**
              * <p> Practice Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 3 ;

}
