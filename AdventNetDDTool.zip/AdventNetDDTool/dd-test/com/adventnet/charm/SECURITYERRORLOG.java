package com.adventnet.charm;

/** <p> Description of the table <code>SecurityErrorLog</code>.
 *  Column Name and Table Name of  database table  <code>SecurityErrorLog</code> is mapped
 * as constants in this util.</p> 
  This table is used to track the security errors in production. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERROR_LOG_ID}
  * </ul>
 */
 
public final class SECURITYERRORLOG
{
    private SECURITYERRORLOG()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SecurityErrorLog" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERROR_LOG_ID= "ERROR_LOG_ID" ;

    /*
    * The index position of the column ERROR_LOG_ID in the table.
    */
    public static final int ERROR_LOG_ID_IDX = 1 ;

    /**
              * <p> Zoho User ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZUID= "ZUID" ;

    /*
    * The index position of the column ZUID in the table.
    */
    public static final int ZUID_IDX = 2 ;

    /**
              * <p> Type of Application i.e NEWUI/OLDUI/PHR.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TYPE_OF_APPLICATION= "TYPE_OF_APPLICATION" ;

    /*
    * The index position of the column TYPE_OF_APPLICATION in the table.
    */
    public static final int TYPE_OF_APPLICATION_IDX = 3 ;

    /**
              * <p> Practice Id of User.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 4 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 5 ;

    /**
              * <p> Time when the user got error.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 6 ;

    /**
              * <p> Type of security error.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TYPE_OF_ERROR= "TYPE_OF_ERROR" ;

    /*
    * The index position of the column TYPE_OF_ERROR in the table.
    */
    public static final int TYPE_OF_ERROR_IDX = 7 ;

    /**
              * <p> Type of security error.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ACTION= "ACTION" ;

    /*
    * The index position of the column ACTION in the table.
    */
    public static final int ACTION_IDX = 8 ;

    /**
              * <p> Type of security error.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String URI= "URI" ;

    /*
    * The index position of the column URI in the table.
    */
    public static final int URI_IDX = 9 ;

    /**
              * <p> Type of security error.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONTENT= "CONTENT" ;

    /*
    * The index position of the column CONTENT in the table.
    */
    public static final int CONTENT_IDX = 10 ;

}
