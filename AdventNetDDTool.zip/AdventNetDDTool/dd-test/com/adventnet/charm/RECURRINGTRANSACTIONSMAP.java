package com.adventnet.charm;

/** <p> Description of the table <code>RecurringTransactionsMap</code>.
 *  Column Name and Table Name of  database table  <code>RecurringTransactionsMap</code> is mapped
 * as constants in this util.</p> 
  Entry for recurring transactions. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #RECURRING_TRANSACTION_ID}
  * <li> {@link #TRANSACTION_ID}
  * </ul>
 */
 
public final class RECURRINGTRANSACTIONSMAP
{
    private RECURRINGTRANSACTIONSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RecurringTransactionsMap" ;
    /**
              * <p> Recurring Transaction Id.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECURRING_TRANSACTION_ID= "RECURRING_TRANSACTION_ID" ;

    /*
    * The index position of the column RECURRING_TRANSACTION_ID in the table.
    */
    public static final int RECURRING_TRANSACTION_ID_IDX = 1 ;

    /**
              * <p> Merchant Transaction Id.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSACTION_ID= "TRANSACTION_ID" ;

    /*
    * The index position of the column TRANSACTION_ID in the table.
    */
    public static final int TRANSACTION_ID_IDX = 2 ;

}
