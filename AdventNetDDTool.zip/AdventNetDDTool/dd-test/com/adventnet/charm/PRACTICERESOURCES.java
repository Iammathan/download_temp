package com.adventnet.charm;

/** <p> Description of the table <code>PracticeResources</code>.
 *  Column Name and Table Name of  database table  <code>PracticeResources</code> is mapped
 * as constants in this util.</p> 
  Contains different resources of a facility. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RESOURCE_ID}
  * </ul>
 */
 
public final class PRACTICERESOURCES
{
    private PRACTICERESOURCES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeResources" ;
    /**
              * <p> Identifier of PracticeResources.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RESOURCE_ID= "RESOURCE_ID" ;

    /*
    * The index position of the column RESOURCE_ID in the table.
    */
    public static final int RESOURCE_ID_IDX = 1 ;

    /**
              * <p> Name assigned to the room/machine.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 2 ;

    /**
              * <p> Used for ordering.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 3 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 4 ;

    /**
              * <p> To indicate whether this status has been deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

}
