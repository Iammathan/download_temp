package com.adventnet.charm;

/** <p> Description of the table <code>LabRecordDetails</code>.
 *  Column Name and Table Name of  database table  <code>LabRecordDetails</code> is mapped
 * as constants in this util.</p> 
  Maintains the detials of a record such as specimen condition type , temperature , etc.. . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_RECORD_DETAIL_ID}
  * </ul>
 */
 
public final class LABRECORDDETAILS
{
    private LABRECORDDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabRecordDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_DETAIL_ID= "LAB_RECORD_DETAIL_ID" ;

    /*
    * The index position of the column LAB_RECORD_DETAIL_ID in the table.
    */
    public static final int LAB_RECORD_DETAIL_ID_IDX = 1 ;

    /**
              * <p> Lab Record Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_RECORD_ID= "LAB_RECORD_ID" ;

    /*
    * The index position of the column LAB_RECORD_ID in the table.
    */
    public static final int LAB_RECORD_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_TEST_DESCRIPTION= "LAB_TEST_DESCRIPTION" ;

    /*
    * The index position of the column LAB_TEST_DESCRIPTION in the table.
    */
    public static final int LAB_TEST_DESCRIPTION_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_CONDITION_TEMPERATURE= "SPECIMEN_CONDITION_TEMPERATURE" ;

    /*
    * The index position of the column SPECIMEN_CONDITION_TEMPERATURE in the table.
    */
    public static final int SPECIMEN_CONDITION_TEMPERATURE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_TYPE= "SPECIMEN_TYPE" ;

    /*
    * The index position of the column SPECIMEN_TYPE in the table.
    */
    public static final int SPECIMEN_TYPE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_CONTAINER= "SPECIMEN_CONTAINER" ;

    /*
    * The index position of the column SPECIMEN_CONTAINER in the table.
    */
    public static final int SPECIMEN_CONTAINER_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_TYPE= "TEST_TYPE" ;

    /*
    * The index position of the column TEST_TYPE in the table.
    */
    public static final int TEST_TYPE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ALTERNATE_TEMPERATURE= "ALTERNATE_TEMPERATURE" ;

    /*
    * The index position of the column ALTERNATE_TEMPERATURE in the table.
    */
    public static final int ALTERNATE_TEMPERATURE_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_AOE_ASSOCIATED= "IS_AOE_ASSOCIATED" ;

    /*
    * The index position of the column IS_AOE_ASSOCIATED in the table.
    */
    public static final int IS_AOE_ASSOCIATED_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PROFILE_INDICATOR= "PROFILE_INDICATOR" ;

    /*
    * The index position of the column PROFILE_INDICATOR in the table.
    */
    public static final int PROFILE_INDICATOR_IDX = 10 ;

    /**
              * <p> In case of Quest, it has many performing labs.It may need each performing lab to have separate set of orders.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PERFORMING_LAB_IDENTIFIER= "PERFORMING_LAB_IDENTIFIER" ;

    /*
    * The index position of the column PERFORMING_LAB_IDENTIFIER in the table.
    */
    public static final int PERFORMING_LAB_IDENTIFIER_IDX = 11 ;

    /**
              * <p> Z-segment map to AOE.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String Z_SEGMENT_AOE_MAP= "Z_SEGMENT_AOE_MAP" ;

    /*
    * The index position of the column Z_SEGMENT_AOE_MAP in the table.
    */
    public static final int Z_SEGMENT_AOE_MAP_IDX = 12 ;

}
