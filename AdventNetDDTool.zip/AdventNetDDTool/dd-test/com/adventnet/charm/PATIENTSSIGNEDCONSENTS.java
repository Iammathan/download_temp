package com.adventnet.charm;

/** <p> Description of the table <code>PatientsSignedConsents</code>.
 *  Column Name and Table Name of  database table  <code>PatientsSignedConsents</code> is mapped
 * as constants in this util.</p> 
   This table maintains the consent forms signed by patients through kiosk . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CONSENT_SIGNATURE_ID}
  * </ul>
 */
 
public final class PATIENTSSIGNEDCONSENTS
{
    private PATIENTSSIGNEDCONSENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientsSignedConsents" ;
    /**
              * <p> Unique identifier for each signed consent.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONSENT_SIGNATURE_ID= "CONSENT_SIGNATURE_ID" ;

    /*
    * The index position of the column CONSENT_SIGNATURE_ID in the table.
    */
    public static final int CONSENT_SIGNATURE_ID_IDX = 1 ;

    /**
              * <p> Unique Patient Identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of file.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 3 ;

    /**
              * <p> Identifier of file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 4 ;

    /**
              * <p> Signature file location in the DFS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SIGNATURE_FILE_POINTER= "SIGNATURE_FILE_POINTER" ;

    /*
    * The index position of the column SIGNATURE_FILE_POINTER in the table.
    */
    public static final int SIGNATURE_FILE_POINTER_IDX = 5 ;

    /**
              * <p> Date and Time on which the consent is signed.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSENT_SIGNED_DATE= "CONSENT_SIGNED_DATE" ;

    /*
    * The index position of the column CONSENT_SIGNED_DATE in the table.
    */
    public static final int CONSENT_SIGNED_DATE_IDX = 6 ;

}
