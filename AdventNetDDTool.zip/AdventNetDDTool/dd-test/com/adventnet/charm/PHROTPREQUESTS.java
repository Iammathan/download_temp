package com.adventnet.charm;

/** <p> Description of the table <code>PHROtpRequests</code>.
 *  Column Name and Table Name of  database table  <code>PHROtpRequests</code> is mapped
 * as constants in this util.</p> 
  phr otp request. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PHR_OTP_REQUEST_ID}
  * </ul>
 */
 
public final class PHROTPREQUESTS
{
    private PHROTPREQUESTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHROtpRequests" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHR_OTP_REQUEST_ID= "PHR_OTP_REQUEST_ID" ;

    /*
    * The index position of the column PHR_OTP_REQUEST_ID in the table.
    */
    public static final int PHR_OTP_REQUEST_ID_IDX = 1 ;

    /**
              * <p> Mobile phone number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MOBILE= "MOBILE" ;

    /*
    * The index position of the column MOBILE in the table.
    */
    public static final int MOBILE_IDX = 2 ;

    /**
              * <p> OTP value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTP= "OTP" ;

    /*
    * The index position of the column OTP in the table.
    */
    public static final int OTP_IDX = 3 ;

    /**
              * <p> OTP status.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_STATUS= "OTP_STATUS" ;

    /*
    * The index position of the column OTP_STATUS in the table.
    */
    public static final int OTP_STATUS_IDX = 4 ;

    /**
              * <p> Time of creating the OTP.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTP_SENT_ON= "OTP_SENT_ON" ;

    /*
    * The index position of the column OTP_SENT_ON in the table.
    */
    public static final int OTP_SENT_ON_IDX = 5 ;

    /**
              * <p> OTP failed attempt count.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_FAILED_ATTEMPT= "OTP_FAILED_ATTEMPT" ;

    /*
    * The index position of the column OTP_FAILED_ATTEMPT in the table.
    */
    public static final int OTP_FAILED_ATTEMPT_IDX = 6 ;

    /**
              * <p> OTP resent count.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_RESENT_COUNT= "OTP_RESENT_COUNT" ;

    /*
    * The index position of the column OTP_RESENT_COUNT in the table.
    */
    public static final int OTP_RESENT_COUNT_IDX = 7 ;

    /**
              * <p> OTP Delivery Status.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_DELIVERY_STATUS= "OTP_DELIVERY_STATUS" ;

    /*
    * The index position of the column OTP_DELIVERY_STATUS in the table.
    */
    public static final int OTP_DELIVERY_STATUS_IDX = 8 ;

}
