package com.adventnet.charm;

/** <p> Description of the table <code>PHRSecureSignup</code>.
 *  Column Name and Table Name of  database table  <code>PHRSecureSignup</code> is mapped
 * as constants in this util.</p> 
  PHR signup invitation related details. like expiry, max fail attempts. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INVITATION_ID}
  * </ul>
 */
 
public final class PHRSECURESIGNUP
{
    private PHRSECURESIGNUP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRSecureSignup" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVITATION_ID= "INVITATION_ID" ;

    /*
    * The index position of the column INVITATION_ID in the table.
    */
    public static final int INVITATION_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_ON= "CREATED_ON" ;

    /*
    * The index position of the column CREATED_ON in the table.
    */
    public static final int CREATED_ON_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXPIRE_ON= "EXPIRE_ON" ;

    /*
    * The index position of the column EXPIRE_ON in the table.
    */
    public static final int EXPIRE_ON_IDX = 4 ;

    /**
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FAIL_ATTEMPT= "FAIL_ATTEMPT" ;

    /*
    * The index position of the column FAIL_ATTEMPT in the table.
    */
    public static final int FAIL_ATTEMPT_IDX = 5 ;

    /**
              * <p>  0 - created and pending for get activate,  1 - link get activated , 2 - Expired .</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 6 ;

    /**
              * <p> Reason for expiry.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EXPIRY_REASON= "EXPIRY_REASON" ;

    /*
    * The index position of the column EXPIRY_REASON in the table.
    */
    public static final int EXPIRY_REASON_IDX = 7 ;

    /**
              * <p> Secret key, which associated with the link.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>8</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SEC_KEY= "SEC_KEY" ;

    /*
    * The index position of the column SEC_KEY in the table.
    */
    public static final int SEC_KEY_IDX = 8 ;

    /**
              * <p> First name of Representative.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REP_FIRST_NAME= "REP_FIRST_NAME" ;

    /*
    * The index position of the column REP_FIRST_NAME in the table.
    */
    public static final int REP_FIRST_NAME_IDX = 9 ;

    /**
              * <p> Last name of Representative.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REP_LAST_NAME= "REP_LAST_NAME" ;

    /*
    * The index position of the column REP_LAST_NAME in the table.
    */
    public static final int REP_LAST_NAME_IDX = 10 ;

}
