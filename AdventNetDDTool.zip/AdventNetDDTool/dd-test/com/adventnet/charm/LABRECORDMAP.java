package com.adventnet.charm;

/** <p> Description of the table <code>LabRecordMap</code>.
 *  Column Name and Table Name of  database table  <code>LabRecordMap</code> is mapped
 * as constants in this util.</p> 
  Grouping of Labs and Records. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_RECORD_ID}
  * </ul>
 */
 
public final class LABRECORDMAP
{
    private LABRECORDMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabRecordMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_ID= "LAB_RECORD_ID" ;

    /*
    * The index position of the column LAB_RECORD_ID in the table.
    */
    public static final int LAB_RECORD_ID_IDX = 1 ;

    /**
              * <p> Lab Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ID= "LAB_ID" ;

    /*
    * The index position of the column LAB_ID in the table.
    */
    public static final int LAB_ID_IDX = 2 ;

    /**
              * <p> Record Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ID= "MEDICAL_RECORD_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ID in the table.
    */
    public static final int MEDICAL_RECORD_ID_IDX = 3 ;

    /**
              * <p> Test code specific to the associated lab.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_CODE= "LAB_RECORD_CODE" ;

    /*
    * The index position of the column LAB_RECORD_CODE in the table.
    */
    public static final int LAB_RECORD_CODE_IDX = 4 ;

    /**
              * <p> To check whether the parameters are taken from the general or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_SUPPRESSED= "IS_SUPPRESSED" ;

    /*
    * The index position of the column IS_SUPPRESSED in the table.
    */
    public static final int IS_SUPPRESSED_IDX = 5 ;

    /**
              * <p> To check the effectiveness of this order in the lab end.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 6 ;

    /**
              * <p> Test Group specific to the associated Test.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_GROUP= "TEST_GROUP" ;

    /*
    * The index position of the column TEST_GROUP in the table.
    */
    public static final int TEST_GROUP_IDX = 7 ;

    /**
              * <p> To check the is group or not of this order in the lab end.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_TEST_GROUP= "IS_TEST_GROUP" ;

    /*
    * The index position of the column IS_TEST_GROUP in the table.
    */
    public static final int IS_TEST_GROUP_IDX = 8 ;

    /**
              * <p> To check the is test Specfic to Gender.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 9 ;

    /**
              * <p> 0 -> Test, 1 -> Profile, 2 -> POP, 3 -> Offer.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String CATEGORY= "CATEGORY" ;

    /*
    * The index position of the column CATEGORY in the table.
    */
    public static final int CATEGORY_IDX = 10 ;

    /**
              * <p> test oda department.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DEPARTMENT= "DEPARTMENT" ;

    /*
    * The index position of the column DEPARTMENT in the table.
    */
    public static final int DEPARTMENT_IDX = 11 ;

    /**
              * <p> Department Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_TEST_DEPARTMENT_ID= "LAB_TEST_DEPARTMENT_ID" ;

    /*
    * The index position of the column LAB_TEST_DEPARTMENT_ID in the table.
    */
    public static final int LAB_TEST_DEPARTMENT_ID_IDX = 12 ;

    /**
              * <p> test description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1024</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_DESCRIPTION= "TEST_DESCRIPTION" ;

    /*
    * The index position of the column TEST_DESCRIPTION in the table.
    */
    public static final int TEST_DESCRIPTION_IDX = 13 ;

}
