package com.adventnet.charm;

/** <p> Description of the table <code>CharmModuleGroupMapping</code>.
 *  Column Name and Table Name of  database table  <code>CharmModuleGroupMapping</code> is mapped
 * as constants in this util.</p> 
  CharmModuleGroupMapping used to map IAM group ID with charm's module Ids like facility|department|role. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAPPING_ID}
  * </ul>
 */
 
public final class CHARMMODULEGROUPMAPPING
{
    private CHARMMODULEGROUPMAPPING()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CharmModuleGroupMapping" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MAPPING_ID= "MAPPING_ID" ;

    /*
    * The index position of the column MAPPING_ID in the table.
    */
    public static final int MAPPING_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MODULE_ID= "MODULE_ID" ;

    /*
    * The index position of the column MODULE_ID in the table.
    */
    public static final int MODULE_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MODULE_TYPE= "MODULE_TYPE" ;

    /*
    * The index position of the column MODULE_TYPE in the table.
    */
    public static final int MODULE_TYPE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GROUP_ID= "GROUP_ID" ;

    /*
    * The index position of the column GROUP_ID in the table.
    */
    public static final int GROUP_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_BY= "CREATED_BY" ;

    /*
    * The index position of the column CREATED_BY in the table.
    */
    public static final int CREATED_BY_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_TIME= "CREATED_TIME" ;

    /*
    * The index position of the column CREATED_TIME in the table.
    */
    public static final int CREATED_TIME_IDX = 6 ;

}
