package com.adventnet.charm;

/** <p> Description of the table <code>ZInventoryDetails</code>.
 *  Column Name and Table Name of  database table  <code>ZInventoryDetails</code> is mapped
 * as constants in this util.</p> 
  Will be storing the Zoho Inventory Mapping details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ZOHO_INVENTORY_DETAILS_ID}
  * </ul>
 */
 
public final class ZINVENTORYDETAILS
{
    private ZINVENTORYDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ZInventoryDetails" ;
    /**
              * <p> Pk for ZInventoryDetails table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_INVENTORY_DETAILS_ID= "ZOHO_INVENTORY_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_INVENTORY_DETAILS_ID in the table.
    */
    public static final int ZOHO_INVENTORY_DETAILS_ID_IDX = 1 ;

    /**
              * <p> Added time into EHR.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 3 ;

    /**
              * <p> ZohoOrganizationDetails.ZOHO_ORG_DETAILS_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_ORG_DETAILS_ID= "ZOHO_ORG_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_ORG_DETAILS_ID in the table.
    */
    public static final int ZOHO_ORG_DETAILS_ID_IDX = 4 ;

    /**
              * <p> Inventory.INVENTORY_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVENTORY_ID= "INVENTORY_ID" ;

    /*
    * The index position of the column INVENTORY_ID in the table.
    */
    public static final int INVENTORY_ID_IDX = 5 ;

    /**
              * <p> Product.PRODUCT_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRODUCT_ID= "PRODUCT_ID" ;

    /*
    * The index position of the column PRODUCT_ID in the table.
    */
    public static final int PRODUCT_ID_IDX = 6 ;

    /**
              * <p> ZInventoryBills.ZOHO_INVENTORY_BILL_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZOHO_INVENTORY_BILL_ID= "ZOHO_INVENTORY_BILL_ID" ;

    /*
    * The index position of the column ZOHO_INVENTORY_BILL_ID in the table.
    */
    public static final int ZOHO_INVENTORY_BILL_ID_IDX = 7 ;

    /**
              * <p> Zoho Bill Id of the stock.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZBILL_ID= "ZBILL_ID" ;

    /*
    * The index position of the column ZBILL_ID in the table.
    */
    public static final int ZBILL_ID_IDX = 8 ;

    /**
              * <p> Zoho Bill line item Id of the stock.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZBILL_LINE_ITEM_ID= "ZBILL_LINE_ITEM_ID" ;

    /*
    * The index position of the column ZBILL_LINE_ITEM_ID in the table.
    */
    public static final int ZBILL_LINE_ITEM_ID_IDX = 9 ;

    /**
              * <p> Zoho Batch Id of the stock.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZBATCH_ID= "ZBATCH_ID" ;

    /*
    * The index position of the column ZBATCH_ID in the table.
    */
    public static final int ZBATCH_ID_IDX = 10 ;

    /**
              * <p> Zoho Warehouse Id of the stock.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZWAREHOUSE_ID= "ZWAREHOUSE_ID" ;

    /*
    * The index position of the column ZWAREHOUSE_ID in the table.
    */
    public static final int ZWAREHOUSE_ID_IDX = 11 ;

    /**
              * <p> ZInventoryAdjustments.ZOHO_INVENTORY_ADJUSTMENT_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZOHO_INVENTORY_ADJUSTMENT_ID= "ZOHO_INVENTORY_ADJUSTMENT_ID" ;

    /*
    * The index position of the column ZOHO_INVENTORY_ADJUSTMENT_ID in the table.
    */
    public static final int ZOHO_INVENTORY_ADJUSTMENT_ID_IDX = 12 ;

    /**
              * <p> Zoho Adjustment line item Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZADJUSTMENT_LINE_ITEM_ID= "ZADJUSTMENT_LINE_ITEM_ID" ;

    /*
    * The index position of the column ZADJUSTMENT_LINE_ITEM_ID in the table.
    */
    public static final int ZADJUSTMENT_LINE_ITEM_ID_IDX = 13 ;

    /**
              * <p> The source inventory from which the Adjustment is happening..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_INVENTORY_ID= "FROM_INVENTORY_ID" ;

    /*
    * The index position of the column FROM_INVENTORY_ID in the table.
    */
    public static final int FROM_INVENTORY_ID_IDX = 14 ;

    /**
              * <p> Adjustment amount reduced.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADJUSTMENT_QUANTITY= "ADJUSTMENT_QUANTITY" ;

    /*
    * The index position of the column ADJUSTMENT_QUANTITY in the table.
    */
    public static final int ADJUSTMENT_QUANTITY_IDX = 15 ;

    /**
              * <p> Will be storing error info in JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERROR_LOG= "ERROR_LOG" ;

    /*
    * The index position of the column ERROR_LOG in the table.
    */
    public static final int ERROR_LOG_IDX = 16 ;

}
