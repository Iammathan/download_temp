package com.adventnet.charm;

/** <p> Description of the table <code>SOAPConditionalEntries</code>.
 *  Column Name and Table Name of  database table  <code>SOAPConditionalEntries</code> is mapped
 * as constants in this util.</p> 
  Table for storing conditional hierarchy. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #CONDITIONAL_ENTRY_ID}
  * <li> {@link #CHILD_ENTRY_ID}
  * </ul>
 */
 
public final class SOAPCONDITIONALENTRIES
{
    private SOAPCONDITIONALENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SOAPConditionalEntries" ;
    /**
              * <p> Mapping from entries table .</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONDITIONAL_ENTRY_ID= "CONDITIONAL_ENTRY_ID" ;

    /*
    * The index position of the column CONDITIONAL_ENTRY_ID in the table.
    */
    public static final int CONDITIONAL_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Mapping from entries table .</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHILD_ENTRY_ID= "CHILD_ENTRY_ID" ;

    /*
    * The index position of the column CHILD_ENTRY_ID in the table.
    */
    public static final int CHILD_ENTRY_ID_IDX = 2 ;

}
