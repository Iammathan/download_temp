package com.adventnet.charm;

/** <p> Description of the table <code>ElectronicStatusDetail</code>.
 *  Column Name and Table Name of  database table  <code>ElectronicStatusDetail</code> is mapped
 * as constants in this util.</p> 
  Contains the actual status information. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ESTATUS_ID}
  * </ul>
 */
 
public final class ELECTRONICSTATUSDETAIL
{
    private ELECTRONICSTATUSDETAIL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ElectronicStatusDetail" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID= "ESTATUS_ID" ;

    /*
    * The index position of the column ESTATUS_ID in the table.
    */
    public static final int ESTATUS_ID_IDX = 1 ;

    /**
              * <p> Code to indicate the status in the payer system which falls under one of the level Error, Acknowledge, Pending, Finalized, Searches.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_CATEGORY_CODE= "STATUS_CATEGORY_CODE" ;

    /*
    * The index position of the column STATUS_CATEGORY_CODE in the table.
    */
    public static final int STATUS_CATEGORY_CODE_IDX = 2 ;

    /**
              * <p> Code is either Health Care Claim Status Code OR NCPDP code; it indicates more specific information about the claim/line regarding this status.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATUS_CODE= "STATUS_CODE" ;

    /*
    * The index position of the column STATUS_CODE in the table.
    */
    public static final int STATUS_CODE_IDX = 3 ;

    /**
              * <p> Code specifies an entity which the status denotes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ENTITY_ID_CODE= "ENTITY_ID_CODE" ;

    /*
    * The index position of the column ENTITY_ID_CODE in the table.
    */
    public static final int ENTITY_ID_CODE_IDX = 4 ;

    /**
              * <p> Qualifier to indicate the status code belongs to NCPDP Rejection/Payment code list. If it does not belongs to STATUS_CODE doesn't belongs to NCPDP then it holds NULL else 'RX'.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NCPDP_CODE= "NCPDP_CODE" ;

    /*
    * The index position of the column NCPDP_CODE in the table.
    */
    public static final int NCPDP_CODE_IDX = 5 ;

}
