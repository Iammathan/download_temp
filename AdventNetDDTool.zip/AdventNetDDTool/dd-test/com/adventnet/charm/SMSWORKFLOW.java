package com.adventnet.charm;

/** <p> Description of the table <code>SMSWorkflow</code>.
 *  Column Name and Table Name of  database table  <code>SMSWorkflow</code> is mapped
 * as constants in this util.</p> 
  2 way SMS workflow (publicspace) for Appointment confirmation/cancellation/reschedule OR Reschedule no shows OR Fill up cancelled slot with waitlist. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SMS_WORKFLOW_ID}
  * </ul>
 */
 
public final class SMSWORKFLOW
{
    private SMSWORKFLOW()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SMSWorkflow" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SMS_WORKFLOW_ID= "SMS_WORKFLOW_ID" ;

    /*
    * The index position of the column SMS_WORKFLOW_ID in the table.
    */
    public static final int SMS_WORKFLOW_ID_IDX = 1 ;

    /**
              * <p> APPOINTMENT_CONFIRMATION or RESCHEDULE_NOSHOW or FILL_WAITLIST_AGAINST_CANCEL.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SMS_WORKFLOW_NAME= "SMS_WORKFLOW_NAME" ;

    /*
    * The index position of the column SMS_WORKFLOW_NAME in the table.
    */
    public static final int SMS_WORKFLOW_NAME_IDX = 2 ;

}
