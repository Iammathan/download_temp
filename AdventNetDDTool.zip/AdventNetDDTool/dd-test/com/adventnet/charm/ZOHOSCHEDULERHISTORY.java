package com.adventnet.charm;

/** <p> Description of the table <code>ZohoSchedulerHistory</code>.
 *  Column Name and Table Name of  database table  <code>ZohoSchedulerHistory</code> is mapped
 * as constants in this util.</p> 
  Stores the CharmToZohoAccess sheduler history. It is a GET/POST only table. PUST/DELETE cannot happen. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ZOHO_SCHEDULER_HISTORY_ID}
  * </ul>
 */
 
public final class ZOHOSCHEDULERHISTORY
{
    private ZOHOSCHEDULERHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ZohoSchedulerHistory" ;
    /**
              * <p> Pk for ZohoSchedulerHistory table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_SCHEDULER_HISTORY_ID= "ZOHO_SCHEDULER_HISTORY_ID" ;

    /*
    * The index position of the column ZOHO_SCHEDULER_HISTORY_ID in the table.
    */
    public static final int ZOHO_SCHEDULER_HISTORY_ID_IDX = 1 ;

    /**
              * <p> if facility id is null, then practice specific.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 2 ;

    /**
              * <p> ZohoOrganizationDetails.ZOHO_ORG_DETAILS_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ZOHO_ORG_DETAILS_ID= "ZOHO_ORG_DETAILS_ID" ;

    /*
    * The index position of the column ZOHO_ORG_DETAILS_ID in the table.
    */
    public static final int ZOHO_ORG_DETAILS_ID_IDX = 3 ;

    /**
              * <p> OAUTH with which Zoho Org is accessed..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_OAUTH_ID= "MEMBER_OAUTH_ID" ;

    /*
    * The index position of the column MEMBER_OAUTH_ID in the table.
    */
    public static final int MEMBER_OAUTH_ID_IDX = 4 ;

    /**
              * <p> Will be storing additional info in JSON.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDITIONAL_INFO= "ADDITIONAL_INFO" ;

    /*
    * The index position of the column ADDITIONAL_INFO in the table.
    */
    public static final int ADDITIONAL_INFO_IDX = 5 ;

}
