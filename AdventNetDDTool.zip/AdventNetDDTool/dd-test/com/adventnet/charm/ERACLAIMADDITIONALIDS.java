package com.adventnet.charm;

/** <p> Description of the table <code>ERAClaimAdditionalIds</code>.
 *  Column Name and Table Name of  database table  <code>ERAClaimAdditionalIds</code> is mapped
 * as constants in this util.</p> 
  This table stores any additional Identifiers(REF) related to claim. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_CLAIM_ADDITIONAL_ID}
  * </ul>
 */
 
public final class ERACLAIMADDITIONALIDS
{
    private ERACLAIMADDITIONALIDS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERAClaimAdditionalIds" ;
    /**
              * <p> SAS Key - Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_CLAIM_ADDITIONAL_ID= "ERA_CLAIM_ADDITIONAL_ID" ;

    /*
    * The index position of the column ERA_CLAIM_ADDITIONAL_ID in the table.
    */
    public static final int ERA_CLAIM_ADDITIONAL_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERAClaimDetail table, where the respective claim detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_CLAIM_DETAIL_ID= "ERA_CLAIM_DETAIL_ID" ;

    /*
    * The index position of the column ERA_CLAIM_DETAIL_ID in the table.
    */
    public static final int ERA_CLAIM_DETAIL_ID_IDX = 2 ;

    /**
              * <p> 2100 : REF01 : #169 Qualifier denoting the type of identifier (REF01).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 3 ;

    /**
              * <p> 2100 : REF01 : #170 Value of the additional identifier of the claim (REF02).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER= "IDENTIFIER" ;

    /*
    * The index position of the column IDENTIFIER in the table.
    */
    public static final int IDENTIFIER_IDX = 4 ;

}
