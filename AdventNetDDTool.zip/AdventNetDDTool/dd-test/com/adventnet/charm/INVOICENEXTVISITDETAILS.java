package com.adventnet.charm;

/** <p> Description of the table <code>InvoiceNextVisitDetails</code>.
 *  Column Name and Table Name of  database table  <code>InvoiceNextVisitDetails</code> is mapped
 * as constants in this util.</p> 
  used to store insurance comment regarding a patient medical info. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INVOICE_NEXT_VISIT_DTAILS_ID}
  * </ul>
 */
 
public final class INVOICENEXTVISITDETAILS
{
    private INVOICENEXTVISITDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InvoiceNextVisitDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVOICE_NEXT_VISIT_DTAILS_ID= "INVOICE_NEXT_VISIT_DTAILS_ID" ;

    /*
    * The index position of the column INVOICE_NEXT_VISIT_DTAILS_ID in the table.
    */
    public static final int INVOICE_NEXT_VISIT_DTAILS_ID_IDX = 1 ;

    /**
              * <p> BILL id for which claim is generated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 2 ;

    /**
              * <p> Confirmed Date by physician.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_DATE= "APPOINTMENT_DATE" ;

    /*
    * The index position of the column APPOINTMENT_DATE in the table.
    */
    public static final int APPOINTMENT_DATE_IDX = 3 ;

    /**
              * <p> Full name of the practice member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>110</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PHYSICIAN_NAME= "PHYSICIAN_NAME" ;

    /*
    * The index position of the column PHYSICIAN_NAME in the table.
    */
    public static final int PHYSICIAN_NAME_IDX = 4 ;

}
