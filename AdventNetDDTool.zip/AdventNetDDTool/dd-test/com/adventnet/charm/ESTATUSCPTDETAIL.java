package com.adventnet.charm;

/** <p> Description of the table <code>EStatusCPTDetail</code>.
 *  Column Name and Table Name of  database table  <code>EStatusCPTDetail</code> is mapped
 * as constants in this util.</p> 
  Line level detail returned in the status response. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ESTATUS_CPT_ID}
  * </ul>
 */
 
public final class ESTATUSCPTDETAIL
{
    private ESTATUSCPTDETAIL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EStatusCPTDetail" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_CPT_ID= "ESTATUS_CPT_ID" ;

    /*
    * The index position of the column ESTATUS_CPT_ID in the table.
    */
    public static final int ESTATUS_CPT_ID_IDX = 1 ;

    /**
              * <p> Holds the transaction reference id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_CLAIM_ID= "ESTATUS_CLAIM_ID" ;

    /*
    * The index position of the column ESTATUS_CLAIM_ID in the table.
    */
    public static final int ESTATUS_CLAIM_ID_IDX = 2 ;

    /**
              * <p> Product or Service ID Qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_ID_QUALIFIER= "SERVICE_ID_QUALIFIER" ;

    /*
    * The index position of the column SERVICE_ID_QUALIFIER in the table.
    */
    public static final int SERVICE_ID_QUALIFIER_IDX = 3 ;

    /**
              * <p> Procedure or Service Id or NUBC Revenue Code(if SERVICE_ID_QUALIFIER is NU).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>48</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SERVICE_ID= "SERVICE_ID" ;

    /*
    * The index position of the column SERVICE_ID in the table.
    */
    public static final int SERVICE_ID_IDX = 4 ;

    /**
              * <p> Modifier 1.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER_1= "MODIFIER_1" ;

    /*
    * The index position of the column MODIFIER_1 in the table.
    */
    public static final int MODIFIER_1_IDX = 5 ;

    /**
              * <p> Modifier 2.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER_2= "MODIFIER_2" ;

    /*
    * The index position of the column MODIFIER_2 in the table.
    */
    public static final int MODIFIER_2_IDX = 6 ;

    /**
              * <p> Modifier 3.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER_3= "MODIFIER_3" ;

    /*
    * The index position of the column MODIFIER_3 in the table.
    */
    public static final int MODIFIER_3_IDX = 7 ;

    /**
              * <p> Modifier 4.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MODIFIER_4= "MODIFIER_4" ;

    /*
    * The index position of the column MODIFIER_4 in the table.
    */
    public static final int MODIFIER_4_IDX = 8 ;

    /**
              * <p> CPT charge as per the status response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CPT_CHARGE= "CPT_CHARGE" ;

    /*
    * The index position of the column CPT_CHARGE in the table.
    */
    public static final int CPT_CHARGE_IDX = 9 ;

    /**
              * <p> CPT Payment amount if given in the status response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CPT_PAYMENT= "CPT_PAYMENT" ;

    /*
    * The index position of the column CPT_PAYMENT in the table.
    */
    public static final int CPT_PAYMENT_IDX = 10 ;

    /**
              * <p> Stores the NUBC Code it it is reported additionaly to the CPT for Institutional Claims.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>48</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVENUE_CODE= "REVENUE_CODE" ;

    /*
    * The index position of the column REVENUE_CODE in the table.
    */
    public static final int REVENUE_CODE_IDX = 11 ;

    /**
              * <p> Submitted Units or Quantity.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UNITS= "UNITS" ;

    /*
    * The index position of the column UNITS in the table.
    */
    public static final int UNITS_IDX = 12 ;

    /**
              * <p> Line Item Identification number submitted in the 276 request.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_ITEM_CONTROL_NO= "LINE_ITEM_CONTROL_NO" ;

    /*
    * The index position of the column LINE_ITEM_CONTROL_NO in the table.
    */
    public static final int LINE_ITEM_CONTROL_NO_IDX = 13 ;

    /**
              * <p> This the status value created by ChARM from the electronic status details fetched for this CPT.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>120</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ELECTRONIC_STATUS= "ELECTRONIC_STATUS" ;

    /*
    * The index position of the column ELECTRONIC_STATUS in the table.
    */
    public static final int ELECTRONIC_STATUS_IDX = 14 ;

    /**
              * <p> Service Start Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_START_DATE= "SERVICE_START_DATE" ;

    /*
    * The index position of the column SERVICE_START_DATE in the table.
    */
    public static final int SERVICE_START_DATE_IDX = 15 ;

    /**
              * <p> Service End Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SERVICE_END_DATE= "SERVICE_END_DATE" ;

    /*
    * The index position of the column SERVICE_END_DATE in the table.
    */
    public static final int SERVICE_END_DATE_IDX = 16 ;

    /**
              * <p> Date on which this status was changed to in the payer/clearinghouse system.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String STATUS_EFFECTIVE_DATE= "STATUS_EFFECTIVE_DATE" ;

    /*
    * The index position of the column STATUS_EFFECTIVE_DATE in the table.
    */
    public static final int STATUS_EFFECTIVE_DATE_IDX = 17 ;

    /**
              * <p> PK of the ElectronicStatusDetail table where the CPT status is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID_1= "ESTATUS_ID_1" ;

    /*
    * The index position of the column ESTATUS_ID_1 in the table.
    */
    public static final int ESTATUS_ID_1_IDX = 18 ;

    /**
              * <p> PK of the ElectronicStatusDetail table where the additional status detail of the CPT is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID_2= "ESTATUS_ID_2" ;

    /*
    * The index position of the column ESTATUS_ID_2 in the table.
    */
    public static final int ESTATUS_ID_2_IDX = 19 ;

    /**
              * <p> PK of the ElectronicStatusDetail table where the additional status detail of the CPT is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ESTATUS_ID_3= "ESTATUS_ID_3" ;

    /*
    * The index position of the column ESTATUS_ID_3 in the table.
    */
    public static final int ESTATUS_ID_3_IDX = 20 ;

}
