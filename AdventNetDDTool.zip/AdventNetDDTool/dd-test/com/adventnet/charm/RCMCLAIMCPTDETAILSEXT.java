package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimCPTDetailsExt</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimCPTDetailsExt</code> is mapped
 * as constants in this util.</p> 
  CPT Code details of the claim. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_CPT_EXT_ID}
  * </ul>
 */
 
public final class RCMCLAIMCPTDETAILSEXT
{
    private RCMCLAIMCPTDETAILSEXT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimCPTDetailsExt" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_CPT_EXT_ID= "CLAIM_CPT_EXT_ID" ;

    /*
    * The index position of the column CLAIM_CPT_EXT_ID in the table.
    */
    public static final int CLAIM_CPT_EXT_ID_IDX = 1 ;

    /**
              * <p> Claim CPT Id of RCMClaimCPTDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLAIM_CPT_ID= "CLAIM_CPT_ID" ;

    /*
    * The index position of the column CLAIM_CPT_ID in the table.
    */
    public static final int CLAIM_CPT_ID_IDX = 2 ;

    /**
              * <p> Service code description.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRODUCT_DESC= "PRODUCT_DESC" ;

    /*
    * The index position of the column PRODUCT_DESC in the table.
    */
    public static final int PRODUCT_DESC_IDX = 3 ;

}
