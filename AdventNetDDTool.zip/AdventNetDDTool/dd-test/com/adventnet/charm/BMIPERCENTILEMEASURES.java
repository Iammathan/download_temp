package com.adventnet.charm;

/** <p> Description of the table <code>BMIPercentileMeasures</code>.
 *  Column Name and Table Name of  database table  <code>BMIPercentileMeasures</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BMI_PERCENTILE_ID}
  * </ul>
 */
 
public final class BMIPERCENTILEMEASURES
{
    private BMIPERCENTILEMEASURES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BMIPercentileMeasures" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BMI_PERCENTILE_ID= "BMI_PERCENTILE_ID" ;

    /*
    * The index position of the column BMI_PERCENTILE_ID in the table.
    */
    public static final int BMI_PERCENTILE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_DATE= "CONSULTATION_DATE" ;

    /*
    * The index position of the column CONSULTATION_DATE in the table.
    */
    public static final int CONSULTATION_DATE_IDX = 5 ;

    /**
              * <p> Visit type of the appointment.Foreign key from PQRIEncounterTypes table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PQRI_ENCOUNTER_TYPE_ID= "PQRI_ENCOUNTER_TYPE_ID" ;

    /*
    * The index position of the column PQRI_ENCOUNTER_TYPE_ID in the table.
    */
    public static final int PQRI_ENCOUNTER_TYPE_ID_IDX = 6 ;

    /**
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AGE= "AGE" ;

    /*
    * The index position of the column AGE in the table.
    */
    public static final int AGE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ENCOUNTER_APPROVED= "IS_ENCOUNTER_APPROVED" ;

    /*
    * The index position of the column IS_ENCOUNTER_APPROVED in the table.
    */
    public static final int IS_ENCOUNTER_APPROVED_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_BMI_CALCULATED= "IS_BMI_CALCULATED" ;

    /*
    * The index position of the column IS_BMI_CALCULATED in the table.
    */
    public static final int IS_BMI_CALCULATED_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_NUTRITION_COUNSELED= "IS_NUTRITION_COUNSELED" ;

    /*
    * The index position of the column IS_NUTRITION_COUNSELED in the table.
    */
    public static final int IS_NUTRITION_COUNSELED_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PHYSICAL_ACTIVITY_COUNSELED= "IS_PHYSICAL_ACTIVITY_COUNSELED" ;

    /*
    * The index position of the column IS_PHYSICAL_ACTIVITY_COUNSELED in the table.
    */
    public static final int IS_PHYSICAL_ACTIVITY_COUNSELED_IDX = 11 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PREGNANCY_DIAGNOISED= "IS_PREGNANCY_DIAGNOISED" ;

    /*
    * The index position of the column IS_PREGNANCY_DIAGNOISED in the table.
    */
    public static final int IS_PREGNANCY_DIAGNOISED_IDX = 12 ;

}
