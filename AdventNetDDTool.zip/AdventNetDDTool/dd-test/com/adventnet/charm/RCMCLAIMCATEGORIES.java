package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimCategories</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimCategories</code> is mapped
 * as constants in this util.</p> 
  List of rcm claim categories. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_CLAIM_CAT_ID}
  * </ul>
 */
 
public final class RCMCLAIMCATEGORIES
{
    private RCMCLAIMCATEGORIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimCategories" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_CLAIM_CAT_ID= "RCM_CLAIM_CAT_ID" ;

    /*
    * The index position of the column RCM_CLAIM_CAT_ID in the table.
    */
    public static final int RCM_CLAIM_CAT_ID_IDX = 1 ;

    /**
              * <p> Category type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 2 ;

}
