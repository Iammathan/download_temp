package com.adventnet.charm;

/** <p> Description of the table <code>BloodSugarsEntries</code>.
 *  Column Name and Table Name of  database table  <code>BloodSugarsEntries</code> is mapped
 * as constants in this util.</p> 
  Daily Blood Sugars record from patients. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BLOOD_SUGARS_ENTRY_ID}
  * </ul>
 */
 
public final class BLOODSUGARSENTRIES
{
    private BLOODSUGARSENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BloodSugarsEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BLOOD_SUGARS_ENTRY_ID= "BLOOD_SUGARS_ENTRY_ID" ;

    /*
    * The index position of the column BLOOD_SUGARS_ENTRY_ID in the table.
    */
    public static final int BLOOD_SUGARS_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Date at which the data is collected.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE_OF_COLLECTION= "DATE_OF_COLLECTION" ;

    /*
    * The index position of the column DATE_OF_COLLECTION in the table.
    */
    public static final int DATE_OF_COLLECTION_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 3 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BLOOD_SUGARS_ID= "BLOOD_SUGARS_ID" ;

    /*
    * The index position of the column BLOOD_SUGARS_ID in the table.
    */
    public static final int BLOOD_SUGARS_ID_IDX = 4 ;

    /**
              * <p> Recorded value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECORDVALUE= "RECORDVALUE" ;

    /*
    * The index position of the column RECORDVALUE in the table.
    */
    public static final int RECORDVALUE_IDX = 5 ;

}
