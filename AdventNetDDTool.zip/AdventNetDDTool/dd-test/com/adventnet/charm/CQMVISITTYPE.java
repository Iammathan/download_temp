package com.adventnet.charm;

/** <p> Description of the table <code>CQMVisitType</code>.
 *  Column Name and Table Name of  database table  <code>CQMVisitType</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #VISIT_TYPE_ID}
  * </ul>
 */
 
public final class CQMVISITTYPE
{
    private CQMVISITTYPE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMVisitType" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String VISIT_TYPE_ID= "VISIT_TYPE_ID" ;

    /*
    * The index position of the column VISIT_TYPE_ID in the table.
    */
    public static final int VISIT_TYPE_ID_IDX = 1 ;

    /**
              * <p> Type code value set .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VALUE_SET= "VALUE_SET" ;

    /*
    * The index position of the column VALUE_SET in the table.
    */
    public static final int VALUE_SET_IDX = 2 ;

    /**
              * <p> Original visit type name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ORIGINAL_TEXT= "ORIGINAL_TEXT" ;

    /*
    * The index position of the column ORIGINAL_TEXT in the table.
    */
    public static final int ORIGINAL_TEXT_IDX = 3 ;

    /**
              * <p> Display name of visit.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISPLAY_NAME= "DISPLAY_NAME" ;

    /*
    * The index position of the column DISPLAY_NAME in the table.
    */
    public static final int DISPLAY_NAME_IDX = 4 ;

    /**
              * <p> Value code (SNOMED/ICD9/ICD10/LOINC).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE= "CODE" ;

    /*
    * The index position of the column CODE in the table.
    */
    public static final int CODE_IDX = 5 ;

    /**
              * <p> Name of the code system values.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CODE_SYSTEM= "CODE_SYSTEM" ;

    /*
    * The index position of the column CODE_SYSTEM in the table.
    */
    public static final int CODE_SYSTEM_IDX = 6 ;

}
