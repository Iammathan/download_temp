package com.adventnet.charm;

/** <p> Description of the table <code>PatientCustomFieldsMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientCustomFieldsMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between PracticePatientsList and DemographicsCustomFields. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_CUSTOM_FIELDS_MAP_ID}
  * </ul>
 */
 
public final class PATIENTCUSTOMFIELDSMAP
{
    private PATIENTCUSTOMFIELDSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientCustomFieldsMap" ;
    /**
              * <p> Unique value generator.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_CUSTOM_FIELDS_MAP_ID= "PATIENT_CUSTOM_FIELDS_MAP_ID" ;

    /*
    * The index position of the column PATIENT_CUSTOM_FIELDS_MAP_ID in the table.
    */
    public static final int PATIENT_CUSTOM_FIELDS_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of PracticePatientsList.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of DemographicsCustomFields.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DEMOGRAPHICS_CUSTOM_FIELD_ID= "DEMOGRAPHICS_CUSTOM_FIELD_ID" ;

    /*
    * The index position of the column DEMOGRAPHICS_CUSTOM_FIELD_ID in the table.
    */
    public static final int DEMOGRAPHICS_CUSTOM_FIELD_ID_IDX = 3 ;

    /**
              * <p> Value of the patient custom fiels.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CUSTOM_FIELD_VALUE= "CUSTOM_FIELD_VALUE" ;

    /*
    * The index position of the column CUSTOM_FIELD_VALUE in the table.
    */
    public static final int CUSTOM_FIELD_VALUE_IDX = 4 ;

}
