package com.adventnet.charm;

/** <p> Description of the table <code>RxRoles</code>.
 *  Column Name and Table Name of  database table  <code>RxRoles</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RX_ROLES_MAP_ID}
  * </ul>
 */
 
public final class RXROLES
{
    private RXROLES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RxRoles" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RX_ROLES_MAP_ID= "RX_ROLES_MAP_ID" ;

    /*
    * The index position of the column RX_ROLES_MAP_ID in the table.
    */
    public static final int RX_ROLES_MAP_ID_IDX = 1 ;

    /**
              * <p> whether the agent can transmit or not .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CAN_AGENT_TRANSMIT_NON_CS= "CAN_AGENT_TRANSMIT_NON_CS" ;

    /*
    * The index position of the column CAN_AGENT_TRANSMIT_NON_CS in the table.
    */
    public static final int CAN_AGENT_TRANSMIT_NON_CS_IDX = 2 ;

    /**
              * <p> Paper CS .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAPER_CS_2= "PAPER_CS_2" ;

    /*
    * The index position of the column PAPER_CS_2 in the table.
    */
    public static final int PAPER_CS_2_IDX = 3 ;

    /**
              * <p> Efax CS .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EFAX_CS_2= "EFAX_CS_2" ;

    /*
    * The index position of the column EFAX_CS_2 in the table.
    */
    public static final int EFAX_CS_2_IDX = 4 ;

    /**
              * <p> Efax CP .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EFAX_CS_3_TO_5= "EFAX_CS_3_TO_5" ;

    /*
    * The index position of the column EFAX_CS_3_TO_5 in the table.
    */
    public static final int EFAX_CS_3_TO_5_IDX = 5 ;

    /**
              * <p> Efax NCS .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EFAX_NCS= "EFAX_NCS" ;

    /*
    * The index position of the column EFAX_NCS in the table.
    */
    public static final int EFAX_NCS_IDX = 6 ;

    /**
              * <p> ERx CS .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERX_CS_2= "ERX_CS_2" ;

    /*
    * The index position of the column ERX_CS_2 in the table.
    */
    public static final int ERX_CS_2_IDX = 7 ;

    /**
              * <p> ERx CP .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERX_CS_3_TO_5= "ERX_CS_3_TO_5" ;

    /*
    * The index position of the column ERX_CS_3_TO_5 in the table.
    */
    public static final int ERX_CS_3_TO_5_IDX = 8 ;

    /**
              * <p> ERx NCS .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ERX_NCS= "ERX_NCS" ;

    /*
    * The index position of the column ERX_NCS in the table.
    */
    public static final int ERX_NCS_IDX = 9 ;

    /**
              * <p> Schedule 2 prescription quantity limit.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>90</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CS_2_QUANTITY_LIMIT= "CS_2_QUANTITY_LIMIT" ;

    /*
    * The index position of the column CS_2_QUANTITY_LIMIT in the table.
    */
    public static final int CS_2_QUANTITY_LIMIT_IDX = 10 ;

    /**
              * <p> Opioid prescription quantity limit.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String OPIOID_QUANTITY_LIMIT= "OPIOID_QUANTITY_LIMIT" ;

    /*
    * The index position of the column OPIOID_QUANTITY_LIMIT in the table.
    */
    public static final int OPIOID_QUANTITY_LIMIT_IDX = 11 ;

    /**
              * <p> Schedule 3 prescription quantity limit.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CS_3_QUANTITY_LIMIT= "CS_3_QUANTITY_LIMIT" ;

    /*
    * The index position of the column CS_3_QUANTITY_LIMIT in the table.
    */
    public static final int CS_3_QUANTITY_LIMIT_IDX = 12 ;

    /**
              * <p> Schedule 4 prescription quantity limit.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CS_4_QUANTITY_LIMIT= "CS_4_QUANTITY_LIMIT" ;

    /*
    * The index position of the column CS_4_QUANTITY_LIMIT in the table.
    */
    public static final int CS_4_QUANTITY_LIMIT_IDX = 13 ;

    /**
              * <p> Schedule 5 prescription quantity limit.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CS_5_QUANTITY_LIMIT= "CS_5_QUANTITY_LIMIT" ;

    /*
    * The index position of the column CS_5_QUANTITY_LIMIT in the table.
    */
    public static final int CS_5_QUANTITY_LIMIT_IDX = 14 ;

}
