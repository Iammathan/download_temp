package com.adventnet.charm;

/** <p> Description of the table <code>PatientPracticeMedRecords</code>.
 *  Column Name and Table Name of  database table  <code>PatientPracticeMedRecords</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient Medical Records and Practice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_PRACTICE_MED_RECORD_ID}
  * </ul>
 */
 
public final class PATIENTPRACTICEMEDRECORDS
{
    private PATIENTPRACTICEMEDRECORDS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientPracticeMedRecords" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_PRACTICE_MED_RECORD_ID= "PATIENT_PRACTICE_MED_RECORD_ID" ;

    /*
    * The index position of the column PATIENT_PRACTICE_MED_RECORD_ID in the table.
    */
    public static final int PATIENT_PRACTICE_MED_RECORD_ID_IDX = 1 ;

    /**
              * <p> Identifier of the Hospital.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Identifier of PHR medical record entry.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_ENTRY_ID= "MEDICAL_RECORD_ENTRY_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_ENTRY_ID in the table.
    */
    public static final int MEDICAL_RECORD_ENTRY_ID_IDX = 3 ;

    /**
              * <p> Status of the Lab Result(Read/UnRead).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String READ_STATUS= "READ_STATUS" ;

    /*
    * The index position of the column READ_STATUS in the table.
    */
    public static final int READ_STATUS_IDX = 4 ;

}
