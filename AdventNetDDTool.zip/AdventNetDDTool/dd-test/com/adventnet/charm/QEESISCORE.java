package com.adventnet.charm;

/** <p> Description of the table <code>QEESIScore</code>.
 *  Column Name and Table Name of  database table  <code>QEESIScore</code> is mapped
 * as constants in this util.</p> 
  QEESI Score for the 5 subscales. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PATIENT_ID}
  * <li> {@link #EVAL_DATE}
  * </ul>
 */
 
public final class QEESISCORE
{
    private QEESISCORE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QEESIScore" ;
    /**
              * <p> Unique identifier for Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 1 ;

    /**
              * <p> Evaluation date.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EVAL_DATE= "EVAL_DATE" ;

    /*
    * The index position of the column EVAL_DATE in the table.
    */
    public static final int EVAL_DATE_IDX = 2 ;

    /**
              * <p> Total score of chemical exposure parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHEMICAL_EXPOSURES= "CHEMICAL_EXPOSURES" ;

    /*
    * The index position of the column CHEMICAL_EXPOSURES in the table.
    */
    public static final int CHEMICAL_EXPOSURES_IDX = 3 ;

    /**
              * <p> Total score of other exposures parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTHER_EXPOSURES= "OTHER_EXPOSURES" ;

    /*
    * The index position of the column OTHER_EXPOSURES in the table.
    */
    public static final int OTHER_EXPOSURES_IDX = 4 ;

    /**
              * <p> Total score of Symptoms parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SYMPTOMS= "SYMPTOMS" ;

    /*
    * The index position of the column SYMPTOMS in the table.
    */
    public static final int SYMPTOMS_IDX = 5 ;

    /**
              * <p> Total score of Masking Index parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MASKING_INDEX= "MASKING_INDEX" ;

    /*
    * The index position of the column MASKING_INDEX in the table.
    */
    public static final int MASKING_INDEX_IDX = 6 ;

    /**
              * <p> Total score of Impact of Sensitivities parameters.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMPACT_OF_SENSITIVITIES= "IMPACT_OF_SENSITIVITIES" ;

    /*
    * The index position of the column IMPACT_OF_SENSITIVITIES in the table.
    */
    public static final int IMPACT_OF_SENSITIVITIES_IDX = 7 ;

    /**
              * <p> Name of the Template.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MCI_DEGREE= "MCI_DEGREE" ;

    /*
    * The index position of the column MCI_DEGREE in the table.
    */
    public static final int MCI_DEGREE_IDX = 8 ;

}
