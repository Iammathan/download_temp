package com.adventnet.charm;

/** <p> Description of the table <code>ConsultationWidgetsMap</code>.
 *  Column Name and Table Name of  database table  <code>ConsultationWidgetsMap</code> is mapped
 * as constants in this util.</p> 
  Table for storing encounter data in a structured manner. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #WIDGET_MAP_ID}
  * </ul>
 */
 
public final class CONSULTATIONWIDGETSMAP
{
    private CONSULTATIONWIDGETSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ConsultationWidgetsMap" ;
    /**
              * <p> Unique Id for storing values.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String WIDGET_MAP_ID= "WIDGET_MAP_ID" ;

    /*
    * The index position of the column WIDGET_MAP_ID in the table.
    */
    public static final int WIDGET_MAP_ID_IDX = 1 ;

    /**
              * <p> Mapping from ConsultationHistory table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Mapping from SOAPWidgets table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String WIDGET_ID= "WIDGET_ID" ;

    /*
    * The index position of the column WIDGET_ID in the table.
    */
    public static final int WIDGET_ID_IDX = 3 ;

    /**
              * <p> For ordering widgets.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String POSITION= "POSITION" ;

    /*
    * The index position of the column POSITION in the table.
    */
    public static final int POSITION_IDX = 4 ;

    /**
              * <p> To indicate whether this widget has been deleted from consultation.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

}
