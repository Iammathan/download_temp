package com.adventnet.charm;

/** <p> Description of the table <code>DeletedEOBs</code>.
 *  Column Name and Table Name of  database table  <code>DeletedEOBs</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DELETE_ID}
  * </ul>
 */
 
public final class DELETEDEOBS
{
    private DELETEDEOBS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DeletedEOBs" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DELETE_ID= "DELETE_ID" ;

    /*
    * The index position of the column DELETE_ID in the table.
    */
    public static final int DELETE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EOB_ID= "EOB_ID" ;

    /*
    * The index position of the column EOB_ID in the table.
    */
    public static final int EOB_ID_IDX = 2 ;

    /**
              * <p> Date and Time of deleting EOB .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DELETED_DATE= "DELETED_DATE" ;

    /*
    * The index position of the column DELETED_DATE in the table.
    */
    public static final int DELETED_DATE_IDX = 3 ;

    /**
              * <p> Person who has DELETED EOB.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DELETED_BY= "DELETED_BY" ;

    /*
    * The index position of the column DELETED_BY in the table.
    */
    public static final int DELETED_BY_IDX = 4 ;

    /**
              * <p>  Reason for deleting EOB .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DELETED_COMMENTS= "DELETED_COMMENTS" ;

    /*
    * The index position of the column DELETED_COMMENTS in the table.
    */
    public static final int DELETED_COMMENTS_IDX = 5 ;

}
