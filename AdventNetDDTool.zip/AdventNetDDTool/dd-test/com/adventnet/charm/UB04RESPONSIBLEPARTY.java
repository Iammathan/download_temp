package com.adventnet.charm;

/** <p> Description of the table <code>UB04ResponsibleParty</code>.
 *  Column Name and Table Name of  database table  <code>UB04ResponsibleParty</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_RESP_PARTY_ID}
  * </ul>
 */
 
public final class UB04RESPONSIBLEPARTY
{
    private UB04RESPONSIBLEPARTY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04ResponsibleParty" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_RESP_PARTY_ID= "UB04_RESP_PARTY_ID" ;

    /*
    * The index position of the column UB04_RESP_PARTY_ID in the table.
    */
    public static final int UB04_RESP_PARTY_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_CLAIM_ID= "UB04_CLAIM_ID" ;

    /*
    * The index position of the column UB04_CLAIM_ID in the table.
    */
    public static final int UB04_CLAIM_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RES_PARTY_LINE_1= "RES_PARTY_LINE_1" ;

    /*
    * The index position of the column RES_PARTY_LINE_1 in the table.
    */
    public static final int RES_PARTY_LINE_1_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RES_PARTY_LINE_2= "RES_PARTY_LINE_2" ;

    /*
    * The index position of the column RES_PARTY_LINE_2 in the table.
    */
    public static final int RES_PARTY_LINE_2_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RES_PARTY_LINE_3= "RES_PARTY_LINE_3" ;

    /*
    * The index position of the column RES_PARTY_LINE_3 in the table.
    */
    public static final int RES_PARTY_LINE_3_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RES_PARTY_LINE_4= "RES_PARTY_LINE_4" ;

    /*
    * The index position of the column RES_PARTY_LINE_4 in the table.
    */
    public static final int RES_PARTY_LINE_4_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RES_PARTY_LINE_5= "RES_PARTY_LINE_5" ;

    /*
    * The index position of the column RES_PARTY_LINE_5 in the table.
    */
    public static final int RES_PARTY_LINE_5_IDX = 7 ;

}
