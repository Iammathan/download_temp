package com.adventnet.charm;

/** <p> Description of the table <code>MessagesAttachmentsMap</code>.
 *  Column Name and Table Name of  database table  <code>MessagesAttachmentsMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ATTACHMENT_ID}
  * </ul>
 */
 
public final class MESSAGESATTACHMENTSMAP
{
    private MESSAGESATTACHMENTSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MessagesAttachmentsMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ATTACHMENT_ID= "ATTACHMENT_ID" ;

    /*
    * The index position of the column ATTACHMENT_ID in the table.
    */
    public static final int ATTACHMENT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MESSAGE_ID= "MESSAGE_ID" ;

    /*
    * The index position of the column MESSAGE_ID in the table.
    */
    public static final int MESSAGE_ID_IDX = 2 ;

    /**
              * <p> Name of the attachment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ATTACHMENT_NAME= "ATTACHMENT_NAME" ;

    /*
    * The index position of the column ATTACHMENT_NAME in the table.
    */
    public static final int ATTACHMENT_NAME_IDX = 3 ;

    /**
              * <p> Location of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ATTCHMENT_LOCATION= "ATTCHMENT_LOCATION" ;

    /*
    * The index position of the column ATTCHMENT_LOCATION in the table.
    */
    public static final int ATTCHMENT_LOCATION_IDX = 4 ;

    /**
              * <p> Attachement Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ATTACHMENT_TYPE= "ATTACHMENT_TYPE" ;

    /*
    * The index position of the column ATTACHMENT_TYPE in the table.
    */
    public static final int ATTACHMENT_TYPE_IDX = 5 ;

    /**
              * <p> Is the document added to a patient chart.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ADDED_TO_PATIENT_CHART= "IS_ADDED_TO_PATIENT_CHART" ;

    /*
    * The index position of the column IS_ADDED_TO_PATIENT_CHART in the table.
    */
    public static final int IS_ADDED_TO_PATIENT_CHART_IDX = 6 ;

}
