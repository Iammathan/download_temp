package com.adventnet.charm;

/** <p> Description of the table <code>UB04RelationshipDetails</code>.
 *  Column Name and Table Name of  database table  <code>UB04RelationshipDetails</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_RELATIONSHIP_ID}
  * </ul>
 */
 
public final class UB04RELATIONSHIPDETAILS
{
    private UB04RELATIONSHIPDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04RelationshipDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_RELATIONSHIP_ID= "UB04_RELATIONSHIP_ID" ;

    /*
    * The index position of the column UB04_RELATIONSHIP_ID in the table.
    */
    public static final int UB04_RELATIONSHIP_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_RELATIONSHIP= "PATIENT_RELATIONSHIP" ;

    /*
    * The index position of the column PATIENT_RELATIONSHIP in the table.
    */
    public static final int PATIENT_RELATIONSHIP_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_RELATIONSHIP_CODE= "PATIENT_RELATIONSHIP_CODE" ;

    /*
    * The index position of the column PATIENT_RELATIONSHIP_CODE in the table.
    */
    public static final int PATIENT_RELATIONSHIP_CODE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 6 ;

}
