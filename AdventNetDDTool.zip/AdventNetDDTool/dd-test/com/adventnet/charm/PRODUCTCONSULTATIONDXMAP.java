package com.adventnet.charm;

/** <p> Description of the table <code>ProductConsultationDxMap</code>.
 *  Column Name and Table Name of  database table  <code>ProductConsultationDxMap</code> is mapped
 * as constants in this util.</p> 
  Maintains Product Vs Diagnosis mapping in Invoice/Claim/Consultation. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRODUCT_DX_MAP_ID}
  * </ul>
 */
 
public final class PRODUCTCONSULTATIONDXMAP
{
    private PRODUCTCONSULTATIONDXMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ProductConsultationDxMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRODUCT_DX_MAP_ID= "PRODUCT_DX_MAP_ID" ;

    /*
    * The index position of the column PRODUCT_DX_MAP_ID in the table.
    */
    public static final int PRODUCT_DX_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of product/item from BillItemDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRODUCT_ITEM_ID= "PRODUCT_ITEM_ID" ;

    /*
    * The index position of the column PRODUCT_ITEM_ID in the table.
    */
    public static final int PRODUCT_ITEM_ID_IDX = 2 ;

    /**
              * <p> Diagnosis map id from PatientDiagnosisMap table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DIAGNOSIS_MAP_ID= "DIAGNOSIS_MAP_ID" ;

    /*
    * The index position of the column DIAGNOSIS_MAP_ID in the table.
    */
    public static final int DIAGNOSIS_MAP_ID_IDX = 3 ;

}
