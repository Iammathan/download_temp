package com.adventnet.charm;

/** <p> Description of the table <code>RCMBatchTransaction</code>.
 *  Column Name and Table Name of  database table  <code>RCMBatchTransaction</code> is mapped
 * as constants in this util.</p> 
  RCM Batch Transction. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BATCH_TRNSXN_ID}
  * </ul>
 */
 
public final class RCMBATCHTRANSACTION
{
    private RCMBATCHTRANSACTION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMBatchTransaction" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BATCH_TRNSXN_ID= "BATCH_TRNSXN_ID" ;

    /*
    * The index position of the column BATCH_TRNSXN_ID in the table.
    */
    public static final int BATCH_TRNSXN_ID_IDX = 1 ;

    /**
              * <p> Batch file generation time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GENERATED_TIME= "GENERATED_TIME" ;

    /*
    * The index position of the column GENERATED_TIME in the table.
    */
    public static final int GENERATED_TIME_IDX = 2 ;

    /**
              * <p> Total n number of cliams.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_COUNT= "CLAIM_COUNT" ;

    /*
    * The index position of the column CLAIM_COUNT in the table.
    */
    public static final int CLAIM_COUNT_IDX = 3 ;

    /**
              * <p> MEMBER ID who is generated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String GENERATED_BY= "GENERATED_BY" ;

    /*
    * The index position of the column GENERATED_BY in the table.
    */
    public static final int GENERATED_BY_IDX = 4 ;

    /**
              * <p> if true clime status are set submit.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_STATUS_UPDATED= "IS_STATUS_UPDATED" ;

    /*
    * The index position of the column IS_STATUS_UPDATED in the table.
    */
    public static final int IS_STATUS_UPDATED_IDX = 5 ;

    /**
              * <p> Date on which claim is submitted.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_SUBMISSION_DATE= "CLAIM_SUBMISSION_DATE" ;

    /*
    * The index position of the column CLAIM_SUBMISSION_DATE in the table.
    */
    public static final int CLAIM_SUBMISSION_DATE_IDX = 6 ;

    /**
              * <p> claim ids in comma separate  .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4096</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_IDS= "CLAIM_IDS" ;

    /*
    * The index position of the column CLAIM_IDS in the table.
    */
    public static final int CLAIM_IDS_IDX = 7 ;

}
