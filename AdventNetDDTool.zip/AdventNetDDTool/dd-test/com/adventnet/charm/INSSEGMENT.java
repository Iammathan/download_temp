package com.adventnet.charm;

/** <p> Description of the table <code>INSSegment</code>.
 *  Column Name and Table Name of  database table  <code>INSSegment</code> is mapped
 * as constants in this util.</p> 
  INS Segment Values. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INS_SEGMENT_ID}
  * </ul>
 */
 
public final class INSSEGMENT
{
    private INSSEGMENT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "INSSegment" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INS_SEGMENT_ID= "INS_SEGMENT_ID" ;

    /*
    * The index position of the column INS_SEGMENT_ID in the table.
    */
    public static final int INS_SEGMENT_ID_IDX = 1 ;

    /**
              * <p> Mapping ID with NM1Segment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String NM1_SEGMENT_ID= "NM1_SEGMENT_ID" ;

    /*
    * The index position of the column NM1_SEGMENT_ID in the table.
    */
    public static final int NM1_SEGMENT_ID_IDX = 2 ;

    /**
              * <p> INS01 - Yes/No Condition or Response Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONDITION_CODE= "CONDITION_CODE" ;

    /*
    * The index position of the column CONDITION_CODE in the table.
    */
    public static final int CONDITION_CODE_IDX = 3 ;

    /**
              * <p> INS02 - Individual Relationship Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REALTTIONSHIP_CODE= "REALTTIONSHIP_CODE" ;

    /*
    * The index position of the column REALTTIONSHIP_CODE in the table.
    */
    public static final int REALTTIONSHIP_CODE_IDX = 4 ;

    /**
              * <p> INS03 - Maintenance Type Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>5</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAINTENACE_TYPE= "MAINTENACE_TYPE" ;

    /*
    * The index position of the column MAINTENACE_TYPE in the table.
    */
    public static final int MAINTENACE_TYPE_IDX = 5 ;

    /**
              * <p> INS04 - Maintenance Reason Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAINTENACE_REASON= "MAINTENACE_REASON" ;

    /*
    * The index position of the column MAINTENACE_REASON in the table.
    */
    public static final int MAINTENACE_REASON_IDX = 6 ;

    /**
              * <p> INS17 - Number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NUMBER= "NUMBER" ;

    /*
    * The index position of the column NUMBER in the table.
    */
    public static final int NUMBER_IDX = 7 ;

}
