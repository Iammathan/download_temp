package com.adventnet.charm;

/** <p> Description of the table <code>PlanAttributes</code>.
 *  Column Name and Table Name of  database table  <code>PlanAttributes</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ATTRIBUTE_ID}
  * </ul>
 */
 
public final class PLANATTRIBUTES
{
    private PLANATTRIBUTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PlanAttributes" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ATTRIBUTE_ID= "ATTRIBUTE_ID" ;

    /*
    * The index position of the column ATTRIBUTE_ID in the table.
    */
    public static final int ATTRIBUTE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER= "IDENTIFIER" ;

    /*
    * The index position of the column IDENTIFIER in the table.
    */
    public static final int IDENTIFIER_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INVOICE_ITEM_ID= "INVOICE_ITEM_ID" ;

    /*
    * The index position of the column INVOICE_ITEM_ID in the table.
    */
    public static final int INVOICE_ITEM_ID_IDX = 5 ;

    /**
              * <p> Used to store the item id for the default charge on addons.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DEFAULT_INVOICE_ITEM_ID= "DEFAULT_INVOICE_ITEM_ID" ;

    /*
    * The index position of the column DEFAULT_INVOICE_ITEM_ID in the table.
    */
    public static final int DEFAULT_INVOICE_ITEM_ID_IDX = 6 ;

    /**
              * <p> Used to store the tax code for each item id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AVALARA_US_TAX_CODE= "AVALARA_US_TAX_CODE" ;

    /*
    * The index position of the column AVALARA_US_TAX_CODE in the table.
    */
    public static final int AVALARA_US_TAX_CODE_IDX = 7 ;

}
