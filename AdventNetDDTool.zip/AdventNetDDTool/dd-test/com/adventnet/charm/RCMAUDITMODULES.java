package com.adventnet.charm;

/** <p> Description of the table <code>RCMAuditModules</code>.
 *  Column Name and Table Name of  database table  <code>RCMAuditModules</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AUDIT_MODULE_ID}
  * </ul>
 */
 
public final class RCMAUDITMODULES
{
    private RCMAUDITMODULES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMAuditModules" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AUDIT_MODULE_ID= "AUDIT_MODULE_ID" ;

    /*
    * The index position of the column AUDIT_MODULE_ID in the table.
    */
    public static final int AUDIT_MODULE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AUDIT_MODULE_NAME= "AUDIT_MODULE_NAME" ;

    /*
    * The index position of the column AUDIT_MODULE_NAME in the table.
    */
    public static final int AUDIT_MODULE_NAME_IDX = 2 ;

}
