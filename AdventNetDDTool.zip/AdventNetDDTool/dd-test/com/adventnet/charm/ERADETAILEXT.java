package com.adventnet.charm;

/** <p> Description of the table <code>ERADetailExt</code>.
 *  Column Name and Table Name of  database table  <code>ERADetailExt</code> is mapped
 * as constants in this util.</p> 
  Contains additional data related to ERADetail table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ERA_DETAIL_EXT_ID}
  * </ul>
 */
 
public final class ERADETAILEXT
{
    private ERADETAILEXT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ERADetailExt" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_DETAIL_EXT_ID= "ERA_DETAIL_EXT_ID" ;

    /*
    * The index position of the column ERA_DETAIL_EXT_ID in the table.
    */
    public static final int ERA_DETAIL_EXT_ID_IDX = 1 ;

    /**
              * <p> SAS Key of ERADetail table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ERA_DETAIL_ID= "ERA_DETAIL_ID" ;

    /*
    * The index position of the column ERA_DETAIL_ID in the table.
    */
    public static final int ERA_DETAIL_ID_IDX = 2 ;

    /**
              * <p> Indicates if the ERA is marked.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_MARKED= "IS_MARKED" ;

    /*
    * The index position of the column IS_MARKED in the table.
    */
    public static final int IS_MARKED_IDX = 3 ;

    /**
              * <p> Last marked Member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MARKED_BY= "MARKED_BY" ;

    /*
    * The index position of the column MARKED_BY in the table.
    */
    public static final int MARKED_BY_IDX = 4 ;

    /**
              * <p> ERA's Last marked time.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MARKED_ON= "MARKED_ON" ;

    /*
    * The index position of the column MARKED_ON in the table.
    */
    public static final int MARKED_ON_IDX = 5 ;

    /**
              * <p> Last marked Member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String UNMARKED_BY= "UNMARKED_BY" ;

    /*
    * The index position of the column UNMARKED_BY in the table.
    */
    public static final int UNMARKED_BY_IDX = 6 ;

    /**
              * <p> ERA's Last marked time.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UNMARKED_ON= "UNMARKED_ON" ;

    /*
    * The index position of the column UNMARKED_ON in the table.
    */
    public static final int UNMARKED_ON_IDX = 7 ;

}
