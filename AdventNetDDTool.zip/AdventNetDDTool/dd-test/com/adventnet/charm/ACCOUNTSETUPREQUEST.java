package com.adventnet.charm;

/** <p> Description of the table <code>AccountSetupRequest</code>.
 *  Column Name and Table Name of  database table  <code>AccountSetupRequest</code> is mapped
 * as constants in this util.</p> 
  To store the information about users sending documents for their practice set up. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REQUEST_ID}
  * </ul>
 */
 
public final class ACCOUNTSETUPREQUEST
{
    private ACCOUNTSETUPREQUEST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AccountSetupRequest" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUEST_ID= "REQUEST_ID" ;

    /*
    * The index position of the column REQUEST_ID in the table.
    */
    public static final int REQUEST_ID_IDX = 1 ;

    /**
              * <p> First name of the users.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 2 ;

    /**
              * <p> Last name of the users.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 3 ;

    /**
              * <p> Email id of the users.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 4 ;

    /**
              * <p> Practice name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PRACTICE_NAME= "PRACTICE_NAME" ;

    /*
    * The index position of the column PRACTICE_NAME in the table.
    */
    public static final int PRACTICE_NAME_IDX = 5 ;

    /**
              * <p> Time of the request.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REQUESTING_TIME= "REQUESTING_TIME" ;

    /*
    * The index position of the column REQUESTING_TIME in the table.
    */
    public static final int REQUESTING_TIME_IDX = 6 ;

    /**
              * <p> Request completed time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COMPLETION_TIME= "COMPLETION_TIME" ;

    /*
    * The index position of the column COMPLETION_TIME in the table.
    */
    public static final int COMPLETION_TIME_IDX = 7 ;

    /**
              * <p> Status of the request(Yet to start/In Progress/Completed).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 8 ;

    /**
              * <p> Comments for the uploaded practice setup documents.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 9 ;

    /**
              * <p> Whether the uploaded documents are securely shared.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SECURE_SHARING= "IS_SECURE_SHARING" ;

    /*
    * The index position of the column IS_SECURE_SHARING in the table.
    */
    public static final int IS_SECURE_SHARING_IDX = 10 ;

}
