package com.adventnet.charm;

/** <p> Description of the table <code>AllergiesList</code>.
 *  Column Name and Table Name of  database table  <code>AllergiesList</code> is mapped
 * as constants in this util.</p> 
  Allergies list of the Patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ALLERGY_ID}
  * </ul>
 */
 
public final class ALLERGIESLIST
{
    private ALLERGIESLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AllergiesList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ALLERGY_ID= "ALLERGY_ID" ;

    /*
    * The index position of the column ALLERGY_ID in the table.
    */
    public static final int ALLERGY_ID_IDX = 1 ;

    /**
              * <p> Name of the allergy.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALLERGY= "ALLERGY" ;

    /*
    * The index position of the column ALLERGY in the table.
    */
    public static final int ALLERGY_IDX = 2 ;

    /**
              * <p> Type of the allergy.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALLERGY_TYPE= "ALLERGY_TYPE" ;

    /*
    * The index position of the column ALLERGY_TYPE in the table.
    */
    public static final int ALLERGY_TYPE_IDX = 3 ;

    /**
              * <p> Rxnorm code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_CODE= "RXNORM_CODE" ;

    /*
    * The index position of the column RXNORM_CODE in the table.
    */
    public static final int RXNORM_CODE_IDX = 4 ;

    /**
              * <p> Snomed code for drug substance.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DRUG_SNOMED_CODE= "DRUG_SNOMED_CODE" ;

    /*
    * The index position of the column DRUG_SNOMED_CODE in the table.
    */
    public static final int DRUG_SNOMED_CODE_IDX = 5 ;

}
