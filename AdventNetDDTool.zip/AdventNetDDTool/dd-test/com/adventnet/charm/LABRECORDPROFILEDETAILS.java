package com.adventnet.charm;

/** <p> Description of the table <code>LabRecordProfileDetails</code>.
 *  Column Name and Table Name of  database table  <code>LabRecordProfileDetails</code> is mapped
 * as constants in this util.</p> 
  Maintains the profile detials of a record. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #LAB_RECORD_PROFILE_ID}
  * </ul>
 */
 
public final class LABRECORDPROFILEDETAILS
{
    private LABRECORDPROFILEDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabRecordProfileDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAB_RECORD_PROFILE_ID= "LAB_RECORD_PROFILE_ID" ;

    /*
    * The index position of the column LAB_RECORD_PROFILE_ID in the table.
    */
    public static final int LAB_RECORD_PROFILE_ID_IDX = 1 ;

    /**
              * <p> Lab Record Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_RECORD_ID= "LAB_RECORD_ID" ;

    /*
    * The index position of the column LAB_RECORD_ID in the table.
    */
    public static final int LAB_RECORD_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TEST_COMP_DESCRIPTION= "TEST_COMP_DESCRIPTION" ;

    /*
    * The index position of the column TEST_COMP_DESCRIPTION in the table.
    */
    public static final int TEST_COMP_DESCRIPTION_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_CONDITION_TEMPERATURE= "SPECIMEN_CONDITION_TEMPERATURE" ;

    /*
    * The index position of the column SPECIMEN_CONDITION_TEMPERATURE in the table.
    */
    public static final int SPECIMEN_CONDITION_TEMPERATURE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIMEN_TYPE= "SPECIMEN_TYPE" ;

    /*
    * The index position of the column SPECIMEN_TYPE in the table.
    */
    public static final int SPECIMEN_TYPE_IDX = 5 ;

}
