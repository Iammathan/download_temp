package com.adventnet.charm;

/** <p> Description of the table <code>RCMTask</code>.
 *  Column Name and Table Name of  database table  <code>RCMTask</code> is mapped
 * as constants in this util.</p> 
  Task main table. Can create task for Claim/Invoice/Patients. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_TASK_ID}
  * </ul>
 */
 
public final class RCMTASK
{
    private RCMTASK()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMTask" ;
    /**
              * <p> Primary Key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_TASK_ID= "RCM_TASK_ID" ;

    /*
    * The index position of the column RCM_TASK_ID in the table.
    */
    public static final int RCM_TASK_ID_IDX = 1 ;

    /**
              * <p> Task Record ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TASK_RECORD_ID= "TASK_RECORD_ID" ;

    /*
    * The index position of the column TASK_RECORD_ID in the table.
    */
    public static final int TASK_RECORD_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 3 ;

    /**
              * <p> Name of RCM Member who created the task.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_MEMBER_NAME= "ADDED_MEMBER_NAME" ;

    /*
    * The index position of the column ADDED_MEMBER_NAME in the table.
    */
    public static final int ADDED_MEMBER_NAME_IDX = 4 ;

    /**
              * <p> ID of RCM Member who created the task.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_MEMBER_ID= "ADDED_MEMBER_ID" ;

    /*
    * The index position of the column ADDED_MEMBER_ID in the table.
    */
    public static final int ADDED_MEMBER_ID_IDX = 5 ;

    /**
              * <p> Description of the task.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 6 ;

    /**
              * <p> Category of the task.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CATEGORY= "CATEGORY" ;

    /*
    * The index position of the column CATEGORY in the table.
    */
    public static final int CATEGORY_IDX = 7 ;

    /**
              * <p> Priority of the task HIGH/MEDIUM/LOW.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRIORITY= "PRIORITY" ;

    /*
    * The index position of the column PRIORITY in the table.
    */
    public static final int PRIORITY_IDX = 8 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DUE_DATE= "DUE_DATE" ;

    /*
    * The index position of the column DUE_DATE in the table.
    */
    public static final int DUE_DATE_IDX = 9 ;

    /**
              * <p> Name of RCM Member to whom the task is assigned.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ASSIGNED_MEMBER_NAME= "ASSIGNED_MEMBER_NAME" ;

    /*
    * The index position of the column ASSIGNED_MEMBER_NAME in the table.
    */
    public static final int ASSIGNED_MEMBER_NAME_IDX = 10 ;

    /**
              * <p> ID of RCM Member to whom the task is assigned.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ASSIGNED_MEMBER_ID= "ASSIGNED_MEMBER_ID" ;

    /*
    * The index position of the column ASSIGNED_MEMBER_ID in the table.
    */
    public static final int ASSIGNED_MEMBER_ID_IDX = 11 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 12 ;

    /**
              * <p> 0 unread/1 read.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String READ_STATUS= "READ_STATUS" ;

    /*
    * The index position of the column READ_STATUS in the table.
    */
    public static final int READ_STATUS_IDX = 13 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 14 ;

    /**
              * <p> PracticeId of MBP where the task was created.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 15 ;

}
