package com.adventnet.charm;

/** <p> Description of the table <code>AllergyMasterList</code>.
 *  Column Name and Table Name of  database table  <code>AllergyMasterList</code> is mapped
 * as constants in this util.</p> 
  Allergy substance and reaction list of the Patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ALLERGY_MASTER_ID}
  * </ul>
 */
 
public final class ALLERGYMASTERLIST
{
    private ALLERGYMASTERLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AllergyMasterList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ALLERGY_MASTER_ID= "ALLERGY_MASTER_ID" ;

    /*
    * The index position of the column ALLERGY_MASTER_ID in the table.
    */
    public static final int ALLERGY_MASTER_ID_IDX = 1 ;

    /**
              * <p> Substance name / Reaction name .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 2 ;

    /**
              * <p> Unique identifier for every substance or reaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CODE= "CODE" ;

    /*
    * The index position of the column CODE in the table.
    */
    public static final int CODE_IDX = 3 ;

    /**
              * <p> Drug Substance or reaction.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 4 ;

}
