package com.adventnet.charm;

/** <p> Description of the table <code>BillVsSavedFiles</code>.
 *  Column Name and Table Name of  database table  <code>BillVsSavedFiles</code> is mapped
 * as constants in this util.</p> 
  Stores the attachment details for the invoices. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_VS_SAVED_FILES_ID}
  * </ul>
 */
 
public final class BILLVSSAVEDFILES
{
    private BILLVSSAVEDFILES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillVsSavedFiles" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_VS_SAVED_FILES_ID= "BILL_VS_SAVED_FILES_ID" ;

    /*
    * The index position of the column BILL_VS_SAVED_FILES_ID in the table.
    */
    public static final int BILL_VS_SAVED_FILES_ID_IDX = 1 ;

    /**
              * <p> Reference to The pk of BillDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 2 ;

    /**
              * <p> The pointer to the file stored.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_POINTER= "FILE_POINTER" ;

    /*
    * The index position of the column FILE_POINTER in the table.
    */
    public static final int FILE_POINTER_IDX = 3 ;

    /**
              * <p> The name of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 4 ;

    /**
              * <p> The type of the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_TYPE= "FILE_TYPE" ;

    /*
    * The index position of the column FILE_TYPE in the table.
    */
    public static final int FILE_TYPE_IDX = 5 ;

    /**
              * <p> false means only can be viewed in EHR.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SHARED_WITH_RCM= "SHARED_WITH_RCM" ;

    /*
    * The index position of the column SHARED_WITH_RCM in the table.
    */
    public static final int SHARED_WITH_RCM_IDX = 6 ;

    /**
              * <p> Date when added.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FILE_ADDED_ON= "FILE_ADDED_ON" ;

    /*
    * The index position of the column FILE_ADDED_ON in the table.
    */
    public static final int FILE_ADDED_ON_IDX = 7 ;

    /**
              * <p> Id of the member who added the file.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_ADDED_MEMBER_ID= "FILE_ADDED_MEMBER_ID" ;

    /*
    * The index position of the column FILE_ADDED_MEMBER_ID in the table.
    */
    public static final int FILE_ADDED_MEMBER_ID_IDX = 8 ;

    /**
              * <p> Name of the member who added the file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>103</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_ADDED_MEMBER_NAME= "FILE_ADDED_MEMBER_NAME" ;

    /*
    * The index position of the column FILE_ADDED_MEMBER_NAME in the table.
    */
    public static final int FILE_ADDED_MEMBER_NAME_IDX = 9 ;

}
