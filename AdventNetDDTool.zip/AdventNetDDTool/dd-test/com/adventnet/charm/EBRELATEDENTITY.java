package com.adventnet.charm;

/** <p> Description of the table <code>EBRelatedEntity</code>.
 *  Column Name and Table Name of  database table  <code>EBRelatedEntity</code> is mapped
 * as constants in this util.</p> 
  This table and the maintains the detail received in the LS-LE(2120) LOOP except the contact/PER-Segment detail. i.e NM1, N3, N4, PRV. It stores the Entity details that is related EB. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #RELATED_ENTITY_ID}
  * <li> {@link #ELIGIBILITY_BENEFIT_INFO_ID}
  * </ul>
 */
 
public final class EBRELATEDENTITY
{
    private EBRELATEDENTITY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EBRelatedEntity" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RELATED_ENTITY_ID= "RELATED_ENTITY_ID" ;

    /*
    * The index position of the column RELATED_ENTITY_ID in the table.
    */
    public static final int RELATED_ENTITY_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of the respective Eligibility Information Group.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ELIGIBILITY_BENEFIT_INFO_ID= "ELIGIBILITY_BENEFIT_INFO_ID" ;

    /*
    * The index position of the column ELIGIBILITY_BENEFIT_INFO_ID in the table.
    */
    public static final int ELIGIBILITY_BENEFIT_INFO_ID_IDX = 2 ;

    /**
              * <p> 2120-NM101 - Entity Identifier Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ENTITY_ID_CODE= "ENTITY_ID_CODE" ;

    /*
    * The index position of the column ENTITY_ID_CODE in the table.
    */
    public static final int ENTITY_ID_CODE_IDX = 3 ;

    /**
              * <p> 2120-NM102 - Entity Type - Personal / Non-Personal entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ENTITY_TYPE_QUALIFIER= "ENTITY_TYPE_QUALIFIER" ;

    /*
    * The index position of the column ENTITY_TYPE_QUALIFIER in the table.
    */
    public static final int ENTITY_TYPE_QUALIFIER_IDX = 4 ;

    /**
              * <p> 2120-NM103 - Represents Last name for personal entity or Org name for non-personal entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_OR_ORG_NAME= "LAST_OR_ORG_NAME" ;

    /*
    * The index position of the column LAST_OR_ORG_NAME in the table.
    */
    public static final int LAST_OR_ORG_NAME_IDX = 5 ;

    /**
              * <p> 2120-NM104 - Represents First name for personal entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 6 ;

    /**
              * <p> 2120-NM105 - Represents Middle name for personal entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIDDLE_NAME= "MIDDLE_NAME" ;

    /*
    * The index position of the column MIDDLE_NAME in the table.
    */
    public static final int MIDDLE_NAME_IDX = 7 ;

    /**
              * <p> 2120-NM107 - Represents suffix of the  entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUFFIX= "SUFFIX" ;

    /*
    * The index position of the column SUFFIX in the table.
    */
    public static final int SUFFIX_IDX = 8 ;

    /**
              * <p> 2120-NM108 - Identification Qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 9 ;

    /**
              * <p> 2120-NM109 - Identiifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IDENTIFIER= "IDENTIFIER" ;

    /*
    * The index position of the column IDENTIFIER in the table.
    */
    public static final int IDENTIFIER_IDX = 10 ;

    /**
              * <p> 2120-NM110 - Relationship Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RELATIONSHIP_CODE= "RELATIONSHIP_CODE" ;

    /*
    * The index position of the column RELATIONSHIP_CODE in the table.
    */
    public static final int RELATIONSHIP_CODE_IDX = 11 ;

    /**
              * <p> 2120-N301 - Address Line 1.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>55</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_1= "LINE_1" ;

    /*
    * The index position of the column LINE_1 in the table.
    */
    public static final int LINE_1_IDX = 12 ;

    /**
              * <p> 2120-N302 - Address Line 2.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>55</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LINE_2= "LINE_2" ;

    /*
    * The index position of the column LINE_2 in the table.
    */
    public static final int LINE_2_IDX = 13 ;

    /**
              * <p> 2120-N401 - City Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CITY= "CITY" ;

    /*
    * The index position of the column CITY in the table.
    */
    public static final int CITY_IDX = 14 ;

    /**
              * <p> 2120-N402 - State Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String STATE_CODE= "STATE_CODE" ;

    /*
    * The index position of the column STATE_CODE in the table.
    */
    public static final int STATE_CODE_IDX = 15 ;

    /**
              * <p> 2120-N403 - Postal Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String POSTAL_CODE= "POSTAL_CODE" ;

    /*
    * The index position of the column POSTAL_CODE in the table.
    */
    public static final int POSTAL_CODE_IDX = 16 ;

    /**
              * <p> 2120-N404 - Country Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COUNTRY_CODE= "COUNTRY_CODE" ;

    /*
    * The index position of the column COUNTRY_CODE in the table.
    */
    public static final int COUNTRY_CODE_IDX = 17 ;

    /**
              * <p> 2120-N405 - Location Qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LOCATION_QUALIFIER= "LOCATION_QUALIFIER" ;

    /*
    * The index position of the column LOCATION_QUALIFIER in the table.
    */
    public static final int LOCATION_QUALIFIER_IDX = 18 ;

    /**
              * <p> 2120-N406 - Location Identifer.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LOCATION_IDENTIFIER= "LOCATION_IDENTIFIER" ;

    /*
    * The index position of the column LOCATION_IDENTIFIER in the table.
    */
    public static final int LOCATION_IDENTIFIER_IDX = 19 ;

    /**
              * <p> 2120-PRV01 - Code identifying the type of provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRV_CODE= "PRV_CODE" ;

    /*
    * The index position of the column PRV_CODE in the table.
    */
    public static final int PRV_CODE_IDX = 20 ;

    /**
              * <p> 2120-PRV02 - Qualifier for Provider Reference Identification.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRV_ID_QUALIFIER= "PRV_ID_QUALIFIER" ;

    /*
    * The index position of the column PRV_ID_QUALIFIER in the table.
    */
    public static final int PRV_ID_QUALIFIER_IDX = 21 ;

    /**
              * <p> 2120-PRV03 - Provider Reference Identifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRV_IDENTIFIER= "PRV_IDENTIFIER" ;

    /*
    * The index position of the column PRV_IDENTIFIER in the table.
    */
    public static final int PRV_IDENTIFIER_IDX = 22 ;

}
