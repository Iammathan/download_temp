package com.adventnet.charm;

/** <p> Description of the table <code>CQMMeasureList</code>.
 *  Column Name and Table Name of  database table  <code>CQMMeasureList</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEASURE_ID}
  * </ul>
 */
 
public final class CQMMEASURELIST
{
    private CQMMEASURELIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMMeasureList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEASURE_ID= "MEASURE_ID" ;

    /*
    * The index position of the column MEASURE_ID in the table.
    */
    public static final int MEASURE_ID_IDX = 1 ;

    /**
              * <p> Name of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MEASURE_NAME= "MEASURE_NAME" ;

    /*
    * The index position of the column MEASURE_NAME in the table.
    */
    public static final int MEASURE_NAME_IDX = 2 ;

    /**
              * <p> Unique identifier of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEASURE_GUID= "MEASURE_GUID" ;

    /*
    * The index position of the column MEASURE_GUID in the table.
    */
    public static final int MEASURE_GUID_IDX = 3 ;

    /**
              * <p> NQF number of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NQF_NUMBER= "NQF_NUMBER" ;

    /*
    * The index position of the column NQF_NUMBER in the table.
    */
    public static final int NQF_NUMBER_IDX = 4 ;

    /**
              * <p> Identifier of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMEASURE_ID= "EMEASURE_ID" ;

    /*
    * The index position of the column EMEASURE_ID in the table.
    */
    public static final int EMEASURE_ID_IDX = 5 ;

    /**
              * <p> Version of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String VERSION= "VERSION" ;

    /*
    * The index position of the column VERSION in the table.
    */
    public static final int VERSION_IDX = 6 ;

    /**
              * <p> Speciality of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65535</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIALITY= "SPECIALITY" ;

    /*
    * The index position of the column SPECIALITY in the table.
    */
    public static final int SPECIALITY_IDX = 7 ;

    /**
              * <p> Category of the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CATEGORY= "CATEGORY" ;

    /*
    * The index position of the column CATEGORY in the table.
    */
    public static final int CATEGORY_IDX = 8 ;

    /**
              * <p> is high priority measure or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_HIGH_PRIORITY= "IS_HIGH_PRIORITY" ;

    /*
    * The index position of the column IS_HIGH_PRIORITY in the table.
    */
    public static final int IS_HIGH_PRIORITY_IDX = 9 ;

    /**
              * <p> Age criteria for the measure.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AGE_CRITERIA= "AGE_CRITERIA" ;

    /*
    * The index position of the column AGE_CRITERIA in the table.
    */
    public static final int AGE_CRITERIA_IDX = 10 ;

    /**
              * <p> used in new ui or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_NEW_UI= "IS_NEW_UI" ;

    /*
    * The index position of the column IS_NEW_UI in the table.
    */
    public static final int IS_NEW_UI_IDX = 11 ;

}
