package com.adventnet.charm;

/** <p> Description of the table <code>ATECPracticeEntry</code>.
 *  Column Name and Table Name of  database table  <code>ATECPracticeEntry</code> is mapped
 * as constants in this util.</p> 
  Entry for ATEC scores for patients in this practice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ATEC_PRACTICE_ENTRY_ID}
  * </ul>
 */
 
public final class ATECPRACTICEENTRY
{
    private ATECPRACTICEENTRY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ATECPracticeEntry" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ATEC_PRACTICE_ENTRY_ID= "ATEC_PRACTICE_ENTRY_ID" ;

    /*
    * The index position of the column ATEC_PRACTICE_ENTRY_ID in the table.
    */
    public static final int ATEC_PRACTICE_ENTRY_ID_IDX = 1 ;

    /**
              * <p> Unique Identifier of the PracticePatientsList table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Test has taken date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 3 ;

    /**
              * <p> Awareness Score.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String AWARENESS_SCORE= "AWARENESS_SCORE" ;

    /*
    * The index position of the column AWARENESS_SCORE in the table.
    */
    public static final int AWARENESS_SCORE_IDX = 4 ;

    /**
              * <p> Behavior Score.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String BEHAVIOR_SCORE= "BEHAVIOR_SCORE" ;

    /*
    * The index position of the column BEHAVIOR_SCORE in the table.
    */
    public static final int BEHAVIOR_SCORE_IDX = 5 ;

    /**
              * <p> Communication Score.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String COMMUNICATION_SCORE= "COMMUNICATION_SCORE" ;

    /*
    * The index position of the column COMMUNICATION_SCORE in the table.
    */
    public static final int COMMUNICATION_SCORE_IDX = 6 ;

    /**
              * <p> Sociability Score.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String SOCIABILITY_SCORE= "SOCIABILITY_SCORE" ;

    /*
    * The index position of the column SOCIABILITY_SCORE in the table.
    */
    public static final int SOCIABILITY_SCORE_IDX = 7 ;

    /**
              * <p> Total Score.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String TOTAL_SCORE= "TOTAL_SCORE" ;

    /*
    * The index position of the column TOTAL_SCORE in the table.
    */
    public static final int TOTAL_SCORE_IDX = 8 ;

    /**
              * <p> Inputs given by for the ATEC data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String INPUTS_GIVEN_BY= "INPUTS_GIVEN_BY" ;

    /*
    * The index position of the column INPUTS_GIVEN_BY in the table.
    */
    public static final int INPUTS_GIVEN_BY_IDX = 9 ;

}
