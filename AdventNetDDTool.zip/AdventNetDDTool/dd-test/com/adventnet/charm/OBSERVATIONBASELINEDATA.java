package com.adventnet.charm;

/** <p> Description of the table <code>ObservationBaselineData</code>.
 *  Column Name and Table Name of  database table  <code>ObservationBaselineData</code> is mapped
 * as constants in this util.</p> 
  Baseline data of an Observation. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #OBSERVATION_MAP_ID}
  * <li> {@link #BASELINE_DATE}
  * </ul>
 */
 
public final class OBSERVATIONBASELINEDATA
{
    private OBSERVATIONBASELINEDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ObservationBaselineData" ;
    /**
              * <p> Identifier of Patient to Observation Map.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OBSERVATION_MAP_ID= "OBSERVATION_MAP_ID" ;

    /*
    * The index position of the column OBSERVATION_MAP_ID in the table.
    */
    public static final int OBSERVATION_MAP_ID_IDX = 1 ;

    /**
              * <p> Date at which the baseline entry is recorded.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BASELINE_DATE= "BASELINE_DATE" ;

    /*
    * The index position of the column BASELINE_DATE in the table.
    */
    public static final int BASELINE_DATE_IDX = 2 ;

    /**
              * <p> Baseline data.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String BASELINE_ENTRY= "BASELINE_ENTRY" ;

    /*
    * The index position of the column BASELINE_ENTRY in the table.
    */
    public static final int BASELINE_ENTRY_IDX = 3 ;

}
