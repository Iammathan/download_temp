package com.adventnet.charm;

/** <p> Description of the table <code>RefundDetails</code>.
 *  Column Name and Table Name of  database table  <code>RefundDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REFUND_ID}
  * </ul>
 */
 
public final class REFUNDDETAILS
{
    private REFUNDDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RefundDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFUND_ID= "REFUND_ID" ;

    /*
    * The index position of the column REFUND_ID in the table.
    */
    public static final int REFUND_ID_IDX = 1 ;

    /**
              * <p> Date of Refund.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REFUND_DATE= "REFUND_DATE" ;

    /*
    * The index position of the column REFUND_DATE in the table.
    */
    public static final int REFUND_DATE_IDX = 2 ;

    /**
              * <p> Added time of refund.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 3 ;

    /**
              * <p> Latest updated time of refund.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String UPDATED_TIME= "UPDATED_TIME" ;

    /*
    * The index position of the column UPDATED_TIME in the table.
    */
    public static final int UPDATED_TIME_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PAYMENT_METHOD= "PAYMENT_METHOD" ;

    /*
    * The index position of the column PAYMENT_METHOD in the table.
    */
    public static final int PAYMENT_METHOD_IDX = 5 ;

    /**
              * <p> REFUND AMOUNT for Receipt.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AMOUNT= "AMOUNT" ;

    /*
    * The index position of the column AMOUNT in the table.
    */
    public static final int AMOUNT_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REFERENCE= "REFERENCE" ;

    /*
    * The index position of the column REFERENCE in the table.
    */
    public static final int REFERENCE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 10 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REFUNDED_BY= "REFUNDED_BY" ;

    /*
    * The index position of the column REFUNDED_BY in the table.
    */
    public static final int REFUNDED_BY_IDX = 11 ;

    /**
              * <p> Descibes to whom refund is done, whether to patient or insurance.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REFUND_TO= "REFUND_TO" ;

    /*
    * The index position of the column REFUND_TO in the table.
    */
    public static final int REFUND_TO_IDX = 12 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 13 ;

    /**
              * <p> This column specifies whether the refund is hard-closed or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>FALSE</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_HARD_CLOSED= "IS_HARD_CLOSED" ;

    /*
    * The index position of the column IS_HARD_CLOSED in the table.
    */
    public static final int IS_HARD_CLOSED_IDX = 14 ;

}
