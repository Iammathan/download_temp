package com.adventnet.charm;

/** <p> Description of the table <code>EDI277CAReportDetails</code>.
 *  Column Name and Table Name of  database table  <code>EDI277CAReportDetails</code> is mapped
 * as constants in this util.</p> 
  This table stores the details of each 277CA (Claim Acknowledgment) report such as Source,
		    Receiver, Provider and Patient along with status detail stored in STCSegments table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EDI_277CA_REPORT_DETAIL_ID}
  * </ul>
 */
 
public final class EDI277CAREPORTDETAILS
{
    private EDI277CAREPORTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EDI277CAReportDetails" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EDI_277CA_REPORT_DETAIL_ID= "EDI_277CA_REPORT_DETAIL_ID" ;

    /*
    * The index position of the column EDI_277CA_REPORT_DETAIL_ID in the table.
    */
    public static final int EDI_277CA_REPORT_DETAIL_ID_IDX = 1 ;

    /**
              * <p> PK of EDI277CAReportFiles master table in which 277CA file detail is saved.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EDI_277CA_REPORT_FILE_ID= "EDI_277CA_REPORT_FILE_ID" ;

    /*
    * The index position of the column EDI_277CA_REPORT_FILE_ID in the table.
    */
    public static final int EDI_277CA_REPORT_FILE_ID_IDX = 2 ;

    /**
              * <p> PK of the EDIEntityDetail table which contains report source information.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SOURCE_ENTITY_ID= "SOURCE_ENTITY_ID" ;

    /*
    * The index position of the column SOURCE_ENTITY_ID in the table.
    */
    public static final int SOURCE_ENTITY_ID_IDX = 3 ;

    /**
              * <p> PK of the EDIEntityDetail table which contains report receiver a.k.a submitter information.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SUBMITTER_ENTITY_ID= "SUBMITTER_ENTITY_ID" ;

    /*
    * The index position of the column SUBMITTER_ENTITY_ID in the table.
    */
    public static final int SUBMITTER_ENTITY_ID_IDX = 4 ;

    /**
              * <p> PK of the EDIEntityDetail table which contains report billing provider detail.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROVIDER_ENTITY_ID= "PROVIDER_ENTITY_ID" ;

    /*
    * The index position of the column PROVIDER_ENTITY_ID in the table.
    */
    public static final int PROVIDER_ENTITY_ID_IDX = 5 ;

    /**
              * <p> PK of the EDIEntityDetail table which contains patient detail.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ENTITY_ID= "PATIENT_ENTITY_ID" ;

    /*
    * The index position of the column PATIENT_ENTITY_ID in the table.
    */
    public static final int PATIENT_ENTITY_ID_IDX = 6 ;

    /**
              * <p> It is a unique number for this claim and 277CA report in they source system,
				    i.e, Clearinghouse - 277CA :: 2200A - TRN02.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SOURCE_RECEIPT_CONTROL_ID= "SOURCE_RECEIPT_CONTROL_ID" ;

    /*
    * The index position of the column SOURCE_RECEIPT_CONTROL_ID in the table.
    */
    public static final int SOURCE_RECEIPT_CONTROL_ID_IDX = 7 ;

    /**
              * <p> This is the BHT03 value of an e-claim transaction ansi message (837P)
				    submitted from ChARM system - 277CA :: 2200B - TRN02.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHARM_ECLAIM_TXN_BATCH_ID= "CHARM_ECLAIM_TXN_BATCH_ID" ;

    /*
    * The index position of the column CHARM_ECLAIM_TXN_BATCH_ID in the table.
    */
    public static final int CHARM_ECLAIM_TXN_BATCH_ID_IDX = 8 ;

    /**
              * <p> Patient's Record ID (or) Account # - 277CA :: 2200D - TRN02.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_RECORD_ID= "PATIENT_RECORD_ID" ;

    /*
    * The index position of the column PATIENT_RECORD_ID in the table.
    */
    public static final int PATIENT_RECORD_ID_IDX = 9 ;

    /**
              * <p> Payer Claim Control Number returedn in - 277CA :: 2200D - TRN02.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYER_CLAIM_CONTROL_ID= "PAYER_CLAIM_CONTROL_ID" ;

    /*
    * The index position of the column PAYER_CLAIM_CONTROL_ID in the table.
    */
    public static final int PAYER_CLAIM_CONTROL_ID_IDX = 10 ;

    /**
              * <p> Unique Identifier of this claim in ChARM (i.e, ClaimCompleteDetails.CLAIM_ID / RCMClaimCompleteDetails.CLAIM_ID).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CHARM_CLAIM_TRACKING_ID= "CHARM_CLAIM_TRACKING_ID" ;

    /*
    * The index position of the column CHARM_CLAIM_TRACKING_ID in the table.
    */
    public static final int CHARM_CLAIM_TRACKING_ID_IDX = 11 ;

    /**
              * <p> Date of Service of a specific claim.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_SERVICE= "DATE_OF_SERVICE" ;

    /*
    * The index position of the column DATE_OF_SERVICE in the table.
    */
    public static final int DATE_OF_SERVICE_IDX = 12 ;

    /**
              * <p> Date on which clearinghouse/source received the claim file.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_RECEIVED_DATE= "CLAIM_RECEIVED_DATE" ;

    /*
    * The index position of the column CLAIM_RECEIVED_DATE in the table.
    */
    public static final int CLAIM_RECEIVED_DATE_IDX = 13 ;

    /**
              * <p> Date on which clearinghouse/source processed the claim file.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_PROCESSED_DATE= "CLAIM_PROCESSED_DATE" ;

    /*
    * The index position of the column CLAIM_PROCESSED_DATE in the table.
    */
    public static final int CLAIM_PROCESSED_DATE_IDX = 14 ;

    /**
              * <p> Claim ID - PK of the ClaimCompleteDetails(or, RCMClaimCompleteDetails) table which has the claim related detail.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID= "CLAIM_ID" ;

    /*
    * The index position of the column CLAIM_ID in the table.
    */
    public static final int CLAIM_ID_IDX = 15 ;

    /**
              * <p> STC01-1 Or STC10-1 Or STC11-1 - Claim Status (WQ|U|ONLY_ERRORS|ONLY_WARNINGS|BOTH_ERRORS_WARNINGS) .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CLAIM_STATUS= "CLAIM_STATUS" ;

    /*
    * The index position of the column CLAIM_STATUS in the table.
    */
    public static final int CLAIM_STATUS_IDX = 16 ;

    /**
              * <p> Denotes whether this claim was processed by a MBP service or in EHR by the practice itself.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_RCM_CLAIM= "IS_RCM_CLAIM" ;

    /*
    * The index position of the column IS_RCM_CLAIM in the table.
    */
    public static final int IS_RCM_CLAIM_IDX = 17 ;

}
