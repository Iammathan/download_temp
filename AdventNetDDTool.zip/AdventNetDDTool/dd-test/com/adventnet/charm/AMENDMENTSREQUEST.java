package com.adventnet.charm;

/** <p> Description of the table <code>AmendmentsRequest</code>.
 *  Column Name and Table Name of  database table  <code>AmendmentsRequest</code> is mapped
 * as constants in this util.</p> 
  patient/provider or organisation requested amendments details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REQUEST_ID}
  * </ul>
 */
 
public final class AMENDMENTSREQUEST
{
    private AMENDMENTSREQUEST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AmendmentsRequest" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUEST_ID= "REQUEST_ID" ;

    /*
    * The index position of the column REQUEST_ID in the table.
    */
    public static final int REQUEST_ID_IDX = 1 ;

    /**
              * <p> patient mapping identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of the diagnosis.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String AMENDMENTS_REQUEST= "AMENDMENTS_REQUEST" ;

    /*
    * The index position of the column AMENDMENTS_REQUEST in the table.
    */
    public static final int AMENDMENTS_REQUEST_IDX = 3 ;

    /**
              * <p> affected Amendments section name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AFFECTED_SECTION= "AFFECTED_SECTION" ;

    /*
    * The index position of the column AFFECTED_SECTION in the table.
    */
    public static final int AFFECTED_SECTION_IDX = 4 ;

    /**
              * <p> time at which the amendments is entered.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REQUESTED_TIME= "REQUESTED_TIME" ;

    /*
    * The index position of the column REQUESTED_TIME in the table.
    */
    public static final int REQUESTED_TIME_IDX = 5 ;

    /**
              * <p> time at which the amendments is processed.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROCESSED_TIME= "PROCESSED_TIME" ;

    /*
    * The index position of the column PROCESSED_TIME in the table.
    */
    public static final int PROCESSED_TIME_IDX = 6 ;

    /**
              * <p> Current Status of the amendments could be "YET TO PROCESS","ACCEPTED" or "DENIED".</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 7 ;

}
