package com.adventnet.charm;

/** <p> Description of the table <code>ClaimStatusList</code>.
 *  Column Name and Table Name of  database table  <code>ClaimStatusList</code> is mapped
 * as constants in this util.</p> 
  Table to add User defined payment methods. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_STATUS_ID}
  * </ul>
 */
 
public final class CLAIMSTATUSLIST
{
    private CLAIMSTATUSLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ClaimStatusList" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_STATUS_ID= "CLAIM_STATUS_ID" ;

    /*
    * The index position of the column CLAIM_STATUS_ID in the table.
    */
    public static final int CLAIM_STATUS_ID_IDX = 1 ;

    /**
              * <p> Write-off type name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CLAIM_STATUS_NAME= "CLAIM_STATUS_NAME" ;

    /*
    * The index position of the column CLAIM_STATUS_NAME in the table.
    */
    public static final int CLAIM_STATUS_NAME_IDX = 2 ;

    /**
              * <p> Whether the Payment method sets default.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_SYSTEM_GENERATED= "IS_SYSTEM_GENERATED" ;

    /*
    * The index position of the column IS_SYSTEM_GENERATED in the table.
    */
    public static final int IS_SYSTEM_GENERATED_IDX = 3 ;

}
