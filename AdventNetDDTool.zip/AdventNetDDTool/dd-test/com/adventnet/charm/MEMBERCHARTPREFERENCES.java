package com.adventnet.charm;

/** <p> Description of the table <code>MemberChartPreferences</code>.
 *  Column Name and Table Name of  database table  <code>MemberChartPreferences</code> is mapped
 * as constants in this util.</p> 
  To store Member related chart preferences. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEMBER_CHART_PREFERENCE_ID}
  * </ul>
 */
 
public final class MEMBERCHARTPREFERENCES
{
    private MEMBERCHARTPREFERENCES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MemberChartPreferences" ;
    /**
              * <p> Unique identifier for MemberChartPreferences.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_CHART_PREFERENCE_ID= "MEMBER_CHART_PREFERENCE_ID" ;

    /*
    * The index position of the column MEMBER_CHART_PREFERENCE_ID in the table.
    */
    public static final int MEMBER_CHART_PREFERENCE_ID_IDX = 1 ;

    /**
              * <p> Member Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 2 ;

    /**
              * <p> List of chart Types Quick,Brief,Comprehensive or SOAP selected for a member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CHART_TYPES= "CHART_TYPES" ;

    /*
    * The index position of the column CHART_TYPES in the table.
    */
    public static final int CHART_TYPES_IDX = 3 ;

    /**
              * <p> From the selected chart types in CHART_TYPES column, make any one as default.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DEFAULT_CHART_TYPE= "DEFAULT_CHART_TYPE" ;

    /*
    * The index position of the column DEFAULT_CHART_TYPE in the table.
    */
    public static final int DEFAULT_CHART_TYPE_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String SHARE_VISIT_SUMMARY_TO_PATIENT= "SHARE_VISIT_SUMMARY_TO_PATIENT" ;

    /*
    * The index position of the column SHARE_VISIT_SUMMARY_TO_PATIENT in the table.
    */
    public static final int SHARE_VISIT_SUMMARY_TO_PATIENT_IDX = 5 ;

    /**
              * <p> Configurable options at provider level for encounter sections.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHART_OPTIONS= "CHART_OPTIONS" ;

    /*
    * The index position of the column CHART_OPTIONS in the table.
    */
    public static final int CHART_OPTIONS_IDX = 6 ;

    /**
              * <p> Co-signer Member Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String COSIGNER= "COSIGNER" ;

    /*
    * The index position of the column COSIGNER in the table.
    */
    public static final int COSIGNER_IDX = 7 ;

}
