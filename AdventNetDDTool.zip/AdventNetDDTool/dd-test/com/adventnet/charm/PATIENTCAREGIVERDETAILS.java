package com.adventnet.charm;

/** <p> Description of the table <code>PatientCareGiverDetails</code>.
 *  Column Name and Table Name of  database table  <code>PatientCareGiverDetails</code> is mapped
 * as constants in this util.</p> 
  Patient care givers and contact map. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CAREGIVER_ID}
  * </ul>
 */
 
public final class PATIENTCAREGIVERDETAILS
{
    private PATIENTCAREGIVERDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientCareGiverDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CAREGIVER_ID= "CAREGIVER_ID" ;

    /*
    * The index position of the column CAREGIVER_ID in the table.
    */
    public static final int CAREGIVER_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Type Of Caregiver.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * </ul>
                         */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 3 ;

    /**
              * <p> First name of the Caregiver.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 4 ;

    /**
              * <p> Middle name of the Caregiver.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIDDLE_NAME= "MIDDLE_NAME" ;

    /*
    * The index position of the column MIDDLE_NAME in the table.
    */
    public static final int MIDDLE_NAME_IDX = 5 ;

    /**
              * <p> Last name of the Caregiver.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 6 ;

    /**
              * <p> Date of Birth of Patient.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_BIRTH= "DATE_OF_BIRTH" ;

    /*
    * The index position of the column DATE_OF_BIRTH in the table.
    */
    public static final int DATE_OF_BIRTH_IDX = 7 ;

    /**
              * <p> Gender of Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>male</code></li>
              * <li><code>female</code></li>
              * <li><code>unknown</code></li>
              * <li><code>other</code></li>
              * </ul>
                         */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 8 ;

    /**
              * <p> Social security number.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SSN= "SSN" ;

    /*
    * The index position of the column SSN in the table.
    */
    public static final int SSN_IDX = 9 ;

    /**
              * <p> Caregiver's relationship with the patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RELATIONSHIP= "RELATIONSHIP" ;

    /*
    * The index position of the column RELATIONSHIP in the table.
    */
    public static final int RELATIONSHIP_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SAME_AS_PATIENT_CONTACT= "SAME_AS_PATIENT_CONTACT" ;

    /*
    * The index position of the column SAME_AS_PATIENT_CONTACT in the table.
    */
    public static final int SAME_AS_PATIENT_CONTACT_IDX = 11 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 12 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 13 ;

}
