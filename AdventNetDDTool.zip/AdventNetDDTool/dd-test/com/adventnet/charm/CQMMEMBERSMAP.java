package com.adventnet.charm;

/** <p> Description of the table <code>CQMMembersMap</code>.
 *  Column Name and Table Name of  database table  <code>CQMMembersMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between CQM and members. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CQM_MEMBER_MAP_ID}
  * </ul>
 */
 
public final class CQMMEMBERSMAP
{
    private CQMMEMBERSMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CQMMembersMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CQM_MEMBER_MAP_ID= "CQM_MEMBER_MAP_ID" ;

    /*
    * The index position of the column CQM_MEMBER_MAP_ID in the table.
    */
    public static final int CQM_MEMBER_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of the CQM.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEASURE_ID= "MEASURE_ID" ;

    /*
    * The index position of the column MEASURE_ID in the table.
    */
    public static final int MEASURE_ID_IDX = 2 ;

    /**
              * <p> Identifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

}
