package com.adventnet.charm;

/** <p> Description of the table <code>DirectAddressDirectory</code>.
 *  Column Name and Table Name of  database table  <code>DirectAddressDirectory</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ADDRESS_ID}
  * </ul>
 */
 
public final class DIRECTADDRESSDIRECTORY
{
    private DIRECTADDRESSDIRECTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DirectAddressDirectory" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDRESS_ID= "ADDRESS_ID" ;

    /*
    * The index position of the column ADDRESS_ID in the table.
    */
    public static final int ADDRESS_ID_IDX = 1 ;

    /**
              * <p> User space of the user .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String USER_SPACE= "USER_SPACE" ;

    /*
    * The index position of the column USER_SPACE in the table.
    */
    public static final int USER_SPACE_IDX = 2 ;

    /**
              * <p> Idendifier of the member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 3 ;

    /**
              * <p> Direct mail Id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DIRECT_EMAILID= "DIRECT_EMAILID" ;

    /*
    * The index position of the column DIRECT_EMAILID in the table.
    */
    public static final int DIRECT_EMAILID_IDX = 4 ;

}
