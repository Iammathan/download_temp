package com.adventnet.charm;

/** <p> Description of the table <code>CCDAMedicationMap</code>.
 *  Column Name and Table Name of  database table  <code>CCDAMedicationMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MEDICATION_WIDGET_ENTRIES_ID}
  * </ul>
 */
 
public final class CCDAMEDICATIONMAP
{
    private CCDAMEDICATIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CCDAMedicationMap" ;
    /**
              * <p> PK of MedicationWidgetEntries.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICATION_WIDGET_ENTRIES_ID= "MEDICATION_WIDGET_ENTRIES_ID" ;

    /*
    * The index position of the column MEDICATION_WIDGET_ENTRIES_ID in the table.
    */
    public static final int MEDICATION_WIDGET_ENTRIES_ID_IDX = 1 ;

    /**
              * <p> PK of UploadedFiles.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 2 ;

}
