package com.adventnet.charm;

/** <p> Description of the table <code>AmendmentsRequestInfo</code>.
 *  Column Name and Table Name of  database table  <code>AmendmentsRequestInfo</code> is mapped
 * as constants in this util.</p> 
  patient/provider or organisation requested amendments details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REQUEST_ID}
  * </ul>
 */
 
public final class AMENDMENTSREQUESTINFO
{
    private AMENDMENTSREQUESTINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AmendmentsRequestInfo" ;
    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REQUEST_INFO_ID= "REQUEST_INFO_ID" ;

    /*
    * The index position of the column REQUEST_INFO_ID in the table.
    */
    public static final int REQUEST_INFO_ID_IDX = 1 ;

    /**
              * <p> Request id of AmendmentsRequest table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REQUEST_ID= "REQUEST_ID" ;

    /*
    * The index position of the column REQUEST_ID in the table.
    */
    public static final int REQUEST_ID_IDX = 2 ;

    /**
              * <p> Information of amendments.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String AMENDMENTS_DETAILS= "AMENDMENTS_DETAILS" ;

    /*
    * The index position of the column AMENDMENTS_DETAILS in the table.
    */
    public static final int AMENDMENTS_DETAILS_IDX = 3 ;

    /**
              * <p> Existing amendments location details.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LOCATION_OF_AMENDMENTS= "LOCATION_OF_AMENDMENTS" ;

    /*
    * The index position of the column LOCATION_OF_AMENDMENTS in the table.
    */
    public static final int LOCATION_OF_AMENDMENTS_IDX = 4 ;

    /**
              * <p> Identifier of the diagnosis.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SOURCE_OF_AMENDMENTS= "SOURCE_OF_AMENDMENTS" ;

    /*
    * The index position of the column SOURCE_OF_AMENDMENTS in the table.
    */
    public static final int SOURCE_OF_AMENDMENTS_IDX = 5 ;

    /**
              * <p> time at which the amendments is modified.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 6 ;

    /**
              * <p> Amendments accpeted/denied time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPENDED_TIME= "APPENDED_TIME" ;

    /*
    * The index position of the column APPENDED_TIME in the table.
    */
    public static final int APPENDED_TIME_IDX = 7 ;

}
