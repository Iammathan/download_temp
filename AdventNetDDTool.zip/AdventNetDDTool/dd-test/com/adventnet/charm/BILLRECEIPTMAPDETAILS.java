package com.adventnet.charm;

/** <p> Description of the table <code>BillReceiptMapDetails</code>.
 *  Column Name and Table Name of  database table  <code>BillReceiptMapDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_RECEIPT_ID}
  * </ul>
 */
 
public final class BILLRECEIPTMAPDETAILS
{
    private BILLRECEIPTMAPDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillReceiptMapDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_RECEIPT_ID= "BILL_RECEIPT_ID" ;

    /*
    * The index position of the column BILL_RECEIPT_ID in the table.
    */
    public static final int BILL_RECEIPT_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ID= "BILL_ID" ;

    /*
    * The index position of the column BILL_ID in the table.
    */
    public static final int BILL_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 3 ;

    /**
              * <p> Amount Paid towards clearing outstanding/due for a bill.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLEARED_BILL_AMOUNT= "CLEARED_BILL_AMOUNT" ;

    /*
    * The index position of the column CLEARED_BILL_AMOUNT in the table.
    */
    public static final int CLEARED_BILL_AMOUNT_IDX = 4 ;

    /**
              * <p> Added time of payment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE= "DATE" ;

    /*
    * The index position of the column DATE in the table.
    */
    public static final int DATE_IDX = 5 ;

    /**
              * <p> Latest updated time of payment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PAYMENT_UPDATED_TIME= "PAYMENT_UPDATED_TIME" ;

    /*
    * The index position of the column PAYMENT_UPDATED_TIME in the table.
    */
    public static final int PAYMENT_UPDATED_TIME_IDX = 6 ;

    /**
              * <p> Type of clearing i.e whether it is deposit or payment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLEARING_TYPE= "CLEARING_TYPE" ;

    /*
    * The index position of the column CLEARING_TYPE in the table.
    */
    public static final int CLEARING_TYPE_IDX = 7 ;

    /**
              * <p> Descibes to whom payment is done, whether for Invoice, or for Claim.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PAYMENT_TO= "PAYMENT_TO" ;

    /*
    * The index position of the column PAYMENT_TO in the table.
    */
    public static final int PAYMENT_TO_IDX = 8 ;

    /**
              * <p> Pk of BillTransactionDetails table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_TXN_ID= "BILL_TXN_ID" ;

    /*
    * The index position of the column BILL_TXN_ID in the table.
    */
    public static final int BILL_TXN_ID_IDX = 9 ;

    /**
              * <p> Indicates whether payment is deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 10 ;

    /**
              * <p> Identifier of deleted payment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REFERENCE_PAYMENT_ID= "REFERENCE_PAYMENT_ID" ;

    /*
    * The index position of the column REFERENCE_PAYMENT_ID in the table.
    */
    public static final int REFERENCE_PAYMENT_ID_IDX = 11 ;

    /**
              * <p> Member ID of user who applied the Payment to Invoice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String APPLIED_MEMBER_ID= "APPLIED_MEMBER_ID" ;

    /*
    * The index position of the column APPLIED_MEMBER_ID in the table.
    */
    public static final int APPLIED_MEMBER_ID_IDX = 12 ;

    /**
              * <p> Name of user who applied the Payment to Invoice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APPLIED_MEMBER_NAME= "APPLIED_MEMBER_NAME" ;

    /*
    * The index position of the column APPLIED_MEMBER_NAME in the table.
    */
    public static final int APPLIED_MEMBER_NAME_IDX = 13 ;

    /**
              * <p> This column specifies whether the payment is hard-closed or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>FALSE</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>FALSE</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_HARD_CLOSED= "IS_HARD_CLOSED" ;

    /*
    * The index position of the column IS_HARD_CLOSED in the table.
    */
    public static final int IS_HARD_CLOSED_IDX = 14 ;

}
