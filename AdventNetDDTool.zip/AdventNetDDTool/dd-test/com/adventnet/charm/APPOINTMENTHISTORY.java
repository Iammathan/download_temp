package com.adventnet.charm;

/** <p> Description of the table <code>AppointmentHistory</code>.
 *  Column Name and Table Name of  database table  <code>AppointmentHistory</code> is mapped
 * as constants in this util.</p> 
  All appointments will be managed in this physician user space table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #APPOINTMENT_ID}
  * </ul>
 */
 
public final class APPOINTMENTHISTORY
{
    private APPOINTMENTHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AppointmentHistory" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Confirmed Date by physician.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_DATE= "APPOINTMENT_DATE" ;

    /*
    * The index position of the column APPOINTMENT_DATE in the table.
    */
    public static final int APPOINTMENT_DATE_IDX = 3 ;

    /**
              * <p> start time of the appointment in UTC/GMT.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String START_TIME_UTC= "START_TIME_UTC" ;

    /*
    * The index position of the column START_TIME_UTC in the table.
    */
    public static final int START_TIME_UTC_IDX = 4 ;

    /**
              * <p> Confirmed Date by physician.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_END_TIME= "APPOINTMENT_END_TIME" ;

    /*
    * The index position of the column APPOINTMENT_END_TIME in the table.
    */
    public static final int APPOINTMENT_END_TIME_IDX = 5 ;

    /**
              * <p> end time of the appointment in UTC/GMT.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String END_TIME_UTC= "END_TIME_UTC" ;

    /*
    * The index position of the column END_TIME_UTC in the table.
    */
    public static final int END_TIME_UTC_IDX = 6 ;

    /**
              * <p> Identifier of Timezone to which the user belongs to.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>GMT</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>GMT</code>" , 
       * will be taken.<br>
                         */
    public static final String TIMEZONE= "TIMEZONE" ;

    /*
    * The index position of the column TIMEZONE in the table.
    */
    public static final int TIMEZONE_IDX = 7 ;

    /**
              * <p> Appointment Type selected by patient(ex : phone call / In person).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APPOINTMENT_TYPE= "APPOINTMENT_TYPE" ;

    /*
    * The index position of the column APPOINTMENT_TYPE in the table.
    */
    public static final int APPOINTMENT_TYPE_IDX = 8 ;

    /**
              * <p> Denote current status of the appointment. Foreign key from EncounterWorkFlow.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STATUS_ID= "STATUS_ID" ;

    /*
    * The index position of the column STATUS_ID in the table.
    */
    public static final int STATUS_ID_IDX = 9 ;

    /**
              * <p> reminder will be sent by a mail or popup.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REMINDER_TYPE= "REMINDER_TYPE" ;

    /*
    * The index position of the column REMINDER_TYPE in the table.
    */
    public static final int REMINDER_TYPE_IDX = 10 ;

    /**
              * <p> Physician remarks will be stored for this appointment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PHYSICIAN_REMARK= "PHYSICIAN_REMARK" ;

    /*
    * The index position of the column PHYSICIAN_REMARK in the table.
    */
    public static final int PHYSICIAN_REMARK_IDX = 11 ;

    /**
              * <p> Patient remarks will be stored for this appointment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_REMARK= "PATIENT_REMARK" ;

    /*
    * The index position of the column PATIENT_REMARK in the table.
    */
    public static final int PATIENT_REMARK_IDX = 12 ;

    /**
              * <p>  Reason for this appointment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REASON= "REASON" ;

    /*
    * The index position of the column REASON in the table.
    */
    public static final int REASON_IDX = 13 ;

    /**
              * <p> Idendifier of the physician.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PHYSICIAN_ID= "PHYSICIAN_ID" ;

    /*
    * The index position of the column PHYSICIAN_ID in the table.
    */
    public static final int PHYSICIAN_ID_IDX = 14 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 15 ;

    /**
              * <p> Denote type of the appointment.Foreign key from EncounterTypes table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENCOUNTER_TYPE_ID= "ENCOUNTER_TYPE_ID" ;

    /*
    * The index position of the column ENCOUNTER_TYPE_ID in the table.
    */
    public static final int ENCOUNTER_TYPE_ID_IDX = 16 ;

    /**
              * <p> Cancelled or Rescheduled date of Appointment.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MODIFIED_DATE= "MODIFIED_DATE" ;

    /*
    * The index position of the column MODIFIED_DATE in the table.
    */
    public static final int MODIFIED_DATE_IDX = 17 ;

    /**
              * <p> Appointment Request Id for reference.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REQUEST_ID= "REQUEST_ID" ;

    /*
    * The index position of the column REQUEST_ID in the table.
    */
    public static final int REQUEST_ID_IDX = 18 ;

    /**
              * <p> Time of Change.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String STATUS_CHANGE_TIME= "STATUS_CHANGE_TIME" ;

    /*
    * The index position of the column STATUS_CHANGE_TIME in the table.
    */
    public static final int STATUS_CHANGE_TIME_IDX = 19 ;

    /**
              * <p> Member ID who booked the appointment (nullable if booked by patient).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BOOKED_BY= "BOOKED_BY" ;

    /*
    * The index position of the column BOOKED_BY in the table.
    */
    public static final int BOOKED_BY_IDX = 20 ;

    /**
              * <p> Booked Time of the appointment.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BOOKED_TIME= "BOOKED_TIME" ;

    /*
    * The index position of the column BOOKED_TIME in the table.
    */
    public static final int BOOKED_TIME_IDX = 21 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 22 ;

    /**
              * <p> Member ID who recently modified appointment .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_BY= "LAST_MODIFIED_BY" ;

    /*
    * The index position of the column LAST_MODIFIED_BY in the table.
    */
    public static final int LAST_MODIFIED_BY_IDX = 23 ;

    /**
              * <p> Source from where the appointment is confirmed.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String SOURCE= "SOURCE" ;

    /*
    * The index position of the column SOURCE in the table.
    */
    public static final int SOURCE_IDX = 24 ;

    /**
              * <p> Token number of patient to consult doctor.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TOKEN_NO= "TOKEN_NO" ;

    /*
    * The index position of the column TOKEN_NO in the table.
    */
    public static final int TOKEN_NO_IDX = 25 ;

    /**
              * <p> Unique Identifier of Receipt.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_ID= "RECEIPT_ID" ;

    /*
    * The index position of the column RECEIPT_ID in the table.
    */
    public static final int RECEIPT_ID_IDX = 26 ;

    /**
              * <p> To Display Receipt Number in UI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RECEIPT_DISPLAY_ID= "RECEIPT_DISPLAY_ID" ;

    /*
    * The index position of the column RECEIPT_DISPLAY_ID in the table.
    */
    public static final int RECEIPT_DISPLAY_ID_IDX = 27 ;

    /**
              * <p> Amount Paid.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RECEIPT_AMOUNT= "RECEIPT_AMOUNT" ;

    /*
    * The index position of the column RECEIPT_AMOUNT in the table.
    */
    public static final int RECEIPT_AMOUNT_IDX = 28 ;

    /**
              * <p> Stores appt. id of aggregator account in practice and vise versa..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXTERNAL_ID= "EXTERNAL_ID" ;

    /*
    * The index position of the column EXTERNAL_ID in the table.
    */
    public static final int EXTERNAL_ID_IDX = 29 ;

}
