package com.adventnet.charm;

/** <p> Description of the table <code>MerchantAccountInfo</code>.
 *  Column Name and Table Name of  database table  <code>MerchantAccountInfo</code> is mapped
 * as constants in this util.</p> 
  For storing Bluefin/Transfirst/Easypay account details of the user. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MERCHANT_ACCOUNT_ID}
  * </ul>
 */
 
public final class MERCHANTACCOUNTINFO
{
    private MERCHANTACCOUNTINFO()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "MerchantAccountInfo" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MERCHANT_ACCOUNT_ID= "MERCHANT_ACCOUNT_ID" ;

    /*
    * The index position of the column MERCHANT_ACCOUNT_ID in the table.
    */
    public static final int MERCHANT_ACCOUNT_ID_IDX = 1 ;

    /**
              * <p> To group the values under Member/Facility/Practice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 2 ;

    /**
              * <p> Gateway to which this account info can be used..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GATEWAY= "GATEWAY" ;

    /*
    * The index position of the column GATEWAY in the table.
    */
    public static final int GATEWAY_IDX = 3 ;

    /**
              * <p> For easy understaning. Entered by the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TITLE= "TITLE" ;

    /*
    * The index position of the column TITLE in the table.
    */
    public static final int TITLE_IDX = 4 ;

    /**
              * <p> Account Id provided by the merchant to the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCOUNT_ID= "ACCOUNT_ID" ;

    /*
    * The index position of the column ACCOUNT_ID in the table.
    */
    public static final int ACCOUNT_ID_IDX = 5 ;

    /**
              * <p> API Key provided by the merchant to the user.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String API_KEY= "API_KEY" ;

    /*
    * The index position of the column API_KEY in the table.
    */
    public static final int API_KEY_IDX = 6 ;

    /**
              * <p> Used for grouping merchants in Bluefin.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GROUP= "GROUP" ;

    /*
    * The index position of the column GROUP in the table.
    */
    public static final int GROUP_IDX = 7 ;

    /**
              * <p> To map with Member/Facility/Practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROFILE_ID= "PROFILE_ID" ;

    /*
    * The index position of the column PROFILE_ID in the table.
    */
    public static final int PROFILE_ID_IDX = 8 ;

    /**
              * <p> Member whom added this account.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 9 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                     * Default Value is <code>Hashing</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String TOKEN_TYPE= "TOKEN_TYPE" ;

    /*
    * The index position of the column TOKEN_TYPE in the table.
    */
    public static final int TOKEN_TYPE_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXPIRES_IN= "EXPIRES_IN" ;

    /*
    * The index position of the column EXPIRES_IN in the table.
    */
    public static final int EXPIRES_IN_IDX = 11 ;

    /**
              * <p> Secret for server to server calls.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCESS_TOKEN= "ACCESS_TOKEN" ;

    /*
    * The index position of the column ACCESS_TOKEN in the table.
    */
    public static final int ACCESS_TOKEN_IDX = 12 ;

    /**
              * <p> Secret for client side calls.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PUBLIC_TOKEN= "PUBLIC_TOKEN" ;

    /*
    * The index position of the column PUBLIC_TOKEN in the table.
    */
    public static final int PUBLIC_TOKEN_IDX = 13 ;

    /**
              * <p> Secret for client side calls.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REFRESH_TOKEN= "REFRESH_TOKEN" ;

    /*
    * The index position of the column REFRESH_TOKEN in the table.
    */
    public static final int REFRESH_TOKEN_IDX = 14 ;

    /**
              * <p> Profile creation time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME= "TIME" ;

    /*
    * The index position of the column TIME in the table.
    */
    public static final int TIME_IDX = 15 ;

    /**
              * <p> Profile creation time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UPDATED_TIME= "UPDATED_TIME" ;

    /*
    * The index position of the column UPDATED_TIME in the table.
    */
    public static final int UPDATED_TIME_IDX = 16 ;

    /**
              * <p> Description entered by the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 17 ;

    /**
              * <p> To check whether PAX has been enabled.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_PAX_ENABLED= "IS_PAX_ENABLED" ;

    /*
    * The index position of the column IS_PAX_ENABLED in the table.
    */
    public static final int IS_PAX_ENABLED_IDX = 18 ;

    /**
              * <p> For handling delete.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 19 ;

}
