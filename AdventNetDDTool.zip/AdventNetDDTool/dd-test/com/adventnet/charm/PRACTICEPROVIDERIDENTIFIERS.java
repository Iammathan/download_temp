package com.adventnet.charm;

/** <p> Description of the table <code>PracticeProviderIdentifiers</code>.
 *  Column Name and Table Name of  database table  <code>PracticeProviderIdentifiers</code> is mapped
 * as constants in this util.</p> 
  Practice Vs Billing provider Identifies (NPI, TAX_ID) in public space. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_PROVIDER_IDENTIFIER_ID}
  * </ul>
 */
 
public final class PRACTICEPROVIDERIDENTIFIERS
{
    private PRACTICEPROVIDERIDENTIFIERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeProviderIdentifiers" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PROVIDER_IDENTIFIER_ID= "PRACTICE_PROVIDER_IDENTIFIER_ID" ;

    /*
    * The index position of the column PRACTICE_PROVIDER_IDENTIFIER_ID in the table.
    */
    public static final int PRACTICE_PROVIDER_IDENTIFIER_ID_IDX = 1 ;

    /**
              * <p> Practice Space key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Unique ID of the facility in the practice.
                Required if the identifier is specific to this facility alone.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Billing Provider's NPI present in the submitted claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 4 ;

    /**
              * <p> Billing Provider's NPI present in the submitted claim.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TAX_ID= "TAX_ID" ;

    /*
    * The index position of the column TAX_ID in the table.
    */
    public static final int TAX_ID_IDX = 5 ;

    /**
              * <p> Identifier Value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OTHER_PROVIDER_IDENTIFIER= "OTHER_PROVIDER_IDENTIFIER" ;

    /*
    * The index position of the column OTHER_PROVIDER_IDENTIFIER in the table.
    */
    public static final int OTHER_PROVIDER_IDENTIFIER_IDX = 6 ;

    /**
              * <p> Type of the other provider identifier such as
                State License Number, UPIN Number, etc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OTHER_IDENTIFIER_TYPE= "OTHER_IDENTIFIER_TYPE" ;

    /*
    * The index position of the column OTHER_IDENTIFIER_TYPE in the table.
    */
    public static final int OTHER_IDENTIFIER_TYPE_IDX = 7 ;

    /**
              * <p> Stores whether this identifier is used in MBP or EHR or BOTH.</p>
                            * Data Type of this field is <code>TINYINT</code>. <br>
                                          * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String PLATFORM= "PLATFORM" ;

    /*
    * The index position of the column PLATFORM in the table.
    */
    public static final int PLATFORM_IDX = 8 ;

}
