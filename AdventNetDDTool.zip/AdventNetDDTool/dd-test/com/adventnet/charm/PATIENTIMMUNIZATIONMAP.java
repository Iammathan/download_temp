package com.adventnet.charm;

/** <p> Description of the table <code>PatientImmunizationMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientImmunizationMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Immunization. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMMUNIZATION_MAP_ID}
  * </ul>
 */
 
public final class PATIENTIMMUNIZATIONMAP
{
    private PATIENTIMMUNIZATIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientImmunizationMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMMUNIZATION_MAP_ID= "IMMUNIZATION_MAP_ID" ;

    /*
    * The index position of the column IMMUNIZATION_MAP_ID in the table.
    */
    public static final int IMMUNIZATION_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Immunization.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMMUNIZATION_ID= "IMMUNIZATION_ID" ;

    /*
    * The index position of the column IMMUNIZATION_ID in the table.
    */
    public static final int IMMUNIZATION_ID_IDX = 3 ;

}
