package com.adventnet.charm;

/** <p> Description of the table <code>ClaimOtherPayerEOBCPTDtl</code>.
 *  Column Name and Table Name of  database table  <code>ClaimOtherPayerEOBCPTDtl</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLM_OTHER_PAYER_EOB_CPT_ID}
  * </ul>
 */
 
public final class CLAIMOTHERPAYEREOBCPTDTL
{
    private CLAIMOTHERPAYEREOBCPTDTL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ClaimOtherPayerEOBCPTDtl" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLM_OTHER_PAYER_EOB_CPT_ID= "CLM_OTHER_PAYER_EOB_CPT_ID" ;

    /*
    * The index position of the column CLM_OTHER_PAYER_EOB_CPT_ID in the table.
    */
    public static final int CLM_OTHER_PAYER_EOB_CPT_ID_IDX = 1 ;

    /**
              * <p> SAS Key of the ClaimOtherPayerEOBDetail table where the EOB detail is stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CLM_OTHER_PAYER_EOB_ID= "CLM_OTHER_PAYER_EOB_ID" ;

    /*
    * The index position of the column CLM_OTHER_PAYER_EOB_ID in the table.
    */
    public static final int CLM_OTHER_PAYER_EOB_ID_IDX = 2 ;

    /**
              * <p> Procedure/Service Id in this claim for which this table contains the line item payment detail available.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>48</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SUBMITTED_PROCEDURE_CODE= "SUBMITTED_PROCEDURE_CODE" ;

    /*
    * The index position of the column SUBMITTED_PROCEDURE_CODE in the table.
    */
    public static final int SUBMITTED_PROCEDURE_CODE_IDX = 3 ;

    /**
              * <p> Unique key with combination of cpt code and modifiers with ':' separator.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUBMITTED_PROCEDURE_REFERENCE= "SUBMITTED_PROCEDURE_REFERENCE" ;

    /*
    * The index position of the column SUBMITTED_PROCEDURE_REFERENCE in the table.
    */
    public static final int SUBMITTED_PROCEDURE_REFERENCE_IDX = 4 ;

    /**
              * <p> Qualifier of the Procedure/Service Id for which the payer made the payment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                     * Default Value is <code>HC</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_CODE_QUALIFIER= "PAID_PROCEDURE_CODE_QUALIFIER" ;

    /*
    * The index position of the column PAID_PROCEDURE_CODE_QUALIFIER in the table.
    */
    public static final int PAID_PROCEDURE_CODE_QUALIFIER_IDX = 5 ;

    /**
              * <p> Procedure/Service Id for which the payer made the payment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>48</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_CODE= "PAID_PROCEDURE_CODE" ;

    /*
    * The index position of the column PAID_PROCEDURE_CODE in the table.
    */
    public static final int PAID_PROCEDURE_CODE_IDX = 6 ;

    /**
              * <p> 1st modifier for the paid service, if available.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_MODIFIER_1= "PAID_PROCEDURE_MODIFIER_1" ;

    /*
    * The index position of the column PAID_PROCEDURE_MODIFIER_1 in the table.
    */
    public static final int PAID_PROCEDURE_MODIFIER_1_IDX = 7 ;

    /**
              * <p> 2nd modifier for the paid service, if available.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_MODIFIER_2= "PAID_PROCEDURE_MODIFIER_2" ;

    /*
    * The index position of the column PAID_PROCEDURE_MODIFIER_2 in the table.
    */
    public static final int PAID_PROCEDURE_MODIFIER_2_IDX = 8 ;

    /**
              * <p> 3rd modifier for the paid service, if available.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_MODIFIER_3= "PAID_PROCEDURE_MODIFIER_3" ;

    /*
    * The index position of the column PAID_PROCEDURE_MODIFIER_3 in the table.
    */
    public static final int PAID_PROCEDURE_MODIFIER_3_IDX = 9 ;

    /**
              * <p> 4th modifier for the paid service, if available.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_MODIFIER_4= "PAID_PROCEDURE_MODIFIER_4" ;

    /*
    * The index position of the column PAID_PROCEDURE_MODIFIER_4 in the table.
    */
    public static final int PAID_PROCEDURE_MODIFIER_4_IDX = 10 ;

    /**
              * <p> Any additional description given by the payer for the paid service.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>80</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAID_PROCEDURE_DESCRIPTION= "PAID_PROCEDURE_DESCRIPTION" ;

    /*
    * The index position of the column PAID_PROCEDURE_DESCRIPTION in the table.
    */
    public static final int PAID_PROCEDURE_DESCRIPTION_IDX = 11 ;

    /**
              * <p> Number of units of the service for which payment was made.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAID_UNITS_OR_QUANTITY= "PAID_UNITS_OR_QUANTITY" ;

    /*
    * The index position of the column PAID_UNITS_OR_QUANTITY in the table.
    */
    public static final int PAID_UNITS_OR_QUANTITY_IDX = 12 ;

    /**
              * <p> Bundled/Unbundled line number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BUNDLED_UNBUNDLED_LINE_NO= "BUNDLED_UNBUNDLED_LINE_NO" ;

    /*
    * The index position of the column BUNDLED_UNBUNDLED_LINE_NO in the table.
    */
    public static final int BUNDLED_UNBUNDLED_LINE_NO_IDX = 13 ;

    /**
              * <p> Amount paid by payer for this line item after adjudication.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PAYER_PAYMENT= "PAYER_PAYMENT" ;

    /*
    * The index position of the column PAYER_PAYMENT in the table.
    */
    public static final int PAYER_PAYMENT_IDX = 14 ;

    /**
              * <p> Amount which is not covered this insurance for this line item.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NON_COVERED_AMOUNT= "NON_COVERED_AMOUNT" ;

    /*
    * The index position of the column NON_COVERED_AMOUNT in the table.
    */
    public static final int NON_COVERED_AMOUNT_IDX = 15 ;

    /**
              * <p> Patient Liability reported by this insurance after adjudication for this line item.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_LIABILITY= "PATIENT_LIABILITY" ;

    /*
    * The index position of the column PATIENT_LIABILITY in the table.
    */
    public static final int PATIENT_LIABILITY_IDX = 16 ;

}
