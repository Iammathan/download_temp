package com.adventnet.charm;

/** <p> Description of the table <code>PatientHistory</code>.
 *  Column Name and Table Name of  database table  <code>PatientHistory</code> is mapped
 * as constants in this util.</p> 
  used to store history regarding a patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_HISTORY_ID}
  * </ul>
 */
 
public final class PATIENTHISTORY
{
    private PATIENTHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientHistory" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_HISTORY_ID= "PATIENT_HISTORY_ID" ;

    /*
    * The index position of the column PATIENT_HISTORY_ID in the table.
    */
    public static final int PATIENT_HISTORY_ID_IDX = 1 ;

    /**
              * <p> patient id in the practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> History data in html format.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FAMILY_AND_SOCIAL_HISTORY= "FAMILY_AND_SOCIAL_HISTORY" ;

    /*
    * The index position of the column FAMILY_AND_SOCIAL_HISTORY in the table.
    */
    public static final int FAMILY_AND_SOCIAL_HISTORY_IDX = 3 ;

    /**
              * <p> History data in html format.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SOCIAL_HISTORY= "SOCIAL_HISTORY" ;

    /*
    * The index position of the column SOCIAL_HISTORY in the table.
    */
    public static final int SOCIAL_HISTORY_IDX = 4 ;

    /**
              * <p> History data in html format.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAST_MEDICAL_HISTORY= "PAST_MEDICAL_HISTORY" ;

    /*
    * The index position of the column PAST_MEDICAL_HISTORY in the table.
    */
    public static final int PAST_MEDICAL_HISTORY_IDX = 5 ;

}
