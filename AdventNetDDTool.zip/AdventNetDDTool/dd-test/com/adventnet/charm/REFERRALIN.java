package com.adventnet.charm;

/** <p> Description of the table <code>ReferralIn</code>.
 *  Column Name and Table Name of  database table  <code>ReferralIn</code> is mapped
 * as constants in this util.</p> 
  Referral IN configuration. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REF_IN_ID}
  * </ul>
 */
 
public final class REFERRALIN
{
    private REFERRALIN()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ReferralIn" ;
    /**
              * <p> Unique value generator.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_IN_ID= "REF_IN_ID" ;

    /*
    * The index position of the column REF_IN_ID in the table.
    */
    public static final int REF_IN_ID_IDX = 1 ;

    /**
              * <p> Identifier of referring directory(external from member).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_EXTERNAL_MEMBER_ID= "FROM_EXTERNAL_MEMBER_ID" ;

    /*
    * The index position of the column FROM_EXTERNAL_MEMBER_ID in the table.
    */
    public static final int FROM_EXTERNAL_MEMBER_ID_IDX = 2 ;

    /**
              * <p> Identifier of practice member(internal from member).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_INTERNAL_MEMBER_ID= "FROM_INTERNAL_MEMBER_ID" ;

    /*
    * The index position of the column FROM_INTERNAL_MEMBER_ID in the table.
    */
    public static final int FROM_INTERNAL_MEMBER_ID_IDX = 3 ;

    /**
              * <p> Identifier of Practice Member(to member).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_MEMBER_ID= "TO_MEMBER_ID" ;

    /*
    * The index position of the column TO_MEMBER_ID in the table.
    */
    public static final int TO_MEMBER_ID_IDX = 4 ;

    /**
              * <p> Identifier of Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 5 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 6 ;

    /**
              * <p> Referral Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REFERRAL_DATE= "REFERRAL_DATE" ;

    /*
    * The index position of the column REFERRAL_DATE in the table.
    */
    public static final int REFERRAL_DATE_IDX = 7 ;

    /**
              * <p> Priority of Referral Out.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PRIORITY= "PRIORITY" ;

    /*
    * The index position of the column PRIORITY in the table.
    */
    public static final int PRIORITY_IDX = 8 ;

    /**
              * <p> Reason of Referral Out.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REFERRAL_REASON= "REFERRAL_REASON" ;

    /*
    * The index position of the column REFERRAL_REASON in the table.
    */
    public static final int REFERRAL_REASON_IDX = 9 ;

    /**
              * <p> Referral Date.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REFERRAL_NOTES= "REFERRAL_NOTES" ;

    /*
    * The index position of the column REFERRAL_NOTES in the table.
    */
    public static final int REFERRAL_NOTES_IDX = 10 ;

    /**
              * <p> Response Date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RESPONSE_DATE= "RESPONSE_DATE" ;

    /*
    * The index position of the column RESPONSE_DATE in the table.
    */
    public static final int RESPONSE_DATE_IDX = 11 ;

    /**
              * <p> Response of the Referral Out.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESPONSE_NOTES= "RESPONSE_NOTES" ;

    /*
    * The index position of the column RESPONSE_NOTES in the table.
    */
    public static final int RESPONSE_NOTES_IDX = 12 ;

    /**
              * <p> Request diagnoses of the Referral In.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REQUEST_DIAGNOSES= "REQUEST_DIAGNOSES" ;

    /*
    * The index position of the column REQUEST_DIAGNOSES in the table.
    */
    public static final int REQUEST_DIAGNOSES_IDX = 13 ;

    /**
              * <p> Response diagnoses of the Referral In.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>256</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESPONSE_DIAGNOSES= "RESPONSE_DIAGNOSES" ;

    /*
    * The index position of the column RESPONSE_DIAGNOSES in the table.
    */
    public static final int RESPONSE_DIAGNOSES_IDX = 14 ;

    /**
              * <p> Status of the Response (Pending, Received, Reviewed).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RESPONSE_STATUS= "RESPONSE_STATUS" ;

    /*
    * The index position of the column RESPONSE_STATUS in the table.
    */
    public static final int RESPONSE_STATUS_IDX = 15 ;

    /**
              * <p> Identifier of Encounter.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RELATED_ENCOUNTER_ID= "RELATED_ENCOUNTER_ID" ;

    /*
    * The index position of the column RELATED_ENCOUNTER_ID in the table.
    */
    public static final int RELATED_ENCOUNTER_ID_IDX = 16 ;

    /**
              * <p> Identifier of Referral out.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REF_OUT_ID= "REF_OUT_ID" ;

    /*
    * The index position of the column REF_OUT_ID in the table.
    */
    public static final int REF_OUT_ID_IDX = 17 ;

}
