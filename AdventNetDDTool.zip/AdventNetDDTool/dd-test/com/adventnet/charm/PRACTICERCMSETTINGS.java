package com.adventnet.charm;

/** <p> Description of the table <code>PracticeRCMSettings</code>.
 *  Column Name and Table Name of  database table  <code>PracticeRCMSettings</code> is mapped
 * as constants in this util.</p> 
  RCM configurations for the Practices. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_RCM_ID}
  * </ul>
 */
 
public final class PRACTICERCMSETTINGS
{
    private PRACTICERCMSETTINGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeRCMSettings" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_RCM_ID= "PRACTICE_RCM_ID" ;

    /*
    * The index position of the column PRACTICE_RCM_ID in the table.
    */
    public static final int PRACTICE_RCM_ID_IDX = 1 ;

    /**
              * <p> Id of the Practice used as Practice Space.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 2 ;

    /**
              * <p> Facility Id for the which the RCM is enabled.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Status for the RCM : Active / Inactive.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                     * Default Value is <code>Inactive</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>Inactive</code>" , 
       * will be taken.<br>
                         */
    public static final String RCM_STATUS= "RCM_STATUS" ;

    /*
    * The index position of the column RCM_STATUS in the table.
    */
    public static final int RCM_STATUS_IDX = 4 ;

    /**
              * <p> Decides all the encounters need to be submitted to RCM by default or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PUSH_ALL_ENC_TO_RCM= "PUSH_ALL_ENC_TO_RCM" ;

    /*
    * The index position of the column PUSH_ALL_ENC_TO_RCM in the table.
    */
    public static final int PUSH_ALL_ENC_TO_RCM_IDX = 5 ;

    /**
              * <p> Prefix for the Claim Reference number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                     * Default Value is <code>CLM</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CLAIM_ID_PREFIX= "CLAIM_ID_PREFIX" ;

    /*
    * The index position of the column CLAIM_ID_PREFIX in the table.
    */
    public static final int CLAIM_ID_PREFIX_IDX = 6 ;

    /**
              * <p> Date on which the first entry is made into this table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 7 ;

    /**
              * <p> Date on which the last update is done.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String LAST_UPDATED_TIME= "LAST_UPDATED_TIME" ;

    /*
    * The index position of the column LAST_UPDATED_TIME in the table.
    */
    public static final int LAST_UPDATED_TIME_IDX = 8 ;

    /**
              * <p> for Pratcice Dx poninter Need Or Not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DX_NEEDED_FOR_RCM= "IS_DX_NEEDED_FOR_RCM" ;

    /*
    * The index position of the column IS_DX_NEEDED_FOR_RCM in the table.
    */
    public static final int IS_DX_NEEDED_FOR_RCM_IDX = 9 ;

    /**
              * <p> True for Test Practice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_TEST_SETUP= "IS_TEST_SETUP" ;

    /*
    * The index position of the column IS_TEST_SETUP in the table.
    */
    public static final int IS_TEST_SETUP_IDX = 10 ;

    /**
              * <p> True for Vaccine Claim Enabled Practice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_VACCINE_CLAIM_ELIGIBLE= "IS_VACCINE_CLAIM_ELIGIBLE" ;

    /*
    * The index position of the column IS_VACCINE_CLAIM_ELIGIBLE in the table.
    */
    public static final int IS_VACCINE_CLAIM_ELIGIBLE_IDX = 11 ;

    /**
              * <p> Sale owner of the practice.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SALE_OWNER= "SALE_OWNER" ;

    /*
    * The index position of the column SALE_OWNER in the table.
    */
    public static final int SALE_OWNER_IDX = 12 ;

    /**
              * <p> Decides to allow rcm enabled practice to raise ehr claim.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ENABLE_EHR_CLAIM= "ENABLE_EHR_CLAIM" ;

    /*
    * The index position of the column ENABLE_EHR_CLAIM in the table.
    */
    public static final int ENABLE_EHR_CLAIM_IDX = 13 ;

    /**
              * <p> Denotes if Invoices with EHR Claim can be submitted to RCM.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ENABLE_RCM_SUB_WITH_EHR_CLAIM= "ENABLE_RCM_SUB_WITH_EHR_CLAIM" ;

    /*
    * The index position of the column ENABLE_RCM_SUB_WITH_EHR_CLAIM in the table.
    */
    public static final int ENABLE_RCM_SUB_WITH_EHR_CLAIM_IDX = 14 ;

    /**
              * <p> Decides to allow rcm enabled practice to submit quick rx for pharmacy claim.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ENABLE_PHARMACY_CLAIM= "ENABLE_PHARMACY_CLAIM" ;

    /*
    * The index position of the column ENABLE_PHARMACY_CLAIM in the table.
    */
    public static final int ENABLE_PHARMACY_CLAIM_IDX = 15 ;

    /**
              * <p> Id of RCM Space.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RCM_SPACE_ID= "RCM_SPACE_ID" ;

    /*
    * The index position of the column RCM_SPACE_ID in the table.
    */
    public static final int RCM_SPACE_ID_IDX = 16 ;

    /**
              * <p> Describe it is demo account or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_TEST_ACCOUNT= "IS_TEST_ACCOUNT" ;

    /*
    * The index position of the column IS_TEST_ACCOUNT in the table.
    */
    public static final int IS_TEST_ACCOUNT_IDX = 17 ;

    /**
              * <p> Describe it is Mail need to Sent or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String EXCLUDE_FROM_MAIL_SUMMARY= "EXCLUDE_FROM_MAIL_SUMMARY" ;

    /*
    * The index position of the column EXCLUDE_FROM_MAIL_SUMMARY in the table.
    */
    public static final int EXCLUDE_FROM_MAIL_SUMMARY_IDX = 18 ;

    /**
              * <p> This enables the user to generate new Invoice from RCM.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ENABLE_NEW_INVOICE_GENERATION= "ENABLE_NEW_INVOICE_GENERATION" ;

    /*
    * The index position of the column ENABLE_NEW_INVOICE_GENERATION in the table.
    */
    public static final int ENABLE_NEW_INVOICE_GENERATION_IDX = 19 ;

    /**
              * <p> This enables generation of Invoice for a claim without Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String GENERATE_INVOICE_FOR_CLAIM= "GENERATE_INVOICE_FOR_CLAIM" ;

    /*
    * The index position of the column GENERATE_INVOICE_FOR_CLAIM in the table.
    */
    public static final int GENERATE_INVOICE_FOR_CLAIM_IDX = 20 ;

    /**
              * <p> This enables EHR Payments to be made from RCM.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ENABLE_EHR_PAYMENTS_IN_RCM= "ENABLE_EHR_PAYMENTS_IN_RCM" ;

    /*
    * The index position of the column ENABLE_EHR_PAYMENTS_IN_RCM in the table.
    */
    public static final int ENABLE_EHR_PAYMENTS_IN_RCM_IDX = 21 ;

    /**
              * <p> This allows members to generate two claims for one invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ENABLE_SPLIT_CLAIMS_FOR_BILL= "ENABLE_SPLIT_CLAIMS_FOR_BILL" ;

    /*
    * The index position of the column ENABLE_SPLIT_CLAIMS_FOR_BILL in the table.
    */
    public static final int ENABLE_SPLIT_CLAIMS_FOR_BILL_IDX = 22 ;

    /**
              * <p> This allows rcm members to generate UB04 claims.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENERATE_UB04_CLAIM= "GENERATE_UB04_CLAIM" ;

    /*
    * The index position of the column GENERATE_UB04_CLAIM in the table.
    */
    public static final int GENERATE_UB04_CLAIM_IDX = 23 ;

}
