package com.adventnet.charm;

/** <p> Description of the table <code>PatientGoogleAccountAccess</code>.
 *  Column Name and Table Name of  database table  <code>PatientGoogleAccountAccess</code> is mapped
 * as constants in this util.</p> 
  Information about the tokens required to authenticate Patient's Google Account. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACCESS_ID}
  * </ul>
 */
 
public final class PATIENTGOOGLEACCOUNTACCESS
{
    private PATIENTGOOGLEACCOUNTACCESS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientGoogleAccountAccess" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ACCESS_ID= "ACCESS_ID" ;

    /*
    * The index position of the column ACCESS_ID in the table.
    */
    public static final int ACCESS_ID_IDX = 1 ;

    /**
              * <p> Identifier of the patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> google email Id of the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 3 ;

    /**
              * <p> Access Token for authentication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCESS_TOKEN= "ACCESS_TOKEN" ;

    /*
    * The index position of the column ACCESS_TOKEN in the table.
    */
    public static final int ACCESS_TOKEN_IDX = 4 ;

    /**
              * <p> Token Type for authentication.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TOKEN_TYPE= "TOKEN_TYPE" ;

    /*
    * The index position of the column TOKEN_TYPE in the table.
    */
    public static final int TOKEN_TYPE_IDX = 5 ;

    /**
              * <p> Refresh Token for getting access token after it expires.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REFRESH_TOKEN= "REFRESH_TOKEN" ;

    /*
    * The index position of the column REFRESH_TOKEN in the table.
    */
    public static final int REFRESH_TOKEN_IDX = 6 ;

    /**
              * <p> Expire time of access token.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EXPIRE_TIME= "EXPIRE_TIME" ;

    /*
    * The index position of the column EXPIRE_TIME in the table.
    */
    public static final int EXPIRE_TIME_IDX = 7 ;

}
