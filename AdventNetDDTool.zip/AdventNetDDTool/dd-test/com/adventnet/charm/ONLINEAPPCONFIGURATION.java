package com.adventnet.charm;

/** <p> Description of the table <code>OnlineAppConfiguration</code>.
 *  Column Name and Table Name of  database table  <code>OnlineAppConfiguration</code> is mapped
 * as constants in this util.</p> 
  It contains work timings for each members in a practice. . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #APPOINTMENT_CONFIG_ID}
  * </ul>
 */
 
public final class ONLINEAPPCONFIGURATION
{
    private ONLINEAPPCONFIGURATION()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "OnlineAppConfiguration" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_CONFIG_ID= "APPOINTMENT_CONFIG_ID" ;

    /*
    * The index position of the column APPOINTMENT_CONFIG_ID in the table.
    */
    public static final int APPOINTMENT_CONFIG_ID_IDX = 1 ;

    /**
              * <p> Unique Idendifier of the practice member.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROVIDER_ID= "PROVIDER_ID" ;

    /*
    * The index position of the column PROVIDER_ID in the table.
    */
    public static final int PROVIDER_ID_IDX = 2 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 3 ;

    /**
              * <p> Slot duration for new patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APP_SLOT_NEW_PATIENT= "APP_SLOT_NEW_PATIENT" ;

    /*
    * The index position of the column APP_SLOT_NEW_PATIENT in the table.
    */
    public static final int APP_SLOT_NEW_PATIENT_IDX = 4 ;

    /**
              * <p> Slot duration for old patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String APP_SLOT_OLD_PATIENT= "APP_SLOT_OLD_PATIENT" ;

    /*
    * The index position of the column APP_SLOT_OLD_PATIENT in the table.
    */
    public static final int APP_SLOT_OLD_PATIENT_IDX = 5 ;

    /**
              * <p> Column to identify appointment approval required for new patients/all patients/not required.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String APP_APPROVAL_PREFERENCES= "APP_APPROVAL_PREFERENCES" ;

    /*
    * The index position of the column APP_APPROVAL_PREFERENCES in the table.
    */
    public static final int APP_APPROVAL_PREFERENCES_IDX = 6 ;

    /**
              * <p> Column to identify the online appointment configuration is enabled or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ENABLED= "IS_ENABLED" ;

    /*
    * The index position of the column IS_ENABLED in the table.
    */
    public static final int IS_ENABLED_IDX = 7 ;

    /**
              * <p> List of VISIT TYPE ID's seperated by comma.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VISITTYPE_IDS= "VISITTYPE_IDS" ;

    /*
    * The index position of the column VISITTYPE_IDS in the table.
    */
    public static final int VISITTYPE_IDS_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String SHOW_VISITTYPE= "SHOW_VISITTYPE" ;

    /*
    * The index position of the column SHOW_VISITTYPE in the table.
    */
    public static final int SHOW_VISITTYPE_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String SHOW_VISIT_DURATION= "SHOW_VISIT_DURATION" ;

    /*
    * The index position of the column SHOW_VISIT_DURATION in the table.
    */
    public static final int SHOW_VISIT_DURATION_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_CARD_PROCESSING_ENABLED= "IS_CARD_PROCESSING_ENABLED" ;

    /*
    * The index position of the column IS_CARD_PROCESSING_ENABLED in the table.
    */
    public static final int IS_CARD_PROCESSING_ENABLED_IDX = 11 ;

    /**
              * <p> Profile to which transaction done.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MERCHANT_ACCOUNT_ID= "MERCHANT_ACCOUNT_ID" ;

    /*
    * The index position of the column MERCHANT_ACCOUNT_ID in the table.
    */
    public static final int MERCHANT_ACCOUNT_ID_IDX = 12 ;

    /**
              * <p> For holding processing type STORE_ONLY, STORE_CHARGE, CHARGE_ONLY.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>CHARGE_ONLY</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CARD_PROCESSING_TYPE= "CARD_PROCESSING_TYPE" ;

    /*
    * The index position of the column CARD_PROCESSING_TYPE in the table.
    */
    public static final int CARD_PROCESSING_TYPE_IDX = 13 ;

    /**
              * <p> For holding charge type FIXED, VISIT_BASED.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>FIXED</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CHARGE_TYPE= "CHARGE_TYPE" ;

    /*
    * The index position of the column CHARGE_TYPE in the table.
    */
    public static final int CHARGE_TYPE_IDX = 14 ;

    /**
              * <p> For holding charge amount in case of FIXED charge type.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                            * Default Value is <code>1.0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String CHARGE_AMOUNT= "CHARGE_AMOUNT" ;

    /*
    * The index position of the column CHARGE_AMOUNT in the table.
    */
    public static final int CHARGE_AMOUNT_IDX = 15 ;

    /**
              * <p> Note to be shown in Payment dialog.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PATIENT_NOTE= "PATIENT_NOTE" ;

    /*
    * The index position of the column PATIENT_NOTE in the table.
    */
    public static final int PATIENT_NOTE_IDX = 16 ;

    /**
              * <p> allow patients to add waiting list from online appointments .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String ALLOW_ADD_WAITLIST= "ALLOW_ADD_WAITLIST" ;

    /*
    * The index position of the column ALLOW_ADD_WAITLIST in the table.
    */
    public static final int ALLOW_ADD_WAITLIST_IDX = 17 ;

    /**
              * <p> Column to identify the provider's appointment type(token based or slot wise).</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_TOKEN_BASED= "IS_TOKEN_BASED" ;

    /*
    * The index position of the column IS_TOKEN_BASED in the table.
    */
    public static final int IS_TOKEN_BASED_IDX = 18 ;

    /**
              * <p> showing starting range for opening of slots.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                     * Default Value is <code>24</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SLOTS_OPENING_PRIOR_HOURS= "SLOTS_OPENING_PRIOR_HOURS" ;

    /*
    * The index position of the column SLOTS_OPENING_PRIOR_HOURS in the table.
    */
    public static final int SLOTS_OPENING_PRIOR_HOURS_IDX = 19 ;

    /**
              * <p>  Future days limit for online slots.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                     * Default Value is <code>180</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String ONLINE_BOOKING_DAYS_LIMIT= "ONLINE_BOOKING_DAYS_LIMIT" ;

    /*
    * The index position of the column ONLINE_BOOKING_DAYS_LIMIT in the table.
    */
    public static final int ONLINE_BOOKING_DAYS_LIMIT_IDX = 20 ;

    /**
              * <p> Template ID of Pre-Screening questionnaire from PhysicianTemplates.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QUESTIONNAIRE_ID= "QUESTIONNAIRE_ID" ;

    /*
    * The index position of the column QUESTIONNAIRE_ID in the table.
    */
    public static final int QUESTIONNAIRE_ID_IDX = 21 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String SEND_RECEIPT_PHR_EMAIL= "SEND_RECEIPT_PHR_EMAIL" ;

    /*
    * The index position of the column SEND_RECEIPT_PHR_EMAIL in the table.
    */
    public static final int SEND_RECEIPT_PHR_EMAIL_IDX = 22 ;

}
