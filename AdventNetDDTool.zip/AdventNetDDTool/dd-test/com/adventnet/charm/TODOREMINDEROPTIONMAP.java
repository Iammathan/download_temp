package com.adventnet.charm;

/** <p> Description of the table <code>TodoReminderOptionMap</code>.
 *  Column Name and Table Name of  database table  <code>TodoReminderOptionMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Todo and Reminder Option. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #TODO_ID}
  * <li> {@link #REMINDEROPTION_ID}
  * </ul>
 */
 
public final class TODOREMINDEROPTIONMAP
{
    private TODOREMINDEROPTIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TodoReminderOptionMap" ;
    /**
              * <p>  TODO ID .</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TODO_ID= "TODO_ID" ;

    /*
    * The index position of the column TODO_ID in the table.
    */
    public static final int TODO_ID_IDX = 1 ;

    /**
              * <p> Reminder Option ID .</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REMINDEROPTION_ID= "REMINDEROPTION_ID" ;

    /*
    * The index position of the column REMINDEROPTION_ID in the table.
    */
    public static final int REMINDEROPTION_ID_IDX = 2 ;

}
