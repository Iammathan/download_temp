package com.adventnet.charm;

/** <p> Description of the table <code>PatientRecall</code>.
 *  Column Name and Table Name of  database table  <code>PatientRecall</code> is mapped
 * as constants in this util.</p> 
  Physician Notes table extended to this table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_RECALL_ID}
  * </ul>
 */
 
public final class PATIENTRECALL
{
    private PATIENTRECALL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientRecall" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_RECALL_ID= "PATIENT_RECALL_ID" ;

    /*
    * The index position of the column PATIENT_RECALL_ID in the table.
    */
    public static final int PATIENT_RECALL_ID_IDX = 1 ;

    /**
              * <p> Patient ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Type of recall.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RECALL_TYPE= "RECALL_TYPE" ;

    /*
    * The index position of the column RECALL_TYPE in the table.
    */
    public static final int RECALL_TYPE_IDX = 3 ;

    /**
              * <p> Recall notes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 4 ;

    /**
              * <p> created by .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_BY= "CREATED_BY" ;

    /*
    * The index position of the column CREATED_BY in the table.
    */
    public static final int CREATED_BY_IDX = 5 ;

    /**
              * <p> created on .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_ON= "CREATED_ON" ;

    /*
    * The index position of the column CREATED_ON in the table.
    */
    public static final int CREATED_ON_IDX = 6 ;

    /**
              * <p> Provider ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROVIDER_ID= "PROVIDER_ID" ;

    /*
    * The index position of the column PROVIDER_ID in the table.
    */
    public static final int PROVIDER_ID_IDX = 7 ;

    /**
              * <p> Facility ID .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 8 ;

    /**
              * <p> Date of recall.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECALL_DATE= "RECALL_DATE" ;

    /*
    * The index position of the column RECALL_DATE in the table.
    */
    public static final int RECALL_DATE_IDX = 9 ;

    /**
              * <p> Recall time.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RECALL_TIME= "RECALL_TIME" ;

    /*
    * The index position of the column RECALL_TIME in the table.
    */
    public static final int RECALL_TIME_IDX = 10 ;

    /**
              * <p> Time  unit  of recall - months / weeks / days.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RECALL_TIMEUNIT= "RECALL_TIMEUNIT" ;

    /*
    * The index position of the column RECALL_TIMEUNIT in the table.
    */
    public static final int RECALL_TIMEUNIT_IDX = 11 ;

    /**
              * <p> Pending / Completed .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String RECALL_STATUS= "RECALL_STATUS" ;

    /*
    * The index position of the column RECALL_STATUS in the table.
    */
    public static final int RECALL_STATUS_IDX = 12 ;

    /**
              * <p> Status of the recall.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>Pending</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>Pending</code>" , 
       * will be taken.<br>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 13 ;

    /**
              * <p> values - after / in .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String RECALL_PERIOD= "RECALL_PERIOD" ;

    /*
    * The index position of the column RECALL_PERIOD in the table.
    */
    public static final int RECALL_PERIOD_IDX = 14 ;

}
