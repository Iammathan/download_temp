package com.adventnet.charm;

/** <p> Description of the table <code>QuestVisits</code>.
 *  Column Name and Table Name of  database table  <code>QuestVisits</code> is mapped
 * as constants in this util.</p> 
  Mapping between facility, provider and VisitTypes . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #QUEST_VISITS_ID}
  * </ul>
 */
 
public final class QUESTVISITS
{
    private QUESTVISITS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QuestVisits" ;
    /**
              * <p> Identifier of QuestVisits.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String QUEST_VISITS_ID= "QUEST_VISITS_ID" ;

    /*
    * The index position of the column QUEST_VISITS_ID in the table.
    */
    public static final int QUEST_VISITS_ID_IDX = 1 ;

    /**
              * <p> Identifier of Facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 2 ;

    /**
              * <p> Identifier of provider .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROVIDER_ID= "PROVIDER_ID" ;

    /*
    * The index position of the column PROVIDER_ID in the table.
    */
    public static final int PROVIDER_ID_IDX = 3 ;

    /**
              * <p> Identifier of VisitTypes.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String VISITTYPE_ID= "VISITTYPE_ID" ;

    /*
    * The index position of the column VISITTYPE_ID in the table.
    */
    public static final int VISITTYPE_ID_IDX = 4 ;

    /**
              * <p> Type of the Questionnaire [0.General 1.Feedback].</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 5 ;

    /**
              * <p> members to notify feedback submission.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTIFY_OTHER_MEMBERS= "NOTIFY_OTHER_MEMBERS" ;

    /*
    * The index position of the column NOTIFY_OTHER_MEMBERS in the table.
    */
    public static final int NOTIFY_OTHER_MEMBERS_IDX = 6 ;

    /**
              * <p> Whether to notify feedback submission to respective provider or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_TO_NOTIFY_RES_PROVIDER= "IS_TO_NOTIFY_RES_PROVIDER" ;

    /*
    * The index position of the column IS_TO_NOTIFY_RES_PROVIDER in the table.
    */
    public static final int IS_TO_NOTIFY_RES_PROVIDER_IDX = 7 ;

    /**
              * <p> Frequcy to submit feedback form.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String FREQUENCY= "FREQUENCY" ;

    /*
    * The index position of the column FREQUENCY in the table.
    */
    public static final int FREQUENCY_IDX = 8 ;

    /**
              * <p>  send feedback form after (days).</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DAYS_AFTER= "DAYS_AFTER" ;

    /*
    * The index position of the column DAYS_AFTER in the table.
    */
    public static final int DAYS_AFTER_IDX = 9 ;

}
