package com.adventnet.charm;

/** <p> Description of the table <code>HealthGoal</code>.
 *  Column Name and Table Name of  database table  <code>HealthGoal</code> is mapped
 * as constants in this util.</p> 
  This table is used to maintain Health goal related data. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #HEALTH_GOAL_ID}
  * </ul>
 */
 
public final class HEALTHGOAL
{
    private HEALTHGOAL()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "HealthGoal" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_GOAL_ID= "HEALTH_GOAL_ID" ;

    /*
    * The index position of the column HEALTH_GOAL_ID in the table.
    */
    public static final int HEALTH_GOAL_ID_IDX = 1 ;

    /**
              * <p> Identifier of Tracker.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRACKER_ID= "TRACKER_ID" ;

    /*
    * The index position of the column TRACKER_ID in the table.
    */
    public static final int TRACKER_ID_IDX = 2 ;

    /**
              * <p> Identifier of current Metric.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String HEALTH_METRIC_ID= "HEALTH_METRIC_ID" ;

    /*
    * The index position of the column HEALTH_METRIC_ID in the table.
    */
    public static final int HEALTH_METRIC_ID_IDX = 3 ;

    /**
              * <p> Goal Value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GOAL_START_VALUE= "GOAL_START_VALUE" ;

    /*
    * The index position of the column GOAL_START_VALUE in the table.
    */
    public static final int GOAL_START_VALUE_IDX = 4 ;

    /**
              * <p> Goal Value.</p>
                            * Data Type of this field is <code>FLOAT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String GOAL_TARGET_VALUE= "GOAL_TARGET_VALUE" ;

    /*
    * The index position of the column GOAL_TARGET_VALUE in the table.
    */
    public static final int GOAL_TARGET_VALUE_IDX = 5 ;

    /**
              * <p> Date on which Goal tracking started.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String START_DATE= "START_DATE" ;

    /*
    * The index position of the column START_DATE in the table.
    */
    public static final int START_DATE_IDX = 6 ;

    /**
              * <p> Date on which Goal tracking actually ended.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String END_DATE= "END_DATE" ;

    /*
    * The index position of the column END_DATE in the table.
    */
    public static final int END_DATE_IDX = 7 ;

    /**
              * <p>  Target Date on which Goal tracking is expected to end.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TARGET_DATE= "TARGET_DATE" ;

    /*
    * The index position of the column TARGET_DATE in the table.
    */
    public static final int TARGET_DATE_IDX = 8 ;

    /**
              * <p> The identifier used to find whether tracking finished or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_COMPLETED= "IS_COMPLETED" ;

    /*
    * The index position of the column IS_COMPLETED in the table.
    */
    public static final int IS_COMPLETED_IDX = 9 ;

}
