package com.adventnet.charm;

/** <p> Description of the table <code>ScheduledJobs</code>.
 *  Column Name and Table Name of  database table  <code>ScheduledJobs</code> is mapped
 * as constants in this util.</p> 
  This table will store the JOB_IDs of scheduled jobs in the user's space. Table created with the assumption of having 1 schedule to 1 job mapping in future as well. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SCHEDULED_JOBS_ID}
  * </ul>
 */
 
public final class SCHEDULEDJOBS
{
    private SCHEDULEDJOBS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ScheduledJobs" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SCHEDULED_JOBS_ID= "SCHEDULED_JOBS_ID" ;

    /*
    * The index position of the column SCHEDULED_JOBS_ID in the table.
    */
    public static final int SCHEDULED_JOBS_ID_IDX = 1 ;

    /**
              * <p> RunnableJob implementation class name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String JOB_CLASS= "JOB_CLASS" ;

    /*
    * The index position of the column JOB_CLASS in the table.
    */
    public static final int JOB_CLASS_IDX = 2 ;

    /**
              * <p> Schedule name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SCHEDULE_NAME= "SCHEDULE_NAME" ;

    /*
    * The index position of the column SCHEDULE_NAME in the table.
    */
    public static final int SCHEDULE_NAME_IDX = 3 ;

}
