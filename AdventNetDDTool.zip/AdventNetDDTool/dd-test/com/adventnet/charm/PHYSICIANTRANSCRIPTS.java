package com.adventnet.charm;

/** <p> Description of the table <code>PhysicianTranscripts</code>.
 *  Column Name and Table Name of  database table  <code>PhysicianTranscripts</code> is mapped
 * as constants in this util.</p> 
  Audio/Video transcripts by recorded by doctors. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PHYSICIAN_TRANSCRIPT_ID}
  * </ul>
 */
 
public final class PHYSICIANTRANSCRIPTS
{
    private PHYSICIANTRANSCRIPTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PhysicianTranscripts" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHYSICIAN_TRANSCRIPT_ID= "PHYSICIAN_TRANSCRIPT_ID" ;

    /*
    * The index position of the column PHYSICIAN_TRANSCRIPT_ID in the table.
    */
    public static final int PHYSICIAN_TRANSCRIPT_ID_IDX = 1 ;

    /**
              * <p> Identifier of ConsultationHistory.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTATION_ID= "CONSULTATION_ID" ;

    /*
    * The index position of the column CONSULTATION_ID in the table.
    */
    public static final int CONSULTATION_ID_IDX = 2 ;

    /**
              * <p> Time at which the transcript was recorded.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_STAMP= "TIME_STAMP" ;

    /*
    * The index position of the column TIME_STAMP in the table.
    */
    public static final int TIME_STAMP_IDX = 3 ;

    /**
              * <p> ID for the recorded file which is stored in the Zoho DFS.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TRANSCRIPT_ID= "TRANSCRIPT_ID" ;

    /*
    * The index position of the column TRANSCRIPT_ID in the table.
    */
    public static final int TRANSCRIPT_ID_IDX = 4 ;

}
