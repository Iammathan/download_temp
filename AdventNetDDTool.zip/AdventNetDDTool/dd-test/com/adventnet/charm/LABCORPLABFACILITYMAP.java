package com.adventnet.charm;

/** <p> Description of the table <code>LabCorpLabFacilityMap</code>.
 *  Column Name and Table Name of  database table  <code>LabCorpLabFacilityMap</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #QUEST_LAB_ACCOUNT_ID}
  * <li> {@link #LABCORP_LAB_FACILITY_ID}
  * </ul>
 */
 
public final class LABCORPLABFACILITYMAP
{
    private LABCORPLABFACILITYMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabCorpLabFacilityMap" ;
    /**
              * <p>  QUEST_LAB_ACCOUNT_ID of the corrected message.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String QUEST_LAB_ACCOUNT_ID= "QUEST_LAB_ACCOUNT_ID" ;

    /*
    * The index position of the column QUEST_LAB_ACCOUNT_ID in the table.
    */
    public static final int QUEST_LAB_ACCOUNT_ID_IDX = 1 ;

    /**
              * <p>  LABCORP_LAB_FACILITY_ID of the respective old message.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LABCORP_LAB_FACILITY_ID= "LABCORP_LAB_FACILITY_ID" ;

    /*
    * The index position of the column LABCORP_LAB_FACILITY_ID in the table.
    */
    public static final int LABCORP_LAB_FACILITY_ID_IDX = 2 ;

}
