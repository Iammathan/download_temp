package com.adventnet.charm;

/** <p> Description of the table <code>BillingTemplateEntries</code>.
 *  Column Name and Table Name of  database table  <code>BillingTemplateEntries</code> is mapped
 * as constants in this util.</p> 
  Used to store Treatment Codes / Product template items. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class BILLINGTEMPLATEENTRIES
{
    private BILLINGTEMPLATEENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillingTemplateEntries" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> TEMPLATE_ID from PhysicianTemplates table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> It will have either 'CODE_ID' from 'ProcedureCode' or 'PRODUCT_ID' from 'Product' table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ITEM_ID= "ITEM_ID" ;

    /*
    * The index position of the column ITEM_ID in the table.
    */
    public static final int ITEM_ID_IDX = 3 ;

    /**
              * <p> Position of an item in a template.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ITEM_POSITION= "ITEM_POSITION" ;

    /*
    * The index position of the column ITEM_POSITION in the table.
    */
    public static final int ITEM_POSITION_IDX = 4 ;

}
