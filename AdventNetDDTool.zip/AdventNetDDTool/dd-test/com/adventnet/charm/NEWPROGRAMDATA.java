package com.adventnet.charm;

/** <p> Description of the table <code>NewProgramData</code>.
 *  Column Name and Table Name of  database table  <code>NewProgramData</code> is mapped
 * as constants in this util.</p> 
  New Program's added by users are stored here. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #NEW_PROG_ID}
  * </ul>
 */
 
public final class NEWPROGRAMDATA
{
    private NEWPROGRAMDATA()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "NewProgramData" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String NEW_PROG_ID= "NEW_PROG_ID" ;

    /*
    * The index position of the column NEW_PROG_ID in the table.
    */
    public static final int NEW_PROG_ID_IDX = 1 ;

    /**
              * <p> Identifier of Academic Program.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PROGRAM_ID= "PROGRAM_ID" ;

    /*
    * The index position of the column PROGRAM_ID in the table.
    */
    public static final int PROGRAM_ID_IDX = 2 ;

    /**
              * <p> Academic Program Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PROGRAM_NAME= "PROGRAM_NAME" ;

    /*
    * The index position of the column PROGRAM_NAME in the table.
    */
    public static final int PROGRAM_NAME_IDX = 3 ;

    /**
              * <p> Response data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String USERID= "USERID" ;

    /*
    * The index position of the column USERID in the table.
    */
    public static final int USERID_IDX = 4 ;

}
