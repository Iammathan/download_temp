package com.adventnet.charm;

/** <p> Description of the table <code>DemographicsSettings</code>.
 *  Column Name and Table Name of  database table  <code>DemographicsSettings</code> is mapped
 * as constants in this util.</p> 
  Patient Demographics settings. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DEMOGRAPHICS_SETTINGS_ID}
  * </ul>
 */
 
public final class DEMOGRAPHICSSETTINGS
{
    private DEMOGRAPHICSSETTINGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DemographicsSettings" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DEMOGRAPHICS_SETTINGS_ID= "DEMOGRAPHICS_SETTINGS_ID" ;

    /*
    * The index position of the column DEMOGRAPHICS_SETTINGS_ID in the table.
    */
    public static final int DEMOGRAPHICS_SETTINGS_ID_IDX = 1 ;

    /**
              * <p> Name of the field.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FIELD= "FIELD" ;

    /*
    * The index position of the column FIELD in the table.
    */
    public static final int FIELD_IDX = 2 ;

    /**
              * <p> This category is required or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String REQUIRED= "REQUIRED" ;

    /*
    * The index position of the column REQUIRED in the table.
    */
    public static final int REQUIRED_IDX = 3 ;

    /**
              * <p> This category is mandatory or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String MANDATORY= "MANDATORY" ;

    /*
    * The index position of the column MANDATORY in the table.
    */
    public static final int MANDATORY_IDX = 4 ;

}
