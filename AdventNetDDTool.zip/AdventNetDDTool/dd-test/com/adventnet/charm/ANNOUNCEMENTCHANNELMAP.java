package com.adventnet.charm;

/** <p> Description of the table <code>AnnouncementChannelMap</code>.
 *  Column Name and Table Name of  database table  <code>AnnouncementChannelMap</code> is mapped
 * as constants in this util.</p> 
  AnnouncementChannelMap used to map Announcement channel ID with charm's module Ids(facility|department|role) like each module has privilege to have limited announcment channes. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #MAPPING_ID}
  * </ul>
 */
 
public final class ANNOUNCEMENTCHANNELMAP
{
    private ANNOUNCEMENTCHANNELMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AnnouncementChannelMap" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MAPPING_ID= "MAPPING_ID" ;

    /*
    * The index position of the column MAPPING_ID in the table.
    */
    public static final int MAPPING_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MODULE_ID= "MODULE_ID" ;

    /*
    * The index position of the column MODULE_ID in the table.
    */
    public static final int MODULE_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHANNEL_ID= "CHANNEL_ID" ;

    /*
    * The index position of the column CHANNEL_ID in the table.
    */
    public static final int CHANNEL_ID_IDX = 3 ;

}
