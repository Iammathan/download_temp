package com.adventnet.charm;

/** <p> Description of the table <code>PatientHIPPADetails</code>.
 *  Column Name and Table Name of  database table  <code>PatientHIPPADetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PATIENT_HIPPA_ID}
  * <li> {@link #PRACTICE_PATIENT_ID}
  * </ul>
 */
 
public final class PATIENTHIPPADETAILS
{
    private PATIENTHIPPADETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientHIPPADetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_HIPPA_ID= "PATIENT_HIPPA_ID" ;

    /*
    * The index position of the column PATIENT_HIPPA_ID in the table.
    */
    public static final int PATIENT_HIPPA_ID_IDX = 1 ;

    /**
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FORM_GIVEN= "IS_FORM_GIVEN" ;

    /*
    * The index position of the column IS_FORM_GIVEN in the table.
    */
    public static final int IS_FORM_GIVEN_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SIGN_BY_PATIENT= "IS_SIGN_BY_PATIENT" ;

    /*
    * The index position of the column IS_SIGN_BY_PATIENT in the table.
    */
    public static final int IS_SIGN_BY_PATIENT_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FORM_GIVEN_DATE= "FORM_GIVEN_DATE" ;

    /*
    * The index position of the column FORM_GIVEN_DATE in the table.
    */
    public static final int FORM_GIVEN_DATE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SIGNED_PATIENT_DATE= "SIGNED_PATIENT_DATE" ;

    /*
    * The index position of the column SIGNED_PATIENT_DATE in the table.
    */
    public static final int SIGNED_PATIENT_DATE_IDX = 6 ;

    /**
              * <p> HIPPA Notes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String HIPPA_NOTES= "HIPPA_NOTES" ;

    /*
    * The index position of the column HIPPA_NOTES in the table.
    */
    public static final int HIPPA_NOTES_IDX = 7 ;

}
