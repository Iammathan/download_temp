package com.adventnet.charm;

/** <p> Description of the table <code>TextRationale</code>.
 *  Column Name and Table Name of  database table  <code>TextRationale</code> is mapped
 * as constants in this util.</p> 
  Text Rationale by physician. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #TEXT_RATIONALE_ID}
  * </ul>
 */
 
public final class TEXTRATIONALE
{
    private TEXTRATIONALE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "TextRationale" ;
    /**
              * <p> Unique identifier of Text Rationale entry.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TEXT_RATIONALE_ID= "TEXT_RATIONALE_ID" ;

    /*
    * The index position of the column TEXT_RATIONALE_ID in the table.
    */
    public static final int TEXT_RATIONALE_ID_IDX = 1 ;

    /**
              * <p> Rationale by physician.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>400</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RATIONALE_TEXT= "RATIONALE_TEXT" ;

    /*
    * The index position of the column RATIONALE_TEXT in the table.
    */
    public static final int RATIONALE_TEXT_IDX = 2 ;

}
