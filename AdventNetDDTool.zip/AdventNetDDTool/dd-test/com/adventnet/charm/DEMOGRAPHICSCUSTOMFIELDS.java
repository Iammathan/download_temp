package com.adventnet.charm;

/** <p> Description of the table <code>DemographicsCustomFields</code>.
 *  Column Name and Table Name of  database table  <code>DemographicsCustomFields</code> is mapped
 * as constants in this util.</p> 
  To store the patient configuration details of patient custom fields. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DEMOGRAPHICS_CUSTOM_FIELD_ID}
  * </ul>
 */
 
public final class DEMOGRAPHICSCUSTOMFIELDS
{
    private DEMOGRAPHICSCUSTOMFIELDS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DemographicsCustomFields" ;
    /**
              * <p> Unique value generator PK.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DEMOGRAPHICS_CUSTOM_FIELD_ID= "DEMOGRAPHICS_CUSTOM_FIELD_ID" ;

    /*
    * The index position of the column DEMOGRAPHICS_CUSTOM_FIELD_ID in the table.
    */
    public static final int DEMOGRAPHICS_CUSTOM_FIELD_ID_IDX = 1 ;

    /**
              * <p> Name of the custom field.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                            *    This field is an unique column.<br>
                            * Allowed Values are ,<br>
       * <ul>
              * <li><code>PATIENT_CUSTOM_FIELD_1</code></li>
              * <li><code>PATIENT_CUSTOM_FIELD_2</code></li>
              * <li><code>PATIENT_CUSTOM_FIELD_3</code></li>
              * <li><code>PATIENT_CUSTOM_FIELD_4</code></li>
              * <li><code>PATIENT_CUSTOM_FIELD_5</code></li>
              * </ul>
                         */
    public static final String FIELD_ID= "FIELD_ID" ;

    /*
    * The index position of the column FIELD_ID in the table.
    */
    public static final int FIELD_ID_IDX = 2 ;

    /**
              * <p> Custom Field Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIELD_NAME= "FIELD_NAME" ;

    /*
    * The index position of the column FIELD_NAME in the table.
    */
    public static final int FIELD_NAME_IDX = 3 ;

    /**
              * <p> Patient is searchable with this field or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String SEARCHABLE= "SEARCHABLE" ;

    /*
    * The index position of the column SEARCHABLE in the table.
    */
    public static final int SEARCHABLE_IDX = 4 ;

    /**
              * <p> Patient is searchable with this field or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

    /**
              * <p> Stores validation type for custom field value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>external_url</code></li>
              * </ul>
                         */
    public static final String VALIDATION_TYPE= "VALIDATION_TYPE" ;

    /*
    * The index position of the column VALIDATION_TYPE in the table.
    */
    public static final int VALIDATION_TYPE_IDX = 6 ;

    /**
              * <p> Stores validation rule for the custom field value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String VALIDATION= "VALIDATION" ;

    /*
    * The index position of the column VALIDATION in the table.
    */
    public static final int VALIDATION_IDX = 7 ;

}
