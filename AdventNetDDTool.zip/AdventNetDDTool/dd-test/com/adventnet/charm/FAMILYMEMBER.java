package com.adventnet.charm;

/** <p> Description of the table <code>FamilyMember</code>.
 *  Column Name and Table Name of  database table  <code>FamilyMember</code> is mapped
 * as constants in this util.</p> 
  List of family member. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FAMILY_HISTORY_ID}
  * </ul>
 */
 
public final class FAMILYMEMBER
{
    private FAMILYMEMBER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FamilyMember" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FAMILY_HISTORY_ID= "FAMILY_HISTORY_ID" ;

    /*
    * The index position of the column FAMILY_HISTORY_ID in the table.
    */
    public static final int FAMILY_HISTORY_ID_IDX = 1 ;

    /**
              * <p> identifier patient family.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Date of bith of member.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DOB= "DOB" ;

    /*
    * The index position of the column DOB in the table.
    */
    public static final int DOB_IDX = 3 ;

    /**
              * <p> Patient relationship with Family member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RELATIONSHIP= "RELATIONSHIP" ;

    /*
    * The index position of the column RELATIONSHIP in the table.
    */
    public static final int RELATIONSHIP_IDX = 4 ;

    /**
              * <p> Patient relationship with Family member SNOMED CT CODE.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RELATIONSHIP_CODE= "RELATIONSHIP_CODE" ;

    /*
    * The index position of the column RELATIONSHIP_CODE in the table.
    */
    public static final int RELATIONSHIP_CODE_IDX = 5 ;

    /**
              * <p> name of Family member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NAME= "NAME" ;

    /*
    * The index position of the column NAME in the table.
    */
    public static final int NAME_IDX = 6 ;

    /**
              * <p> member ALIVE status.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ALIVE= "IS_ALIVE" ;

    /*
    * The index position of the column IS_ALIVE in the table.
    */
    public static final int IS_ALIVE_IDX = 7 ;

    /**
              * <p> member ALIVE status.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String NO_DX_TO_RECORD= "NO_DX_TO_RECORD" ;

    /*
    * The index position of the column NO_DX_TO_RECORD in the table.
    */
    public static final int NO_DX_TO_RECORD_IDX = 8 ;

    /**
              * <p> Health status of SNOMED CT CODE.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String HEALTH_STATUS_CODE= "HEALTH_STATUS_CODE" ;

    /*
    * The index position of the column HEALTH_STATUS_CODE in the table.
    */
    public static final int HEALTH_STATUS_CODE_IDX = 9 ;

}
