package com.adventnet.charm;

/** <p> Description of the table <code>ExostarProductMemberMap</code>.
 *  Column Name and Table Name of  database table  <code>ExostarProductMemberMap</code> is mapped
 * as constants in this util.</p> 
  Stores details about the txn with exostar. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXO_PRD_USER_ID}
  * </ul>
 */
 
public final class EXOSTARPRODUCTMEMBERMAP
{
    private EXOSTARPRODUCTMEMBERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ExostarProductMemberMap" ;
    /**
              * <p> Pk of ExostarOrderProductsMap.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXO_PRD_USER_ID= "EXO_PRD_USER_ID" ;

    /*
    * The index position of the column EXO_PRD_USER_ID in the table.
    */
    public static final int EXO_PRD_USER_ID_IDX = 1 ;

    /**
              * <p> Pk of ExostarOrderProducts.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXO_ORD_PRD_ID= "EXO_ORD_PRD_ID" ;

    /*
    * The index position of the column EXO_ORD_PRD_ID in the table.
    */
    public static final int EXO_ORD_PRD_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXO_ACC_DET_ID= "EXO_ACC_DET_ID" ;

    /*
    * The index position of the column EXO_ACC_DET_ID in the table.
    */
    public static final int EXO_ACC_DET_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MEMBER_ID= "MEMBER_ID" ;

    /*
    * The index position of the column MEMBER_ID in the table.
    */
    public static final int MEMBER_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 5 ;

    /**
              * <p> Zoho's USER ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ZUID= "ZUID" ;

    /*
    * The index position of the column ZUID in the table.
    */
    public static final int ZUID_IDX = 6 ;

    /**
                            * Data Type of this field is <code>TIMESTAMP</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BOUND_DATE= "BOUND_DATE" ;

    /*
    * The index position of the column BOUND_DATE in the table.
    */
    public static final int BOUND_DATE_IDX = 7 ;

    /**
              * <p> specifies the name of the member.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MEMBER_NAME= "MEMBER_NAME" ;

    /*
    * The index position of the column MEMBER_NAME in the table.
    */
    public static final int MEMBER_NAME_IDX = 8 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>NASCENT</code></li>
              * <li><code>ACTIVE</code></li>
              * <li><code>SUSPENDED</code></li>
              * <li><code>DEAD</code></li>
              * </ul>
                         */
    public static final String USER_ACCOUNT_STATUS= "USER_ACCOUNT_STATUS" ;

    /*
    * The index position of the column USER_ACCOUNT_STATUS in the table.
    */
    public static final int USER_ACCOUNT_STATUS_IDX = 9 ;

    /**
              * <p> is NPI verified.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_NPI_VERIFIED_FOR_EPCS= "IS_NPI_VERIFIED_FOR_EPCS" ;

    /*
    * The index position of the column IS_NPI_VERIFIED_FOR_EPCS in the table.
    */
    public static final int IS_NPI_VERIFIED_FOR_EPCS_IDX = 10 ;

}
