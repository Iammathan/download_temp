package com.adventnet.charm;

/** <p> Description of the table <code>RepeatAppointments</code>.
 *  Column Name and Table Name of  database table  <code>RepeatAppointments</code> is mapped
 * as constants in this util.</p> 
  Information about the Repeat setting for an appointment. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REPEAT_ID}
  * </ul>
 */
 
public final class REPEATAPPOINTMENTS
{
    private REPEATAPPOINTMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RepeatAppointments" ;
    /**
              * <p> Identifier of Repeat Appointments.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPEAT_ID= "REPEAT_ID" ;

    /*
    * The index position of the column REPEAT_ID in the table.
    */
    public static final int REPEAT_ID_IDX = 1 ;

    /**
              * <p> Repeat Type like (Daily, Weakly etc).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REPEAT_TYPE= "REPEAT_TYPE" ;

    /*
    * The index position of the column REPEAT_TYPE in the table.
    */
    public static final int REPEAT_TYPE_IDX = 2 ;

    /**
              * <p> When the repeat event starts.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 3 ;

    /**
              * <p> When the repeat event ends.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 4 ;

    /**
              * <p> Used to define weekly events (0-6 for Sunday - Saturday) comma separated.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DAYS_OF_WEEK= "DAYS_OF_WEEK" ;

    /*
    * The index position of the column DAYS_OF_WEEK in the table.
    */
    public static final int DAYS_OF_WEEK_IDX = 5 ;

    /**
              * <p> Specifying repeat intervals for the repeat appointments.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String REPEAT_INTERVAL= "REPEAT_INTERVAL" ;

    /*
    * The index position of the column REPEAT_INTERVAL in the table.
    */
    public static final int REPEAT_INTERVAL_IDX = 6 ;

    /**
              * <p> Specifying number of occurrence for the repeat appointments.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OCCURRENCE_COUNT= "OCCURRENCE_COUNT" ;

    /*
    * The index position of the column OCCURRENCE_COUNT in the table.
    */
    public static final int OCCURRENCE_COUNT_IDX = 7 ;

}
