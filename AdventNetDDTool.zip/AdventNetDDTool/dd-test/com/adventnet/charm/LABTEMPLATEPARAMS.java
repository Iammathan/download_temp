package com.adventnet.charm;

/** <p> Description of the table <code>LabTemplateParams</code>.
 *  Column Name and Table Name of  database table  <code>LabTemplateParams</code> is mapped
 * as constants in this util.</p> 
  Mapping template with the parameters list. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * <li> {@link #MEDICAL_RECORD_PARAM_ID}
  * </ul>
 */
 
public final class LABTEMPLATEPARAMS
{
    private LABTEMPLATEPARAMS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "LabTemplateParams" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> Id of the MedicalRecordParams.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MEDICAL_RECORD_PARAM_ID= "MEDICAL_RECORD_PARAM_ID" ;

    /*
    * The index position of the column MEDICAL_RECORD_PARAM_ID in the table.
    */
    public static final int MEDICAL_RECORD_PARAM_ID_IDX = 2 ;

}
