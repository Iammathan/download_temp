package com.adventnet.charm;

/** <p> Description of the table <code>BillItemProductDetails</code>.
 *  Column Name and Table Name of  database table  <code>BillItemProductDetails</code> is mapped
 * as constants in this util.</p> 
  used to store inventory item detail for invoice. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #BILL_ITEM_PRODUCT_DETAILS_ID}
  * </ul>
 */
 
public final class BILLITEMPRODUCTDETAILS
{
    private BILLITEMPRODUCTDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "BillItemProductDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String BILL_ITEM_PRODUCT_DETAILS_ID= "BILL_ITEM_PRODUCT_DETAILS_ID" ;

    /*
    * The index position of the column BILL_ITEM_PRODUCT_DETAILS_ID in the table.
    */
    public static final int BILL_ITEM_PRODUCT_DETAILS_ID_IDX = 1 ;

    /**
              * <p> BILL ITEM id which repesensts the inventory product.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILL_ITEM_ID= "BILL_ITEM_ID" ;

    /*
    * The index position of the column BILL_ITEM_ID in the table.
    */
    public static final int BILL_ITEM_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INVENTORY_ID= "INVENTORY_ID" ;

    /*
    * The index position of the column INVENTORY_ID in the table.
    */
    public static final int INVENTORY_ID_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRODUCT_ID= "PRODUCT_ID" ;

    /*
    * The index position of the column PRODUCT_ID in the table.
    */
    public static final int PRODUCT_ID_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String BATCH_NO= "BATCH_NO" ;

    /*
    * The index position of the column BATCH_NO in the table.
    */
    public static final int BATCH_NO_IDX = 5 ;

    /**
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ITEM_EXPIRY_DATE= "ITEM_EXPIRY_DATE" ;

    /*
    * The index position of the column ITEM_EXPIRY_DATE in the table.
    */
    public static final int ITEM_EXPIRY_DATE_IDX = 6 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CATEGORY_NAME= "CATEGORY_NAME" ;

    /*
    * The index position of the column CATEGORY_NAME in the table.
    */
    public static final int CATEGORY_NAME_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COST_PRICE= "COST_PRICE" ;

    /*
    * The index position of the column COST_PRICE in the table.
    */
    public static final int COST_PRICE_IDX = 8 ;

}
