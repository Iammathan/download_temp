package com.adventnet.charm;

/** <p> Description of the table <code>PatientDiagnosisMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientDiagnosisMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Diagnosis. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DIAGNOSIS_MAP_ID}
  * </ul>
 */
 
public final class PATIENTDIAGNOSISMAP
{
    private PATIENTDIAGNOSISMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientDiagnosisMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DIAGNOSIS_MAP_ID= "DIAGNOSIS_MAP_ID" ;

    /*
    * The index position of the column DIAGNOSIS_MAP_ID in the table.
    */
    public static final int DIAGNOSIS_MAP_ID_IDX = 1 ;

    /**
              * <p> Date at which the diagnosis is entered.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE_OF_ENTRY= "DATE_OF_ENTRY" ;

    /*
    * The index position of the column DATE_OF_ENTRY in the table.
    */
    public static final int DATE_OF_ENTRY_IDX = 2 ;

    /**
              * <p> Identifier of the diagnosis.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DIAGNOSIS_ID= "DIAGNOSIS_ID" ;

    /*
    * The index position of the column DIAGNOSIS_ID in the table.
    */
    public static final int DIAGNOSIS_ID_IDX = 3 ;

    /**
              * <p> ICD9 or ICD10 code of the Diagnosis.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ICD_CODE= "ICD_CODE" ;

    /*
    * The index position of the column ICD_CODE in the table.
    */
    public static final int ICD_CODE_IDX = 4 ;

    /**
              * <p> ICD9 or ICD10.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ICD_CODE_TYPE= "ICD_CODE_TYPE" ;

    /*
    * The index position of the column ICD_CODE_TYPE in the table.
    */
    public static final int ICD_CODE_TYPE_IDX = 5 ;

    /**
              * <p> Descripion of ICD9 or ICD10.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ICD_DESCRIPTION= "ICD_DESCRIPTION" ;

    /*
    * The index position of the column ICD_DESCRIPTION in the table.
    */
    public static final int ICD_DESCRIPTION_IDX = 6 ;

    /**
              * <p> Long SNOMED CT name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SNOMED_DESCRIPTION= "SNOMED_DESCRIPTION" ;

    /*
    * The index position of the column SNOMED_DESCRIPTION in the table.
    */
    public static final int SNOMED_DESCRIPTION_IDX = 7 ;

    /**
              * <p> Unique identifier for SNOMED.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SNOMED_CODE= "SNOMED_CODE" ;

    /*
    * The index position of the column SNOMED_CODE in the table.
    */
    public static final int SNOMED_CODE_IDX = 8 ;

    /**
              * <p> Identifier of the Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 9 ;

    /**
              * <p> Diagnosis starting date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FROM_DATE= "FROM_DATE" ;

    /*
    * The index position of the column FROM_DATE in the table.
    */
    public static final int FROM_DATE_IDX = 10 ;

    /**
              * <p> Diagnosis finishing date.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String TO_DATE= "TO_DATE" ;

    /*
    * The index position of the column TO_DATE in the table.
    */
    public static final int TO_DATE_IDX = 11 ;

    /**
              * <p> Comments about the diagnosis.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 12 ;

    /**
              * <p> Current Status of the diagnosis could be "ACTIVE","INACTIVE" or "RESOLVED".</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 13 ;

    /**
              * <p> Time of entry in milliseconds.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_ENTRY= "TIME_OF_ENTRY" ;

    /*
    * The index position of the column TIME_OF_ENTRY in the table.
    */
    public static final int TIME_OF_ENTRY_IDX = 14 ;

    /**
              * <p> Last Modified Time of the data.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_MODIFIED_TIME= "LAST_MODIFIED_TIME" ;

    /*
    * The index position of the column LAST_MODIFIED_TIME in the table.
    */
    public static final int LAST_MODIFIED_TIME_IDX = 15 ;

    /**
              * <p> Provider who has administered the dx.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 16 ;

}
