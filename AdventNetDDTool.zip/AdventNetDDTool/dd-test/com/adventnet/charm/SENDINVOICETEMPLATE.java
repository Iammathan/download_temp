package com.adventnet.charm;

/** <p> Description of the table <code>SendInvoiceTemplate</code>.
 *  Column Name and Table Name of  database table  <code>SendInvoiceTemplate</code> is mapped
 * as constants in this util.</p> 
  Used to store Treatment Codes / Product template items. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SEND_INVOICE_TEMPLATE_ID}
  * </ul>
 */
 
public final class SENDINVOICETEMPLATE
{
    private SENDINVOICETEMPLATE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SendInvoiceTemplate" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SEND_INVOICE_TEMPLATE_ID= "SEND_INVOICE_TEMPLATE_ID" ;

    /*
    * The index position of the column SEND_INVOICE_TEMPLATE_ID in the table.
    */
    public static final int SEND_INVOICE_TEMPLATE_ID_IDX = 1 ;

    /**
              * <p> TEMPLATE_ID from PhysicianTemplates table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TEMPLATE_ID= "TEMPLATE_ID" ;

    /*
    * The index position of the column TEMPLATE_ID in the table.
    */
    public static final int TEMPLATE_ID_IDX = 2 ;

    /**
              * <p> Subject of Email or PHR Message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SUBJECT= "SUBJECT" ;

    /*
    * The index position of the column SUBJECT in the table.
    */
    public static final int SUBJECT_IDX = 3 ;

    /**
              * <p> EMAIL or PHR MESSAGE 's content.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>65536</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MESSAGE_CONTENT= "MESSAGE_CONTENT" ;

    /*
    * The index position of the column MESSAGE_CONTENT in the table.
    */
    public static final int MESSAGE_CONTENT_IDX = 4 ;

    /**
              * <p> Is Superbill PDF attached with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_SUPERBILL_PDF= "IS_SUPERBILL_PDF" ;

    /*
    * The index position of the column IS_SUPERBILL_PDF in the table.
    */
    public static final int IS_SUPERBILL_PDF_IDX = 5 ;

    /**
              * <p> Is Invoice PDF attached with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_INVOICE_PDF= "IS_INVOICE_PDF" ;

    /*
    * The index position of the column IS_INVOICE_PDF in the table.
    */
    public static final int IS_INVOICE_PDF_IDX = 6 ;

    /**
              * <p> Is Invoice PDF attached with Invoice.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_INVOICE_PDF1= "IS_INVOICE_PDF1" ;

    /*
    * The index position of the column IS_INVOICE_PDF1 in the table.
    */
    public static final int IS_INVOICE_PDF1_IDX = 7 ;

    /**
              * <p> PDF file name attached to the mails.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PDF_FILE_NAME1= "PDF_FILE_NAME1" ;

    /*
    * The index position of the column PDF_FILE_NAME1 in the table.
    */
    public static final int PDF_FILE_NAME1_IDX = 8 ;

    /**
              * <p> PDF file name attached to the mails.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PDF_FILE_NAME2= "PDF_FILE_NAME2" ;

    /*
    * The index position of the column PDF_FILE_NAME2 in the table.
    */
    public static final int PDF_FILE_NAME2_IDX = 9 ;

}
