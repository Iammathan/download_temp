package com.adventnet.charm;

/** <p> Description of the table <code>ImageTests</code>.
 *  Column Name and Table Name of  database table  <code>ImageTests</code> is mapped
 * as constants in this util.</p> 
  Image Tests (Tests defined in each Image type). <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #IMAGE_TEST_ID}
  * </ul>
 */
 
public final class IMAGETESTS
{
    private IMAGETESTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ImageTests" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IMAGE_TEST_ID= "IMAGE_TEST_ID" ;

    /*
    * The index position of the column IMAGE_TEST_ID in the table.
    */
    public static final int IMAGE_TEST_ID_IDX = 1 ;

    /**
              * <p> Image Test code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String IMAGE_TEST_CODE= "IMAGE_TEST_CODE" ;

    /*
    * The index position of the column IMAGE_TEST_CODE in the table.
    */
    public static final int IMAGE_TEST_CODE_IDX = 2 ;

    /**
              * <p> Image Test Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String IMAGE_TEST= "IMAGE_TEST" ;

    /*
    * The index position of the column IMAGE_TEST in the table.
    */
    public static final int IMAGE_TEST_IDX = 3 ;

    /**
              * <p> Image type id to whom Image is Ordered.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IMAGE_TYPE_ID= "IMAGE_TYPE_ID" ;

    /*
    * The index position of the column IMAGE_TYPE_ID in the table.
    */
    public static final int IMAGE_TYPE_ID_IDX = 4 ;

    /**
              * <p> To indicate whether this image test is  deleted.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 5 ;

    /**
              * <p> LOINC CODE associated with this test.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LOINC_CODE= "LOINC_CODE" ;

    /*
    * The index position of the column LOINC_CODE in the table.
    */
    public static final int LOINC_CODE_IDX = 6 ;

}
