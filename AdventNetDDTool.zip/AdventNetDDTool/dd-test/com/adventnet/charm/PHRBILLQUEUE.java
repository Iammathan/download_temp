package com.adventnet.charm;

/** <p> Description of the table <code>PHRBillQueue</code>.
 *  Column Name and Table Name of  database table  <code>PHRBillQueue</code> is mapped
 * as constants in this util.</p> 
  Queue for pushing invoices from EHR to PHR. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PHR_BILL_QUEUE_ID}
  * </ul>
 */
 
public final class PHRBILLQUEUE
{
    private PHRBILLQUEUE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRBillQueue" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PHR_BILL_QUEUE_ID= "PHR_BILL_QUEUE_ID" ;

    /*
    * The index position of the column PHR_BILL_QUEUE_ID in the table.
    */
    public static final int PHR_BILL_QUEUE_ID_IDX = 1 ;

    /**
              * <p> Identifier of invoice/receipt.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ITEM_ID= "ITEM_ID" ;

    /*
    * The index position of the column ITEM_ID in the table.
    */
    public static final int ITEM_ID_IDX = 2 ;

    /**
              * <p> To hold additional information for pushing invoice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String META_INFO= "META_INFO" ;

    /*
    * The index position of the column META_INFO in the table.
    */
    public static final int META_INFO_IDX = 3 ;

}
