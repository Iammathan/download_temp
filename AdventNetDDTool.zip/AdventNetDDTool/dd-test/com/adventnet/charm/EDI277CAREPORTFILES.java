package com.adventnet.charm;

/** <p> Description of the table <code>EDI277CAReportFiles</code>.
 *  Column Name and Table Name of  database table  <code>EDI277CAReportFiles</code> is mapped
 * as constants in this util.</p> 
  This table maintains all the 277CA (Claim Acknowledgment) report files received from Clearinghouse - Change Health. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EDI_277CA_REPORT_FILE_ID}
  * </ul>
 */
 
public final class EDI277CAREPORTFILES
{
    private EDI277CAREPORTFILES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EDI277CAReportFiles" ;
    /**
              * <p> SAS Key - Unique Identifier for this table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EDI_277CA_REPORT_FILE_ID= "EDI_277CA_REPORT_FILE_ID" ;

    /*
    * The index position of the column EDI_277CA_REPORT_FILE_ID in the table.
    */
    public static final int EDI_277CA_REPORT_FILE_ID_IDX = 1 ;

    /**
              * <p> Name of the 277CA report file.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FILE_NAME= "FILE_NAME" ;

    /*
    * The index position of the column FILE_NAME in the table.
    */
    public static final int FILE_NAME_IDX = 2 ;

    /**
              * <p> Time on which this 277CA report file is added.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ADDED_TIME= "ADDED_TIME" ;

    /*
    * The index position of the column ADDED_TIME in the table.
    */
    public static final int ADDED_TIME_IDX = 3 ;

}
