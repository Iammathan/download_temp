package com.adventnet.charm;

/** <p> Description of the table <code>ActivityLabOrderMap</code>.
 *  Column Name and Table Name of  database table  <code>ActivityLabOrderMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Activity and Lab order. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ACTIVITY_LOG_ID}
  * </ul>
 */
 
public final class ACTIVITYLABORDERMAP
{
    private ACTIVITYLABORDERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ActivityLabOrderMap" ;
    /**
              * <p> Activity Log id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACTIVITY_LOG_ID= "ACTIVITY_LOG_ID" ;

    /*
    * The index position of the column ACTIVITY_LOG_ID in the table.
    */
    public static final int ACTIVITY_LOG_ID_IDX = 1 ;

    /**
              * <p> Lab order id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAB_ORDER_ID= "LAB_ORDER_ID" ;

    /*
    * The index position of the column LAB_ORDER_ID in the table.
    */
    public static final int LAB_ORDER_ID_IDX = 2 ;

}
