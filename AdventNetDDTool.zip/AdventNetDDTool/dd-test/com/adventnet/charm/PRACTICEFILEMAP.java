package com.adventnet.charm;

/** <p> Description of the table <code>PracticeFileMap</code>.
 *  Column Name and Table Name of  database table  <code>PracticeFileMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between practice and uploaded files. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FILE_ID}
  * </ul>
 */
 
public final class PRACTICEFILEMAP
{
    private PRACTICEFILEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeFileMap" ;
    /**
              * <p> Identifier of file.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 1 ;

    /**
              * <p> To check whether the uploaded files for physician specific or practice specific.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_PRACTICE_SPECIFIC= "IS_PRACTICE_SPECIFIC" ;

    /*
    * The index position of the column IS_PRACTICE_SPECIFIC in the table.
    */
    public static final int IS_PRACTICE_SPECIFIC_IDX = 2 ;

    /**
              * <p> Identifier  of the folder.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FOLDER_ID= "FOLDER_ID" ;

    /*
    * The index position of the column FOLDER_ID in the table.
    */
    public static final int FOLDER_ID_IDX = 3 ;

}
