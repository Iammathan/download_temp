package com.adventnet.charm;

/** <p> Description of the table <code>ExostarOrders</code>.
 *  Column Name and Table Name of  database table  <code>ExostarOrders</code> is mapped
 * as constants in this util.</p> 
  Stores details about the txn with exostar. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EXO_ORDER_ID}
  * </ul>
 */
 
public final class EXOSTARORDERS
{
    private EXOSTARORDERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ExostarOrders" ;
    /**
              * <p> Pk of ExostarOrders.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EXO_ORDER_ID= "EXO_ORDER_ID" ;

    /*
    * The index position of the column EXO_ORDER_ID in the table.
    */
    public static final int EXO_ORDER_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ORDER_ID= "ORDER_ID" ;

    /*
    * The index position of the column ORDER_ID in the table.
    */
    public static final int ORDER_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ORDER_TAG= "ORDER_TAG" ;

    /*
    * The index position of the column ORDER_TAG in the table.
    */
    public static final int ORDER_TAG_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                     * Default Value is <code>invoice</code>. <br>
                            * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>invoice</code></li>
              * <li><code>credit</code></li>
              * </ul>
                         */
    public static final String PAYMENT_METHOD= "PAYMENT_METHOD" ;

    /*
    * The index position of the column PAYMENT_METHOD in the table.
    */
    public static final int PAYMENT_METHOD_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>New</code></li>
              * <li><code>Renewal</code></li>
              * <li><code>Upgrade</code></li>
              * </ul>
                         */
    public static final String ORDER_TYPE= "ORDER_TYPE" ;

    /*
    * The index position of the column ORDER_TYPE in the table.
    */
    public static final int ORDER_TYPE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>submitted</code></li>
              * <li><code>pendingPayment</code></li>
              * <li><code>processing</code></li>
              * <li><code>completed</code></li>
              * </ul>
                         */
    public static final String ORDER_STATUS= "ORDER_STATUS" ;

    /*
    * The index position of the column ORDER_STATUS in the table.
    */
    public static final int ORDER_STATUS_IDX = 6 ;

    /**
              * <p> Data added into system.</p>
                            * Data Type of this field is <code>DATETIME</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ORDERED_DATE= "ORDERED_DATE" ;

    /*
    * The index position of the column ORDERED_DATE in the table.
    */
    public static final int ORDERED_DATE_IDX = 7 ;

    /**
              * <p> Member Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ORDERED_BY= "ORDERED_BY" ;

    /*
    * The index position of the column ORDERED_BY in the table.
    */
    public static final int ORDERED_BY_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_ID= "PRACTICE_ID" ;

    /*
    * The index position of the column PRACTICE_ID in the table.
    */
    public static final int PRACTICE_ID_IDX = 9 ;

    /**
              * <p> Identifier of the facility.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 10 ;

    /**
              * <p> payment transaction id.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>500</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PAYMENT_TRANSACTION_ID= "PAYMENT_TRANSACTION_ID" ;

    /*
    * The index position of the column PAYMENT_TRANSACTION_ID in the table.
    */
    public static final int PAYMENT_TRANSACTION_ID_IDX = 11 ;

}
