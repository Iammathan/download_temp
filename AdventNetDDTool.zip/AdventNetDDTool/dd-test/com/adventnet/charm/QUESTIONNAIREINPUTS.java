package com.adventnet.charm;

/** <p> Description of the table <code>QuestionnaireInputs</code>.
 *  Column Name and Table Name of  database table  <code>QuestionnaireInputs</code> is mapped
 * as constants in this util.</p> 
  Answers filled by patient before consulation. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #QUESTION_ID}
  * <li> {@link #APPOINTMENT_ID}
  * </ul>
 */
 
public final class QUESTIONNAIREINPUTS
{
    private QUESTIONNAIREINPUTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "QuestionnaireInputs" ;
    /**
              * <p> Question ID.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String QUESTION_ID= "QUESTION_ID" ;

    /*
    * The index position of the column QUESTION_ID in the table.
    */
    public static final int QUESTION_ID_IDX = 1 ;

    /**
              * <p> Appointment ID .</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String APPOINTMENT_ID= "APPOINTMENT_ID" ;

    /*
    * The index position of the column APPOINTMENT_ID in the table.
    */
    public static final int APPOINTMENT_ID_IDX = 2 ;

    /**
              * <p> Answer that is filled by patient before consultation.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ANSWER= "ANSWER" ;

    /*
    * The index position of the column ANSWER in the table.
    */
    public static final int ANSWER_IDX = 3 ;

}
