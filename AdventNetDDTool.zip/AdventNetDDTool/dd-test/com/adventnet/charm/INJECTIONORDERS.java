package com.adventnet.charm;

/** <p> Description of the table <code>InjectionOrders</code>.
 *  Column Name and Table Name of  database table  <code>InjectionOrders</code> is mapped
 * as constants in this util.</p> 
  Injections orders with and without consultation. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INJECTION_ORDER_ID}
  * </ul>
 */
 
public final class INJECTIONORDERS
{
    private INJECTIONORDERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InjectionOrders" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INJECTION_ORDER_ID= "INJECTION_ORDER_ID" ;

    /*
    * The index position of the column INJECTION_ORDER_ID in the table.
    */
    public static final int INJECTION_ORDER_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ORDERED_TIME= "ORDERED_TIME" ;

    /*
    * The index position of the column ORDERED_TIME in the table.
    */
    public static final int ORDERED_TIME_IDX = 2 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ORDERED_DATE_TIME= "ORDERED_DATE_TIME" ;

    /*
    * The index position of the column ORDERED_DATE_TIME in the table.
    */
    public static final int ORDERED_DATE_TIME_IDX = 3 ;

    /**
              * <p> Facility Id.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 4 ;

}
