package com.adventnet.charm;

/** <p> Description of the table <code>PatientPrescriptionMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientPrescriptionMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Prescription. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRESCRIPTION_MAP_ID}
  * </ul>
 */
 
public final class PATIENTPRESCRIPTIONMAP
{
    private PATIENTPRESCRIPTIONMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientPrescriptionMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRESCRIPTION_MAP_ID= "PRESCRIPTION_MAP_ID" ;

    /*
    * The index position of the column PRESCRIPTION_MAP_ID in the table.
    */
    public static final int PRESCRIPTION_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Prescription.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRESCRIPTION_ID= "PRESCRIPTION_ID" ;

    /*
    * The index position of the column PRESCRIPTION_ID in the table.
    */
    public static final int PRESCRIPTION_ID_IDX = 3 ;

}
