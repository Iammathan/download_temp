package com.adventnet.charm;

/** <p> Description of the table <code>UB04RevenueCodes</code>.
 *  Column Name and Table Name of  database table  <code>UB04RevenueCodes</code> is mapped
 * as constants in this util.</p> 
   . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #UB04_REV_CODE_ID}
  * </ul>
 */
 
public final class UB04REVENUECODES
{
    private UB04REVENUECODES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "UB04RevenueCodes" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_REV_CODE_ID= "UB04_REV_CODE_ID" ;

    /*
    * The index position of the column UB04_REV_CODE_ID in the table.
    */
    public static final int UB04_REV_CODE_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String UB04_REV_CAT_ID= "UB04_REV_CAT_ID" ;

    /*
    * The index position of the column UB04_REV_CAT_ID in the table.
    */
    public static final int UB04_REV_CAT_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>4</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVENUE_CODE= "REVENUE_CODE" ;

    /*
    * The index position of the column REVENUE_CODE in the table.
    */
    public static final int REVENUE_CODE_IDX = 3 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>24</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVENUE_DESC= "REVENUE_DESC" ;

    /*
    * The index position of the column REVENUE_DESC in the table.
    */
    public static final int REVENUE_DESC_IDX = 4 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVENUE_SUB_CAT_CODE= "REVENUE_SUB_CAT_CODE" ;

    /*
    * The index position of the column REVENUE_SUB_CAT_CODE in the table.
    */
    public static final int REVENUE_SUB_CAT_CODE_IDX = 5 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String REVENUE_FULL_DESC= "REVENUE_FULL_DESC" ;

    /*
    * The index position of the column REVENUE_FULL_DESC in the table.
    */
    public static final int REVENUE_FULL_DESC_IDX = 6 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 8 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 9 ;

}
