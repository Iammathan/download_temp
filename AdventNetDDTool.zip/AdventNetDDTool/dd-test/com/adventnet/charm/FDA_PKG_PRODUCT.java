package com.adventnet.charm;

/** <p> Description of the table <code>FDA_PKG_PRODUCT</code>.
 *  Column Name and Table Name of  database table  <code>FDA_PKG_PRODUCT</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #FDA_PKG_PRODUCT_ID}
  * </ul>
 */
 
public final class FDA_PKG_PRODUCT
{
    private FDA_PKG_PRODUCT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "FDA_PKG_PRODUCT" ;
    /**
              * <p> PK of FDA_PKG_PRODUCT.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FDA_PKG_PRODUCT_ID= "FDA_PKG_PRODUCT_ID" ;

    /*
    * The index position of the column FDA_PKG_PRODUCT_ID in the table.
    */
    public static final int FDA_PKG_PRODUCT_ID_IDX = 1 ;

    /**
              * <p> Unique identifier from FDA_PRODUCT.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FDA_PRODUCT_ID= "FDA_PRODUCT_ID" ;

    /*
    * The index position of the column FDA_PRODUCT_ID in the table.
    */
    public static final int FDA_PRODUCT_ID_IDX = 2 ;

    /**
              * <p> 10 digit ndc.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PACKAGE_NDC_FORMATTED= "PACKAGE_NDC_FORMATTED" ;

    /*
    * The index position of the column PACKAGE_NDC_FORMATTED in the table.
    */
    public static final int PACKAGE_NDC_FORMATTED_IDX = 3 ;

    /**
              * <p> 10 digit ndc un formatted.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PACKAGE_NDC= "PACKAGE_NDC" ;

    /*
    * The index position of the column PACKAGE_NDC in the table.
    */
    public static final int PACKAGE_NDC_IDX = 4 ;

    /**
              * <p> DESCRIPTION.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DESCRIPTION= "DESCRIPTION" ;

    /*
    * The index position of the column DESCRIPTION in the table.
    */
    public static final int DESCRIPTION_IDX = 5 ;

    /**
              * <p> MARKETING_START_DATE.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MARKETING_START_DATE= "MARKETING_START_DATE" ;

    /*
    * The index position of the column MARKETING_START_DATE in the table.
    */
    public static final int MARKETING_START_DATE_IDX = 6 ;

}
