package com.adventnet.charm;

/** <p> Description of the table <code>SpecialCSDrugsDetails</code>.
 *  Column Name and Table Name of  database table  <code>SpecialCSDrugsDetails</code> is mapped
 * as constants in this util.</p> 
  CS drugs used for de-toxification and GHB drug mandate notes to pharamacy in public space. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #SPL_CS_DRUG_ID}
  * </ul>
 */
 
public final class SPECIALCSDRUGSDETAILS
{
    private SPECIALCSDRUGSDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SpecialCSDrugsDetails" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SPL_CS_DRUG_ID= "SPL_CS_DRUG_ID" ;

    /*
    * The index position of the column SPL_CS_DRUG_ID in the table.
    */
    public static final int SPL_CS_DRUG_ID_IDX = 1 ;

    /**
              * <p> Trade name of the drug as in LEXI drug DB.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_TRADE_NAME= "DRUG_TRADE_NAME" ;

    /*
    * The index position of the column DRUG_TRADE_NAME in the table.
    */
    public static final int DRUG_TRADE_NAME_IDX = 2 ;

    /**
              * <p> De-toxification / GHB drug .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String TYPE_OF_SPECIALITY= "TYPE_OF_SPECIALITY" ;

    /*
    * The index position of the column TYPE_OF_SPECIALITY in the table.
    */
    public static final int TYPE_OF_SPECIALITY_IDX = 3 ;

}
