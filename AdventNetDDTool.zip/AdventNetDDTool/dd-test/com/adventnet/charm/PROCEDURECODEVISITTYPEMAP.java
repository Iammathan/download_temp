package com.adventnet.charm;

/** <p> Description of the table <code>ProcedureCodeVisitTypeMap</code>.
 *  Column Name and Table Name of  database table  <code>ProcedureCodeVisitTypeMap</code> is mapped
 * as constants in this util.</p> 
  Maintains Procedure Code Vs Visit Type mapping. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CODE_VISIT_MAP_ID}
  * </ul>
 */
 
public final class PROCEDURECODEVISITTYPEMAP
{
    private PROCEDURECODEVISITTYPEMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ProcedureCodeVisitTypeMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CODE_VISIT_MAP_ID= "CODE_VISIT_MAP_ID" ;

    /*
    * The index position of the column CODE_VISIT_MAP_ID in the table.
    */
    public static final int CODE_VISIT_MAP_ID_IDX = 1 ;

    /**
              * <p> Visit Type Id - PK of EncounterType .</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENCOUNTER_TYPE_ID= "ENCOUNTER_TYPE_ID" ;

    /*
    * The index position of the column ENCOUNTER_TYPE_ID in the table.
    */
    public static final int ENCOUNTER_TYPE_ID_IDX = 2 ;

    /**
              * <p> Code id of ProcedureCodeVisitTypeMap table.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CODE_ID= "CODE_ID" ;

    /*
    * The index position of the column CODE_ID in the table.
    */
    public static final int CODE_ID_IDX = 3 ;

}
