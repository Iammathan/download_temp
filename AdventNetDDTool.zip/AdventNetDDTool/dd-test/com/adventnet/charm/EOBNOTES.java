package com.adventnet.charm;

/** <p> Description of the table <code>EOBNotes</code>.
 *  Column Name and Table Name of  database table  <code>EOBNotes</code> is mapped
 * as constants in this util.</p> 
  Manually Added EOB related notes are stored in this table. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #EOB_NOTES_ID}
  * </ul>
 */
 
public final class EOBNOTES
{
    private EOBNOTES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EOBNotes" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EOB_NOTES_ID= "EOB_NOTES_ID" ;

    /*
    * The index position of the column EOB_NOTES_ID in the table.
    */
    public static final int EOB_NOTES_ID_IDX = 1 ;

    /**
              * <p> EOB Details table Primary key.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String EOB_ID= "EOB_ID" ;

    /*
    * The index position of the column EOB_ID in the table.
    */
    public static final int EOB_ID_IDX = 2 ;

    /**
              * <p> Member's Name who has added the EOB note.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ADDED_BY= "ADDED_BY" ;

    /*
    * The index position of the column ADDED_BY in the table.
    */
    public static final int ADDED_BY_IDX = 3 ;

    /**
              * <p> the claim notes created time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TIME_OF_CREATION= "TIME_OF_CREATION" ;

    /*
    * The index position of the column TIME_OF_CREATION in the table.
    */
    public static final int TIME_OF_CREATION_IDX = 4 ;

    /**
              * <p> Claim Notes.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 5 ;

    /**
              * <p> Used to identitfy whether note is added by user or by system for EOB history.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>true</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_USER_NOTES= "IS_USER_NOTES" ;

    /*
    * The index position of the column IS_USER_NOTES in the table.
    */
    public static final int IS_USER_NOTES_IDX = 6 ;

}
