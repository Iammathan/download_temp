package com.adventnet.charm;

/** <p> Description of the table <code>ClaimServiceLineProviders</code>.
 *  Column Name and Table Name of  database table  <code>ClaimServiceLineProviders</code> is mapped
 * as constants in this util.</p> 
  This table maintain the provider(s) detail that are given in the service line level, whereas "ClaimProviderDetails" table keeps claim level provider details . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_SERVICE_LINE_PROVIDER_ID}
  * </ul>
 */
 
public final class CLAIMSERVICELINEPROVIDERS
{
    private CLAIMSERVICELINEPROVIDERS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ClaimServiceLineProviders" ;
    /**
              * <p> Unique surrogate key provided by Mickey .</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_SERVICE_LINE_PROVIDER_ID= "CLAIM_SERVICE_LINE_PROVIDER_ID" ;

    /*
    * The index position of the column CLAIM_SERVICE_LINE_PROVIDER_ID in the table.
    */
    public static final int CLAIM_SERVICE_LINE_PROVIDER_ID_IDX = 1 ;

    /**
              * <p> Original Reference Id(PK) of this provider(For eg: 'referring' provider this is ReferringProviderDetails-PK). This will not be used in the claim workflow; this is just for a reference..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROVIDER_ID= "PROVIDER_ID" ;

    /*
    * The index position of the column PROVIDER_ID in the table.
    */
    public static final int PROVIDER_ID_IDX = 2 ;

    /**
              * <p> Identifiers whether this provider is an Individual OR Organizational entity. For eg, 'Service Facilyt/Provider' this will alwasy be 'true', and for 'Referring Provider' this will alwasy be 'false'.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String IS_ORGANIZATION= "IS_ORGANIZATION" ;

    /*
    * The index position of the column IS_ORGANIZATION in the table.
    */
    public static final int IS_ORGANIZATION_IDX = 3 ;

    /**
              * <p> Contains Full Name[First name , Middle Name , Last Name] for Non-organizational providers and Organization name for Organizational Provider entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>120</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_NAME= "PROVIDER_NAME" ;

    /*
    * The index position of the column PROVIDER_NAME in the table.
    */
    public static final int PROVIDER_NAME_IDX = 4 ;

    /**
              * <p> Contains 'Last Name' of this provider, if provider is an Individual.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_LAST_NAME= "PROVIDER_LAST_NAME" ;

    /*
    * The index position of the column PROVIDER_LAST_NAME in the table.
    */
    public static final int PROVIDER_LAST_NAME_IDX = 5 ;

    /**
              * <p> Contains 'Last Name' of this provider, if provider is an Individual.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_FIRST_NAME= "PROVIDER_FIRST_NAME" ;

    /*
    * The index position of the column PROVIDER_FIRST_NAME in the table.
    */
    public static final int PROVIDER_FIRST_NAME_IDX = 6 ;

    /**
              * <p> Contains 'Middle Name' of this provider, if provider is an Individual.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_MIDDLE_NAME= "PROVIDER_MIDDLE_NAME" ;

    /*
    * The index position of the column PROVIDER_MIDDLE_NAME in the table.
    */
    public static final int PROVIDER_MIDDLE_NAME_IDX = 7 ;

    /**
              * <p> Type of this provider. For different type(s) check the allowed-values list.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>rendering</code></li>
              * <li><code>outsidelab</code></li>
              * <li><code>facility</code></li>
              * <li><code>referring</code></li>
              * </ul>
                         */
    public static final String TYPE= "TYPE" ;

    /*
    * The index position of the column TYPE in the table.
    */
    public static final int TYPE_IDX = 8 ;

    /**
              * <p> Type of Referring Provider(DN(Referring provider), DK(Ordering Provider), DQ(Supervising Provider)) for 02/12 cms1500 form.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>DN</code></li>
              * <li><code>DK</code></li>
              * <li><code>DQ</code></li>
              * </ul>
                         */
    public static final String REF_PROVIDER_TYPE= "REF_PROVIDER_TYPE" ;

    /*
    * The index position of the column REF_PROVIDER_TYPE in the table.
    */
    public static final int REF_PROVIDER_TYPE_IDX = 9 ;

    /**
              * <p> NPI of this provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 10 ;

    /**
              * <p> Unique ID of the selected ID Type(QualifierList-PK).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 11 ;

    /**
              * <p> Identifier value for the selected ID Type.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 12 ;

    /**
              * <p> Claim ServiceLine Provider's Taxonomy Code - a unique ten character alphanumeric code that enables providers to identify their specialty. These codes are assigned at both the individual provider and organizational provider level..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String TAXONOMY_CODE= "TAXONOMY_CODE" ;

    /*
    * The index position of the column TAXONOMY_CODE in the table.
    */
    public static final int TAXONOMY_CODE_IDX = 13 ;

    /**
              * <p> Unique ID(PK) of the PostalAddress table, where this provider's postal address detail is stored. It may available only for 'Service Facility/Provider' and 'Ordering Provider'.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 14 ;

    /**
              * <p> Name of the contact person for this provider entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONTACT_PERSON_NAME= "CONTACT_PERSON_NAME" ;

    /*
    * The index position of the column CONTACT_PERSON_NAME in the table.
    */
    public static final int CONTACT_PERSON_NAME_IDX = 15 ;

    /**
              * <p> Unique ID(PK) of the ContactDetails table, where this provider's contact detail is stored. It may available only for 'Service Facility/Provider' and 'Ordering Provider'.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 16 ;

}
