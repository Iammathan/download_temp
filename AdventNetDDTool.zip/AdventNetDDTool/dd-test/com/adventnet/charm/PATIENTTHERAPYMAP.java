package com.adventnet.charm;

/** <p> Description of the table <code>PatientTherapyMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientTherapyMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Therapy. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #THERAPY_MAP_ID}
  * </ul>
 */
 
public final class PATIENTTHERAPYMAP
{
    private PATIENTTHERAPYMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientTherapyMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String THERAPY_MAP_ID= "THERAPY_MAP_ID" ;

    /*
    * The index position of the column THERAPY_MAP_ID in the table.
    */
    public static final int THERAPY_MAP_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String THERAPY_ID= "THERAPY_ID" ;

    /*
    * The index position of the column THERAPY_ID in the table.
    */
    public static final int THERAPY_ID_IDX = 3 ;

}
