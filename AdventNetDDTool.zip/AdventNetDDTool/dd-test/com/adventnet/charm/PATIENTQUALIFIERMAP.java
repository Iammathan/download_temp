package com.adventnet.charm;

/** <p> Description of the table <code>PatientQualifierMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientQualifierMap</code> is mapped
 * as constants in this util.</p> 
  Patient's ID Qualifier details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PATIENT_QUALIFIER_MAP_ID}
  * </ul>
 */
 
public final class PATIENTQUALIFIERMAP
{
    private PATIENTQUALIFIERMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientQualifierMap" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PATIENT_QUALIFIER_MAP_ID= "PATIENT_QUALIFIER_MAP_ID" ;

    /*
    * The index position of the column PATIENT_QUALIFIER_MAP_ID in the table.
    */
    public static final int PATIENT_QUALIFIER_MAP_ID_IDX = 1 ;

    /**
              * <p> Unique identifier.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> CommonQualifierList.ID_QUALIFIER.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 3 ;

    /**
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID_OF_PATIENT= "ID_OF_PATIENT" ;

    /*
    * The index position of the column ID_OF_PATIENT in the table.
    */
    public static final int ID_OF_PATIENT_IDX = 4 ;

    /**
              * <p> UploadedFiles.FILE_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String FILE_ID= "FILE_ID" ;

    /*
    * The index position of the column FILE_ID in the table.
    */
    public static final int FILE_ID_IDX = 5 ;

}
