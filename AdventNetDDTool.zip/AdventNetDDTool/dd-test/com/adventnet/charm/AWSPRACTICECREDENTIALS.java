package com.adventnet.charm;

/** <p> Description of the table <code>AWSPracticeCredentials</code>.
 *  Column Name and Table Name of  database table  <code>AWSPracticeCredentials</code> is mapped
 * as constants in this util.</p> 
   Contains the aws credentials of the practice . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AWS_PRACTICE_CREDENTIAL_ID}
  * </ul>
 */
 
public final class AWSPRACTICECREDENTIALS
{
    private AWSPRACTICECREDENTIALS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AWSPracticeCredentials" ;
    /**
              * <p> Primary Key for AWS user credentials table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_PRACTICE_CREDENTIAL_ID= "AWS_PRACTICE_CREDENTIAL_ID" ;

    /*
    * The index position of the column AWS_PRACTICE_CREDENTIAL_ID in the table.
    */
    public static final int AWS_PRACTICE_CREDENTIAL_ID_IDX = 1 ;

    /**
              * <p> This will contain the practice id..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_AWS_USER_NAME= "PRACTICE_AWS_USER_NAME" ;

    /*
    * The index position of the column PRACTICE_AWS_USER_NAME in the table.
    */
    public static final int PRACTICE_AWS_USER_NAME_IDX = 2 ;

    /**
              * <p> Contains the region name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REGION_NAME= "REGION_NAME" ;

    /*
    * The index position of the column REGION_NAME in the table.
    */
    public static final int REGION_NAME_IDX = 3 ;

    /**
              * <p> Access key of the user.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCESS_KEY= "ACCESS_KEY" ;

    /*
    * The index position of the column ACCESS_KEY in the table.
    */
    public static final int ACCESS_KEY_IDX = 4 ;

    /**
              * <p> Secret access key of the user.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String SECRET_ACCESS_KEY= "SECRET_ACCESS_KEY" ;

    /*
    * The index position of the column SECRET_ACCESS_KEY in the table.
    */
    public static final int SECRET_ACCESS_KEY_IDX = 5 ;

    /**
              * <p>  Contains the time that when the keys are created for the user.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ACCESS_KEY_LAST_CREATED_ON= "ACCESS_KEY_LAST_CREATED_ON" ;

    /*
    * The index position of the column ACCESS_KEY_LAST_CREATED_ON in the table.
    */
    public static final int ACCESS_KEY_LAST_CREATED_ON_IDX = 6 ;

    /**
              * <p>  Contains the name of the IAM user which created the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>250</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ACCESS_KEYS_CREATED_BY= "ACCESS_KEYS_CREATED_BY" ;

    /*
    * The index position of the column ACCESS_KEYS_CREATED_BY in the table.
    */
    public static final int ACCESS_KEYS_CREATED_BY_IDX = 7 ;

    /**
              * <p> Contains boolean value that whether user is active or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String IS_ACTIVE= "IS_ACTIVE" ;

    /*
    * The index position of the column IS_ACTIVE in the table.
    */
    public static final int IS_ACTIVE_IDX = 8 ;

    /**
              * <p>  Contains the time that when the user is deactivated.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DEACTIVATED_DATE= "DEACTIVATED_DATE" ;

    /*
    * The index position of the column DEACTIVATED_DATE in the table.
    */
    public static final int DEACTIVATED_DATE_IDX = 9 ;

}
