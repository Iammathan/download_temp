package com.adventnet.charm;

/** <p> Description of the table <code>RCMRuleTypes</code>.
 *  Column Name and Table Name of  database table  <code>RCMRuleTypes</code> is mapped
 * as constants in this util.</p> 
  set of rule types aiding for medical coding. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_RULE_TYPE_ID}
  * </ul>
 */
 
public final class RCMRULETYPES
{
    private RCMRULETYPES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMRuleTypes" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_RULE_TYPE_ID= "RCM_RULE_TYPE_ID" ;

    /*
    * The index position of the column RCM_RULE_TYPE_ID in the table.
    */
    public static final int RCM_RULE_TYPE_ID_IDX = 1 ;

    /**
              * <p> Type of the rule.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RCM_RULE_TYPE= "RCM_RULE_TYPE" ;

    /*
    * The index position of the column RCM_RULE_TYPE in the table.
    */
    public static final int RCM_RULE_TYPE_IDX = 2 ;

    /**
              * <p> Description of the rule.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RCM_RULE_DESC= "RCM_RULE_DESC" ;

    /*
    * The index position of the column RCM_RULE_DESC in the table.
    */
    public static final int RCM_RULE_DESC_IDX = 3 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_USER_DEFINED_RULE= "IS_USER_DEFINED_RULE" ;

    /*
    * The index position of the column IS_USER_DEFINED_RULE in the table.
    */
    public static final int IS_USER_DEFINED_RULE_IDX = 4 ;

}
