package com.adventnet.charm;

/** <p> Description of the table <code>InjectionList</code>.
 *  Column Name and Table Name of  database table  <code>InjectionList</code> is mapped
 * as constants in this util.</p> 
  Injection list. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #INJECTION_ID}
  * </ul>
 */
 
public final class INJECTIONLIST
{
    private INJECTIONLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "InjectionList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String INJECTION_ID= "INJECTION_ID" ;

    /*
    * The index position of the column INJECTION_ID in the table.
    */
    public static final int INJECTION_ID_IDX = 1 ;

    /**
              * <p> Name of Injection given by physician.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String INJECTION_NAME= "INJECTION_NAME" ;

    /*
    * The index position of the column INJECTION_NAME in the table.
    */
    public static final int INJECTION_NAME_IDX = 2 ;

    /**
              * <p> To indicate whether this injection is deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 3 ;

}
