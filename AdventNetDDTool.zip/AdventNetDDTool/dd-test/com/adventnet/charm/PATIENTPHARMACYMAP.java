package com.adventnet.charm;

/** <p> Description of the table <code>PatientPharmacyMap</code>.
 *  Column Name and Table Name of  database table  <code>PatientPharmacyMap</code> is mapped
 * as constants in this util.</p> 
  Mapping between Patient and Pharmacy. <br>
   * 
  * Primary Keys for this definition are  <br>
  <ul>
  * <li> {@link #PATIENT_ID}
  * <li> {@link #PHARMACY_ID}
  * </ul>
 */
 
public final class PATIENTPHARMACYMAP
{
    private PATIENTPHARMACYMAP()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PatientPharmacyMap" ;
    /**
              * <p> To idendify the Patient.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 1 ;

    /**
              * <p> To identify the Pharmacy.</p>
                            * This column is one of the Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PHARMACY_ID= "PHARMACY_ID" ;

    /*
    * The index position of the column PHARMACY_ID in the table.
    */
    public static final int PHARMACY_ID_IDX = 2 ;

}
