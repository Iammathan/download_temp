package com.adventnet.charm;

/** <p> Description of the table <code>RCMClaimGuarantorDetails</code>.
 *  Column Name and Table Name of  database table  <code>RCMClaimGuarantorDetails</code> is mapped
 * as constants in this util.</p> 
  RCM Claim patient Guarantor details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #CLAIM_GUARANTOR_ID}
  * </ul>
 */
 
public final class RCMCLAIMGUARANTORDETAILS
{
    private RCMCLAIMGUARANTORDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMClaimGuarantorDetails" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CLAIM_GUARANTOR_ID= "CLAIM_GUARANTOR_ID" ;

    /*
    * The index position of the column CLAIM_GUARANTOR_ID in the table.
    */
    public static final int CLAIM_GUARANTOR_ID_IDX = 1 ;

    /**
              * <p> First name of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 2 ;

    /**
              * <p> Last name of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIDDLE_NAME= "MIDDLE_NAME" ;

    /*
    * The index position of the column MIDDLE_NAME in the table.
    */
    public static final int MIDDLE_NAME_IDX = 3 ;

    /**
              * <p> Last name of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 4 ;

    /**
              * <p> Gender of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 5 ;

    /**
              * <p> Date of birth of Guarantor.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DATE_OF_BIRTH= "DATE_OF_BIRTH" ;

    /*
    * The index position of the column DATE_OF_BIRTH in the table.
    */
    public static final int DATE_OF_BIRTH_IDX = 6 ;

    /**
              * <p> marital status of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MARITAL_STATUS= "MARITAL_STATUS" ;

    /*
    * The index position of the column MARITAL_STATUS in the table.
    */
    public static final int MARITAL_STATUS_IDX = 7 ;

    /**
              * <p> Employment status of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMPLOYMENT_STATUS= "EMPLOYMENT_STATUS" ;

    /*
    * The index position of the column EMPLOYMENT_STATUS in the table.
    */
    public static final int EMPLOYMENT_STATUS_IDX = 8 ;

    /**
              * <p> Postal address id - PK of PostalAddress.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 9 ;

    /**
              * <p> Social security number.</p>
                            * Data Type of this field is <code>SCHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String SSN= "SSN" ;

    /*
    * The index position of the column SSN in the table.
    */
    public static final int SSN_IDX = 10 ;

    /**
              * <p> Id for Mapping ContactDetails and Guarantor Profile.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 11 ;

    /**
              * <p> Employer name of the Guarantor.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String EMPLOYER_NAME= "EMPLOYER_NAME" ;

    /*
    * The index position of the column EMPLOYER_NAME in the table.
    */
    public static final int EMPLOYER_NAME_IDX = 12 ;

    /**
              * <p> Employer Postal address id - PK of PostalAddress.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String EMPLOYER_ADDRESS_ID= "EMPLOYER_ADDRESS_ID" ;

    /*
    * The index position of the column EMPLOYER_ADDRESS_ID in the table.
    */
    public static final int EMPLOYER_ADDRESS_ID_IDX = 13 ;

    /**
              * <p> Patient relationship with guarantor person.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>20</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RELATIONSHIP= "RELATIONSHIP" ;

    /*
    * The index position of the column RELATIONSHIP in the table.
    */
    public static final int RELATIONSHIP_IDX = 14 ;

}
