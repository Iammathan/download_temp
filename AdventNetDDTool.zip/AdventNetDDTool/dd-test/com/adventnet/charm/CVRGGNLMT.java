package com.adventnet.charm;

/** <p> Description of the table <code>CvrgGnLmt</code>.
 *  Column Name and Table Name of  database table  <code>CvrgGnLmt</code> is mapped
 * as constants in this util.</p> 
  Weekly downloaded list from surescripts for coverage gender limit. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #GL_DOWNLOAD_ID}
  * </ul>
 */
 
public final class CVRGGNLMT
{
    private CVRGGNLMT()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "CvrgGnLmt" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String GL_DOWNLOAD_ID= "GL_DOWNLOAD_ID" ;

    /*
    * The index position of the column GL_DOWNLOAD_ID in the table.
    */
    public static final int GL_DOWNLOAD_ID_IDX = 1 ;

    /**
              * <p> PBM unique ID for surescripts.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String PBM_PARTICIPANT_ID= "PBM_PARTICIPANT_ID" ;

    /*
    * The index position of the column PBM_PARTICIPANT_ID in the table.
    */
    public static final int PBM_PARTICIPANT_ID_IDX = 2 ;

    /**
              * <p> Coverage ID from eligibility response.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>40</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COVERAGE_ID= "COVERAGE_ID" ;

    /*
    * The index position of the column COVERAGE_ID in the table.
    */
    public static final int COVERAGE_ID_IDX = 3 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>19</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_ID= "DRUG_ID" ;

    /*
    * The index position of the column DRUG_ID in the table.
    */
    public static final int DRUG_ID_IDX = 4 ;

    /**
              * <p> Coverage list ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COVERAGE_LIST_ID= "COVERAGE_LIST_ID" ;

    /*
    * The index position of the column COVERAGE_LIST_ID in the table.
    */
    public static final int COVERAGE_LIST_ID_IDX = 5 ;

    /**
              * <p> Coverage list type (TM).</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COVERAGE_LIST_TYPE= "COVERAGE_LIST_TYPE" ;

    /*
    * The index position of the column COVERAGE_LIST_TYPE in the table.
    */
    public static final int COVERAGE_LIST_TYPE_IDX = 6 ;

    /**
              * <p> Date the list goes into effect.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EFFECTIVE_DATE= "EFFECTIVE_DATE" ;

    /*
    * The index position of the column EFFECTIVE_DATE in the table.
    */
    public static final int EFFECTIVE_DATE_IDX = 7 ;

    /**
              * <p> only Add is supported now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CHANGE_IDENTIFIER= "CHANGE_IDENTIFIER" ;

    /*
    * The index position of the column CHANGE_IDENTIFIER in the table.
    */
    public static final int CHANGE_IDENTIFIER_IDX = 8 ;

    /**
              * <p> NDC only supported for now.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String DRUG_ID_QUALIFIER= "DRUG_ID_QUALIFIER" ;

    /*
    * The index position of the column DRUG_ID_QUALIFIER in the table.
    */
    public static final int DRUG_ID_QUALIFIER_IDX = 9 ;

    /**
              * <p> Identifier for the drug from proprietary code sources.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DRUG_REFERENCE_NUMBER= "DRUG_REFERENCE_NUMBER" ;

    /*
    * The index position of the column DRUG_REFERENCE_NUMBER in the table.
    */
    public static final int DRUG_REFERENCE_NUMBER_IDX = 10 ;

    /**
              * <p> Type of drug reference number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DRUG_REFERENCE_QUALIFIER= "DRUG_REFERENCE_QUALIFIER" ;

    /*
    * The index position of the column DRUG_REFERENCE_QUALIFIER in the table.
    */
    public static final int DRUG_REFERENCE_QUALIFIER_IDX = 11 ;

    /**
              * <p> Rxnorm code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_CODE= "RXNORM_CODE" ;

    /*
    * The index position of the column RXNORM_CODE in the table.
    */
    public static final int RXNORM_CODE_IDX = 12 ;

    /**
              * <p> Rxnorm qualifier.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>3</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String RXNORM_QUALIFIER= "RXNORM_QUALIFIER" ;

    /*
    * The index position of the column RXNORM_QUALIFIER in the table.
    */
    public static final int RXNORM_QUALIFIER_IDX = 13 ;

    /**
              * <p> Long text message.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String GENDER= "Gender" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 14 ;

}
