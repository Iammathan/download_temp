package com.adventnet.charm;

/** <p> Description of the table <code>RecurringServicePlanConfigs</code>.
 *  Column Name and Table Name of  database table  <code>RecurringServicePlanConfigs</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PLAN_CONFIG_ID}
  * </ul>
 */
 
public final class RECURRINGSERVICEPLANCONFIGS
{
    private RECURRINGSERVICEPLANCONFIGS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RecurringServicePlanConfigs" ;
    /**
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PLAN_CONFIG_ID= "PLAN_CONFIG_ID" ;

    /*
    * The index position of the column PLAN_CONFIG_ID in the table.
    */
    public static final int PLAN_CONFIG_ID_IDX = 1 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PLANID= "PLANID" ;

    /*
    * The index position of the column PLANID in the table.
    */
    public static final int PLANID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ATTRIBUTE_ID= "ATTRIBUTE_ID" ;

    /*
    * The index position of the column ATTRIBUTE_ID in the table.
    */
    public static final int ATTRIBUTE_ID_IDX = 3 ;

    /**
              * <p> 0-Disabled, 1-Enabled, 2-Addon.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>1</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>1</code>" , 
       * will be taken.<br>
                                   * Allowed Values are ,<br>
       * <ul>
              * <li><code>0</code></li>
              * <li><code>1</code></li>
              * <li><code>2</code></li>
              * </ul>
                         */
    public static final String STATUS= "STATUS" ;

    /*
    * The index position of the column STATUS in the table.
    */
    public static final int STATUS_IDX = 4 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CHARGE_PER_UNIT= "CHARGE_PER_UNIT" ;

    /*
    * The index position of the column CHARGE_PER_UNIT in the table.
    */
    public static final int CHARGE_PER_UNIT_IDX = 5 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String MAX_LIMIT= "MAX_LIMIT" ;

    /*
    * The index position of the column MAX_LIMIT in the table.
    */
    public static final int MAX_LIMIT_IDX = 6 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIXED_CHARGE= "FIXED_CHARGE" ;

    /*
    * The index position of the column FIXED_CHARGE in the table.
    */
    public static final int FIXED_CHARGE_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIN_THRESHOLD= "MIN_THRESHOLD" ;

    /*
    * The index position of the column MIN_THRESHOLD in the table.
    */
    public static final int MIN_THRESHOLD_IDX = 8 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIN_THRESHOLD_CHARGE= "MIN_THRESHOLD_CHARGE" ;

    /*
    * The index position of the column MIN_THRESHOLD_CHARGE in the table.
    */
    public static final int MIN_THRESHOLD_CHARGE_IDX = 9 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String SHOULD_REDUCE_MIN_THRESHOLD= "SHOULD_REDUCE_MIN_THRESHOLD" ;

    /*
    * The index position of the column SHOULD_REDUCE_MIN_THRESHOLD in the table.
    */
    public static final int SHOULD_REDUCE_MIN_THRESHOLD_IDX = 10 ;

    /**
                            * Data Type of this field is <code>BIGINT</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAX_THRESHOLD= "MAX_THRESHOLD" ;

    /*
    * The index position of the column MAX_THRESHOLD in the table.
    */
    public static final int MAX_THRESHOLD_IDX = 11 ;

    /**
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MAX_THRESHOLD_CHARGE= "MAX_THRESHOLD_CHARGE" ;

    /*
    * The index position of the column MAX_THRESHOLD_CHARGE in the table.
    */
    public static final int MAX_THRESHOLD_CHARGE_IDX = 12 ;

    /**
              * <p> Discount in Amount.If it is in percentage then add a percentage after the number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String DISCOUNT= "DISCOUNT" ;

    /*
    * The index position of the column DISCOUNT in the table.
    */
    public static final int DISCOUNT_IDX = 13 ;

    /**
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>M</code></li>
              * <li><code>Y</code></li>
              * </ul>
                         */
    public static final String BILLING_CYCLE= "BILLING_CYCLE" ;

    /*
    * The index position of the column BILLING_CYCLE in the table.
    */
    public static final int BILLING_CYCLE_IDX = 14 ;

    /**
              * <p> used to store the next cycle when this attribute is to be stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DUE_BY= "DUE_BY" ;

    /*
    * The index position of the column DUE_BY in the table.
    */
    public static final int DUE_BY_IDX = 15 ;

    /**
              * <p> Name of the feature available in the service plan.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONFIG_NAME= "CONFIG_NAME" ;

    /*
    * The index position of the column CONFIG_NAME in the table.
    */
    public static final int CONFIG_NAME_IDX = 16 ;

    /**
              * <p> configured value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONFIG_VALUE= "CONFIG_VALUE" ;

    /*
    * The index position of the column CONFIG_VALUE in the table.
    */
    public static final int CONFIG_VALUE_IDX = 17 ;

    /**
              * <p> Configuration type : functionality , threshold , etc... .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String CONFIG_TYPE= "CONFIG_TYPE" ;

    /*
    * The index position of the column CONFIG_TYPE in the table.
    */
    public static final int CONFIG_TYPE_IDX = 18 ;

    /**
              * <p> Display status : HIDE , SHOW , etc.. .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                     * Default Value is <code>SHOW</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String DISPLAY_STATUS= "DISPLAY_STATUS" ;

    /*
    * The index position of the column DISPLAY_STATUS in the table.
    */
    public static final int DISPLAY_STATUS_IDX = 19 ;

}
