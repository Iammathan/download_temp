package com.adventnet.charm;

/** <p> Description of the table <code>PracticeOtpRequests</code>.
 *  Column Name and Table Name of  database table  <code>PracticeOtpRequests</code> is mapped
 * as constants in this util.</p> 
  patient otp request. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PRACTICE_OTP_REQUEST_ID}
  * </ul>
 */
 
public final class PRACTICEOTPREQUESTS
{
    private PRACTICEOTPREQUESTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticeOtpRequests" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_OTP_REQUEST_ID= "PRACTICE_OTP_REQUEST_ID" ;

    /*
    * The index position of the column PRACTICE_OTP_REQUEST_ID in the table.
    */
    public static final int PRACTICE_OTP_REQUEST_ID_IDX = 1 ;

    /**
              * <p> Identifier of Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PATIENT_ID= "PATIENT_ID" ;

    /*
    * The index position of the column PATIENT_ID in the table.
    */
    public static final int PATIENT_ID_IDX = 2 ;

    /**
              * <p> Mobile phone number.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>30</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String MOBILE= "MOBILE" ;

    /*
    * The index position of the column MOBILE in the table.
    */
    public static final int MOBILE_IDX = 3 ;

    /**
              * <p> To check whether otp is verified by patient or not .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_OTP_VERIFIED= "IS_OTP_VERIFIED" ;

    /*
    * The index position of the column IS_OTP_VERIFIED in the table.
    */
    public static final int IS_OTP_VERIFIED_IDX = 4 ;

    /**
              * <p> Country code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String COUNTRY_CODE= "COUNTRY_CODE" ;

    /*
    * The index position of the column COUNTRY_CODE in the table.
    */
    public static final int COUNTRY_CODE_IDX = 5 ;

    /**
              * <p> Time of creating the Row.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CREATED_TIME= "CREATED_TIME" ;

    /*
    * The index position of the column CREATED_TIME in the table.
    */
    public static final int CREATED_TIME_IDX = 6 ;

    /**
              * <p> OTP value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTP= "OTP" ;

    /*
    * The index position of the column OTP in the table.
    */
    public static final int OTP_IDX = 7 ;

    /**
              * <p> OTP status count.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String OTP_STATUS= "OTP_STATUS" ;

    /*
    * The index position of the column OTP_STATUS in the table.
    */
    public static final int OTP_STATUS_IDX = 8 ;

    /**
              * <p> Time of creating the OTP.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String OTP_SENT_ON= "OTP_SENT_ON" ;

    /*
    * The index position of the column OTP_SENT_ON in the table.
    */
    public static final int OTP_SENT_ON_IDX = 9 ;

}
