package com.adventnet.charm;

/** <p> Description of the table <code>RCMDashboardReports</code>.
 *  Column Name and Table Name of  database table  <code>RCMDashboardReports</code> is mapped
 * as constants in this util.</p> 
  For RCM dashboard reports list. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REPORT_ID}
  * </ul>
 */
 
public final class RCMDASHBOARDREPORTS
{
    private RCMDASHBOARDREPORTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMDashboardReports" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REPORT_ID= "REPORT_ID" ;

    /*
    * The index position of the column REPORT_ID in the table.
    */
    public static final int REPORT_ID_IDX = 1 ;

    /**
              * <p> Name of the report in the RCM dashboard.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>100</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REPORT_NAME= "REPORT_NAME" ;

    /*
    * The index position of the column REPORT_NAME in the table.
    */
    public static final int REPORT_NAME_IDX = 2 ;

    /**
              * <p> Name of the report for the User view.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>255</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String REPORT_TEXT= "REPORT_TEXT" ;

    /*
    * The index position of the column REPORT_TEXT in the table.
    */
    public static final int REPORT_TEXT_IDX = 3 ;

}
