package com.adventnet.charm;

/** <p> Description of the table <code>DXIndexer</code>.
 *  Column Name and Table Name of  database table  <code>DXIndexer</code> is mapped
 * as constants in this util.</p> 
  To convert DX ICD Codes into ML Numbers and vice-versa. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #DX_INDEXER_ID}
  * </ul>
 */
 
public final class DXINDEXER
{
    private DXINDEXER()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "DXIndexer" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String DX_INDEXER_ID= "DX_INDEXER_ID" ;

    /*
    * The index position of the column DX_INDEXER_ID in the table.
    */
    public static final int DX_INDEXER_ID_IDX = 1 ;

    /**
              * <p> Index of the DX.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INDEX= "INDEX" ;

    /*
    * The index position of the column INDEX in the table.
    */
    public static final int INDEX_IDX = 2 ;

    /**
              * <p> Dx Code.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ICD_CODE= "ICD_CODE" ;

    /*
    * The index position of the column ICD_CODE in the table.
    */
    public static final int ICD_CODE_IDX = 3 ;

}
