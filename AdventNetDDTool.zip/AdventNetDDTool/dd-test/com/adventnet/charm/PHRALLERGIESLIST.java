package com.adventnet.charm;

/** <p> Description of the table <code>PHRAllergiesList</code>.
 *  Column Name and Table Name of  database table  <code>PHRAllergiesList</code> is mapped
 * as constants in this util.</p> 
  Allergies list of the Patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ALLERGY_ID}
  * </ul>
 */
 
public final class PHRALLERGIESLIST
{
    private PHRALLERGIESLIST()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PHRAllergiesList" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ALLERGY_ID= "ALLERGY_ID" ;

    /*
    * The index position of the column ALLERGY_ID in the table.
    */
    public static final int ALLERGY_ID_IDX = 1 ;

    /**
              * <p> Name of the allergy.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALLERGY= "ALLERGY" ;

    /*
    * The index position of the column ALLERGY in the table.
    */
    public static final int ALLERGY_IDX = 2 ;

    /**
              * <p> Type of the allergy.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ALLERGY_TYPE= "ALLERGY_TYPE" ;

    /*
    * The index position of the column ALLERGY_TYPE in the table.
    */
    public static final int ALLERGY_TYPE_IDX = 3 ;

}
