package com.adventnet.charm;

/** <p> Description of the table <code>SOAPWidgetEntries</code>.
 *  Column Name and Table Name of  database table  <code>SOAPWidgetEntries</code> is mapped
 * as constants in this util.</p> 
  Table to store entries definition. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ENTRY_ID}
  * </ul>
 */
 
public final class SOAPWIDGETENTRIES
{
    private SOAPWIDGETENTRIES()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "SOAPWidgetEntries" ;
    /**
              * <p> Unique Id for the widgets.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ENTRY_ID= "ENTRY_ID" ;

    /*
    * The index position of the column ENTRY_ID in the table.
    */
    public static final int ENTRY_ID_IDX = 1 ;

    /**
              * <p> For grouping under a widget..</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String WIDGET_ID= "WIDGET_ID" ;

    /*
    * The index position of the column WIDGET_ID in the table.
    */
    public static final int WIDGET_ID_IDX = 2 ;

    /**
              * <p> Entry name. Holds label in case of text field. Question in case of Question with options .</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENTRY_NAME= "ENTRY_NAME" ;

    /*
    * The index position of the column ENTRY_NAME in the table.
    */
    public static final int ENTRY_NAME_IDX = 3 ;

    /**
              * <p> Denotes the type of the entry Question, Question with Options etc.,.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String ENTRY_TYPE= "ENTRY_TYPE" ;

    /*
    * The index position of the column ENTRY_TYPE in the table.
    */
    public static final int ENTRY_TYPE_IDX = 4 ;

    /**
              * <p> For ordering entries.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String ENTRY_POSITION= "ENTRY_POSITION" ;

    /*
    * The index position of the column ENTRY_POSITION in the table.
    */
    public static final int ENTRY_POSITION_IDX = 5 ;

    /**
              * <p> To store the custom text to be rendered while constructing chart note..</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String CUSTOM_TEXT= "CUSTOM_TEXT" ;

    /*
    * The index position of the column CUSTOM_TEXT in the table.
    */
    public static final int CUSTOM_TEXT_IDX = 6 ;

    /**
              * <p> Flag to indicate whether entry has been deleted or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 7 ;

    /**
              * <p> Indicate whether this entry is mandatory or not.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_MANDATORY= "IS_MANDATORY" ;

    /*
    * The index position of the column IS_MANDATORY in the table.
    */
    public static final int IS_MANDATORY_IDX = 8 ;

}
