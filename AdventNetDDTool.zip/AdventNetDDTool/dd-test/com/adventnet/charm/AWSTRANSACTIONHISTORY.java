package com.adventnet.charm;

/** <p> Description of the table <code>AWSTransactionHistory</code>.
 *  Column Name and Table Name of  database table  <code>AWSTransactionHistory</code> is mapped
 * as constants in this util.</p> 
   Contains the transaction details for the practice . <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #AWS_TRANSACTION_HISTORY_ID}
  * </ul>
 */
 
public final class AWSTRANSACTIONHISTORY
{
    private AWSTRANSACTIONHISTORY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AWSTransactionHistory" ;
    /**
              * <p> Primary Key for aws transaction history table.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String AWS_TRANSACTION_HISTORY_ID= "AWS_TRANSACTION_HISTORY_ID" ;

    /*
    * The index position of the column AWS_TRANSACTION_HISTORY_ID in the table.
    */
    public static final int AWS_TRANSACTION_HISTORY_ID_IDX = 1 ;

    /**
              * <p> ID of the member who is logged in.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PERFORMED_MEMBER_ID= "PERFORMED_MEMBER_ID" ;

    /*
    * The index position of the column PERFORMED_MEMBER_ID in the table.
    */
    public static final int PERFORMED_MEMBER_ID_IDX = 2 ;

    /**
              * <p> Timestamp which contains the last request transmitted date and time.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSMITTED_DATE_TIME= "TRANSMITTED_DATE_TIME" ;

    /*
    * The index position of the column TRANSMITTED_DATE_TIME in the table.
    */
    public static final int TRANSMITTED_DATE_TIME_IDX = 3 ;

    /**
              * <p> Name of the function which is accessed by the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>200</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String AWS_FUNCTION_ACCESSED= "AWS_FUNCTION_ACCESSED" ;

    /*
    * The index position of the column AWS_FUNCTION_ACCESSED in the table.
    */
    public static final int AWS_FUNCTION_ACCESSED_IDX = 4 ;

    /**
              * <p> Contains the time taken(in milliseconds) to perform the function.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RESPONSE_TIME_IN_MS= "RESPONSE_TIME_IN_MS" ;

    /*
    * The index position of the column RESPONSE_TIME_IN_MS in the table.
    */
    public static final int RESPONSE_TIME_IN_MS_IDX = 5 ;

    /**
              * <p> Contains the comments or any kind of information that needs to be stored.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String COMMENTS= "COMMENTS" ;

    /*
    * The index position of the column COMMENTS in the table.
    */
    public static final int COMMENTS_IDX = 6 ;

    /**
              * <p> This is used for billing purpose. That is, for a specific patient how much calls are made to aws.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 7 ;

    /**
              * <p> This will contain the insurance card copy id which will be used to get the pointer to the stored file in DFS.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String INSURANCE_CARD_COPY_ID= "INSURANCE_CARD_COPY_ID" ;

    /*
    * The index position of the column INSURANCE_CARD_COPY_ID in the table.
    */
    public static final int INSURANCE_CARD_COPY_ID_IDX = 8 ;

    /**
              * <p> File path of the front or back page.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FILE_PATH= "FILE_PATH" ;

    /*
    * The index position of the column FILE_PATH in the table.
    */
    public static final int FILE_PATH_IDX = 9 ;

    /**
              * <p> Extracted content of the required front or back page. Required, so that AWS call will not go again.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OCR_CONTENT= "OCR_CONTENT" ;

    /*
    * The index position of the column OCR_CONTENT in the table.
    */
    public static final int OCR_CONTENT_IDX = 10 ;

    /**
              * <p> Name of the month in which the aws call is transmitted.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSMITTED_MONTH= "TRANSMITTED_MONTH" ;

    /*
    * The index position of the column TRANSMITTED_MONTH in the table.
    */
    public static final int TRANSMITTED_MONTH_IDX = 11 ;

    /**
              * <p> Year in which the aws call is transmitted.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String TRANSMITTED_YEAR= "TRANSMITTED_YEAR" ;

    /*
    * The index position of the column TRANSMITTED_YEAR in the table.
    */
    public static final int TRANSMITTED_YEAR_IDX = 12 ;

    /**
              * <p> If past cards are called from admin console for training, this is not listed in user settings but stored in userspace.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_ADMIN_ACTION= "IS_ADMIN_ACTION" ;

    /*
    * The index position of the column IS_ADMIN_ACTION in the table.
    */
    public static final int IS_ADMIN_ACTION_IDX = 13 ;

}
