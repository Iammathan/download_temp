package com.adventnet.charm;

/** <p> Description of the table <code>AONESurveyProfile</code>.
 *  Column Name and Table Name of  database table  <code>AONESurveyProfile</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROFILE_ID}
  * </ul>
 */
 
public final class AONESURVEYPROFILE
{
    private AONESURVEYPROFILE()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "AONESurveyProfile" ;
    /**
              * <p> Unique ID for Survey.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROFILE_ID= "PROFILE_ID" ;

    /*
    * The index position of the column PROFILE_ID in the table.
    */
    public static final int PROFILE_ID_IDX = 1 ;

    /**
              * <p> Email id of the user.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String EMAIL_ID= "EMAIL_ID" ;

    /*
    * The index position of the column EMAIL_ID in the table.
    */
    public static final int EMAIL_ID_IDX = 2 ;

    /**
              * <p> To indicate whether this survey person has ChARM Account.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String HAS_ACCOUNT= "HAS_ACCOUNT" ;

    /*
    * The index position of the column HAS_ACCOUNT in the table.
    */
    public static final int HAS_ACCOUNT_IDX = 3 ;

    /**
              * <p> Login id of the user if user have a ChARM account.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LOGIN_ID= "LOGIN_ID" ;

    /*
    * The index position of the column LOGIN_ID in the table.
    */
    public static final int LOGIN_ID_IDX = 4 ;

    /**
              * <p> First Name of the user if he/she does not have a ChARM account.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 5 ;

    /**
              * <p> Login id of the user if user have a ChARM account.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>25</code>. <br>
                                   * This field is nullable. <br>
                                */
    public static final String LAST_NAME= "LAST_NAME" ;

    /*
    * The index position of the column LAST_NAME in the table.
    */
    public static final int LAST_NAME_IDX = 6 ;

    /**
              * <p> Gender of Patient.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>10</code>. <br>
                                   * This field is not nullable. <br>
                                          * Allowed Values are ,<br>
       * <ul>
              * <li><code>male</code></li>
              * <li><code>female</code></li>
              * </ul>
                         */
    public static final String GENDER= "GENDER" ;

    /*
    * The index position of the column GENDER in the table.
    */
    public static final int GENDER_IDX = 7 ;

    /**
              * <p> Date of Birth of Patient.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String DATE_OF_BIRTH= "DATE_OF_BIRTH" ;

    /*
    * The index position of the column DATE_OF_BIRTH in the table.
    */
    public static final int DATE_OF_BIRTH_IDX = 8 ;

}
