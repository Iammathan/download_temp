package com.adventnet.charm;

/** <p> Description of the table <code>ReferringProviderDetails</code>.
 *  Column Name and Table Name of  database table  <code>ReferringProviderDetails</code> is mapped
 * as constants in this util.</p> 
  Referring Provider Details. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #REFERRING_PROVIDER_ID}
  * </ul>
 */
 
public final class REFERRINGPROVIDERDETAILS
{
    private REFERRINGPROVIDERDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "ReferringProviderDetails" ;
    /**
              * <p> Referring provider's Id.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String REFERRING_PROVIDER_ID= "REFERRING_PROVIDER_ID" ;

    /*
    * The index position of the column REFERRING_PROVIDER_ID in the table.
    */
    public static final int REFERRING_PROVIDER_ID_IDX = 1 ;

    /**
              * <p> Type of Provider(DN(Referring provider), DK(Ordering Provider), DQ(Supervising Provider)) for 02/12 cms1500 form.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>2</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_TYPE= "PROVIDER_TYPE" ;

    /*
    * The index position of the column PROVIDER_TYPE in the table.
    */
    public static final int PROVIDER_TYPE_IDX = 2 ;

    /**
              * <p> Id for the patient in this practice.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 3 ;

    /**
              * <p> Speciality of Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String SPECIALITY= "SPECIALITY" ;

    /*
    * The index position of the column SPECIALITY in the table.
    */
    public static final int SPECIALITY_IDX = 4 ;

    /**
              * <p> Name of Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>75</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String PROVIDER_NAME= "PROVIDER_NAME" ;

    /*
    * The index position of the column PROVIDER_NAME in the table.
    */
    public static final int PROVIDER_NAME_IDX = 5 ;

    /**
              * <p> Id for Mapping PostalAddress and ReferringProviderDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String POSTALADDRESS_ID= "POSTALADDRESS_ID" ;

    /*
    * The index position of the column POSTALADDRESS_ID in the table.
    */
    public static final int POSTALADDRESS_ID_IDX = 6 ;

    /**
              * <p> Id for Mapping ContactDetails and ReferringProviderDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 7 ;

    /**
              * <p> NPI number of Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NPI= "NPI" ;

    /*
    * The index position of the column NPI in the table.
    */
    public static final int NPI_IDX = 8 ;

    /**
              * <p> Id Qualifier of Referring Provider.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ID_QUALIFIER= "ID_QUALIFIER" ;

    /*
    * The index position of the column ID_QUALIFIER in the table.
    */
    public static final int ID_QUALIFIER_IDX = 9 ;

    /**
              * <p> Referring Provider Id know as NonNPI.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ID= "ID" ;

    /*
    * The index position of the column ID in the table.
    */
    public static final int ID_IDX = 10 ;

    /**
              * <p> Notes about Providers.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>1000</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String NOTES= "NOTES" ;

    /*
    * The index position of the column NOTES in the table.
    */
    public static final int NOTES_IDX = 11 ;

    /**
              * <p> First Name of the Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 12 ;

    /**
              * <p> Middle Name of the Referring Provider.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIDDLE_NAME= "MIDDLE_NAME" ;

    /*
    * The index position of the column MIDDLE_NAME in the table.
    */
    public static final int MIDDLE_NAME_IDX = 13 ;

    /**
              * <p> Other Payer Primary ID.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>50</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OTHER_PAYER_PRIMARY_IDENTIFIER= "OTHER_PAYER_PRIMARY_IDENTIFIER" ;

    /*
    * The index position of the column OTHER_PAYER_PRIMARY_IDENTIFIER in the table.
    */
    public static final int OTHER_PAYER_PRIMARY_IDENTIFIER_IDX = 14 ;

}
