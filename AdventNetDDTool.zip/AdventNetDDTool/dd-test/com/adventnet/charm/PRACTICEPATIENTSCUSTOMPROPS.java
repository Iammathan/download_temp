package com.adventnet.charm;

/** <p> Description of the table <code>PracticePatientsCustomProps</code>.
 *  Column Name and Table Name of  database table  <code>PracticePatientsCustomProps</code> is mapped
 * as constants in this util.</p> 
  To store custom properties of the Patient. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #PROP_ENTRY}
  * </ul>
 */
 
public final class PRACTICEPATIENTSCUSTOMPROPS
{
    private PRACTICEPATIENTSCUSTOMPROPS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "PracticePatientsCustomProps" ;
    /**
              * <p> Unique identifier for Patient Custom Property.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROP_ENTRY= "PROP_ENTRY" ;

    /*
    * The index position of the column PROP_ENTRY in the table.
    */
    public static final int PROP_ENTRY_IDX = 1 ;

    /**
              * <p> Unique identifier for the Patient.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PRACTICE_PATIENT_ID= "PRACTICE_PATIENT_ID" ;

    /*
    * The index position of the column PRACTICE_PATIENT_ID in the table.
    */
    public static final int PRACTICE_PATIENT_ID_IDX = 2 ;

    /**
              * <p> Property Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROP_NAME= "PROP_NAME" ;

    /*
    * The index position of the column PROP_NAME in the table.
    */
    public static final int PROP_NAME_IDX = 3 ;

    /**
              * <p> Property Value.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROP_VALUE= "PROP_VALUE" ;

    /*
    * The index position of the column PROP_VALUE in the table.
    */
    public static final int PROP_VALUE_IDX = 4 ;

}
