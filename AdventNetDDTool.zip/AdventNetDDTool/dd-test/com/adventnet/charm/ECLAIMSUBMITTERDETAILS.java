package com.adventnet.charm;

/** <p> Description of the table <code>EClaimSubmitterDetails</code>.
 *  Column Name and Table Name of  database table  <code>EClaimSubmitterDetails</code> is mapped
 * as constants in this util.</p> 
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #ECLAIM_SUBMITTER_ID}
  * </ul>
 */
 
public final class ECLAIMSUBMITTERDETAILS
{
    private ECLAIMSUBMITTERDETAILS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "EClaimSubmitterDetails" ;
    /**
              * <p> Unique Identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ECLAIM_SUBMITTER_ID= "ECLAIM_SUBMITTER_ID" ;

    /*
    * The index position of the column ECLAIM_SUBMITTER_ID in the table.
    */
    public static final int ECLAIM_SUBMITTER_ID_IDX = 1 ;

    /**
              * <p> Name of the entity.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FULL_NAME= "FULL_NAME" ;

    /*
    * The index position of the column FULL_NAME in the table.
    */
    public static final int FULL_NAME_IDX = 2 ;

    /**
              * <p> Last Name if entity is Individual Else Organization Name.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>60</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String LAST_OR_ORG_NAME= "LAST_OR_ORG_NAME" ;

    /*
    * The index position of the column LAST_OR_ORG_NAME in the table.
    */
    public static final int LAST_OR_ORG_NAME_IDX = 3 ;

    /**
              * <p> First Name of the entity, if the entity is an Individual.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String FIRST_NAME= "FIRST_NAME" ;

    /*
    * The index position of the column FIRST_NAME in the table.
    */
    public static final int FIRST_NAME_IDX = 4 ;

    /**
              * <p> Middle Name of the entity, if the entity is an Individual.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>35</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String MIDDLE_NAME= "MIDDLE_NAME" ;

    /*
    * The index position of the column MIDDLE_NAME in the table.
    */
    public static final int MIDDLE_NAME_IDX = 5 ;

    /**
              * <p> claim submitter's ETIN value  provided by Optum.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>15</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ETIN_VALUE= "ETIN_VALUE" ;

    /*
    * The index position of the column ETIN_VALUE in the table.
    */
    public static final int ETIN_VALUE_IDX = 6 ;

    /**
              * <p> Stores whether the entity is Individual or Organization.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>true</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_ORGANIZATION= "IS_ORGANIZATION" ;

    /*
    * The index position of the column IS_ORGANIZATION in the table.
    */
    public static final int IS_ORGANIZATION_IDX = 7 ;

    /**
              * <p> Stores whether It is from RCM or EHR.</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_FROM_RCM= "IS_FROM_RCM" ;

    /*
    * The index position of the column IS_FROM_RCM in the table.
    */
    public static final int IS_FROM_RCM_IDX = 8 ;

    /**
              * <p> DELETE Flag .</p>
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 9 ;

    /**
              * <p> PK of ContactDetails table, where claim submitter's contact details are stored.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String CONTACTDETAILS_ID= "CONTACTDETAILS_ID" ;

    /*
    * The index position of the column CONTACTDETAILS_ID in the table.
    */
    public static final int CONTACTDETAILS_ID_IDX = 10 ;

    /**
              * <p> PK of rendering provider table (RCM), service facility (RCM), Practice members list MEMBER_ID, Facility list (FACILITY_ID).</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String PROVIDER_ID= "PROVIDER_ID" ;

    /*
    * The index position of the column PROVIDER_ID in the table.
    */
    public static final int PROVIDER_ID_IDX = 11 ;

}
