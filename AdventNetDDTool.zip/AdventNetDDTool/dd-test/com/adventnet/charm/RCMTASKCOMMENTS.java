package com.adventnet.charm;

/** <p> Description of the table <code>RCMTaskComments</code>.
 *  Column Name and Table Name of  database table  <code>RCMTaskComments</code> is mapped
 * as constants in this util.</p> 
  Comments for task. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_TASK_COM_ID}
  * </ul>
 */
 
public final class RCMTASKCOMMENTS
{
    private RCMTASKCOMMENTS()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMTaskComments" ;
    /**
              * <p> Primary Key.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_TASK_COM_ID= "RCM_TASK_COM_ID" ;

    /*
    * The index position of the column RCM_TASK_COM_ID in the table.
    */
    public static final int RCM_TASK_COM_ID_IDX = 1 ;

    /**
              * <p> RCMTask.RCM_TASK_ID.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_TASK_ID= "RCM_TASK_ID" ;

    /*
    * The index position of the column RCM_TASK_ID in the table.
    */
    public static final int RCM_TASK_ID_IDX = 2 ;

    /**
                            * Data Type of this field is <code>DATETIME</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_DATE= "ADDED_DATE" ;

    /*
    * The index position of the column ADDED_DATE in the table.
    */
    public static final int ADDED_DATE_IDX = 3 ;

    /**
              * <p> Name of RCM Member who created the task.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>150</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String ADDED_MEMBER_NAME= "ADDED_MEMBER_NAME" ;

    /*
    * The index position of the column ADDED_MEMBER_NAME in the table.
    */
    public static final int ADDED_MEMBER_NAME_IDX = 4 ;

    /**
              * <p> ID of RCM Member who created the task.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String ADDED_MEMBER_ID= "ADDED_MEMBER_ID" ;

    /*
    * The index position of the column ADDED_MEMBER_ID in the table.
    */
    public static final int ADDED_MEMBER_ID_IDX = 5 ;

    /**
              * <p> Comment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String OPERATION_TYPE= "OPERATION_TYPE" ;

    /*
    * The index position of the column OPERATION_TYPE in the table.
    */
    public static final int OPERATION_TYPE_IDX = 6 ;

    /**
              * <p> Comment.</p>
                            * Data Type of this field is <code>CHAR</code>. <br>
                     * Maximum length of this field value is <code>300</code>. <br>
                                   * This field is not nullable. <br>
                                */
    public static final String COMMENT= "COMMENT" ;

    /*
    * The index position of the column COMMENT in the table.
    */
    public static final int COMMENT_IDX = 7 ;

    /**
                            * Data Type of this field is <code>BOOLEAN</code>. <br>
                            * Default Value is <code>false</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>false</code>" , 
       * will be taken.<br>
                         */
    public static final String IS_DELETED= "IS_DELETED" ;

    /*
    * The index position of the column IS_DELETED in the table.
    */
    public static final int IS_DELETED_IDX = 8 ;

}
