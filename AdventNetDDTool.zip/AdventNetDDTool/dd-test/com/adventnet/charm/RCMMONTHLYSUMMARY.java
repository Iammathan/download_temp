package com.adventnet.charm;

/** <p> Description of the table <code>RCMMonthlySummary</code>.
 *  Column Name and Table Name of  database table  <code>RCMMonthlySummary</code> is mapped
 * as constants in this util.</p> 
  Persists static monthly summary for rendering RCM report. <br>
   * 
  * Primary Key for this definition is  <br>
  <ul>
  * <li> {@link #RCM_MON_SUM_ID}
  * </ul>
 */
 
public final class RCMMONTHLYSUMMARY
{
    private RCMMONTHLYSUMMARY()
    {
    }
   
    /** Constant denoting the Table Name of this definition.
     */
    public static final String TABLE = "RCMMonthlySummary" ;
    /**
              * <p> Unique identifier.</p>
                            * This column is an Primary Key for this Table definition. <br>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is not nullable. <br>
                                */
    public static final String RCM_MON_SUM_ID= "RCM_MON_SUM_ID" ;

    /*
    * The index position of the column RCM_MON_SUM_ID in the table.
    */
    public static final int RCM_MON_SUM_ID_IDX = 1 ;

    /**
              * <p> Report Month.</p>
                            * Data Type of this field is <code>DATE</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String RERORT_MONTH= "RERORT_MONTH" ;

    /*
    * The index position of the column RERORT_MONTH in the table.
    */
    public static final int RERORT_MONTH_IDX = 2 ;

    /**
              * <p> Billing Provider Id from RCMClaimProviderDetails.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String BILLING_PROVIDER_ID= "BILLING_PROVIDER_ID" ;

    /*
    * The index position of the column BILLING_PROVIDER_ID in the table.
    */
    public static final int BILLING_PROVIDER_ID_IDX = 3 ;

    /**
              * <p> Service Facility Id from ServiceFacilities.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String FACILITY_ID= "FACILITY_ID" ;

    /*
    * The index position of the column FACILITY_ID in the table.
    */
    public static final int FACILITY_ID_IDX = 4 ;

    /**
              * <p> Consulting Provider Id from RenderingProviders.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String CONSULTING_PROVIDER_ID= "CONSULTING_PROVIDER_ID" ;

    /*
    * The index position of the column CONSULTING_PROVIDER_ID in the table.
    */
    public static final int CONSULTING_PROVIDER_ID_IDX = 5 ;

    /**
              * <p> Count of the claims generated in this month.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String GENERATED_CLAIMS_COUNT= "GENERATED_CLAIMS_COUNT" ;

    /*
    * The index position of the column GENERATED_CLAIMS_COUNT in the table.
    */
    public static final int GENERATED_CLAIMS_COUNT_IDX = 6 ;

    /**
              * <p> Amount of the claims generated in this month.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String GENERATED_CLAIMS_AMOUNT= "GENERATED_CLAIMS_AMOUNT" ;

    /*
    * The index position of the column GENERATED_CLAIMS_AMOUNT in the table.
    */
    public static final int GENERATED_CLAIMS_AMOUNT_IDX = 7 ;

    /**
              * <p> Count of the claims denied in this month's claims.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String DENIED_CLAIMS_COUNT= "DENIED_CLAIMS_COUNT" ;

    /*
    * The index position of the column DENIED_CLAIMS_COUNT in the table.
    */
    public static final int DENIED_CLAIMS_COUNT_IDX = 8 ;

    /**
              * <p> Amount of the claims denied in this month's claims.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String DENIED_CLAIMS_AMOUNT= "DENIED_CLAIMS_AMOUNT" ;

    /*
    * The index position of the column DENIED_CLAIMS_AMOUNT in the table.
    */
    public static final int DENIED_CLAIMS_AMOUNT_IDX = 9 ;

    /**
              * <p> Count of the claims rejected in this month's claims.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String REJECTED_CLAIMS_COUNT= "REJECTED_CLAIMS_COUNT" ;

    /*
    * The index position of the column REJECTED_CLAIMS_COUNT in the table.
    */
    public static final int REJECTED_CLAIMS_COUNT_IDX = 10 ;

    /**
              * <p> Amount of the claims rejected in this month's claims.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String REJECTED_CLAIMS_AMOUNT= "REJECTED_CLAIMS_AMOUNT" ;

    /*
    * The index position of the column REJECTED_CLAIMS_AMOUNT in the table.
    */
    public static final int REJECTED_CLAIMS_AMOUNT_IDX = 11 ;

    /**
              * <p> Count of the claims being paid in this month.</p>
                            * Data Type of this field is <code>INTEGER</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String PAID_CLAIMS_COUNT= "PAID_CLAIMS_COUNT" ;

    /*
    * The index position of the column PAID_CLAIMS_COUNT in the table.
    */
    public static final int PAID_CLAIMS_COUNT_IDX = 12 ;

    /**
              * <p> Amount received in this month.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String RECEIVED_CLAIMS_AMOUNT= "RECEIVED_CLAIMS_AMOUNT" ;

    /*
    * The index position of the column RECEIVED_CLAIMS_AMOUNT in the table.
    */
    public static final int RECEIVED_CLAIMS_AMOUNT_IDX = 13 ;

    /**
              * <p> Amount received through patient.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String PATIENT_PAYMENTS= "PATIENT_PAYMENTS" ;

    /*
    * The index position of the column PATIENT_PAYMENTS in the table.
    */
    public static final int PATIENT_PAYMENTS_IDX = 14 ;

    /**
              * <p> Amount received through payer.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String PAYER_PAYMENTS= "PAYER_PAYMENTS" ;

    /*
    * The index position of the column PAYER_PAYMENTS in the table.
    */
    public static final int PAYER_PAYMENTS_IDX = 15 ;

    /**
              * <p> Adjustments made in this month.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String ADJUSTMENTS= "ADJUSTMENTS" ;

    /*
    * The index position of the column ADJUSTMENTS in the table.
    */
    public static final int ADJUSTMENTS_IDX = 16 ;

    /**
              * <p> Last updated time of the counts except receivables.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_UPDATED_TIME= "LAST_UPDATED_TIME" ;

    /*
    * The index position of the column LAST_UPDATED_TIME in the table.
    */
    public static final int LAST_UPDATED_TIME_IDX = 17 ;

    /**
              * <p> Outstanding amount as on the end of the month.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String RECEIVABLES_AMOUNT= "RECEIVABLES_AMOUNT" ;

    /*
    * The index position of the column RECEIVABLES_AMOUNT in the table.
    */
    public static final int RECEIVABLES_AMOUNT_IDX = 18 ;

    /**
              * <p> Last update on receivables amount.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String LAST_REC_UPDATED_TIME= "LAST_REC_UPDATED_TIME" ;

    /*
    * The index position of the column LAST_REC_UPDATED_TIME in the table.
    */
    public static final int LAST_REC_UPDATED_TIME_IDX = 19 ;

    /**
              * <p> Claim Summary Write off Amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String WRITE_OFF= "WRITE_OFF" ;

    /*
    * The index position of the column WRITE_OFF in the table.
    */
    public static final int WRITE_OFF_IDX = 20 ;

    /**
              * <p> patient resposibility amount.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                            * This field is not nullable. <br>
                                */
    public static final String PAT_RESP_AMT= "PAT_RESP_AMT" ;

    /*
    * The index position of the column PAT_RESP_AMT in the table.
    */
    public static final int PAT_RESP_AMT_IDX = 21 ;

    /**
              * <p> Total denied  amount for the claim.</p>
                            * Data Type of this field is <code>DOUBLE</code>. <br>
                            * Default Value is <code>0</code>. <br>
                     * This field is not nullable. If value for field is not set default value "<code>0</code>" , 
       * will be taken.<br>
                         */
    public static final String DENIAL_AMOUNT= "DENIAL_AMOUNT" ;

    /*
    * The index position of the column DENIAL_AMOUNT in the table.
    */
    public static final int DENIAL_AMOUNT_IDX = 22 ;

    /**
              * <p> PracticeId of MBP for Monthly Summary.</p>
                            * Data Type of this field is <code>BIGINT</code>. <br>
                                          * This field is nullable. <br>
                                */
    public static final String MBP_ACCOUNT_ID= "MBP_ACCOUNT_ID" ;

    /*
    * The index position of the column MBP_ACCOUNT_ID in the table.
    */
    public static final int MBP_ACCOUNT_ID_IDX = 23 ;

}
