#!/usr/bin/env bash

echo "========== PROCESS STARTED ========"
#This file should run under build location ex. /AdventNet
#arg 1 should be DD build location  ex.  <LOCATION>/AdventNetDDTool
#JAVA should be set in global path
build_dir=./Sas/tomcat/webapps/ROOT
#dd_file_dir=$build_dir/WEB-INF/conf/Charm/data-dictionary.xml
dd_file_dir=/Users/mathan-1403/Work/git-repo/product_package/conf/Charm/data-dictionary.xml
#dd_file_dir=$2
ddtool_zip_dir=$1
echo "====> Current build directory :$build_dir"

export CLASSPATH=.:$ddtool_zip_dir/build_tools/lib/*
echo "====>>Setting CLASS PATH as :$CLASSPATH"

/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/bin/java   test.DDReader -dd $dd_file_dir -template $ddtool_zip_dir/build_tools/conf/ClassTemplate.vtl   -outDir dd-test/

echo "====>>dd file converted as java and saved under folder :$ddtool_zip_dir/dd-test"

/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/bin/javac -d  . ./dd-test/com/adventnet/charm/*.java

echo "====>>All  java file has compiled"

jar -uvf  $build_dir/WEB-INF/lib/charmDD.jar com/

echo "====>>updated dd java class into jar under dir :$build_dir/WEB-INF/lib/charmDD.jar"

echo "========== PROCESS COMPLETED ========"

